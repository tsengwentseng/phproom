<?php header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");header("Pragma: no-cache");header("Expires: 0");ini_set('session.gc_maxlifetime',7*60*60);session_set_cookie_params(0);if(session_status()==PHP_SESSION_NONE){session_start();}require_once 'config.php';define('SESSION_TIMEOUT_FRONT',360);define('SESSION_TIMEOUT_ADMIN',120);define('LOGIN_MAX_ATTEMPTS',5);define('LOGIN_ATTEMPTS_WINDOW',60);define('LOGIN_LOCKOUT_TIME',300);define('PASSWORD_MIN_LENGTH',6);function handleLogout(){if(!isset($_GET['logout'])){return;}$type=$_GET['logout'];$closeIframe=isset($_GET['close'])&&$_GET['close']==='1';$sourcePage=$_GET['source']?? '';$originalRole=$_SESSION['front_role']?? '';logoutUser($type);if($closeIframe){ ?>
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"><title></title></head>
        <body>
        <script>
        (function() {
            try {
                if (window.parent && window.parent !== window && typeof window.parent.closeWindow === 'function') {
                    var winId = '';
                    var source = '<?php echo htmlspecialchars($sourcePage); ?>';
                    if (source === 'handover') {
                        winId = 'handoverWindow';
                    } else if (source === 'sys_query') {
                        winId = 'reportWindow';
                    } else if (source === 'admin') {
                        winId = 'adminWindow';
                    }
                    if (!winId) {
                        var referrer = document.referrer || '';
                        if (referrer.indexOf('handover.php') !== -1) {
                            winId = 'handoverWindow';
                        } else if (referrer.indexOf('sys_query.php') !== -1) {
                            winId = 'reportWindow';
                        } else if (referrer.indexOf('admin.php') !== -1) {
                            winId = 'adminWindow';
                        }
                    }
                    if (winId) {
                        window.parent.closeWindow(winId, true);
                        return;
                    }
                }
            } catch(e) {}
            setTimeout(function() {
                window.location.href = '../index.php';
            }, 300);
        })();
        </script>
        </body>
        </html>
        <?php exit;}if($type==='admin'){if($originalRole==='front'){header('Location: room.php');}else{header('Location: ../index.php');}}else{header('Location: ../index.php');}exit;}function logoutUser($type='all'){if($type==='admin'){unset($_SESSION['admin_loggedin']);unset($_SESSION['admin_user_id']);unset($_SESSION['admin_username']);unset($_SESSION['admin_name']);unset($_SESSION['admin_role']);unset($_SESSION['admin_timeout_start']);}else if($type==='front'){unset($_SESSION['front_loggedin']);unset($_SESSION['front_user_id']);unset($_SESSION['front_username']);unset($_SESSION['front_name']);unset($_SESSION['front_role']);unset($_SESSION['timeout_start']);}else if($type==='all'){unset($_SESSION['admin_loggedin']);unset($_SESSION['admin_user_id']);unset($_SESSION['admin_username']);unset($_SESSION['admin_name']);unset($_SESSION['admin_role']);unset($_SESSION['front_loggedin']);unset($_SESSION['front_user_id']);unset($_SESSION['front_username']);unset($_SESSION['front_name']);unset($_SESSION['front_role']);unset($_SESSION['admin_timeout_start']);unset($_SESSION['timeout_start']);unset($_SESSION['timeout_message']);unset($_SESSION['loggedin']);}}handleLogout();function checkLoginLockout($type='admin'){if(!isset($_SESSION['login_attempts'])){$_SESSION['login_attempts']=[];}if(!isset($_SESSION['login_attempts'][$type])){$_SESSION['login_attempts'][$type]=['count'=>0,'first_attempt'=>0,'lockout_until'=>0];}$now=time();$lockout_data=$_SESSION['login_attempts'][$type];if($lockout_data['lockout_until']>$now){$remaining=$lockout_data['lockout_until']-$now;return['locked'=>true,'remaining'=>$remaining,'remaining_minutes'=>ceil($remaining/60)];}if($lockout_data['lockout_until']>0&&$lockout_data['lockout_until']<=$now){$_SESSION['login_attempts'][$type]=['count'=>0,'first_attempt'=>0,'lockout_until'=>0];}if($lockout_data['first_attempt']>0&&($now-$lockout_data['first_attempt'])>LOGIN_ATTEMPTS_WINDOW){$_SESSION['login_attempts'][$type]=['count'=>0,'first_attempt'=>0,'lockout_until'=>0];}return['locked'=>false,'remaining'=>0,'remaining_minutes'=>0];}function recordFailedLoginAttempt(string $type='admin'):void{$now=time();$_SESSION['login_attempts']??=[];$_SESSION['login_attempts'][$type]??=['count'=>0,'first_attempt'=>0,'lockout_until'=>0];$attempts=&$_SESSION['login_attempts'][$type];if($attempts['count']===0){$attempts['first_attempt']=$now;}$attempts['count']++;if($attempts['count']>=LOGIN_MAX_ATTEMPTS&&($now-$attempts['first_attempt'])<=LOGIN_ATTEMPTS_WINDOW){$attempts['lockout_until']=$now+LOGIN_LOCKOUT_TIME;}}function resetLoginAttempts(string $type='admin'):void{if(isset($_SESSION['login_attempts'][$type])){$_SESSION['login_attempts'][$type]=['count'=>0,'first_attempt'=>0,'lockout_until'=>0];}}function checkSessionTimeout(int $minutes=SESSION_TIMEOUT_FRONT,?string $type=null):bool{$timeoutKey=$type!==null?"{$type}_timeout_start":'timeout_start';$_SESSION[$timeoutKey]??=time();if(time()-$_SESSION[$timeoutKey]>$minutes*60){$timeoutMessage=match($type){'admin'=>"管理员会话已超时，请重新登录",'front'=>"前台会话已超时，请重新登录",default=>"会话已超时，请重新登录"};if($type!==null){unset($_SESSION["{$type}_loggedin"],$_SESSION[$timeoutKey]);$_SESSION['timeout_message']=$timeoutMessage;return false;}else{session_unset();session_destroy();session_start();$_SESSION['timeout_start']=time();$_SESSION['timeout_message']=$timeoutMessage;return false;}}$_SESSION[$timeoutKey]=time();return true;}function isAuthenticated(string $type='admin',int $timeout=SESSION_TIMEOUT_ADMIN):bool{$validSession=match($type){'admin'=>checkSessionTimeout($timeout,'admin'),default=>checkSessionTimeout($timeout)};if(!$validSession){return false;}if(!isset($_SESSION["{$type}_loggedin"])){return false;}$_SESSION['loggedin']=true;return true;}function authenticateFront(string $username,string $password):array{global $conn;$result=['success'=>false,'message'=>'','user_role'=>''];$password=mb_substr($password,0,20);$lockout_status=checkLoginLockout('front');if($lockout_status['locked']){$result['message']="由于多次密码错误，账户已被临时锁定，请在{$lockout_status['remaining_minutes']}分钟后重试。";return $result;}try{$user=getUserByUsername($username);if(!$user){recordFailedLoginAttempt('front');$result['message']="用户名或密码错误";return $result;}if(!$user['is_enabled']){$result['message']="该账户已被停用，请联系管理员";return $result;}if(!password_verify($password,$user['password'])){recordFailedLoginAttempt('front');$result['message']="用户名或密码错误";return $result;}session_regenerate_id(true);$_SESSION['front_loggedin']=true;$_SESSION['front_user_id']=$user['id'];$_SESSION['front_username']=$user['username'];$_SESSION['front_name']=$user['name'];$_SESSION['front_role']=$user['role'];$_SESSION['timeout_start']=time();$_SESSION['loggedin']=true;if($user['role']==='admin'){$_SESSION['admin_loggedin']=true;$_SESSION['admin_user_id']=$user['id'];$_SESSION['admin_username']=$user['username'];$_SESSION['admin_name']=$user['name'];$_SESSION['admin_role']=$user['role'];$_SESSION['admin_timeout_start']=time();resetLoginAttempts('admin');}resetLoginAttempts('front');$result['success']=true;$result['user_role']=$user['role'];return $result;}catch(Exception $e){$result['message']="系统错误，请稍后再试";}return $result;}function getUserByUsername(string $username):?array{global $conn;try{$stmt=$conn->prepare("SELECT id, username, name, password, role, is_enabled, is_deleted FROM system_users WHERE LOWER(username) = LOWER(?) AND is_deleted = 0 LIMIT 1");$stmt->bind_param('s',$username);$stmt->execute();$result=$stmt->get_result();if($result->num_rows>0){return $result->fetch_assoc();}return null;}catch(Exception $e){return null;}}function validatePassword(string $password):array{$errors=[];if(mb_strlen($password)<PASSWORD_MIN_LENGTH){$errors[]="密码长度不能少于".PASSWORD_MIN_LENGTH."位";}return['valid'=>empty($errors),'errors'=>$errors];}function authenticateAdmin(string $username,string $password):array{global $conn;$result=['success'=>false,'message'=>''];$password=mb_substr($password,0,20);$lockout_status=checkLoginLockout('admin');if($lockout_status['locked']){$result['message']="由于多次密码错误，账户已被临时锁定，请在{$lockout_status['remaining_minutes']}分钟后重试。";return $result;}try{$user=getUserByUsername($username);if(!$user){recordFailedLoginAttempt('admin');$result['message']="用户名或密码错误";return $result;}if($user['role']!=='admin'){$result['message']="权限不足，该账户无法登录管理后台";return $result;}if(!$user['is_enabled']){$result['message']="该账户已被停用，请联系管理员";return $result;}if(password_verify($password,$user['password'])){session_regenerate_id(true);$_SESSION['admin_loggedin']=true;$_SESSION['admin_user_id']=$user['id'];$_SESSION['admin_username']=$user['username'];$_SESSION['admin_name']=$user['name'];$_SESSION['admin_role']=$user['role'];$_SESSION['admin_timeout_start']=time();resetLoginAttempts('admin');$result['success']=true;return $result;}recordFailedLoginAttempt('admin');$result['message']="用户名或密码错误";}catch(Exception $e){$result['message']="系统错误，请稍后再试";}return $result;}function displayAdminLoginForm($title='管理员登录',$redirectUrl=null){$lockout_status=checkLoginLockout('admin');$isLocked=$lockout_status['locked'];$error='';if(isset($_SESSION['timeout_message'])){$error=$_SESSION['timeout_message'];unset($_SESSION['timeout_message']);}if($isLocked){$error="由于多次密码错误，账户已被临时锁定，请在{$lockout_status['remaining_minutes']}分钟后重试。";}$current_url=$redirectUrl ?? $_SERVER['PHP_SELF'];$redirect_param=(!empty($_SERVER['QUERY_STRING']))?"?{$_SERVER['QUERY_STRING']}":''; ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title><?=htmlspecialchars($title)?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="/asset/lib/css/bootstrap.min.css" rel="stylesheet">
        <link href="/asset/lib/css/all.min.css" rel="stylesheet">
        <script src="/asset/core.js"></script>                
        <style>
            .login-container { 
                min-height: 100vh; 
                display: flex; 
                align-items: flex-start; 
                justify-content: center; 
                padding-top: 20vh;
                background-color: #f8f9fa; 
            }
            .login-card { 
                width: 100%; 
                max-width: 350px; 
                border-radius: 8px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="card login-card">
                <div class="card-body p-4">
                    <h5 class="card-title text-center mb-4"><?=htmlspecialchars($title)?></h5>
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
                    <?php endif; ?>
                    <form method="post" action="<?=$current_url.$redirect_param?>">
                        <div class="form-group">
                            <label for="admin_username">用户名</label>
                            <input type="text" class="form-control" id="admin_username" name="admin_username" 
                                   placeholder="请输入用户名" required autofocus 
                                   autocomplete="username" <?=$isLocked?'disabled':''?>>
                        </div>
                        <div class="form-group">
                            <label for="admin_password">密码</label>
                            <input type="password" class="form-control" id="admin_password" name="admin_password" 
                                   placeholder="请输入密码" required 
                                   autocomplete="current-password" <?=$isLocked?'disabled':''?>>
                        </div>
                        <input type="hidden" name="admin_login_submit" value="1">
                        <button type="submit" class="btn btn-primary btn-block mb-3" <?=$isLocked?'disabled':''?>>
                            登录
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php exit();}function requireAdminAuthentication(string $title='管理员登录',int $timeout=SESSION_TIMEOUT_ADMIN):void{if(isset($_SESSION['admin_loggedin'])){$validSession=checkSessionTimeout($timeout,'admin');if($validSession){return;}}if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['admin_login_submit'])){$inputUsername=trim($_POST['admin_username']?? '');$inputPassword=trim($_POST['admin_password']?? '');if(empty($inputUsername)||empty($inputPassword)){$_SESSION['timeout_message']="用户名和密码不能为空";displayAdminLoginForm($title,null);return;}$auth_result=authenticateAdmin($inputUsername,$inputPassword);if($auth_result['success']){$redirect=$_SERVER['PHP_SELF'];if(!empty($_SERVER['QUERY_STRING'])){$redirect.="?{$_SERVER['QUERY_STRING']}";}header("Location: $redirect");exit();}else{$_SESSION['timeout_message']=$auth_result['message'];displayAdminLoginForm($title,null);}}displayAdminLoginForm($title,null);}function requirePageAccess(string $requiredRole='any',int $timeout=SESSION_TIMEOUT_FRONT,string $pageTitle='系统页面'):void{if(!isAuthenticated('front',$timeout)){header("Location: ../index.php");exit();}if($requiredRole==='admin'){$currentRole=$_SESSION['front_role']?? '';if($currentRole==='admin'){if(isAuthenticated('admin',$timeout)){return;}requireAdminAuthentication($pageTitle.' - 登录',$timeout);}else{requireAdminAuthentication($pageTitle.' - 登录',$timeout);}}}function displayFrontLoginForm($title='系统登录',$redirectUrl=null){$lockout_status=checkLoginLockout('front');$isLocked=$lockout_status['locked'];$error='';if(isset($_SESSION['timeout_message'])){$error=$_SESSION['timeout_message'];unset($_SESSION['timeout_message']);}if($isLocked){$error="由于多次密码错误，账户已被临时锁定，请在{$lockout_status['remaining_minutes']}分钟后重试。";}$current_url=$redirectUrl ?? $_SERVER['PHP_SELF'];$redirect_param=(!empty($_SERVER['QUERY_STRING']))?"?{$_SERVER['QUERY_STRING']}":''; ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title><?=htmlspecialchars($title)?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="/asset/lib/css/bootstrap.min.css" rel="stylesheet">
        <link href="/asset/lib/css/all.min.css" rel="stylesheet">
        <script src="/asset/core.js"></script>
        <style>
            .login-container { 
                min-height: 100vh; 
                display: flex; 
                align-items: flex-start; 
                justify-content: center; 
                padding-top: 20vh;
                background-color: #f8f9fa; 
            }
            .login-card { 
                width: 100%; 
                max-width: 350px; 
                border-radius: 8px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="card login-card">
                <div class="card-body p-4">
                    <h5 class="card-title text-center mb-4"><?=htmlspecialchars($title)?></h5>
                    <?php if(!empty($error)): ?>
                        <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
                    <?php endif; ?>
                    <form method="post" action="<?=$current_url.$redirect_param?>">
                        <div class="form-group">
                            <label for="username">用户名</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   placeholder="请输入用户名" required autofocus 
                                   autocomplete="username" <?=$isLocked?'disabled':''?>>
                        </div>
                        <div class="form-group">
                            <label for="password">密码</label>
                            <input type="password" class="form-control" id="password" name="password" 
                                   placeholder="请输入密码" required 
                                   autocomplete="current-password" <?=$isLocked?'disabled':''?>>
                        </div>
                        <input type="hidden" name="login_submit" value="1">
                        <button type="submit" class="btn btn-primary btn-block mb-3" <?=$isLocked?'disabled':''?>>
                            登录
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php exit();}function requireFrontAuthentication(string $title='系统登录',int $timeout=SESSION_TIMEOUT_FRONT,?string $redirectUrl=null):void{if(isAuthenticated('front',$timeout)){return;}if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['login_submit'])){$username=trim($_POST['username']?? '');$password=trim($_POST['password']?? '');if(empty($username)||empty($password)){$_SESSION['timeout_message']="用户名和密码不能为空";displayFrontLoginForm($title,$redirectUrl);return;}$auth_result=authenticateFront($username,$password);if($auth_result['success']){$redirect=$redirectUrl ?? $_SERVER['PHP_SELF'];if($redirectUrl===null&&!empty($_SERVER['QUERY_STRING'])){$redirect.="?{$_SERVER['QUERY_STRING']}";}header("Location: $redirect");exit();}else{$_SESSION['timeout_message']=$auth_result['message'];displayFrontLoginForm($title,$redirectUrl);}}displayFrontLoginForm($title,$redirectUrl);}