<?php
declare(strict_types=1);
const ALLOW_COUPON_IN_IDLE = 0;
error_reporting(0);
ini_set('display_errors', '0');
require_once '../config/config.php';
$SCENE_ROOM_NAME = '房间'; 
$scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'");
if ($scene_stmt) {
    $scene_stmt->execute();
    $scene_result = $scene_stmt->get_result();
    if ($scene_result && $scene_row = $scene_result->fetch_assoc()) {
        $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间';
    }
    $scene_stmt->close();
}
if (!function_exists('getAmountTwoDecimals')) {
    function getAmountTwoDecimals(float $value): float {
        $cents = (int)floor(floatval($value) * 100 + 0.0001);
        return $cents / 100;
    }
}
function validateAccessCode($accessCode, $roomId, $conn) {
    $stmt = $conn->prepare("
        SELECT rac.id, rac.audio_muted, rac.audio_updated_at, rac.qr_audio,
               rac.verification_time, rac.qr_verification, r.type as room_type
        FROM room_access_codes rac
        INNER JOIN rooms r ON rac.room_id = r.id
        WHERE rac.access_code = ? AND rac.room_id = ? AND rac.is_enabled = 1 AND r.is_enabled = 1 AND r.is_deleted = 0
    ");
    $stmt->bind_param('si', $accessCode, $roomId);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        throw new Exception('访问码无效或已被停用');
    }
    return $result->fetch_assoc();
}
function getIdleServiceConfig($conn) {
    $qrIdleServiceEnabled = null;
    $idleServiceStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'qr_idle_service_enabled'");
    $idleServiceStmt->execute();
    $idleServiceResult = $idleServiceStmt->get_result();
    if ($row = $idleServiceResult->fetch_assoc()) {
        $qrIdleServiceEnabled = (int)$row['config_value'];
    }
    if ($qrIdleServiceEnabled === null) {
        $qrIdleServiceEnabled = ALLOW_COUPON_IN_IDLE;
    }
    return $qrIdleServiceEnabled;
}
function checkIdlePermission($roomId, $conn, $qrIdleServiceEnabled, $actionName) {
    $orderCheckStmt = $conn->prepare("SELECT id FROM orders WHERE room_id = ? AND status = 0 LIMIT 1");
    $orderCheckStmt->bind_param('i', $roomId);
    $orderCheckStmt->execute();
    $orderResult = $orderCheckStmt->get_result();
    $isIdle = ($orderResult->num_rows === 0);
    if ($isIdle && !$qrIdleServiceEnabled) {
        throw new Exception('空闲状态服务暂不可用');
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'call_staff') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $accessCode = trim($_POST['access_code'] ?? '');
        $roomId = trim($_POST['room_id'] ?? '');
        $note = trim($_POST['note'] ?? '');
        if (empty($accessCode) || empty($roomId)) {
            throw new Exception('参数不完整');
        }
        if (!empty($note) && mb_strlen($note, 'UTF-8') > 30) {
            throw new Exception('描述不能超过30个字');
        }
        $row = validateAccessCode($accessCode, $roomId, $conn);
        $qrIdleServiceEnabled = getIdleServiceConfig($conn);
        checkIdlePermission($roomId, $conn, $qrIdleServiceEnabled, '呼叫服务');
        if ($row['qr_audio']) {
            $stmt_check = $conn->prepare("SELECT IF(? > DATE_SUB(NOW(), INTERVAL 30 SECOND), 1, 0) AS too_frequent");
            $stmt_check->bind_param('s', $row['qr_audio']);
            $stmt_check->execute();
            $check_result = $stmt_check->get_result()->fetch_assoc();
            $stmt_check->close();
            if ($check_result['too_frequent']) {
                throw new Exception('请勿频繁呼叫，请耐心等待');
            }
        }
        $updateStmt = $conn->prepare("
            UPDATE room_access_codes 
            SET audio_muted = 0, 
                audio_updated_at = NOW(),
                qr_audio = NOW(),
                note = ?
            WHERE access_code = ? AND room_id = ?
        ");
        $updateStmt->bind_param('ssi', $note, $accessCode, $roomId);
        $updateStmt->execute();
        echo json_encode(['success' => true, 'message' => '已通知店员，请稍候', 'qr_audio' => date('Y-m-d H:i:s')]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel_staff') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $accessCode = trim($_POST['access_code'] ?? '');
        $roomId = trim($_POST['room_id'] ?? '');
        if (empty($accessCode) || empty($roomId)) {
            throw new Exception('参数不完整');
        }
        $row = validateAccessCode($accessCode, $roomId, $conn);
        $updateStmt = $conn->prepare("
            UPDATE room_access_codes 
            SET audio_muted = 1,
                audio_updated_at = NOW()
            WHERE access_code = ? AND room_id = ?
        ");
        $updateStmt->bind_param('si', $accessCode, $roomId);
        $updateStmt->execute();
        echo json_encode(['success' => true, 'message' => '已取消服务呼叫']);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_coupon') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $accessCode = trim($_POST['access_code'] ?? '');
        $roomId = trim($_POST['room_id'] ?? '');
        $verificationCode = trim($_POST['verification_code'] ?? '');
        $verificationType = trim($_POST['verification_type'] ?? '');
        $verificationNote = trim($_POST['verification_note'] ?? '');
        $verificationCode = str_replace(' ', '', $verificationCode);
        if (empty($accessCode) || empty($roomId)) {
            throw new Exception('参数不完整');
        }
        if (empty($verificationCode)) {
            throw new Exception('请输入券号');
        }
        if (empty($verificationType)) {
            throw new Exception('请选择券号类型');
        }
        if (!in_array($verificationType, ['meituan', 'douyin'])) {
            throw new Exception('无效的券号类型');
        }
        if (!empty($verificationNote) && mb_strlen($verificationNote, 'UTF-8') > 30) {
            throw new Exception('备注不能超过30个字');
        }
        $row = validateAccessCode($accessCode, $roomId, $conn);
        $qrIdleServiceEnabled = getIdleServiceConfig($conn);
        checkIdlePermission($roomId, $conn, $qrIdleServiceEnabled, '发送券号');
        if ($row['qr_verification']) {
            $stmt_check = $conn->prepare("SELECT IF(? > DATE_SUB(NOW(), INTERVAL 30 SECOND), 1, 0) AS too_frequent");
            $stmt_check->bind_param('s', $row['qr_verification']);
            $stmt_check->execute();
            $check_result = $stmt_check->get_result()->fetch_assoc();
            $stmt_check->close();
            if ($check_result['too_frequent']) {
                throw new Exception('请勿频繁提交，请耐心等待');
            }
        }
        if (!preg_match('/^[A-Za-z0-9]{1,30}$/', $verificationCode)) {
            throw new Exception('核销码格式错误，请检查');
        }
        $updateStmt = $conn->prepare("
            UPDATE room_access_codes 
            SET verification_code = ?, 
                verification_type = ?,
                verification_note = ?,
                verification_time = NOW(),
                verification_status = 0,
                qr_verification = NOW()
            WHERE access_code = ? AND room_id = ?
        ");
        $updateStmt->bind_param('ssssi', $verificationCode, $verificationType, $verificationNote, $accessCode, $roomId);
        $updateStmt->execute();
        echo json_encode(['success' => true, 'message' => '券号提交成功', 'qr_verification' => date('Y-m-d H:i:s')]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'scan_checkin') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $accessCode = trim($_POST['access_code'] ?? '');
        $roomId = trim($_POST['room_id'] ?? '');
        $clientId = trim($_POST['client_id'] ?? '');
        $promotionId = isset($_POST['promotion_id']) ? (int)$_POST['promotion_id'] : 0;
        if (empty($accessCode) || empty($roomId)) {
            throw new Exception('参数不完整');
        }
        $row = validateAccessCode($accessCode, $roomId, $conn);
        $checkinStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'qr_checkin_enabled'");
        $checkinStmt->execute();
        $checkinResult = $checkinStmt->get_result()->fetch_assoc();
        if (!($checkinResult && $checkinResult['config_value'] == '1')) {
            throw new Exception('扫码开台功能未开启');
        }
        $checkinStmt->close();
        $requestCode = bin2hex(random_bytes(8));
        $startTime = date('Y-m-d H:i:s');
        $paymentMethodId = 88; 
        $isScanCheckin = 1;
        $promotionData = null;
        $promotionHours = 0;
        $promotionPrice = 0;
        $usePromotion = ($promotionId > 0);
        if ($usePromotion) {
            $promoCheckStmt = $conn->prepare("
                SELECT id, name, hours, price, room_ids, weekdays, time_start, time_end, is_all_day
                FROM promotion_strategies
                WHERE id = ? AND type = '桌码' AND is_enabled = 1 AND is_deleted = 0
            ");
            $promoCheckStmt->bind_param('i', $promotionId);
            $promoCheckStmt->execute();
            $promoCheckResult = $promoCheckStmt->get_result()->fetch_assoc();
            $promoCheckStmt->close();
            if (!$promoCheckResult) {
                throw new Exception('该套餐不存在或已停用');
            }
            $roomIds = $promoCheckResult['room_ids'];
            if (!empty($roomIds) && $roomIds !== '[]') {
                $roomIdsArr = json_decode($roomIds, true);
                if (is_array($roomIdsArr) && !in_array((int)$roomId, $roomIdsArr)) {
                    throw new Exception('该套餐不适用于此' . $SCENE_ROOM_NAME);
                }
            }
            if (!empty($promoCheckResult['weekdays'])) {
                $dbWeekday = (date('w') == 0) ? 7 : (int)date('w');
                $weekdayArr = array_map('intval', explode(',', str_replace(' ', '', $promoCheckResult['weekdays'])));
                if (!in_array($dbWeekday, $weekdayArr)) {
                    throw new Exception('该套餐今天不可用');
                }
            }
            if (!empty($promoCheckResult['time_start']) && !empty($promoCheckResult['time_end'])) {
                $now = date('H:i:s');
                if ($now < $promoCheckResult['time_start'] || $now > $promoCheckResult['time_end']) {
                    throw new Exception('该套餐当前时段不可用');
                }
            }
            $promotionHours = floatval($promoCheckResult['hours']);
            $promotionPrice = floatval($promoCheckResult['price']);
            $displayedHours = isset($_POST['displayed_hours']) ? floatval($_POST['displayed_hours']) : 0;
            $displayedPrice = isset($_POST['displayed_price']) ? floatval($_POST['displayed_price']) : 0;
            if ($displayedHours > 0 && ($displayedHours != $promotionHours || $displayedPrice != $promotionPrice)) {
                throw new Exception('套餐信息已变更，请刷新页面后重试');
            }
            $promotionData = json_encode([
                ['id' => (int)$promoCheckResult['id'], 'quantity' => 1]
            ], JSON_UNESCAPED_UNICODE);
        }
        $audioMuted = $usePromotion ? 0 : 1;
        $conn->begin_transaction();
        try {
            if ($usePromotion) {
                $roomStmt = $conn->prepare("SELECT id, enable_standard_price, standard_price FROM rooms WHERE id = ? AND is_enabled = 1 AND is_deleted = 0 FOR UPDATE");
            } else {
                $roomStmt = $conn->prepare("SELECT id, enable_standard_price, standard_price FROM rooms WHERE id = ? AND is_enabled = 1 AND is_deleted = 0 AND enable_standard_price = 1 AND standard_price > 0 FOR UPDATE");
            }
            $roomStmt->bind_param('i', $roomId);
            $roomStmt->execute();
            $roomInfo = $roomStmt->get_result()->fetch_assoc();
            $roomStmt->close();
            if (!$roomInfo) {
                throw new Exception($usePromotion ? '该房间不可用' : '该房间未启用标准价，不支持扫码开台');
            }
            if (!$usePromotion) {
                $displayedStandardPrice = isset($_POST['displayed_standard_price']) ? floatval($_POST['displayed_standard_price']) : 0;
                $currentStandardPrice = floatval($roomInfo['standard_price']);
                if ($displayedStandardPrice > 0 && $displayedStandardPrice != $currentStandardPrice) {
                    throw new Exception('标准价信息已变更，请刷新页面后重试');
                }
            }
            $orderCheck = $conn->prepare("SELECT id FROM orders WHERE room_id = ? AND status = 0 FOR UPDATE");
            $orderCheck->bind_param('i', $roomId);
            $orderCheck->execute();
            $orderExists = $orderCheck->get_result()->num_rows > 0;
            $orderCheck->close();
            if ($orderExists) {
                throw new Exception('该' . $SCENE_ROOM_NAME . '正在使用中');
            }
            if ($usePromotion) {
                if ($promoCheckResult['is_all_day'] == 1) {
                    $startDt = new DateTime($startTime);
                    $startDt->setTime(23, 59, 59);
                    $endTime = $startDt->format('Y-m-d H:i:s');
                } elseif ($promotionHours > 0) {
                    $startDt = new DateTime($startTime);
                    $minutes = (int)round($promotionHours * 60);
                    $startDt->modify("+{$minutes} minutes");
                    $endTime = $startDt->format('Y-m-d H:i:s');
                } else {
                    $endTime = $startTime;
                }
                $totalAmount = 0;         
                $creditAmount = $promotionPrice;
                $hoursVal = $promotionHours;
                $notes = '扫码开台-套餐:' . $promoCheckResult['name'];
            } else {
                $endTime = $startTime;
                $totalAmount = 0;
                $creditAmount = 0;
                $hoursVal = 0;
                $notes = '扫码开台';
            }
            $insertStmt = $conn->prepare("INSERT INTO orders
                (room_id, start_time, expected_end_time, total_amount, member_card_no, audio_muted, origin_client, notes, is_scan_checkin)
                VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?)");
            $insertStmt->bind_param('issdissi', $roomId, $startTime, $endTime, $totalAmount, $audioMuted, $clientId, $notes, $isScanCheckin);
            if (!$insertStmt->execute()) {
                throw new Exception('订单创建失败: ' . $insertStmt->error);
            }
            $insertStmt->close();
            $idStmt = $conn->prepare("SELECT id FROM orders WHERE room_id = ? ORDER BY id DESC LIMIT 1");
            $idStmt->bind_param('i', $roomId);
            $idStmt->execute();
            $formattedOrderId = $idStmt->get_result()->fetch_assoc()['id'];
            $idStmt->close();
            $extraFeeVal = 0;
            $paymentTypeVal = 0;
            $paymentAmount = 0;
            $operatorId = 0;
            $detailsStmt = $conn->prepare("INSERT INTO orders_payment_details
                (order_id, payment_method_id, amount, credit_amount, extra_fee, member_card_no, payment_type, hours, promotion_data, time_card_data, operator_id, request_code)
                VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, NULL, ?, ?)");
            $detailsStmt->bind_param('siddddisis', $formattedOrderId, $paymentMethodId, $paymentAmount, $creditAmount, $extraFeeVal, $paymentTypeVal, $hoursVal, $promotionData, $operatorId, $requestCode);
            if (!$detailsStmt->execute()) {
                throw new Exception('支付明细记录失败: ' . $detailsStmt->error);
            }
            $detailsStmt->close();
            if ($usePromotion) {
                $promoIdVal = (int)$promoCheckResult['id'];
                $updatePromoStmt = $conn->prepare("UPDATE promotion_strategies SET usage_count = 1 WHERE id = ? AND usage_count = 0");
                $updatePromoStmt->bind_param('i', $promoIdVal);
                $updatePromoStmt->execute();
                $updatePromoStmt->close();
            }
            $racId = $row['id'];
            $checkinUpdate = $conn->prepare("UPDATE room_access_codes SET qr_checkin_muted = 0, qr_checkin_time = NOW() WHERE id = ?");
            $checkinUpdate->bind_param('i', $racId);
            $checkinUpdate->execute();
            $checkinUpdate->close();
            $conn->commit();
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
        updateRefreshFlag();
        $pushClientId = $clientId;
        pushToWebSocket([
            'type' => 'room_update',
            'action' => 'open',
            'room_id' => (int)$roomId,
            'order_id' => $formattedOrderId,
            'start_time' => $startTime,
            'end_time' => $endTime,
            'is_scan_checkin' => true,
            'exclude_client_id' => $pushClientId
        ]);
        pushToWebSocket([
            'type' => 'stats_update',
            'action' => 'room_open',
            'room_id' => (int)$roomId,
            'exclude_client_id' => $pushClientId
        ]);
        pushToWebSocket([
            'type' => 'device_trigger'
        ]);
        echo json_encode([
            'success' => true,
            'message' => '开台成功，计时已开始',
            'order_id' => $formattedOrderId,
            'start_time' => $startTime
        ]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}
$accessCode = trim($_GET['code'] ?? '');
if (empty($accessCode)) {
    http_response_code(400);
    showErrorPage('缺少访问码', '请检查二维码是否完整，或联系工作人员。');
    exit;
}
try {
    $configStmt = $conn->prepare("
        SELECT 
            MAX(CASE WHEN config_key = 'site_title' THEN config_value END) AS site_title,
            MAX(CASE WHEN config_key = 'qr_notice' THEN config_value END) AS qr_notice,
            MAX(CASE WHEN config_key = 'qr_idle_service_enabled' THEN config_value END) AS qr_idle_service_enabled,
            MAX(CASE WHEN config_key = 'qr_checkin_enabled' THEN config_value END) AS qr_checkin_enabled,
            MAX(CASE WHEN config_key = 'overtime_fee_rule' THEN config_value END) AS overtime_fee_rule
        FROM system_config
        WHERE config_key IN ('site_title', 'qr_notice', 'qr_idle_service_enabled', 'qr_checkin_enabled', 'overtime_fee_rule')
    ");
    $configStmt->execute();
    $configResult = $configStmt->get_result();
    $siteTitle = '';
    $qrNotice = '';
    $qrIdleServiceEnabled = null;
    $qrCheckinEnabled = 0;
    $overtimeFeeRule = 1;
    if ($row = $configResult->fetch_assoc()) {
        $siteTitle = $row['site_title'] ?? '';
        $qrNotice = $row['qr_notice'] ?? '';
        $qrIdleServiceEnabled = $row['qr_idle_service_enabled'] !== null ? (int)$row['qr_idle_service_enabled'] : null;
    $qrCheckinEnabled = (int)($row['qr_checkin_enabled'] ?? 0);
    $overtimeFeeRule = (int)($row['overtime_fee_rule'] ?? 1);
    if (!($overtimeFeeRule >= 1 && $overtimeFeeRule <= 300 && ($overtimeFeeRule === 1 || $overtimeFeeRule % 5 === 0))) {
        $overtimeFeeRule = 1;
    }
    }
    if ($qrIdleServiceEnabled === null) {
        $qrIdleServiceEnabled = ALLOW_COUPON_IN_IDLE;
    }
    $stmt = $conn->prepare("
        SELECT rac.room_id, rac.is_enabled, rac.audio_muted, r.name AS room_name, r.standard_price, r.enable_standard_price
        FROM room_access_codes rac
        INNER JOIN rooms r ON rac.room_id = r.id
        WHERE rac.access_code = ? AND rac.is_enabled = 1 AND r.is_enabled = 1 AND r.is_deleted = 0
    ");
    $stmt->bind_param('s', $accessCode);
    $stmt->execute();
    $result = $stmt->get_result();
    $roomData = $result->fetch_assoc();
    if (!$roomData) {
        http_response_code(404);
        showErrorPage('访问码无效或已被停用', '如需服务，请联系工作人员。');
        exit;
    }
    $isInternalRefresh = isset($_GET['internal_refresh']) && $_GET['internal_refresh'] === '1';
    if (!$isInternalRefresh) {
        try {
            $updateStmt = $conn->prepare("UPDATE room_access_codes SET scan_count = scan_count + 1, last_scanned_at = CURRENT_TIMESTAMP WHERE access_code = ?");
            $updateStmt->bind_param('s', $accessCode);
            $updateStmt->execute();
        } catch (Exception $e) {}
    }
    $orderStmt = $conn->prepare("SELECT id, start_time, expected_end_time, status, total_amount FROM orders WHERE room_id = ? AND status = 0 ORDER BY id DESC LIMIT 1");
    $orderStmt->bind_param('i', $roomData['room_id']);
    $orderStmt->execute();
    $order = $orderStmt->get_result()->fetch_assoc();
    $isUsing = ($order !== null);
    $orderFees = null;
    if ($isUsing && $order) {
        $orderId = $order['id'];
        $paidAmount = floatval($order['total_amount'] ?? 0);
        $creditAmount = 0;
        $productCreditAmount = 0;
        $overtimeFee = 0;
        try {
            $stmt = $conn->prepare("
                SELECT 
                    COALESCE((SELECT SUM(credit_amount) FROM orders_payment_details WHERE order_id = ? AND credit_amount > 0), 0) as order_credit,
                    COALESCE((SELECT SUM(total_amount) FROM product_credit_for_room WHERE batch_no = ?), 0) as product_credit,
                    r.enable_standard_price,
                    r.standard_price
                FROM rooms r
                WHERE r.id = ?
            ");
            if ($stmt) {
                $stmt->bind_param('ssi', $orderId, $orderId, $roomData['room_id']);
                if ($stmt->execute()) {
                    $res = $stmt->get_result();
                    if ($res && $row = $res->fetch_assoc()) {
                        $creditAmount = floatval($row['order_credit']);
                        $productCreditAmount = floatval($row['product_credit']);
                        if ($row['enable_standard_price'] == 1 && floatval($row['standard_price']) > 0) {
                            $expectedEndDateTime = new DateTime($order['expected_end_time']);
                            $currentDateTime = new DateTime();
                            $interval = $currentDateTime->diff($expectedEndDateTime);
                            if ($interval->invert === 0) {
                                $overtimeMinutes = 0;
                            } else {
                                $secondDiff = ($interval->days * 86400) + ($interval->h * 3600) + ($interval->i * 60) + $interval->s;
                                $overtimeMinutes = round($secondDiff / 60);
                            }
                            if ($overtimeMinutes > 0) {
                                $ruleStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'overtime_fee_rule'");
                                if ($ruleStmt) {
                                    $ruleStmt->execute();
                                    $ruleResult = $ruleStmt->get_result();
                                    if ($ruleResult && $ruleResult->num_rows > 0) {
                                        $ruleValue = (int)$ruleResult->fetch_assoc()['config_value'];
                                        if ($ruleValue >= 1 && $ruleValue <= 300 && ($ruleValue === 1 || $ruleValue % 5 === 0)) {
                                            $overtimeFeeRule = $ruleValue;
                                        }
                                    }
                                    $ruleStmt->close();
                                }
                                if ($overtimeFeeRule > 1) {
                                    $overtimeMinutes = (int)ceil($overtimeMinutes / $overtimeFeeRule) * $overtimeFeeRule;
                                }
                                $standardPriceYuan = floatval($row['standard_price']);
                                $priceCents = round($standardPriceYuan * 100);
                                $totalCents = $priceCents * $overtimeMinutes;
                                $feeYuan = $totalCents / (100 * 60);
                                $truncatedFee = getAmountTwoDecimals($feeYuan);
                                $overtimeFee = floor($truncatedFee * 10) / 10;
                            }
                        }
                    }
                }
                $stmt->close();
            }
        } catch (Exception $e) {
        }
        $orderFees = [
            'paid' => $paidAmount,
            'credit' => $creditAmount + $productCreditAmount,
            'overtime' => $overtimeFee,
            'pending_total' => ($creditAmount + $productCreditAmount) + $overtimeFee,
            'fee_rule' => $overtimeFeeRule
        ];
    }
} catch (Exception $e) {
    http_response_code(500);
    showErrorPage('服务异常', '请稍后再试，或联系工作人员。');
    exit;
}
function showErrorPage(string $title, string $message): void {
    global $siteTitle;
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
        <title>信息查看</title>
        <style>
            body { background: #f3f4f6; color:#333; font-family: sans-serif; display:flex; justify-content:center; padding:40px 20px; }
            .err { background:#fff; padding:40px; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.05); text-align:center; width:100%; max-width:400px; }
            h2 { color:#ef4444; } p { color:#6b7280; line-height:1.5; }
        </style>
    </head>
    <body><div class="err"><h2><?= htmlspecialchars($title) ?></h2><p><?= htmlspecialchars($message) ?></p></div></body>
    </html>
    <?php
    exit;
}
$applicablePromotions = [];
if ($qrCheckinEnabled == 1 && !$isUsing) {
    $roomIdInt = (int)$roomData['room_id'];
    $promoStmt = $conn->prepare("
        SELECT id, name, hours, price, member_discount, room_ids, weekdays, time_start, time_end, is_all_day
        FROM promotion_strategies
        WHERE type = '桌码' AND is_enabled = 1 AND is_deleted = 0
        ORDER BY sort_order ASC, id ASC
    ");
    $promoStmt->execute();
    $promoResult = $promoStmt->get_result();
    $dbWeekday = (date('w') == 0) ? 7 : (int)date('w');
    $currentTime = date('H:i:s');
    while ($pRow = $promoResult->fetch_assoc()) {
        $pRoomIds = $pRow['room_ids'];
        if (!empty($pRoomIds) && $pRoomIds !== '[]') {
            $roomIdsArr = json_decode($pRoomIds, true);
            if (is_array($roomIdsArr) && !empty($roomIdsArr) && !in_array($roomIdInt, $roomIdsArr)) {
                continue;
            }
        }
        if (!empty($pRow['weekdays'])) {
            $weekdays = array_map('intval', explode(',', str_replace(' ', '', $pRow['weekdays'])));
            if (!in_array($dbWeekday, $weekdays)) {
                continue;
            }
        }
        if (!empty($pRow['time_start']) && !empty($pRow['time_end'])) {
            if ($currentTime < $pRow['time_start'] || $currentTime > $pRow['time_end']) {
                continue;
            }
        }
        $applicablePromotions[] = [
            'id' => (int)$pRow['id'],
            'name' => $pRow['name'],
            'hours' => floatval($pRow['hours']),
            'price' => floatval($pRow['price']),
            'is_all_day' => (int)$pRow['is_all_day']
        ];
    }
    $promoStmt->close();
}
$hasStandardPrice = ($roomData['enable_standard_price'] == 1 && floatval($roomData['standard_price']) > 0);
$canScanCheckin = ($qrCheckinEnabled == 1 && !$isUsing && ($hasStandardPrice || !empty($applicablePromotions)));
$overtimeFeeRuleText = $overtimeFeeRule > 1 ? "（超时按{$overtimeFeeRule}分钟为单位计费）" : "（超时按实计费）";
$pageData = [
    'site_title' => htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'),
    'room_name'  => htmlspecialchars($roomData['room_name'], ENT_QUOTES, 'UTF-8'),
    'room_id'    => (int)$roomData['room_id'],
    'is_using'   => $isUsing,
    'is_calling' => (isset($roomData['audio_muted']) && $roomData['audio_muted'] == 0),
    'audio_updated_at' => $roomData['audio_updated_at'] ?? null,
    'start_time' => $order['start_time'] ?? null,
    'end_time'   => $order['expected_end_time'] ?? null,
    'allow_idle_action' => $qrIdleServiceEnabled,
    'qr_checkin_enabled' => $qrCheckinEnabled,
    'can_scan_checkin' => $canScanCheckin,
    'has_standard_price' => $hasStandardPrice,
    'standard_price' => floatval($roomData['standard_price'] ?? 0),
    'overtime_fee_rule_text' => $overtimeFeeRuleText,
    'promotions' => $applicablePromotions,
    'order_fees' => $orderFees,
    'server_timestamp' => date('c')
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>信息查看</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --danger: #ef4444;
            --danger-bg: #fef2f2;
            --success: #10b981;
            --success-bg: #ecfdf5;
            --bg: #f3f4f6;
            --card-bg: #ffffff;
            --text-main: #111827;
            --text-sec: #6b7280;
            --border: #e5e7eb;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background-color: var(--bg);
            background-image: radial-gradient(circle at 50% 0%, #e0e7ff 0%, var(--bg) 70vh);
            font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            display: flex; justify-content: center; align-items: flex-start; min-height: 100vh;
            padding: 40px 20px 60px;
            -webkit-font-smoothing: antialiased;
        }
        @media (max-width: 480px) {
            body {
                padding: 10px 16px 40px;
            }
        }
        .card {
            background: var(--card-bg);
            border-radius: 24px;
            box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.05), 0 0 1px rgba(0, 0, 0, 0.1);
            width: 100%; max-width: 420px;
            padding: 20px 24px;
            position: relative;
        }
        .header {
            position: relative;
            margin-bottom: 16px;
            text-align: center;
        }
        .title-group {
            width: 100%;
        }
        .shop-name {
            font-size: 24px; font-weight: 700; color: var(--text-main); margin-bottom: 6px;
            letter-spacing: 0px; line-height: 1.2; font-family: inherit;
        }
        .room-name {
            font-size: 16px; font-weight: 500; color: var(--text-sec); letter-spacing: 0px;
        }
        .btn-refresh {
            position: absolute; right: 0; top: 0;
            background: var(--bg); border: none; border-radius: 50%; width: 44px; height: 44px;
            display: flex; align-items: center; justify-content: center;
            color: var(--primary); cursor: pointer; transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(37,99,235,0.1);
        }
        .btn-refresh:active:not(:disabled) { background: #e5e7eb; transform: scale(0.92); }
        .btn-refresh:disabled { color: #9ca3af; box-shadow: none; cursor: not-allowed; background: #e5e7eb;}
        .btn-refresh.spinning svg { animation: spin 1s cubic-bezier(0.4, 0, 0.2, 1) infinite; color: var(--primary); }
        .hero-box {
            background: #f8fafc; border-radius: 16px; padding: 16px 16px;
            text-align: center; margin-bottom: 16px; transition: background 0.3s ease;
            border: 1px solid rgba(0,0,0,0.02);
        }
        .hero-box.overdue { background: var(--danger-bg); border-color: rgba(239,68,68,0.1); }
        .hero-box.idle { background: var(--success-bg); border-color: rgba(16,185,129,0.1); }
        .hero-time {
            font-size: 26px; font-weight: 700; color: var(--primary);
            line-height: 1.2; font-feature-settings: "tnum"; font-variant-numeric: tabular-nums;
            letter-spacing: 0px;
        }
        .hero-box.overdue .hero-time { color: var(--danger); }
        .hero-box.idle .hero-time { color: var(--success); font-size: 22px; margin-bottom: 8px;}
        .hero-label { font-size: 15px; color: var(--text-sec); font-weight: 600; margin-bottom: 5px; }
        .hero-box.overdue .hero-label { color: #b91c1c; }
        .hero-box.idle .hero-label { color: #047857; margin-top: 8px; font-size: 15px; font-weight: 500;}
        .info-list { margin-bottom: 20px; padding: 0 4px; }
        .info-row {
            display: flex; justify-content: space-between; align-items: center;
            padding: 10px 0; border-bottom: 1px solid #f1f5f9;
        }
        .info-row:last-child { border-bottom: none; }
        .info-label { color: var(--text-sec); font-size: 15px; font-weight: 500;}
        .info-value { color: var(--text-main); font-size: 15px; font-weight: 600; font-variant-numeric: tabular-nums;}
        .btn-call {
            width: 100%; border: none; border-radius: 20px; padding: 14px 20px;
            font-size: 17px; font-weight: 600; color: white;
            background: linear-gradient(135deg, var(--primary) 0%, #3b82f6 100%);
            box-shadow: 0 12px 24px -8px rgba(37, 99, 235, 0.5);
            cursor: pointer; transition: all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
            display: flex; justify-content: center; align-items: center; gap: 10px;
        }
        .btn-call:active { transform: translateY(4px) scale(0.97); box-shadow: 0 4px 12px -4px rgba(37, 99, 235, 0.4); }
        .btn-call:disabled {
            background: #d1d5db; color: #9ca3af; box-shadow: none; cursor: not-allowed;
            transform: none;
        }
        .toast {
            position: fixed; top: 30px; left: 50%; transform: translateX(-50%) translateY(-20px);
            background: rgba(17, 24, 39, 0.95); color: white;
            padding: 14px 28px; border-radius: 100px; font-size: 15px; font-weight: 500;
            opacity: 0; pointer-events: none; transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            backdrop-filter: blur(10px); box-shadow: 0 10px 40px rgba(0,0,0,0.15); z-index: 1000;
            display: flex; align-items: center; gap: 8px; white-space: nowrap;
        }
        .toast.show { opacity: 1; transform: translateX(-50%) translateY(0); }
        .notice-box {
            background: #f8fafc;
            border-radius: 16px;
            padding: 20px 24px;
            margin-top: 24px;
            border: 1px solid rgba(0,0,0,0.03);
            transition: all 0.3s ease;
        }
        .notice-box:hover {
            background: #f1f5f9;
            border-color: rgba(37, 99, 235, 0.1);
        }
        .notice-title {
            font-size: 15px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 12px;
            letter-spacing: 0.5px;
        }
        .notice-content {
            font-size: 14px;
            line-height: 1.7;
            color: var(--text-sec);
            font-weight: 500;
        }
        .footer-note {
            text-align: center; margin-top: 32px; font-size: 13px; color: #9ca3af; font-weight: 500;
        }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
    </style>
</head>
<body>
    <div id="toast" class="toast"></div>
    <div class="card">
        <div class="header">
            <div class="title-group">
                <?php if (!empty($pageData['site_title'])): ?>
                    <div class="shop-name"><?= $pageData['site_title'] ?></div>
                <?php endif; ?>
                <div class="room-name"><?= $pageData['room_name'] ?></div>
            </div>
            <button type="button" class="btn-refresh" id="refreshBtn" onclick="manualRefresh(event)" aria-label="手动刷新状态">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="23 4 23 10 17 10"></polyline>
                    <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
                </svg>
            </button>
        </div>
        <?php if ($pageData['is_using']): ?>
            <div class="hero-box" id="heroBox">
                <div class="hero-label" id="heroLabelItem">剩余可用时长</div>
                <div class="hero-time" id="heroTimeStr">计算中...</div>
                <?php if ($pageData['order_fees']): ?>
                <div style="margin-top: 12px; padding-top: 8px; border-top: 1px solid rgba(0,0,0,0.06);">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 15px;">
                        <span style="color: var(--text-sec); font-weight: 500;">已收费用</span>
                        <span style="color: var(--success); font-weight: 700; font-variant-numeric: tabular-nums;">¥<?= number_format($pageData['order_fees']['paid'], 2) ?></span>
                    </div>
                    <?php if ($pageData['order_fees']['credit'] > 0): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 15px;">
                        <span style="color: var(--text-sec); font-weight: 500;">挂单费用</span>
                        <span style="color: var(--danger); font-weight: 700; font-variant-numeric: tabular-nums;">¥<?= number_format($pageData['order_fees']['credit'], 2) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($pageData['order_fees']['overtime'] > 0): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; font-size: 15px;">
                        <span style="color: var(--text-sec); font-weight: 500;">超时费用</span>
                        <span style="color: var(--danger); font-weight: 700; font-variant-numeric: tabular-nums;">¥<?= number_format($pageData['order_fees']['overtime'], 2) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($pageData['order_fees']['credit'] > 0 || $pageData['order_fees']['overtime'] > 0): ?>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0 4px 0; font-size: 15px; border-top: 1px dashed rgba(0,0,0,0.08); margin-top: 4px;">
                        <span style="color: var(--text-main); font-weight: 600;">待支付合计</span>
                        <span style="color: var(--danger); font-weight: 700; font-size: 16px; font-variant-numeric: tabular-nums;">¥<?= number_format($pageData['order_fees']['pending_total'], 2) ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($roomData['enable_standard_price'] == 1 && floatval($roomData['standard_price']) > 0): ?>
                    <div style="padding: 2px 0 0 0; font-size: 12px; color: #6b7280; text-align: right;">
                        ¥<?= number_format(floatval($roomData['standard_price']), 2) ?>/小时 <?= $pageData['overtime_fee_rule_text'] ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="info-list">
                <div class="info-row">
                    <div class="info-label">开始时间</div>
                    <div class="info-value"><?= substr($pageData['start_time'], 5, 11) ?></div>
                </div>
                <div class="info-row">
                    <div class="info-label">预计结束</div>
                    <div class="info-value"><?= substr($pageData['end_time'], 5, 11) ?></div>
                </div>
            </div>
        <?php else: ?>
            <div class="hero-box idle">
                <div class="hero-time">空闲中</div>
                <div class="hero-label">当前<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>为空闲状态，请前往服务台办理使用<?= $canScanCheckin ? '或使用下方功能开台' : '' ?></div>
            </div>
        <?php endif; ?>
        <?php if ($canScanCheckin): ?>
        <div id="checkinPromotions" style="margin-bottom:12px; position:relative; padding:18px 14px 14px 14px; border:1.5px dashed #d1d5db; border-radius:14px; background: #fafbfc;">
            <div style="position:absolute; top:-12px; left:14px; background:#fafbfc; padding:0 8px; font-size:12px; color:#6b7280; font-weight:500; letter-spacing:0.5px;">
                开台使用
            </div>
            <?php if (!empty($pageData['promotions'])): ?>
                <?php foreach ($pageData['promotions'] as $index => $promo): ?>
                <button class="btn-call promo-checkin-btn" data-promo-id="<?= $promo['id'] ?>" data-promo-name="<?= htmlspecialchars($promo['name']) ?>" data-promo-hours="<?= floatval($promo['hours']) ?>" data-promo-price="<?= floatval($promo['price']) ?>"
                        style="margin-top:<?= $index > 0 ? '10px' : '0' ?>; background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                    <span style="display:flex; flex-direction:column; align-items:center; width:100%;">
                        <span style="display:flex; align-items:center; gap: 8px; font-weight:700; font-size:16px;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                            </svg>
                            套餐：<?= htmlspecialchars($promo['name']) ?>
                        </span>
                        <span style="font-size:13px; opacity:0.85; margin-top:2px;">
                            ¥<?= number_format($promo['price'], 2) ?> / <?= floatval($promo['hours']) ?>小时
                        </span>
                    </span>
                </button>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if ($hasStandardPrice): ?>
            <button class="btn-call promo-checkin-btn" data-promo-id="0" data-standard-price="<?= floatval($pageData['standard_price']) ?>"
                    style="margin-top:<?= !empty($pageData['promotions']) ? '10px' : '0' ?>; background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);">
                <span style="display:flex; flex-direction:column; align-items:center; width:100%;">
                    <span style="display:flex; align-items:center; gap: 8px; font-weight:700; font-size:16px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                        </svg>
                        标准价
                    </span>
                    <span style="font-size:13px; opacity:0.85; margin-top:2px;">
                        ¥<?= number_format($pageData['standard_price'], 2) ?> / 小时
                    </span>
                </span>
            </button>
            <?php endif; ?>
            <?php if (!empty($pageData['overtime_fee_rule_text'])): ?>
            <div style="text-align:center; font-size:12px; color:#6b7280; margin-top:8px; line-height:1.5;">
                <?= $pageData['overtime_fee_rule_text'] ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <button class="btn-call" id="callBtn" onclick="toggleCall()" <?= (!$pageData['is_using'] && !$pageData['allow_idle_action']) ? 'disabled' : '' ?> 
                data-calling="<?= $pageData['is_calling'] ? 'true' : 'false' ?>"
                style="margin-top: 12px; <?= (!$pageData['is_using'] && !$pageData['allow_idle_action']) ? '' : ($pageData['is_calling'] ? 'background: linear-gradient(135deg, var(--danger) 0%, #dc2626 100%);' : '') ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" id="btnIcon">
                <?php if ($pageData['is_calling']): ?>
                    <circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>
                <?php else: ?>
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                    <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                <?php endif; ?>
            </svg>
            <span id="btnText">
                <?php if (!$pageData['is_using'] && !$pageData['allow_idle_action']): ?>
                    空闲状态暂不可呼叫
                <?php elseif ($pageData['is_calling']): ?>
                    已呼叫服务，点击可取消
                <?php else: ?>
                    呼叫店员
                <?php endif; ?>
            </span>
        </button>
        <button class="btn-call" id="couponBtn" onclick="showCouponModal()" <?= (!$pageData['is_using'] && !$pageData['allow_idle_action']) ? 'disabled' : '' ?> style="margin-top: 12px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                <line x1="7" y1="7" x2="7.01" y2="7"></line>
            </svg>
            <span>
                <?php if (!$pageData['is_using'] && !$pageData['allow_idle_action']): ?>
                    空闲状态暂不可发送
                <?php else: ?>
                    发送团购券号
                <?php endif; ?>
            </span>
        </button>
        <div class="notice-box" id="noticeBox" style="margin-top: 16px;">
            <div class="notice-title">商家公告：</div>
            <div class="notice-content">
                <?php if (!empty($qrNotice)): ?>
                    <?= strip_tags($qrNotice, '<br>') ?>
                <?php else: ?>
                    暂无
                <?php endif; ?>
            </div>
        </div>
        <div class="footer-note">
            <div style="font-size: 13px; color: #6b7280; margin-bottom: 4px;">
                费用仅供参考，具体以服务台最终结算为准
            </div>
            <?= !empty($pageData['site_title']) ? $pageData['site_title'] . ' ' : '' ?>祝您体验愉快
        </div>
    </div>
    <div id="couponModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
        <div style="background:#fff; padding:24px; border-radius:16px; width:90%; max-width:400px; box-shadow:0 20px 60px rgba(0,0,0,0.3);">
            <h3 style="margin:0 0 20px 0; color:#1f2937; font-size:20px;">发送团购券号</h3>
            <div style="display:flex; gap:12px; margin-bottom:12px;">
                <input type="text" id="couponCodeInput" maxlength="30" placeholder="请输入数字券号" 
                       style="flex:1; padding:12px; border:2px solid #e5e7eb; border-radius:8px; font-size:16px; box-sizing:border-box;"
                       onkeydown="if(event.keyCode===13) submitCouponCode();">
                <select id="couponTypeSelect" style="padding:12px; border:2px solid #e5e7eb; border-radius:8px; font-size:16px; min-width:100px;">
                    <option value="">类型</option>
                    <option value="meituan">美团</option>
                    <option value="douyin">抖音</option>
                </select>
            </div>
            <textarea id="couponNoteInput" maxlength="30" placeholder="可输入备注，也可直接确定提交" 
                      style="width:100%; padding:12px; border:2px solid #e5e7eb; border-radius:8px; font-size:16px; box-sizing:border-box; margin-bottom:8px; resize:none; height:80px;"></textarea>
            <div style="text-align:right; font-size:13px; color:#9ca3af; margin-bottom:16px;">
                <span id="couponNoteCharCount">0</span>/30
            </div>
            <div style="display:flex; gap:12px;">
                <button onclick="closeCouponModal()" 
                        style="flex:1; padding:12px; border:1px solid #d1d5db; background:#f9fafb; color:#6b7280; border-radius:8px; font-size:16px; cursor:pointer;">
                    取消
                </button>
                <button onclick="submitCouponCode()" 
                        style="flex:1; padding:12px; border:none; background:linear-gradient(135deg, #10b981 0%, #059669 100%); color:white; border-radius:8px; font-size:16px; cursor:pointer;">
                    确定
                </button>
            </div>
        </div>
    </div>
    <div id="callStaffModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
        <div style="background:#fff; padding:24px; border-radius:16px; width:90%; max-width:400px; box-shadow:0 20px 60px rgba(0,0,0,0.3);">
            <h3 style="margin:0 0 20px 0; color:#1f2937; font-size:20px;">呼叫店员</h3>
            <textarea id="callNoteInput" maxlength="30" placeholder="可输入备注，也可直接确定提交" 
                      style="width:100%; padding:12px; border:2px solid #e5e7eb; border-radius:8px; font-size:16px; box-sizing:border-box; margin-bottom:8px; resize:none; height:80px;"></textarea>
            <div style="text-align:right; font-size:13px; color:#9ca3af; margin-bottom:16px;">
                <span id="noteCharCount">0</span>/30
            </div>
            <div style="display:flex; gap:12px;">
                <button onclick="closeCallStaffModal()" 
                        style="flex:1; padding:12px; border:1px solid #d1d5db; background:#f9fafb; color:#6b7280; border-radius:8px; font-size:16px; cursor:pointer;">
                    取消
                </button>
                <button onclick="confirmCallStaff()" 
                        style="flex:1; padding:12px; border:none; background:linear-gradient(135deg, var(--primary) 0%, #3b82f6 100%); color:white; border-radius:8px; font-size:16px; cursor:pointer;">
                    确定
                </button>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
        const ACCESS_CODE = '<?= $accessCode ?>';
        const ROOM_ID = <?= $pageData['room_id'] ?>;
        const IS_USING = <?= $pageData['is_using'] ? 'true' : 'false' ?>;
        const START_TIME = '<?= $pageData['start_time'] ?: '' ?>';
        let local_end_time = '<?= $pageData['end_time'] ?: '' ?>';
        const SERVER_TIMESTAMP = new Date('<?= $pageData['server_timestamp'] ?>').getTime();
        const CLIENT_TIMESTAMP = Date.now();
        const TIME_OFFSET = SERVER_TIMESTAMP - CLIENT_TIMESTAMP;  
        let toastTimeout;
        function showToast(icon, msg) {
            const t = document.getElementById('toast');
            t.innerHTML = `<span>${icon}</span> <span>${msg}</span>`;
            t.classList.add('show');
            clearTimeout(toastTimeout);
            toastTimeout = setTimeout(() => t.classList.remove('show'), 3500);
        }
        function showCouponModal() {
            document.getElementById('couponModal').style.display = 'flex';
            document.getElementById('couponCodeInput').value = '';
            document.getElementById('couponTypeSelect').value = '';
            document.getElementById('couponNoteInput').value = '';
            document.getElementById('couponNoteCharCount').textContent = '0';
            document.getElementById('couponCodeInput').focus();
        }
        function closeCouponModal() {
            document.getElementById('couponModal').style.display = 'none';
        }
        let callAutoSubmitTimer = null; 
        function showCallStaffModal() {
            document.getElementById('callStaffModal').style.display = 'flex';
            document.getElementById('callNoteInput').value = '';
            document.getElementById('noteCharCount').textContent = '0';
            const noteInput = document.getElementById('callNoteInput');
            let hasInteracted = false;
            let countdown = 5;
            clearTimeout(callAutoSubmitTimer);
            noteInput.placeholder = '可输入备注，也可直接确定提交（5秒后自动呼叫）';
            callAutoSubmitTimer = setInterval(function() {
                countdown--;
                if (countdown <= 0) {
                    clearInterval(callAutoSubmitTimer);
                    callAutoSubmitTimer = null;
                    if (!hasInteracted && document.getElementById('callStaffModal').style.display !== 'none') {
                        confirmCallStaff();
                    }
                } else {
                    noteInput.placeholder = '可输入备注，也可直接确定提交（' + countdown + '秒后自动呼叫）';
                }
            }, 1000);
            function cancelAutoSubmit() {
                hasInteracted = true;
                if (callAutoSubmitTimer) {
                    clearInterval(callAutoSubmitTimer);
                    callAutoSubmitTimer = null;
                }
                noteInput.placeholder = '可输入备注，也可直接确定提交';
                noteInput.removeEventListener('focus', cancelAutoSubmit);
                noteInput.removeEventListener('input', cancelAutoSubmit);
            }
            noteInput.addEventListener('focus', cancelAutoSubmit, { once: true });
            noteInput.addEventListener('input', cancelAutoSubmit, { once: true });
        }
        function closeCallStaffModal() {
            document.getElementById('callStaffModal').style.display = 'none';
            if (callAutoSubmitTimer) {
                clearInterval(callAutoSubmitTimer);
                callAutoSubmitTimer = null;
            }
        }
        document.addEventListener('DOMContentLoaded', function() {
            const noteInput = document.getElementById('callNoteInput');
            if (noteInput) {
                noteInput.addEventListener('input', function() {
                    document.getElementById('noteCharCount').textContent = this.value.length;
                });
            }
            const couponNoteInput = document.getElementById('couponNoteInput');
            if (couponNoteInput) {
                couponNoteInput.addEventListener('input', function() {
                    document.getElementById('couponNoteCharCount').textContent = this.value.length;
                });
            }
        });
        let isSubmittingCoupon = false;
        function submitCouponCode() {
            if (isSubmittingCoupon) return;
            const couponCode = document.getElementById('couponCodeInput').value.trim();
            const couponType = document.getElementById('couponTypeSelect').value;
            const couponNote = document.getElementById('couponNoteInput').value.trim();
            if (!couponCode) {
                showToast('⚠️', '请输入券号');
                return;
            }
            if (!couponType) {
                const typeSelect = document.getElementById('couponTypeSelect');
                typeSelect.style.borderColor = '#ef4444';
                typeSelect.style.backgroundColor = '#fef2f2';
                setTimeout(() => {
                    typeSelect.style.borderColor = '#e5e7eb';
                    typeSelect.style.backgroundColor = '';
                }, 2000);
                showToast('⚠️', '请选择券号类型');
                return;
            }
            const codeWithoutSpaces = couponCode.replace(/\s/g, '');
            const validPattern = /^[A-Za-z0-9\s]{1,50}$/; 
            if (!validPattern.test(couponCode)) {
                showToast('⚠️', '核销码格式错误，请检查');
                return;
            }
            if (codeWithoutSpaces.length === 0) {
                showToast('⚠️', '请输入有效的券号');
                return;
            }
            if (codeWithoutSpaces.length > 30) {
                showToast('⚠️', '券号过长，最多30个字符');
                return;
            }
            isSubmittingCoupon = true;
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'action': 'submit_coupon',
                    'access_code': ACCESS_CODE,
                    'room_id': ROOM_ID,
                    'verification_code': couponCode,
                    'verification_type': couponType,
                    'verification_note': couponNote
                })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('✅', data.message || '券号发送成功');
                    closeCouponModal();
                } else {
                    showToast('⚠️', data.message || '系统繁忙，请稍后再试');
                }
            })
            .catch(e => {
                showToast('📡', '网络连接丢失，请检查网络');
            })
            .finally(() => {
                setTimeout(() => {
                    isSubmittingCoupon = false;
                }, 1000);
            });
        }
        document.getElementById('couponModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCouponModal();
            }
        });
        document.getElementById('callStaffModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCallStaffModal();
            }
        });
        function formatDurationText(ms) {
            const totalSeconds = Math.floor(Math.abs(ms) / 1000);
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const seconds = totalSeconds % 60;
            if (hours > 0) return `${hours}小时 ${minutes}分钟`;
            if (minutes > 0) return `${minutes}分钟 ${seconds}秒`;
            return `${seconds}秒`;
        }
        function updateTimer() {
            if (!IS_USING || !local_end_time) return;
            const now = Date.now() + TIME_OFFSET;
            const endTimeMs = new Date(local_end_time).getTime();
            const diff = endTimeMs - now;
            const heroBox = document.getElementById('heroBox');
            const heroTimeStr = document.getElementById('heroTimeStr');
            const heroLabelItem = document.getElementById('heroLabelItem');
            if (diff > 0) {
                if (heroBox.classList.contains('overdue')) heroBox.classList.remove('overdue');
                heroLabelItem.innerHTML = '剩余可用时长';
                heroTimeStr.innerHTML = formatDurationText(diff);
            } else {
                if (!heroBox.classList.contains('overdue')) heroBox.classList.add('overdue');
                heroLabelItem.innerHTML = '订单已超时';
                heroTimeStr.innerHTML = formatDurationText(diff);
            }
        }
        (function() {
            const url = new URL(window.location.href);
            if (url.searchParams.has('internal_refresh')) {
                url.searchParams.delete('internal_refresh');
                window.history.replaceState({}, '', url.toString());
            }
        })();
        const btn = document.getElementById('callBtn');
        if (!btn.disabled) {
            updateCallBtnUI(<?= $pageData['is_calling'] ? 'true' : 'false' ?>);
        }
        setTimeout(() => {
            const refreshBtn = document.getElementById('refreshBtn');
            refreshBtn.disabled = true;
            showToast('✅', '页面加载成功');
            setTimeout(() => {
                refreshBtn.disabled = false;
            }, 10000); 
        }, 100); 
        function manualRefresh(event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }
            const btn = document.getElementById('refreshBtn');
            btn.classList.add('spinning');
            btn.disabled = true;
            const url = new URL(window.location.href);
            url.searchParams.set('internal_refresh', '1');
            window.location.href = url.toString();
        }
        let isCheckingIn = false;
        async function scanCheckin(promotionId, btnElement) {
            if (isCheckingIn) return;
            const btn = btnElement || document.querySelector('.promo-checkin-btn');
            if (!btn) return;
            const promoName = btn.getAttribute('data-promo-name') || '';
            const isPromo = promotionId > 0;
            const displayedHours = parseFloat(btn.getAttribute('data-promo-hours')) || 0;
            const displayedPrice = parseFloat(btn.getAttribute('data-promo-price')) || 0;
            const displayedStandardPrice = parseFloat(btn.getAttribute('data-standard-price')) || 0;
            const confirmMsg = isPromo 
                ? '确认使用「套餐：' + promoName + '」扫码开台？\n将开始计时，结账时请前往服务台办理。'
                : '确认标准价扫码开台？\n费用按标准价计算，结账时请前往服务台办理。';
            if (!confirm(confirmMsg)) {
                return;
            }
            isCheckingIn = true;
            document.querySelectorAll('.promo-checkin-btn').forEach(b => b.disabled = true);
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<span style="display:flex; flex-direction:column; align-items:center; width:100%;"><span style="font-weight:700;">开台中...</span></span>';
            btn.style.opacity = '0.7';
            try {
                const resp = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        'action': 'scan_checkin',
                        'access_code': ACCESS_CODE,
                        'room_id': ROOM_ID,
                        'client_id': 'qr_' + Date.now(),
                        'promotion_id': promotionId,
                        'displayed_hours': displayedHours,
                        'displayed_price': displayedPrice,
                        'displayed_standard_price': displayedStandardPrice
                    })
                });
                const data = await resp.json();
                if (data.success) {
                    showToast('✅', data.message || '开台成功，计时已开始');
                    setTimeout(() => {
                        const url = new URL(window.location.href);
                        url.searchParams.set('internal_refresh', '1');
                        window.location.href = url.toString();
                    }, 1500);
                } else {
                    showToast('⚠️', data.message || '开台失败');
                    btn.innerHTML = originalHTML;
                    btn.style.opacity = '1';
                    document.querySelectorAll('.promo-checkin-btn').forEach(b => b.disabled = false);
                }
            } catch (e) {
                showToast('⚠️', '网络错误，请重试');
                btn.innerHTML = originalHTML;
                btn.style.opacity = '1';
                document.querySelectorAll('.promo-checkin-btn').forEach(b => b.disabled = false);
            } finally {
                isCheckingIn = false;
            }
        }
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.promo-checkin-btn').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const promoId = parseInt(this.getAttribute('data-promo-id')) || 0;
                    scanCheckin(promoId, this);
                });
            });
        });
        function toggleCall() {
            const btn = document.getElementById('callBtn');
            const isCurrentlyCalling = btn.getAttribute('data-calling') === 'true';
            if (isCurrentlyCalling) {
                cancelCall();
            } else {
                showCallStaffModal();
            }
        }
        function confirmCallStaff() {
            const note = document.getElementById('callNoteInput').value.trim();
            callStaff(note);
            closeCallStaffModal();
        }
        let isCallingApi = false;
        let callDebounceTimer = null; 
        function callStaff(note = '') {
            if (isCallingApi) return;
            if (callDebounceTimer) return;
            isCallingApi = true;
            callDebounceTimer = setTimeout(() => {
                callDebounceTimer = null;
            }, 1000);
            const btn = document.getElementById('callBtn');
            const btnText = document.getElementById('btnText');
            const originalText = btnText.innerText;
            btnText.innerText = '发送中...';
            btn.style.opacity = '0.9';
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({'action': 'call_staff', 'access_code': ACCESS_CODE, 'room_id': ROOM_ID, 'note': note})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('🛎️', data.message || '呼叫成功，店员正赶来为您服务');
                    updateCallBtnUI(true);
                    setTimeout(() => {
                        updateCallBtnUI(false);
                    }, 30000);
                } else {
                    if (data.message && data.message.includes('空闲状态')) {
                        showToast('⚠️', '空闲状态服务暂不可用');
                    }
                    else if (data.message && data.message.includes('访问码')) {
                        window.location.reload();
                        return;
                    }
                    else {
                        showToast('⚠️', data.message || '系统繁忙，请稍后再试');
                    }
                    btnText.innerText = originalText;
                    btn.style.opacity = '1';
                }
            })
            .catch(e => {
                showToast('📡', '网络连接丢失，请检查网络');
                btnText.innerText = originalText;
                btn.style.opacity = '1';
            })
            .finally(() => {
                isCallingApi = false;
            });
        }
        function cancelCall() {
            if (isCallingApi) return;
            if (callDebounceTimer) return;
            isCallingApi = true;
            callDebounceTimer = setTimeout(() => {
                callDebounceTimer = null;
            }, 1000);
            const btn = document.getElementById('callBtn');
            const btnText = document.getElementById('btnText');
            btnText.innerText = '正在取消...';
            btn.style.opacity = '0.9';
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({'action': 'cancel_staff', 'access_code': ACCESS_CODE, 'room_id': ROOM_ID})
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    showToast('🔇', data.message || '已取消通知店员');
                    updateCallBtnUI(false);
                } else {
                    if (data.message && data.message.includes('空闲状态')) {
                        showToast('⚠️', '空闲状态服务暂不可用');
                        return;
                    }
                    showToast('⚠️', data.message || '系统繁忙，请稍后再试');
                }
            })
            .catch(e => {
                showToast('📡', '网络连接较差');
            })
            .finally(() => {
                setTimeout(() => {
                    isCallingApi = false;
                    btn.style.opacity = '1';
                }, 1000);
            });
        }
        function updateCallBtnUI(isCallingFromServer) {
            const btn = document.getElementById('callBtn');
            const btnText = document.getElementById('btnText');
            const btnIcon = document.getElementById('btnIcon');
            if (btn.disabled) return;
            if (!IS_USING) {
                btn.setAttribute('data-calling', isCallingFromServer ? 'true' : 'false');
                if (isCallingFromServer) {
                    btn.style.background = 'linear-gradient(135deg, var(--danger) 0%, #dc2626 100%)';
                    btnText.innerText = '已呼叫服务，点击可取消';
                    btnIcon.innerHTML = '<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>';
                } else {
                    btn.style.background = 'linear-gradient(135deg, var(--primary) 0%, #3b82f6 100%)';
                    btnText.innerText = '呼叫店员';
                    btnIcon.innerHTML = '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path>';
                }
                return;
            }
            btn.setAttribute('data-calling', isCallingFromServer ? 'true' : 'false');
            if (isCallingFromServer) {
                btn.style.background = 'linear-gradient(135deg, var(--danger) 0%, #dc2626 100%)';
                btnText.innerText = '已呼叫服务，点击可取消';
                btnIcon.innerHTML = '<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>';
            } else {
                btn.style.background = 'linear-gradient(135deg, var(--primary) 0%, #3b82f6 100%)';
                btnText.innerText = '呼叫店员';
                btnIcon.innerHTML = '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path>';
            }
        }
        if (IS_USING && START_TIME && local_end_time) {
            updateTimer();
            setInterval(updateTimer, 1000);
        }
    </script>
</body>
</html>
