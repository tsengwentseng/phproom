<?php date_default_timezone_set("Asia/Shanghai");
$dbHost = base64_decode("MTI3LjAuMC4x");
$dbUser = base64_decode("cm9vdA==");
$dbPassword = base64_decode("cm9vbTI1ODQ1NnJvb20=");
$dbName = base64_decode("cm9vbV9tYW5hZ2VtZW50");
if (!function_exists("handleDbError")) {
    function handleDbError($message, $errorDetail = "", $code = 500)
    {
        $isApi =
            isset($_SERVER["PHP_SELF"]) &&
            str_contains($_SERVER["PHP_SELF"], "/api/");
        if ($isApi) {
            http_response_code($code);
            header("Content-Type: application/json; charset=utf-8");
            echo json_encode(
                [
                    "success" => false,
                    "message" => $message,
                    "error" => $errorDetail,
                    "code" => $code,
                ],
                JSON_UNESCAPED_UNICODE,
            );
            exit();
        }
        die($message . ($errorDetail ? ": " . $errorDetail : ""));
    }
}
if (!function_exists("normalizeMemberCardNo")) {
    function normalizeMemberCardNo($memberCardNo)
    {
        if ($memberCardNo === null) {
            return null;
        }
        $memberCardNo = trim((string) $memberCardNo);
        if ($memberCardNo === "") {
            return null;
        }
        return $memberCardNo;
    }
}
$conn = null;
try {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    if ($e->getCode() === 1049) {
        header("Location: ./install/index.php");
        exit();
    }
    handleDbError("数据库连接失败", $e->getMessage(), $e->getCode());
}
if (!function_exists("pushToWebSocket")) {
    function pushToWebSocket($data)
    {
        global $conn;
        try {
            $url = "http://127.0.0.1:9000/api/push";
            $json = json_encode($data, JSON_UNESCAPED_UNICODE);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt(
                $ch,
                CURLOPT_POSTFIELDS,
                json_encode(["msg" => $json], JSON_UNESCAPED_UNICODE),
            );
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json; charset=utf-8",
            ]);
            curl_setopt($ch, CURLOPT_TIMEOUT, 1);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curlError = curl_error($ch);
            curl_close($ch);
            if ($curlError) {
                error_log("pushToWebSocket错误: $curlError");
            }
            return $httpCode === 200;
        } catch (Exception $e) {
            error_log("pushToWebSocket异常: " . $e->getMessage());
            return false;
        }
    }
}
if (!function_exists("updateRefreshFlag")) {
    function updateRefreshFlag()
    {
        global $conn;
        $timestamp = round(microtime(true) * 1000);
        $stmt = $conn->prepare(
            "UPDATE system_config SET config_value = ? WHERE config_key = 'refresh_flag'",
        );
        $stmt->bind_param("s", $timestamp);
        $stmt->execute();
        $stmt->close();
    }
}
if (!function_exists("getCurrentOperatorId")) {
    function getCurrentOperatorId()
    {
        global $conn;
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $userId = null;
        if (isset($_SESSION["front_user_id"])) {
            $userId = (int) $_SESSION["front_user_id"];
        } elseif (isset($_SESSION["admin_user_id"])) {
            $userId = (int) $_SESSION["admin_user_id"];
        }
        if ($userId === null) {
            _denyAccess("未登录或会话已过期");
        }
        static $validatedUsers = [];
        if (isset($validatedUsers[$userId])) {
            return $userId;
        }
        try {
            $stmt = $conn->prepare(
                "SELECT id, is_enabled, is_deleted FROM system_users WHERE id = ? LIMIT 1",
            );
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                _denyAccess("您的账户不存在，请退出登录，联系管理员");
            }
            $user = $result->fetch_assoc();
            if ($user["is_deleted"] == 1) {
                _denyAccess("您的账户已被删除，请退出登录，联系管理员");
            }
            if ($user["is_enabled"] == 0) {
                _denyAccess("您的账户已被停用，请退出登录，联系管理员");
            }
            $validatedUsers[$userId] = true;
            return $userId;
        } catch (Exception $e) {
            error_log("getCurrentOperatorId 验证失败: " . $e->getMessage());
            return $userId;
        }
    }
}
if (!function_exists("_denyAccess")) {
    function _denyAccess($message)
    {
        $isApi =
            isset($_SERVER["PHP_SELF"]) &&
            str_contains($_SERVER["PHP_SELF"], "/api/");
        if ($isApi) {
            http_response_code(403);
            header("Content-Type: application/json; charset=utf-8");
            echo json_encode(
                ["success" => false, "message" => $message, "code" => 403],
                JSON_UNESCAPED_UNICODE,
            );
            exit();
        } else {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION["toast"] = [
                "type" => "error",
                "title" => "权限错误",
                "message" => $message,
            ];
            header("Location: index.php");
            exit();
        }
    }
}
