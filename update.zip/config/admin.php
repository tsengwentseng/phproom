<?php
header("Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
$config_path = __DIR__ . '/config.php';
if (file_exists($config_path)) {
    include($config_path);
} else {
    http_response_code(500);
    echo json_encode(['error' => '配置文件不存在']);
    exit;
}
$SCENE_ROOM_NAME = '房间'; 
$scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'");
if ($scene_stmt) {
    $scene_stmt->execute();
    $scene_result = $scene_stmt->get_result();
    if ($scene_result && $scene_row = $scene_result->fetch_assoc()) {
        $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间';
    }
    $scene_stmt->close();
}
require_once 'auth.php';
requirePageAccess('admin', SESSION_TIMEOUT_ADMIN, '后台管理');
$currentUserId = $_SESSION['admin_user_id'] ?? $_SESSION['front_user_id'] ?? 0;
$currentUsername = $_SESSION['admin_username'] ?? $_SESSION['front_username'] ?? '';
$isSuperAdmin = ($currentUserId == 1); 
function validateUserInput(array $data, bool $isEdit = false): array {
    $errors = [];
    $username = null;  
    if (!$isEdit) {
        $username = trim($data['username'] ?? '');
        if (empty($username)) {
            $errors[] = '用户名不能为空';
        } else {
            if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
                $errors[] = '用户名只能包含字母和数字';
            }
            $username = mb_substr($username, 0, 10);
        }
    }
    $name = mb_substr(trim($data['name'] ?? ''), 0, 10);
    if (empty($name)) {
        $errors[] = '姓名不能为空';
    }
    $password = $data['password'] ?? '';
    if (!empty($password)) {
        $password = mb_substr($password, 0, 20);
        $passwordValidation = validatePassword($password);
        if (!$passwordValidation['valid']) {
            $errors = array_merge($errors, $passwordValidation['errors']);
        }
    } elseif (!$isEdit) {
        $errors[] = '密码不能为空';
    }
    $role = $data['role'] ?? 'front';
    if (!in_array($role, ['admin', 'front'])) {
        $errors[] = '无效的权限角色';
    }
    return [
        'valid' => empty($errors),
        'errors' => $errors,
        'data' => [
            'username' => $username,  
            'name' => $name,
            'password' => $password,  
            'role' => $role
        ]
    ];
}
function isSystemProtectedUser(int $userId, string $username = ''): bool {
    return ($userId === 1 || $username === 'admin');
}
if (isset($_GET['action']) && $_GET['action'] === 'get_users') {
    header('Content-Type: application/json');
    try {
        $stmt = $conn->prepare("SELECT id, username, name, role, is_enabled, is_deleted, create_time FROM system_users ORDER BY id ASC");
        $stmt->execute();
        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        echo json_encode(['success' => true, 'users' => $users]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['add_user']) || (isset($_POST['action']) && $_POST['action'] === 'add_user')) {
    $validation = validateUserInput($_POST, false);
    if (!$validation['valid']) {
        $_SESSION['toast'] = [
            'type' => 'error', 
            'title' => '用户管理', 
            'message' => implode('；', $validation['errors'])
        ];
        header('Location: admin.php#usersSection');
        exit;
    }
    $data = $validation['data'];
    if (!$isSuperAdmin && $data['role'] === 'admin') {
        $_SESSION['toast'] = [
            'type' => 'error', 
            'title' => '用户管理', 
            'message' => '您没有权限添加管理员账户，只能添加前台账户'
        ];
        header('Location: admin.php#usersSection');
        exit;
    }
    try {
        $checkStmt = $conn->prepare("SELECT id FROM system_users WHERE LOWER(username) = LOWER(?) LIMIT 1");
        $checkStmt->bind_param('s', $data['username']);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '用户名已存在'];
            header('Location: admin.php#usersSection');
            exit;
        }
        $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
        $is_enabled = 1; 
        $stmt = $conn->prepare("INSERT INTO system_users (username, name, password, role, is_enabled, is_deleted) VALUES (?, ?, ?, ?, ?, 0)");
        $stmt->bind_param('ssssi', $data['username'], $data['name'], $hashedPassword, $data['role'], $is_enabled);
        if ($stmt->execute()) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '用户管理', 'message' => '添加成功'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '添加用户失败'];
        }
    } catch (Exception $e) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => $e->getMessage()];
    }
    header('Location: admin.php#usersSection');
    exit;
}
if (isset($_POST['edit_user']) || (isset($_POST['action']) && $_POST['action'] === 'edit_user')) {
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '参数错误'];
        header('Location: admin.php#usersSection');
        exit;
    }
    try {
        $userStmt = $conn->prepare("SELECT username, name, role FROM system_users WHERE id = ? LIMIT 1");
        $userStmt->bind_param('i', $id);
        $userStmt->execute();
        $userResult = $userStmt->get_result();
        if ($userResult->num_rows === 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '用户不存在'];
            header('Location: admin.php#usersSection');
            exit;
        }
        $originalUser = $userResult->fetch_assoc();
        if (!$isSuperAdmin && $originalUser['role'] === 'admin' && $id != $currentUserId) {
            $_SESSION['toast'] = [
                'type' => 'error', 
                'title' => '用户管理', 
                'message' => '您没有权限修改其他管理员的资料'
            ];
            header('Location: admin.php#usersSection');
            exit;
        }
        $validation = validateUserInput($_POST, true);
        if (!$validation['valid']) {
            $_SESSION['toast'] = [
                'type' => 'error', 
                'title' => '用户管理', 
                'message' => implode('；', $validation['errors'])
            ];
            header('Location: admin.php#usersSection');
            exit;
        }
        $data = $validation['data'];
        if (isSystemProtectedUser($id, $originalUser['username'])) {
            $data['name'] = $originalUser['name'];
            $data['role'] = $originalUser['role'];
        }
        if (!$isSuperAdmin) {
            $data['role'] = $originalUser['role']; 
        }
        if (!empty($data['password'])) {
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE system_users SET name = ?, password = ?, role = ? WHERE id = ?");
            $stmt->bind_param('sssi', $data['name'], $hashedPassword, $data['role'], $id);
        } else {
            $stmt = $conn->prepare("UPDATE system_users SET name = ?, role = ? WHERE id = ?");
            $stmt->bind_param('ssi', $data['name'], $data['role'], $id);
        }
        if ($stmt->execute()) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '用户管理', 'message' => '更新成功'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '更新用户失败'];
        }
    } catch (Exception $e) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => $e->getMessage()];
    }
    header('Location: admin.php#usersSection');
    exit;
}
if (isset($_GET['delete_user'])) {
    $id = intval($_GET['delete_user']);
    if ($id <= 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '参数错误'];
        header('Location: admin.php#usersSection');
        exit;
    }
    if ($id == $currentUserId) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '不能删除自己的账户'];
        header('Location: admin.php#usersSection');
        exit;
    }
    if (!$isSuperAdmin && $id != $currentUserId) {
        $checkStmt = $conn->prepare("SELECT role FROM system_users WHERE id = ? LIMIT 1");
        $checkStmt->bind_param('i', $id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            $user = $checkResult->fetch_assoc();
            if ($user['role'] === 'admin') {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '您没有权限删除其他管理员'];
                header('Location: admin.php#usersSection');
                exit;
            }
        }
    }
    try {
        $checkStmt = $conn->prepare("SELECT username FROM system_users WHERE id = ? LIMIT 1");
        $checkStmt->bind_param('i', $id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows === 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '用户不存在'];
            header('Location: admin.php#usersSection');
            exit;
        }
        $user = $checkResult->fetch_assoc();
        if (isSystemProtectedUser($id, $user['username'])) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '不能删除系统保护用户'];
            header('Location: admin.php#usersSection');
            exit;
        }
        $tablesToCheck = [
            'member_recharges' => 'operator_id',
            'orders_payment_details' => 'operator_id',
            'reservations' => 'operator_id',
            'product_orders' => 'operator_id',
            'product_stock_records' => 'operator_id',
            'product_credit_for_room' => 'operator_id',
            'time_card_orders' => 'operator_id',
            'time_card_consumptions' => 'operator_id',
            'shift_handovers' => 'operator_id',
            'member_consumptions' => 'operator_id',
            'member_card_transfer_history' => 'operator_id'
        ];
        $hasUsageRecords = false;
        foreach ($tablesToCheck as $tableName => $columnName) {
            $checkSql = "SELECT COUNT(*) as count FROM {$tableName} WHERE {$columnName} = ? LIMIT 1";
            $checkStmt = $conn->prepare($checkSql);
            $checkStmt->bind_param('i', $id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            $row = $result->fetch_assoc();
            if ($row['count'] > 0) {
                $hasUsageRecords = true;
                break;
            }
        }
        if ($hasUsageRecords) {
            $stmt = $conn->prepare("UPDATE system_users SET is_deleted = 1 WHERE id = ?");
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                $_SESSION['toast'] = ['type' => 'success', 'title' => '用户管理', 'message' => '用户已隐藏'];
            } else {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '隐藏用户失败'];
            }
        } else {
            $stmt = $conn->prepare("DELETE FROM system_users WHERE id = ?");
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                $_SESSION['toast'] = ['type' => 'success', 'title' => '用户管理', 'message' => '删除成功'];
            } else {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => '删除用户失败'];
            }
        }
    } catch (Exception $e) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '用户管理', 'message' => $e->getMessage()];
    }
    header('Location: admin.php#usersSection');
    exit;
}
if (isset($_POST['action']) && ($_POST['action'] === 'enable_user' || $_POST['action'] === 'disable_user')) {
    header('Content-Type: application/json');
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => '参数错误']);
        exit;
    }
    if ($id == $currentUserId) {
        echo json_encode(['success' => false, 'message' => '不能操作自己的账户']);
        exit;
    }
    try {
        $isEnable = $_POST['action'] === 'enable_user';
        $checkStmt = $conn->prepare("SELECT username, role FROM system_users WHERE id = ? LIMIT 1");
        $checkStmt->bind_param('i', $id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => '用户不存在']);
            exit;
        }
        $user = $checkResult->fetch_assoc();
        if (!$isSuperAdmin && $user['role'] === 'admin') {
            echo json_encode(['success' => false, 'message' => '您没有权限操作其他管理员']);
            exit;
        }
        if (isSystemProtectedUser($id, $user['username'])) {
            echo json_encode(['success' => false, 'message' => '不能修改系统保护用户的状态']);
            exit;
        }
        $newStatus = $isEnable ? 1 : 0;
        $stmt = $conn->prepare("UPDATE system_users SET is_enabled = ? WHERE id = ?");
        $stmt->bind_param('ii', $newStatus, $id);
        if ($stmt->execute()) {
            $statusText = $isEnable ? '启用' : '停用';
            echo json_encode(['success' => true, 'message' => $statusText . '成功']);
        } else {
            echo json_encode(['success' => false, 'message' => '操作失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
function smartRedirect($defaultSection = '', $preservePosition = true) {
    if ($preservePosition && isset($_SERVER['HTTP_REFERER'])) {
        $referer = $_SERVER['HTTP_REFERER'];
        $host = $_SERVER['HTTP_HOST'];
        $refererParsed = parse_url($referer);
        if (isset($refererParsed['host']) && $refererParsed['host'] === $host) {
            if (isset($refererParsed['path']) && basename($refererParsed['path']) === 'admin.php') {
                header("Location: " . $referer);
                exit;
            }
        }
    }
    $location = 'admin.php';
    if (!empty($defaultSection)) {
        $location .= '#' . $defaultSection;
    }
    header("Location: " . $location);
    exit;
}
function updateRefreshFlag() {
    global $conn;
    $timestamp = date('Y-m-d H:i:s.v'); 
    $stmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = 'refresh_flag'");
    $stmt->bind_param("s", $timestamp);
    $stmt->execute();
    $stmt->close();
    pushToWebSocket([
        'type' => 'page_refresh',
        'exclude_client_id' => '' 
    ]);
}
function nameExists($table, $name, $excludeId = 0) {
    global $conn;
    $allowed_tables = ['rooms', 'products', 'payment_methods', 'promotion_strategies', 'member_levels', 'time_card_products'];
    if (!in_array($table, $allowed_tables)) {
        return "无效的表名";
    }
    $excludeId = intval($excludeId);
    $sql = "SELECT COUNT(*) as count FROM $table WHERE name=? AND is_deleted=0";
    if ($excludeId > 0) {
        $sql .= " AND id!=?";
    }
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return "数据库准备失败";
    }
    if ($excludeId > 0) {
        $stmt->bind_param("si", $name, $excludeId);
    } else {
        $stmt->bind_param("s", $name);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->fetch_assoc()['count'];
    $stmt->close();
    if ($count > 0) {
        return "名称已存在";
    }
    $sql = "SELECT COUNT(*) as count FROM $table WHERE name=? AND is_deleted=1";
    if ($excludeId > 0) {
        $sql .= " AND id!=?";
    }
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return "数据库准备失败";
    }
    if ($excludeId > 0) {
        $stmt->bind_param("si", $name, $excludeId);
    } else {
        $stmt->bind_param("s", $name);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->fetch_assoc()['count'];
    $stmt->close();
    if ($count > 0) {
        return "名称已存在隐藏列中";
    }
    return false;
}
function handleRestoreItem($table, $id, $redirectAction, $section) {
    global $conn;
    $id = intval($id);
    $stmt = $conn->prepare("UPDATE $table SET is_deleted = 0 WHERE id = ?");
    $stmt->bind_param('i', $id);
    $result = $stmt->execute();
    if (in_array($table, ['rooms', 'products', 'payment_methods'])) {
        updateRefreshFlag();
    }
    $title = '';
    $message = '';
    switch($table) {
        case 'rooms':
            $title = $SCENE_ROOM_NAME . '管理';
            $message = $result ? $SCENE_ROOM_NAME . '恢复成功，请刷新前端页面更新！' : $SCENE_ROOM_NAME . '恢复失败，请重试！';
            break;
        case 'products':
            $title = '商品管理';
            $message = $result ? '商品恢复成功，请刷新前端页面更新！' : '商品恢复失败，请重试！';
            break;
        case 'payment_methods':
            $title = '支付方式管理';
            $message = $result ? '支付方式恢复成功，请刷新前端页面更新！' : '支付方式恢复失败，请重试！';
            break;
        case 'system_users':
            $title = '用户管理';
            $message = $result ? '用户恢复成功' : '用户恢复失败，请重试！';
            break;
    }
    $_SESSION['toast'] = [
        'type' => $result ? 'success' : 'error',
        'title' => $title,
        'message' => $message
    ];
    smartRedirect($section, false);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_purpose_tags') {
    header('Content-Type: application/json');
    $sql = "SELECT id, name, usage_count, is_deleted FROM purpose_tags WHERE is_deleted = 0 ORDER BY usage_count DESC, id ASC";
    $result = $conn->query($sql);
    $tags = [];
    while ($row = $result->fetch_assoc()) {
        $tags[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $tags]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'add_purpose_tag') {
    header('Content-Type: application/json');
    $name = trim($_POST['name'] ?? '');
    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => '标签名称不能为空']);
        exit;
    }
    if (mb_strlen($name) > 30) {
        echo json_encode(['success' => false, 'message' => '标签名称不能超过30个字']);
        exit;
    }
    $check_stmt = $conn->prepare("SELECT id, is_deleted FROM purpose_tags WHERE name = ?");
    $check_stmt->bind_param('s', $name);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    if ($result->num_rows > 0) {
        $existing = $result->fetch_assoc();
        if ($existing['is_deleted'] == 1) {
            $restore_stmt = $conn->prepare("UPDATE purpose_tags SET is_deleted = 0 WHERE id = ?");
            $restore_stmt->bind_param('i', $existing['id']);
            if ($restore_stmt->execute()) {
                echo json_encode(['success' => true, 'message' => '标签已恢复']);
            } else {
                echo json_encode(['success' => false, 'message' => '标签恢复失败']);
            }
            exit;
        } else {
            echo json_encode(['success' => false, 'message' => '标签已存在']);
            exit;
        }
    }
    $stmt = $conn->prepare("INSERT INTO purpose_tags (name, usage_count, is_deleted) VALUES (?, 0, 0)");
    $stmt->bind_param('s', $name);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => '标签添加成功']);
    } else {
        echo json_encode(['success' => false, 'message' => '标签添加失败']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'delete_purpose_tag') {
    header('Content-Type: application/json');
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => '无效的标签ID']);
        exit;
    }
    $check_stmt = $conn->prepare("SELECT usage_count FROM purpose_tags WHERE id = ?");
    $check_stmt->bind_param('i', $id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => '标签不存在']);
        exit;
    }
    $tag = $result->fetch_assoc();
    if ($tag['usage_count'] > 0) {
        $stmt = $conn->prepare("UPDATE purpose_tags SET is_deleted = 1 WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '用途标签', 'message' => '标签已隐藏'];
            echo json_encode(['success' => true, 'message' => '标签已隐藏']);
        } else {
            echo json_encode(['success' => false, 'message' => '标签隐藏失败']);
        }
    } else {
        $stmt = $conn->prepare("DELETE FROM purpose_tags WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '用途标签', 'message' => '标签删除成功'];
            echo json_encode(['success' => true, 'message' => '标签删除成功']);
        } else {
            echo json_encode(['success' => false, 'message' => '标签删除失败']);
        }
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'edit_purpose_tag') {
    header('Content-Type: application/json');
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => '无效的标签ID']);
        exit;
    }
    if (empty($name)) {
        echo json_encode(['success' => false, 'message' => '标签名称不能为空']);
        exit;
    }
    if (mb_strlen($name) > 30) {
        echo json_encode(['success' => false, 'message' => '标签名称不能超过30个字']);
        exit;
    }
    $check_stmt = $conn->prepare("SELECT id FROM purpose_tags WHERE name = ? AND id != ?");
    $check_stmt->bind_param('si', $name, $id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    if ($result->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => '标签名称已存在']);
        exit;
    }
    $stmt = $conn->prepare("UPDATE purpose_tags SET name = ? WHERE id = ?");
    $stmt->bind_param('si', $name, $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => '标签编辑成功']);
    } else {
        echo json_encode(['success' => false, 'message' => '标签编辑失败']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'restore_purpose_tag') {
    header('Content-Type: application/json');
    $id = intval($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => '无效的标签 ID']);
        exit;
    }
    $stmt = $conn->prepare("UPDATE purpose_tags SET is_deleted = 0 WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $_SESSION['toast'] = ['type' => 'success', 'title' => '用途标签', 'message' => '标签恢复成功'];
        echo json_encode(['success' => true, 'message' => '标签恢复成功']);
    } else {
        echo json_encode(['success' => false, 'message' => '标签恢复失败']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_qrcode_list') {
    header('Content-Type: application/json');
    $sql = "
        SELECT 
            rac.id,
            rac.room_id,
            rac.access_code,
            rac.is_enabled,
            rac.scan_count,
            rac.last_scanned_at,
            rac.create_time,
            r.name AS room_name,
            r.type AS room_type
        FROM room_access_codes rac
        INNER JOIN rooms r ON rac.room_id = r.id
        WHERE r.is_deleted = 0
        ORDER BY r.sort_order, r.id
    ";
    $result = $conn->query($sql);
    $qrcodes = [];
    while ($row = $result->fetch_assoc()) {
        $qrcodes[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $qrcodes]);
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_enabled_qrcodes') {
    header('Content-Type: application/json');
    $domain_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'qr_domain'");
    $domain_stmt->execute();
    $domain_result = $domain_stmt->get_result();
    $domain_row = $domain_result->fetch_assoc();
    $domain = $domain_row ? rtrim($domain_row['config_value'], '/') : '';
    $sql = "
        SELECT 
            rac.room_id,
            rac.access_code,
            r.name AS room_name
        FROM room_access_codes rac
        INNER JOIN rooms r ON rac.room_id = r.id
        WHERE r.is_deleted = 0 AND rac.is_enabled = 1
        ORDER BY r.sort_order, r.id
    ";
    $result = $conn->query($sql);
    $qrcodes = [];
    while ($row = $result->fetch_assoc()) {
        $row['qr_url'] = $domain . '/config/room_qr.php?code=' . $row['access_code'];
        $qrcodes[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $qrcodes, 'domain' => $domain]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'sync_qrcodes') {
    header('Content-Type: application/json');
    $rooms_sql = "SELECT id FROM rooms WHERE is_deleted = 0";
    $rooms_result = $conn->query($rooms_sql);
    $active_room_ids = [];
    while ($row = $rooms_result->fetch_assoc()) {
        $active_room_ids[] = intval($row['id']);
    }
    if (!empty($active_room_ids)) {
        $ids_str = implode(',', $active_room_ids);
        $delete_sql = "DELETE FROM room_access_codes WHERE room_id NOT IN ($ids_str)";
    } else {
        $delete_sql = "DELETE FROM room_access_codes";
    }
    $conn->query($delete_sql);
    $deleted_count = $conn->affected_rows;
    $added_count = 0;
    foreach ($active_room_ids as $room_id) {
        $check_stmt = $conn->prepare("SELECT id FROM room_access_codes WHERE room_id = ?");
        $check_stmt->bind_param('i', $room_id);
        $check_stmt->execute();
        if ($check_stmt->get_result()->num_rows === 0) {
            $access_code = bin2hex(random_bytes(8));
            $insert_stmt = $conn->prepare("INSERT INTO room_access_codes (room_id, access_code, is_enabled) VALUES (?, ?, 1)");
            $insert_stmt->bind_param('is', $room_id, $access_code);
            if ($insert_stmt->execute()) {
                $added_count++;
            }
        }
    }
    echo json_encode([
        'success' => true,
        'message' => sprintf('同步成功：新增 %d 个桌码，删除 %d 个多余桌码', $added_count, $deleted_count)
    ]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_generate') {
    header('Content-Type: application/json');
    $qrcodes_sql = "SELECT room_id FROM room_access_codes";
    $qrcodes_result = $conn->query($qrcodes_sql);
    $updated = 0;
    while ($row = $qrcodes_result->fetch_assoc()) {
        $room_id = $row['room_id'];
        $access_code = bin2hex(random_bytes(8));
        $update_stmt = $conn->prepare("UPDATE room_access_codes SET access_code = ?, is_enabled = 1, scan_count = 0, update_time = CURRENT_TIMESTAMP WHERE room_id = ?");
        $update_stmt->bind_param('si', $access_code, $room_id);
        if ($update_stmt->execute()) {
            $updated++;
        }
    }
    echo json_encode([
        'success' => true, 
        'message' => sprintf('批量重置成功，共更新 %d 个' . $SCENE_ROOM_NAME . '访问码', $updated)
    ]);
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_all_qr_codes') {
    header('Content-Type: application/json');
    try {
        $sql = "
            SELECT 
                rac.room_id,
                rac.access_code,
                r.name AS room_name
            FROM room_access_codes rac
            INNER JOIN rooms r ON rac.room_id = r.id
            WHERE r.is_deleted = 0 AND rac.is_enabled = 1
            ORDER BY r.sort_order, r.id
        ";
        $result = $conn->query($sql);
        if (!$result || $result->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => '没有可用的二维码']);
            exit;
        }
        $qr_codes = [];
        while ($row = $result->fetch_assoc()) {
            $qr_codes[] = [
                'room_id' => $row['room_id'],
                'room_name' => $row['room_name'],
                'access_code' => $row['access_code']
            ];
        }
        echo json_encode(['success' => true, 'data' => $qr_codes]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => '获取失败：' . $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'regenerate') {
    header('Content-Type: application/json');
    $room_id = intval($_POST['room_id'] ?? 0);
    if ($room_id <= 0) {
        echo json_encode(['success' => false, 'message' => '无效的' . $SCENE_ROOM_NAME . ' ID']);
        exit;
    }
    $access_code = bin2hex(random_bytes(8)); 
    $check_stmt = $conn->prepare("SELECT id FROM room_access_codes WHERE room_id = ?");
    $check_stmt->bind_param('i', $room_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    if ($check_result->num_rows > 0) {
        $update_stmt = $conn->prepare("UPDATE room_access_codes SET access_code = ?, is_enabled = 1, scan_count = 0, update_time = CURRENT_TIMESTAMP WHERE room_id = ?");
        $update_stmt->bind_param('si', $access_code, $room_id);
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '访问码已重新生成']);
        } else {
            echo json_encode(['success' => false, 'message' => '重新生成失败']);
        }
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO room_access_codes (room_id, access_code, is_enabled) VALUES (?, ?, 1)");
        $insert_stmt->bind_param('is', $room_id, $access_code);
        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '访问码已生成']);
        } else {
            echo json_encode(['success' => false, 'message' => '生成失败']);
        }
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    header('Content-Type: application/json');
    $room_id = intval($_POST['room_id'] ?? 0);
    $is_enabled = intval($_POST['is_enabled'] ?? 0);
    if ($room_id <= 0) {
        echo json_encode(['success' => false, 'message' => "无效的{$SCENE_ROOM_NAME} ID"]);
        exit;
    }
    if ($is_enabled == 1) {
        $room_check_stmt = $conn->prepare("SELECT is_enabled FROM rooms WHERE id = ?");
        $room_check_stmt->bind_param('i', $room_id);
        $room_check_stmt->execute();
        $room_result = $room_check_stmt->get_result();
        $room_data = $room_result ? $room_result->fetch_assoc() : null;
        if (!$room_data || $room_data['is_enabled'] == 0) {
            echo json_encode(['success' => false, 'message' => '此' . $SCENE_ROOM_NAME . '处于停用状态，访问码无法开启。']);
            exit;
        }
    }
    $stmt = $conn->prepare("UPDATE room_access_codes SET is_enabled = ?, update_time = CURRENT_TIMESTAMP WHERE room_id = ?");
    $stmt->bind_param('ii', $is_enabled, $room_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => $is_enabled ? '已启用' : '已停用']);
    } else {
        echo json_encode(['success' => false, 'message' => '操作失败']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'delete_qrcode') {
    header('Content-Type: application/json');
    $room_id = intval($_POST['room_id'] ?? 0);
    if ($room_id <= 0) {
        echo json_encode(['success' => false, 'message' => '无效的' . $SCENE_ROOM_NAME . ' ID']);
        exit;
    }
    $stmt = $conn->prepare("DELETE FROM room_access_codes WHERE room_id = ?");
    $stmt->bind_param('i', $room_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => '桌码已删除']);
    } else {
        echo json_encode(['success' => false, 'message' => '删除失败']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'save_qr_domain') {
    header('Content-Type: application/json');
    $domain = trim($_POST['domain'] ?? '');
    if (empty($domain)) {
        echo json_encode(['success' => false, 'message' => '域名不能为空']);
        exit;
    }
    if (!preg_match('/^https?:\/\/.+/i', $domain)) {
        echo json_encode(['success' => false, 'message' => '域名必须以 http://或https://开头']);
        exit;
    }
    if (!filter_var($domain, FILTER_VALIDATE_URL)) {
        echo json_encode(['success' => false, 'message' => '请输入有效的网址格式']);
        exit;
    }
    $check_stmt = $conn->prepare("SELECT id FROM system_config WHERE config_key = 'qr_domain'");
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    if ($check_result->num_rows > 0) {
        $update_stmt = $conn->prepare("UPDATE system_config SET config_value = ?, config_description = '二维码生成域名', is_visible = 0 WHERE config_key = 'qr_domain'");
        $update_stmt->bind_param('s', $domain);
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '域名已保存']);
        } else {
            echo json_encode(['success' => false, 'message' => '保存失败']);
        }
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_type, config_group, config_description, is_visible) VALUES ('qr_domain', ?, 'string', 'system', '二维码生成域名', 0)");
        $insert_stmt->bind_param('s', $domain);
        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '域名已保存']);
        } else {
            echo json_encode(['success' => false, 'message' => '保存失败']);
        }
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_qr_domain') {
    header('Content-Type: application/json');
    $stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'qr_domain'");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $row['config_value']]);
    } else {
        echo json_encode(['success' => true, 'data' => '']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'save_qr_notice') {
    header('Content-Type: application/json');
    $notice = trim($_POST['notice'] ?? '');
    if (mb_strlen($notice) > 200) {
        echo json_encode(['success' => false, 'message' => '公告内容不能超过 200 字']);
        exit;
    }
    $clean_notice = strip_tags($notice, '<br>');
    $check_stmt = $conn->prepare("SELECT id FROM system_config WHERE config_key = 'qr_notice'");
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    if ($check_result->num_rows > 0) {
        $update_stmt = $conn->prepare("UPDATE system_config SET config_value = ?, config_description = '商家公告内容', is_visible = 0 WHERE config_key = 'qr_notice'");
        $update_stmt->bind_param('s', $clean_notice);
        if ($update_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '公告已保存']);
        } else {
            echo json_encode(['success' => false, 'message' => '保存失败']);
        }
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_type, config_group, config_description, is_visible) VALUES ('qr_notice', ?, 'string', 'system', '商家公告内容', 0)");
        $insert_stmt->bind_param('s', $clean_notice);
        if ($insert_stmt->execute()) {
            echo json_encode(['success' => true, 'message' => '公告已保存']);
        } else {
            echo json_encode(['success' => false, 'message' => '保存失败']);
        }
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_qr_notice') {
    header('Content-Type: application/json');
    $stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'qr_notice'");
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['success' => true, 'data' => $row['config_value']]);
    } else {
        echo json_encode(['success' => true, 'data' => '']);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_room_types') {
    header('Content-Type: application/json');
    $sql = "SELECT DISTINCT UPPER(type) as type FROM rooms WHERE type IS NOT NULL AND type != '' ORDER BY type ASC";
    $result = $conn->query($sql);
    $types = [];
    while ($row = $result->fetch_assoc()) {
        $types[] = $row['type'];
    }
    echo json_encode(['success' => true, 'data' => $types]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_product_types') {
    header('Content-Type: application/json');
    $sql = "SELECT DISTINCT UPPER(type) as type FROM products WHERE type IS NOT NULL AND type != '' ORDER BY type ASC";
    $result = $conn->query($sql);
    $types = [];
    while ($row = $result->fetch_assoc()) {
        $types[] = $row['type'];
    }
    echo json_encode(['success' => true, 'data' => $types]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'get_promotion_types') {
    header('Content-Type: application/json');
    $sql = "SELECT DISTINCT UPPER(type) as type FROM promotion_strategies WHERE type IS NOT NULL AND type != '' ORDER BY type ASC";
    $result = $conn->query($sql);
    $types = [];
    while ($row = $result->fetch_assoc()) {
        $types[] = $row['type'];
    }
    echo json_encode(['success' => true, 'data' => $types]);
    exit;
}
if (isset($_POST['action']) && in_array($_POST['action'], ['save_order', 'save_product_order', 'save_payment_order', 'save_promotion_order', 'save_member_level_order', 'save_time_card_order'])) {
    header('Content-Type: application/json');
    try {
        $conn->begin_transaction();
        $cases = [];
        $params = [];
        $ids = array_keys($_POST['order']);
        if ($_POST['action'] === 'save_order') {
            $table = 'rooms';
        } elseif ($_POST['action'] === 'save_product_order') {
            $table = 'products';
        } elseif ($_POST['action'] === 'save_promotion_order') {
            $table = 'promotion_strategies';
        } elseif ($_POST['action'] === 'save_member_level_order') {
            $table = 'member_levels';
        } elseif ($_POST['action'] === 'save_time_card_order') {
            $table = 'time_card_products';
        } else {
            $table = 'payment_methods';
        }
        foreach ($_POST['order'] as $id => $order) {
            $cases[] = "WHEN ? THEN ?";
            array_push($params, (int)$id, (int)$order);
        }
        $sql = "UPDATE $table SET sort_order = CASE id ".implode(' ', $cases)." END WHERE id IN (".implode(',', array_fill(0, count($ids), '?')).")";
        $params = array_merge($params, $ids);
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(str_repeat('i', count($params)), ...$params);
        $stmt->execute();
        $conn->commit();
        updateRefreshFlag();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (($_GET['db_manager'] ?? $_POST['db_manager'] ?? false)) {
    set_time_limit(0);
    ini_set('memory_limit', '512M');
    error_reporting(E_ERROR);
    ini_set('display_errors', 0);
    $backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backups';
    if (!is_dir($backupDir)) {
        if (!mkdir($backupDir, 0755, true)) {
            logOperation('SYSTEM', "创建备份目录失败", $backupDir);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => '创建备份目录失败']);
            exit;
        }
    }
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && isset($_GET['file'])) {
        downloadBackup();
        exit;
    }
    header('Content-Type: application/json');
    match ($_SERVER['REQUEST_METHOD'] ?? '') {
        'POST' => handleBackupPostRequest(),
        default => handleBackupDefaultRequest()
    };
    exit; 
}
function handleBackupPostRequest(): void {
    $action = $_POST['action'] ?? '';
    if ($action === 'start') {
        $currentUserId = $_SESSION['admin_user_id'] ?? $_SESSION['front_user_id'] ?? 0;
        if ($currentUserId != 1) {
            echo json_encode(['success' => false, 'message' => '本操作仅支持admin用户操作！']);
            exit;
        }
    }
    match ($action) {
        'backup' => createBackup(),
        'auto_backup' => createAutoBackup(),
        'list' => listBackups(),
        'delete' => deleteBackup(),
        'start' => startRestore(),
        'progress' => getRestoreProgress(),
        default => handleBackupUnknownAction()
    };
}
function handleBackupDefaultRequest(): void {
    echo json_encode(['success' => false, 'message' => '请求方法不支持']);
}
function handleBackupUnknownAction(): void {
    echo json_encode(['success' => false, 'message' => '未知的操作类型']);
}
if (isset($_POST['action']) && ($_POST['action'] === 'enable_room' || $_POST['action'] === 'disable_room')) {
    header('Content-Type: application/json');
    $roomId = $_POST['room_id'] ?? 0;
    if (empty($roomId)) {
        echo json_encode(['success' => false, 'message' => $SCENE_ROOM_NAME . 'ID不能为空']);
        exit;
    }
    try {
        $isEnable = $_POST['action'] === 'enable_room';
        if ($isEnable) {
            $stmt = $conn->prepare("UPDATE rooms SET is_enabled = 1 WHERE id = ?");
            $stmt->bind_param('i', $roomId);
        } else {
            $active_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
            $active_stmt->bind_param('i', $roomId);
            $active_stmt->execute();
            $active_result = $active_stmt->get_result();
            $active_count = $active_result ? $active_result->fetch_assoc()['count'] : 0;
            $reservation_stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE room_id = ? AND status IN (0, 1)");
            $reservation_stmt->bind_param('i', $roomId);
            $reservation_stmt->execute();
            $reservation_result = $reservation_stmt->get_result();
            $reservation_count = $reservation_result ? $reservation_result->fetch_assoc()['count'] : 0;
            if ($active_count > 0 || $reservation_count > 0) {
                echo json_encode(['success' => false, 'message' => $SCENE_ROOM_NAME . '有正在使用或预定使用的订单，无法停用！']);
                exit;
            }
            $stmt = $conn->prepare("UPDATE rooms SET is_enabled = 0 WHERE id = ?");
            $stmt->bind_param('i', $roomId);
        }
        if ($stmt->execute()) {
            $qrcode_stmt = $conn->prepare("
                UPDATE room_access_codes 
                SET is_enabled = ?
                WHERE room_id = ?
            ");
            $qrcode_is_enabled = $isEnable ? 1 : 0;
            $qrcode_stmt->bind_param('ii', $qrcode_is_enabled, $roomId);
            $qrcode_stmt->execute();
            updateRefreshFlag();
            $actionText = $isEnable ? '启用' : '停用';
            echo json_encode(['success' => true, 'message' => $SCENE_ROOM_NAME . $actionText . '成功，请刷新前端页面更新！']);
        } else {
            echo json_encode(['success' => false, 'message' => '更新' . $SCENE_ROOM_NAME . '状态失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_update_rooms') {
    header('Content-Type: application/json');
    $room_ids = explode(',', $_POST['room_ids'] ?? '');
    $room_ids = array_filter(array_map('intval', $room_ids));
    if (empty($room_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的' . $SCENE_ROOM_NAME]);
        exit;
    }
    $type = isset($_POST['type']) && $_POST['type'] !== '' ? strtoupper(trim($_POST['type'])) : null;
    $standard_price = isset($_POST['standard_price']) && $_POST['standard_price'] !== '' ? floatval($_POST['standard_price']) : null;
    $member_discount = isset($_POST['member_discount']) && $_POST['member_discount'] !== '' ? intval($_POST['member_discount']) : null;
    $enable_member_levels_discount = isset($_POST['enable_member_levels_discount']) && $_POST['enable_member_levels_discount'] !== '' ? intval($_POST['enable_member_levels_discount']) : null;
    if ($type === null && $standard_price === null && $member_discount === null && $enable_member_levels_discount === null) {
        echo json_encode(['success' => false, 'message' => '请至少填写一个要修改的字段']);
        exit;
    }
    if ($type !== null && mb_strlen($type, 'UTF-8') > 10) {
        echo json_encode(['success' => false, 'message' => $SCENE_ROOM_NAME . '类型最多10个字符！']);
        exit;
    }
    if ($standard_price !== null) {
        if ($standard_price < 0) {
            echo json_encode(['success' => false, 'message' => '标准价格不能为负数！']);
            exit;
        }
        if ($standard_price > 9999) {
            echo json_encode(['success' => false, 'message' => '标准价格不能超过9999元！']);
            exit;
        }
    }
    if ($member_discount !== null) {
        if ($member_discount < 1 || $member_discount > 100) {
            echo json_encode(['success' => false, 'message' => '会员折扣必须在1-100之间！']);
            exit;
        }
    }
    try {
        $success_count = 0;
        $skipped_rooms = [];
        $failed_rooms = [];
        $unchanged_count = 0;
        foreach ($room_ids as $room_id) {
            $activeOrderStmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
            $activeOrderStmt->bind_param('i', $room_id);
            $activeOrderStmt->execute();
            $activeOrderResult = $activeOrderStmt->get_result();
            $activeOrderCount = $activeOrderResult->fetch_assoc()['count'];
            if ($activeOrderCount > 0) {
                $skipped_rooms[] = $room_id;
                continue;
            }
            $updates = [];
            $params = [];
            $types = '';
            if ($type !== null) {
                $updates[] = "type = ?";
                $params[] = $type;
                $types .= 's';
            }
            if ($standard_price !== null) {
                $updates[] = "standard_price = ?";
                $params[] = $standard_price;
                $types .= 'd';
                $enable_standard_price = ($standard_price > 0) ? 1 : 0;
                $updates[] = "enable_standard_price = ?";
                $params[] = $enable_standard_price;
                $types .= 'i';
            }
            if ($member_discount !== null) {
                $updates[] = "member_discount = ?";
                $params[] = $member_discount;
                $types .= 'i';
            }
            if ($enable_member_levels_discount !== null) {
                $updates[] = "enable_member_levels_discount = ?";
                $params[] = $enable_member_levels_discount;
                $types .= 'i';
            }
            $params[] = $room_id;
            $types .= 'i';
            $sql = "UPDATE rooms SET " . implode(', ', $updates) . " WHERE id = ? AND is_deleted = 0";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            } else {
                $failed_rooms[] = $room_id;
            }
        }
        updateRefreshFlag();
        $message_parts = [];
        if ($success_count > 0) {
            $message_parts[] = "{$success_count} 个{$SCENE_ROOM_NAME}已修改";
        }
        if ($unchanged_count > 0) {
            $field_descriptions = [];
            if ($type !== null) {
                $field_descriptions[] = "类型为{$type}";
            }
            if ($standard_price !== null) {
                $field_descriptions[] = "标准价为{$standard_price}元";
            }
            if ($member_discount !== null) {
                $field_descriptions[] = "会员折扣为{$member_discount}%";
            }
            if ($enable_member_levels_discount !== null) {
                $field_descriptions[] = ($enable_member_levels_discount ? "已启用" : "已停用") . "会员等级折扣";
            }
            $field_desc = implode("、", $field_descriptions);
            $message_parts[] = "{$unchanged_count} 个{$SCENE_ROOM_NAME}已是{$field_desc}";
        }
        if (!empty($skipped_rooms)) {
            $message_parts[] = count($skipped_rooms) . " 个{$SCENE_ROOM_NAME}因有订单而跳过";
        }
        if (!empty($failed_rooms)) {
            $message_parts[] = count($failed_rooms) . " 个{$SCENE_ROOM_NAME}修改失败";
        }
        if ($success_count > 0 || $unchanged_count > 0) {
            $message = "批量修改完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            if (!empty($skipped_rooms)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '都有订单，无法修改'];
                echo json_encode(['success' => false]);
            } elseif (!empty($failed_rooms)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '修改失败'];
                echo json_encode(['success' => false]);
            } else {
                $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '的值已相同，无需修改'];
                echo json_encode(['success' => true]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_enable_rooms') {
    header('Content-Type: application/json');
    $room_ids = explode(',', $_POST['room_ids'] ?? '');
    $room_ids = array_filter(array_map('intval', $room_ids));
    if (empty($room_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的' . $SCENE_ROOM_NAME]);
        exit;
    }
    try {
        $success_count = 0;
        $failed_rooms = [];
        $unchanged_count = 0;
        foreach ($room_ids as $room_id) {
            $stmt = $conn->prepare("UPDATE rooms SET is_enabled = 1 WHERE id = ? AND is_deleted = 0");
            $stmt->bind_param('i', $room_id);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $qr_stmt = $conn->prepare("UPDATE room_access_codes SET is_enabled = 1 WHERE room_id = ?");
                    $qr_stmt->bind_param('i', $room_id);
                    $qr_stmt->execute();
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            } else {
                $failed_rooms[] = $room_id;
            }
        }
        updateRefreshFlag();
        if ($success_count > 0 || $unchanged_count > 0) {
            $message_parts = [];
            if ($success_count > 0) {
                $message_parts[] = "{$success_count} 个{$SCENE_ROOM_NAME}已启用";
            }
            if ($unchanged_count > 0) {
                $message_parts[] = "{$unchanged_count} 个{$SCENE_ROOM_NAME}已是启用状态";
            }
            if (!empty($failed_rooms)) {
                $message_parts[] = count($failed_rooms) . " 个{$SCENE_ROOM_NAME}启用失败";
            }
            $message = "批量启用完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '启用失败'];
            echo json_encode(['success' => false]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_disable_rooms') {
    header('Content-Type: application/json');
    $room_ids = explode(',', $_POST['room_ids'] ?? '');
    $room_ids = array_filter(array_map('intval', $room_ids));
    if (empty($room_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的' . $SCENE_ROOM_NAME]);
        exit;
    }
    try {
        $success_count = 0;
        $skipped_rooms = [];
        $unchanged_count = 0;
        foreach ($room_ids as $room_id) {
            $active_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
            $active_stmt->bind_param('i', $room_id);
            $active_stmt->execute();
            $active_result = $active_stmt->get_result();
            $active_count = $active_result->fetch_assoc()['count'];
            $reservation_stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE room_id = ? AND status IN (0, 1)");
            $reservation_stmt->bind_param('i', $room_id);
            $reservation_stmt->execute();
            $reservation_result = $reservation_stmt->get_result();
            $reservation_count = $reservation_result->fetch_assoc()['count'];
            if ($active_count > 0 || $reservation_count > 0) {
                $skipped_rooms[] = $room_id;
                continue;
            }
            $stmt = $conn->prepare("UPDATE rooms SET is_enabled = 0 WHERE id = ? AND is_deleted = 0");
            $stmt->bind_param('i', $room_id);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $qr_stmt = $conn->prepare("UPDATE room_access_codes SET is_enabled = 0 WHERE room_id = ?");
                    $qr_stmt->bind_param('i', $room_id);
                    $qr_stmt->execute();
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            }
        }
        updateRefreshFlag();
        if ($success_count > 0 || $unchanged_count > 0) {
            $message_parts = [];
            if ($success_count > 0) {
                $message_parts[] = "{$success_count} 个{$SCENE_ROOM_NAME}已停用";
            }
            if ($unchanged_count > 0) {
                $message_parts[] = "{$unchanged_count} 个{$SCENE_ROOM_NAME}已是停用状态";
            }
            if (!empty($skipped_rooms)) {
                $message_parts[] = count($skipped_rooms) . " 个{$SCENE_ROOM_NAME}因有订单或预定而跳过";
            }
            $message = "批量停用完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            if (!empty($skipped_rooms)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '都有订单或预定，无法停用'];
                echo json_encode(['success' => false]);
            } else {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '批量停用失败'];
                echo json_encode(['success' => false]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_delete_rooms') {
    header('Content-Type: application/json');
    $room_ids = explode(',', $_POST['room_ids'] ?? '');
    $room_ids = array_filter(array_map('intval', $room_ids));
    if (empty($room_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的' . $SCENE_ROOM_NAME]);
        exit;
    }
    try {
        $soft_delete_ids = [];
        $hard_delete_ids = [];
        $skipped_rooms = [];
        foreach ($room_ids as $room_id) {
            $active_order_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
            $active_order_stmt->bind_param('i', $room_id);
            $active_order_stmt->execute();
            $active_order_result = $active_order_stmt->get_result();
            $active_order_count = $active_order_result->fetch_assoc()['count'];
            if ($active_order_count > 0) {
                $skipped_rooms[] = $room_id;
                continue;
            }
            $active_reservation_stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE room_id = ? AND status = 0");
            $active_reservation_stmt->bind_param('i', $room_id);
            $active_reservation_stmt->execute();
            $active_reservation_result = $active_reservation_stmt->get_result();
            $active_reservation_count = $active_reservation_result->fetch_assoc()['count'];
            if ($active_reservation_count > 0) {
                $skipped_rooms[] = $room_id;
                continue;
            }
            $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ?");
            $check_stmt->bind_param('i', $room_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $order_count = $check_result->fetch_assoc()['count'];
            if ($order_count > 0) {
                $soft_delete_ids[] = $room_id;
            } else {
                $hard_delete_ids[] = $room_id;
            }
        }
        $soft_count = 0;
        $hard_count = 0;
        if (!empty($soft_delete_ids)) {
            foreach ($soft_delete_ids as $room_id) {
                $stmt = $conn->prepare("UPDATE rooms SET is_deleted = 1 WHERE id = ?");
                $stmt->bind_param('i', $room_id);
                if ($stmt->execute()) {
                    $soft_count++;
                    $qr_stmt = $conn->prepare("UPDATE room_access_codes SET is_enabled = 0 WHERE room_id = ?");
                    $qr_stmt->bind_param('i', $room_id);
                    $qr_stmt->execute();
                }
            }
        }
        if (!empty($hard_delete_ids)) {
            foreach ($hard_delete_ids as $room_id) {
                $stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
                $stmt->bind_param('i', $room_id);
                if ($stmt->execute()) {
                    $hard_count++;
                    $qr_stmt = $conn->prepare("DELETE FROM room_access_codes WHERE room_id = ?");
                    $qr_stmt->bind_param('i', $room_id);
                    $qr_stmt->execute();
                }
            }
        }
        updateRefreshFlag();
        $message_parts = [];
        if ($soft_count > 0) {
            $message_parts[] = "{$soft_count} 个{$SCENE_ROOM_NAME}已软删除";
        }
        if ($hard_count > 0) {
            $message_parts[] = "{$hard_count} 个{$SCENE_ROOM_NAME}已删除";
        }
        if (!empty($skipped_rooms)) {
            $message_parts[] = count($skipped_rooms) . " 个{$SCENE_ROOM_NAME}因有订单或预定而跳过";
        }
        if ($soft_count > 0 || $hard_count > 0) {
            $message = "批量删除完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            if (!empty($skipped_rooms)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '所有' . $SCENE_ROOM_NAME . '都有订单或预定，无法删除'];
                echo json_encode(['success' => false]);
            } else {
                $_SESSION['toast'] = ['type' => 'warning', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '未删除任何' . $SCENE_ROOM_NAME];
                echo json_encode(['success' => true]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_update_products') {
    header('Content-Type: application/json');
    $product_ids = explode(',', $_POST['product_ids'] ?? '');
    $product_ids = array_filter(array_map('intval', $product_ids));
    if (empty($product_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的商品']);
        exit;
    }
    $type = isset($_POST['type']) && $_POST['type'] !== '' ? strtoupper(trim($_POST['type'])) : null;
    $price = isset($_POST['price']) && $_POST['price'] !== '' ? floatval($_POST['price']) : null;
    $member_discount = isset($_POST['member_discount']) && $_POST['member_discount'] !== '' ? intval($_POST['member_discount']) : null;
    $enable_member_levels_discount = isset($_POST['enable_member_levels_discount']) && $_POST['enable_member_levels_discount'] !== '' ? intval($_POST['enable_member_levels_discount']) : null;
    $allow_zero_stock = isset($_POST['allow_zero_stock']) && $_POST['allow_zero_stock'] !== '' ? intval($_POST['allow_zero_stock']) : null;
    if ($type === null && $price === null && $member_discount === null && $enable_member_levels_discount === null && $allow_zero_stock === null) {
        echo json_encode(['success' => false, 'message' => '请至少填写一个要修改的字段']);
        exit;
    }
    if ($type !== null && mb_strlen($type, 'UTF-8') > 10) {
        echo json_encode(['success' => false, 'message' => '商品类型最多10个字符！']);
        exit;
    }
    if ($price !== null) {
        if ($price < 0) {
            echo json_encode(['success' => false, 'message' => '商品价格不能为负数！']);
            exit;
        }
        if ($price > 9999) {
            echo json_encode(['success' => false, 'message' => '商品价格不能超过9999元！']);
            exit;
        }
    }
    if ($member_discount !== null) {
        if ($member_discount < 1 || $member_discount > 100) {
            echo json_encode(['success' => false, 'message' => '会员折扣必须在1-100之间！']);
            exit;
        }
    }
    try {
        $success_count = 0;
        $skipped_products = [];
        $failed_products = [];
        $unchanged_count = 0;
        foreach ($product_ids as $product_id) {
            $activeProductOrderStmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ? AND status = 0");
            $activeProductOrderStmt->bind_param('i', $product_id);
            $activeProductOrderStmt->execute();
            $activeProductOrderResult = $activeProductOrderStmt->get_result();
            $activeProductOrderCount = $activeProductOrderResult->fetch_assoc()['count'];
            $creditProductStmt = $conn->prepare("SELECT COUNT(*) as count FROM product_credit_for_room WHERE product_id = ?");
            $creditProductStmt->bind_param('i', $product_id);
            $creditProductStmt->execute();
            $creditProductResult = $creditProductStmt->get_result();
            $creditProductCount = $creditProductResult->fetch_assoc()['count'];
            if ($activeProductOrderCount > 0 || $creditProductCount > 0) {
                $skipped_products[] = $product_id;
                continue;
            }
            $updates = [];
            $params = [];
            $types = '';
            if ($type !== null) {
                $updates[] = "type = ?";
                $params[] = $type;
                $types .= 's';
            }
            if ($price !== null) {
                $updates[] = "price = ?";
                $params[] = $price;
                $types .= 'd';
            }
            if ($member_discount !== null) {
                $updates[] = "member_discount = ?";
                $params[] = $member_discount;
                $types .= 'i';
            }
            if ($enable_member_levels_discount !== null) {
                $updates[] = "enable_member_levels_discount = ?";
                $params[] = $enable_member_levels_discount;
                $types .= 'i';
            }
            if ($allow_zero_stock !== null) {
                $updates[] = "allow_zero_stock = ?";
                $params[] = $allow_zero_stock;
                $types .= 'i';
            }
            $params[] = $product_id;
            $types .= 'i';
            $sql = "UPDATE products SET " . implode(', ', $updates) . " WHERE id = ? AND is_deleted = 0";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($types, ...$params);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            } else {
                $failed_products[] = $product_id;
            }
        }
        updateRefreshFlag();
        $message_parts = [];
        if ($success_count > 0) {
            $message_parts[] = "{$success_count} 个商品已修改";
        }
        if ($unchanged_count > 0) {
            $field_names = [
                'type' => '类型',
                'price' => '价格',
                'cost' => '成本',
                'stock' => '库存',
                'stock_alert' => '库存预警',
                'unit' => '单位',
                'description' => '描述'
            ];
            $field_label = $field_names[$field] ?? $field;
            $message_parts[] = "{$unchanged_count} 个商品{$field_label}已是{$value}";
        }
        if (!empty($skipped_products)) {
            $message_parts[] = count($skipped_products) . " 个商品因有订单或挂单而跳过";
        }
        if (!empty($failed_products)) {
            $message_parts[] = count($failed_products) . " 个商品修改失败";
        }
        if ($success_count > 0 || $unchanged_count > 0) {
            $message = "批量修改完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            if (!empty($skipped_products)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '所有商品都有订单或挂单，无法修改'];
                echo json_encode(['success' => false]);
            } elseif (!empty($failed_products)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '所有商品修改失败'];
                echo json_encode(['success' => false]);
            } else {
                $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => '所有商品的值已相同，无需修改'];
                echo json_encode(['success' => true]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_enable_products') {
    header('Content-Type: application/json');
    $product_ids = explode(',', $_POST['product_ids'] ?? '');
    $product_ids = array_filter(array_map('intval', $product_ids));
    if (empty($product_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的商品']);
        exit;
    }
    try {
        $success_count = 0;
        $failed_products = [];
        $unchanged_count = 0;
        foreach ($product_ids as $product_id) {
            $stmt = $conn->prepare("UPDATE products SET is_enabled = 1 WHERE id = ? AND is_deleted = 0");
            $stmt->bind_param('i', $product_id);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            } else {
                $failed_products[] = $product_id;
            }
        }
        updateRefreshFlag();
        if ($success_count > 0 || $unchanged_count > 0) {
            $message_parts = [];
            if ($success_count > 0) {
                $message_parts[] = "{$success_count} 个商品已启用";
            }
            if ($unchanged_count > 0) {
                $message_parts[] = "{$unchanged_count} 个商品已是启用状态";
            }
            if (!empty($failed_products)) {
                $message_parts[] = count($failed_products) . " 个商品启用失败";
            }
            $message = "批量启用完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '所有商品启用失败'];
            echo json_encode(['success' => false]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_disable_products') {
    header('Content-Type: application/json');
    $product_ids = explode(',', $_POST['product_ids'] ?? '');
    $product_ids = array_filter(array_map('intval', $product_ids));
    if (empty($product_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的商品']);
        exit;
    }
    try {
        $success_count = 0;
        $skipped_products = [];
        $unchanged_count = 0;
        foreach ($product_ids as $product_id) {
            $active_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ? AND status = 0");
            $active_stmt->bind_param('i', $product_id);
            $active_stmt->execute();
            $active_result = $active_stmt->get_result();
            $active_count = $active_result->fetch_assoc()['count'];
            $credit_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_credit_for_room WHERE product_id = ?");
            $credit_stmt->bind_param('i', $product_id);
            $credit_stmt->execute();
            $credit_result = $credit_stmt->get_result();
            $credit_count = $credit_result->fetch_assoc()['count'];
            if ($active_count > 0 || $credit_count > 0) {
                $skipped_products[] = $product_id;
                continue;
            }
            $stmt = $conn->prepare("UPDATE products SET is_enabled = 0 WHERE id = ? AND is_deleted = 0");
            $stmt->bind_param('i', $product_id);
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $success_count++;
                } else {
                    $unchanged_count++;
                }
            }
        }
        updateRefreshFlag();
        if ($success_count > 0 || $unchanged_count > 0) {
            $message_parts = [];
            if ($success_count > 0) {
                $message_parts[] = "{$success_count} 个商品已停用";
            }
            if ($unchanged_count > 0) {
                $message_parts[] = "{$unchanged_count} 个商品已是停用状态";
            }
            if (!empty($skipped_products)) {
                $message_parts[] = count($skipped_products) . " 个商品因有订单或挂单而跳过";
            }
            $message = "批量停用完成：" . implode("，", $message_parts);
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => $message];
            echo json_encode(['success' => true]);
        } else {
            if (!empty($skipped_products)) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '所有商品都有订单或挂单，无法停用'];
                echo json_encode(['success' => false]);
            } else {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '批量停用失败'];
                echo json_encode(['success' => false]);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_delete_products') {
    header('Content-Type: application/json');
    $product_ids = explode(',', $_POST['product_ids'] ?? '');
    $product_ids = array_filter(array_map('intval', $product_ids));
    if (empty($product_ids)) {
        echo json_encode(['success' => false, 'message' => '请选择要操作的商品']);
        exit;
    }
    try {
        $soft_delete_ids = [];
        $hard_delete_ids = [];
        foreach ($product_ids as $product_id) {
            $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ?");
            $check_stmt->bind_param('i', $product_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $order_count = $check_result->fetch_assoc()['count'];
            if ($order_count > 0) {
                $soft_delete_ids[] = $product_id;
            } else {
                $hard_delete_ids[] = $product_id;
            }
        }
        $soft_count = 0;
        $hard_count = 0;
        if (!empty($soft_delete_ids)) {
            $soft_placeholders = implode(',', array_fill(0, count($soft_delete_ids), '?'));
            $soft_sql = "UPDATE products SET is_deleted = 1 WHERE id IN ($soft_placeholders)";
            $soft_stmt = $conn->prepare($soft_sql);
            $soft_types = str_repeat('i', count($soft_delete_ids));
            $soft_stmt->bind_param($soft_types, ...$soft_delete_ids);
            if ($soft_stmt->execute()) {
                $soft_count = $soft_stmt->affected_rows;
            }
        }
        if (!empty($hard_delete_ids)) {
            $hard_placeholders = implode(',', array_fill(0, count($hard_delete_ids), '?'));
            $hard_sql = "DELETE FROM products WHERE id IN ($hard_placeholders)";
            $hard_stmt = $conn->prepare($hard_sql);
            $hard_types = str_repeat('i', count($hard_delete_ids));
            $hard_stmt->bind_param($hard_types, ...$hard_delete_ids);
            if ($hard_stmt->execute()) {
                $hard_count = $hard_stmt->affected_rows;
            }
        }
        updateRefreshFlag();
        $message = '';
        if ($soft_count > 0 && $hard_count > 0) {
            $message = "批量删除完成：{$soft_count} 个商品已软删除，{$hard_count} 个商品已删除";
        } elseif ($soft_count > 0) {
            $message = "批量删除完成：{$soft_count} 个商品已软删除";
        } elseif ($hard_count > 0) {
            $message = "批量删除完成：{$hard_count} 个商品已删除";
        } else {
            $message = "未删除任何商品";
        }
        $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => $message];
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_add_rooms') {
    header('Content-Type: application/json');
    try {
        $pattern = trim($_POST['name_pattern'] ?? '');
        $quantity = intval($_POST['quantity'] ?? 0);
        $type = strtoupper(trim($_POST['type'] ?? ''));
        $standard_price = floatval($_POST['standard_price'] ?? 0);
        $member_discount = intval($_POST['member_discount'] ?? 100);
        $enable_member_levels_discount = intval($_POST['enable_member_levels_discount'] ?? 0);
        if (empty($pattern)) {
            throw new Exception($SCENE_ROOM_NAME . '名模式不能为空');
        }
        if ($quantity <= 0) {
            throw new Exception('生成数量必须大于0');
        }
        if ($quantity > 99) {
            throw new Exception('单次批量生成数量不能超过99');
        }
        if (empty($type)) {
            throw new Exception($SCENE_ROOM_NAME . '类型不能为空');
        }
        if (mb_strlen($type, 'UTF-8') > 10) {
            throw new Exception($SCENE_ROOM_NAME . '类型最多10个字符');
        }
        if ($member_discount < 1 || $member_discount > 100) {
            throw new Exception('会员折扣必须在1-100之间');
        }
        if ($member_discount < 100 && $standard_price <= 0) {
            throw new Exception('会员折扣小于100时，标准价必须大于0');
        }
        if ($standard_price < 0) {
            throw new Exception('标准价格不能为负数');
        }
        if ($standard_price > 9999) {
            throw new Exception('标准价格不能超过9999元');
        }
        preg_match_all('/%([A-Za-z]|[0-9]+)%/', $pattern, $matches, PREG_OFFSET_CAPTURE);
        $wildcards = $matches[0];
        if (count($wildcards) === 0) {
            throw new Exception($SCENE_ROOM_NAME . '名模式必须包含至少一个通配符（如%A%或%1%）');
        }
        if (count($wildcards) > 2) {
            throw new Exception($SCENE_ROOM_NAME . '名模式最多支持2个通配符');
        }
        $conn->begin_transaction();
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM rooms");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $nextSort = $maxSort + 1;
        $createdCount = 0;
        $skippedCount = 0;
        for ($i = 0; $i < $quantity; $i++) {
            $name = $pattern;
            $isValid = true;
            foreach ($wildcards as $wc) {
                $wcText = $wc[0]; 
                $wcVal = trim($wcText, '%');
                $replacement = "";
                if (preg_match('/^[A-Za-z]$/', $wcVal)) {
                    $wcVal = strtoupper($wcVal);
                    $startCode = ord($wcVal);
                    $currentCode = $startCode + $i;
                    $limit = ord('Z');
                    if ($currentCode > $limit) {
                        $isValid = false;
                        break;
                    }
                    $replacement = chr($currentCode);
                } else if (is_numeric($wcVal)) {
                    $startNum = intval($wcVal);
                    $currentNum = $startNum + $i;
                    if ($currentNum > 999) {
                        $isValid = false;
                        break;
                    }
                    $replacement = (string)$currentNum;
                }
                $name = preg_replace('/' . preg_quote($wcText, '/') . '/', $replacement, $name, 1);
            }
            if (!$isValid) break;
            $name = strtoupper($name);
            if (mb_strlen($name, 'UTF-8') > 10) {
                continue;
            }
            if (nameExists('rooms', $name, 0)) {
                $skippedCount++;
                continue;
            }
            $enable_standard_price = ($standard_price > 0) ? 1 : 0;
            $stmt = $conn->prepare("INSERT INTO rooms (name, type, standard_price, enable_standard_price, member_discount, enable_member_levels_discount, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt) {
                throw new Exception('数据库准备失败: ' . $conn->error);
            }
            $stmt->bind_param("ssddiii", $name, $type, $standard_price, $enable_standard_price, $member_discount, $enable_member_levels_discount, $nextSort);
            if ($stmt->execute()) {
                $nextSort++;
                $createdCount++;
            }
            $stmt->close();
        }
        $conn->commit();
        updateRefreshFlag();
        $msg = "批量添加完成：成功创建 {$createdCount} 个{$SCENE_ROOM_NAME}";
        if ($skippedCount > 0) {
            $msg .= "，自动跳过 {$skippedCount} 个已存在的名称";
        }
        echo json_encode(['success' => true, 'message' => $msg]);
    } catch (Exception $e) {
        if ($conn->in_transaction) $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
function handleRoomSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['id']) : 0;
    $name = trim($data['name'] ?? '');
    $type = strtoupper(trim($data['type'] ?? '')); 
    $standard_price = floatval($data['standard_price'] ?? 0);
    $enable_standard_price = ($standard_price > 0) ? 1 : 0;
    $member_discount = intval($data['member_discount'] ?? 100);
    $enable_member_levels_discount = isset($data['enable_member_levels_discount']) ? intval($data['enable_member_levels_discount']) : 0;
    $device_enabled = isset($data['device_enabled']) ? 1 : 0;
    $device_ip = trim($data['device_ip'] ?? '');
    $device_port = intval($data['device_port'] ?? null);
    $device_protocol = trim($data['device_protocol'] ?? '');
    $device_commands = trim($data['device_commands'] ?? '');
    $device_workflow = trim($data['device_workflow'] ?? '');
    if (empty($name)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '名称不能为空！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if (mb_strlen($name, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '名称最多10个字符！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if (empty($type)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '类型不能为空！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if (mb_strlen($type, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '类型最多10个字符！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if (empty($member_discount)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '会员折扣不能为空！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($member_discount < 1 || $member_discount > 100) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '会员折扣必须在1-100之间！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($member_discount < 100 && $standard_price <= 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '会员折扣小于100时，标准价必须大于0！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($standard_price < 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '标准价格不能为负数！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($standard_price > 9999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '标准价格不能超过9999元！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($device_enabled && $device_port > 0) {
        if ($device_port < 1 || $device_port > 65535) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '设备端口必须在1-65535之间！'];
            smartRedirect('roomSection', false);
            exit;
        }
    }
    if ($nameError = nameExists('rooms', $name, $id)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '名称' . $name . '已存在，请修改重试！'];
        smartRedirect('roomSection', false);
        exit;
    }
    if ($mode === 'add') {
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM rooms");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO rooms (name, type, standard_price, enable_standard_price, member_discount, enable_member_levels_discount,
                                  device_enabled, device_ip, device_port, device_protocol, device_commands, device_workflow, sort_order) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('roomSection', false);
            exit;
        }
        $device_ip_val = $device_ip !== '' ? $device_ip : null;
        $device_port_val = $device_port > 0 ? $device_port : null;
        $device_protocol_val = $device_protocol !== '' ? $device_protocol : null;
        $device_commands_val = $device_commands !== '' ? $device_commands : null;
        $device_workflow_val = $device_workflow !== '' ? $device_workflow : null;
        $types = 'ssddiii';
        $params = [$name, $type, $standard_price, $enable_standard_price, $member_discount, $enable_member_levels_discount, $device_enabled];
        $types .= 's';
        $params[] = $device_ip_val;
        $types .= 'i';
        $params[] = $device_port_val;
        $types .= 's';
        $params[] = $device_protocol_val;
        $types .= 's';
        $params[] = $device_commands_val;
        $types .= 's';
        $params[] = $device_workflow_val;
        $types .= 'i';
        $params[] = $sortOrder;
        $stmt->bind_param($types, ...$params);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '添加成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '添加失败，请重试！'];
        }
    } else {
        $activeOrderStmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
        $activeOrderStmt->bind_param('i', $id);
        $activeOrderStmt->execute();
        $activeOrderResult = $activeOrderStmt->get_result();
        $activeOrderCount = $activeOrderResult ? $activeOrderResult->fetch_assoc()['count'] : 0;
        $activeOrderStmt->close();
        if ($activeOrderCount > 0) {
            $currentRoomStmt = $conn->prepare("SELECT name, type, standard_price, enable_standard_price, member_discount, enable_member_levels_discount FROM rooms WHERE id = ?");
            $currentRoomStmt->bind_param('i', $id);
            $currentRoomStmt->execute();
            $currentRoomResult = $currentRoomStmt->get_result();
            $currentRoom = $currentRoomResult->fetch_assoc();
            $currentRoomStmt->close();
            $hasNonDeviceChange = false;
            if ($currentRoom['name'] !== $name) $hasNonDeviceChange = true;
            if ($currentRoom['type'] !== $type) $hasNonDeviceChange = true;
            if (abs($currentRoom['standard_price'] - $standard_price) > 0.001) $hasNonDeviceChange = true;
            if ($currentRoom['enable_standard_price'] != $enable_standard_price) $hasNonDeviceChange = true;
            if ($currentRoom['member_discount'] != $member_discount) $hasNonDeviceChange = true;
            if ($currentRoom['enable_member_levels_discount'] != $enable_member_levels_discount) $hasNonDeviceChange = true;
            if ($hasNonDeviceChange) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '有正在进行中的订单，只能修改设备控制相关信息，其他信息请等待订单结账后再修改。'];
                smartRedirect('roomSection', false);
                exit;
            }
        }
        $stmt = $conn->prepare("UPDATE rooms SET name=?, type=?, standard_price=?, 
                      enable_standard_price=?, member_discount=?,
                      enable_member_levels_discount=?,
                      device_enabled=?, device_ip=?, 
                      device_port=?, 
                      device_protocol=?, 
                      device_commands=?, 
                      device_workflow=?
                WHERE id=?");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('roomSection', false);
            exit;
        }
        $device_ip_val = $device_ip !== '' ? $device_ip : null;
        $device_port_val = $device_port > 0 ? $device_port : null;
        $device_protocol_val = $device_protocol !== '' ? $device_protocol : null;
        $device_commands_val = $device_commands !== '' ? $device_commands : null;
        $device_workflow_val = $device_workflow !== '' ? $device_workflow : null;
        $types = 'ssddiii';
        $params = [$name, $type, $standard_price, $enable_standard_price, $member_discount, $enable_member_levels_discount, $device_enabled];
        $types .= 's';
        $params[] = $device_ip_val;
        $types .= 'i';
        $params[] = $device_port_val;
        $types .= 's';
        $params[] = $device_protocol_val;
        $types .= 's';
        $params[] = $device_commands_val;
        $types .= 's';
        $params[] = $device_workflow_val;
        $types .= 'i';
        $params[] = $id;
        $stmt->bind_param($types, ...$params);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '编辑成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '编辑失败，请重试！'];
        }
    }
    smartRedirect('roomSection');
    exit;
}
if (isset($_GET['delete_rooms'])) {
    $id = intval($_GET['delete_rooms']);
    $active_order_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ? AND status = 0");
    $active_order_stmt->bind_param('i', $id);
    $active_order_stmt->execute();
    $active_order_result = $active_order_stmt->get_result();
    $active_order_count = $active_order_result ? $active_order_result->fetch_assoc()['count'] : 0;
    if ($active_order_count > 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '有正在使用或预定使用的订单，无法删除！'];
        smartRedirect('roomSection', false);
        exit;
    }
    $active_reservation_stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE room_id = ? AND status = 0");
    $active_reservation_stmt->bind_param('i', $id);
    $active_reservation_stmt->execute();
    $active_reservation_result = $active_reservation_stmt->get_result();
    $active_reservation_count = $active_reservation_result ? $active_reservation_result->fetch_assoc()['count'] : 0;
    if ($active_reservation_count > 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '有正在使用或预定使用的订单，无法删除！'];
        smartRedirect('roomSection', false);
        exit;
    }
    $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE room_id = ?");
    $check_stmt->bind_param('i', $id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $order_count = $check_result ? $check_result->fetch_assoc()['count'] : 0;
    if ($order_count > 0) {
        $stmt = $conn->prepare("UPDATE rooms SET is_deleted = 1 WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        if ($result) {
            $mute_stmt = $conn->prepare("
                UPDATE room_access_codes 
                SET is_enabled = 0
                WHERE room_id = ?
            ");
            $mute_stmt->bind_param('i', $id);
            $mute_stmt->execute();
        }
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '已隐藏，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '隐藏失败，请重试！'];
        }
    } else {
        $stmt = $conn->prepare("DELETE FROM rooms WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        if ($result) {
            $qrcode_stmt = $conn->prepare("DELETE FROM room_access_codes WHERE room_id = ?");
            $qrcode_stmt->bind_param('i', $id);
            $qrcode_stmt->execute();
        }
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '删除成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => $SCENE_ROOM_NAME . '管理', 'message' => $SCENE_ROOM_NAME . '删除失败，请重试！'];
        }
    }
    smartRedirect('roomSection');
    exit;
}
if (isset($_GET['restore_room'])) {
    handleRestoreItem('rooms', $_GET['restore_room'], 'room_restored', 'roomSection');
}
if (isset($_POST['add'])) {
    handleRoomSubmit($_POST, 'add');
}
if (isset($_POST['edit'])) {
    handleRoomSubmit($_POST, 'edit');
}
if (isset($_POST['action']) && ($_POST['action'] === 'enable_product' || $_POST['action'] === 'disable_product')) {
    header('Content-Type: application/json');
    $productId = $_POST['product_id'] ?? 0;
    if (empty($productId)) {
        echo json_encode(['success' => false, 'message' => '商品ID不能为空']);
        exit;
    }
    try {
        $isEnable = $_POST['action'] === 'enable_product';
        if ($isEnable) {
            $stmt = $conn->prepare("UPDATE products SET is_enabled = 1 WHERE id = ?");
            $stmt->bind_param('i', $productId);
        } else {
            $active_product_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ? AND status = 0");
            $active_product_stmt->bind_param('i', $productId);
            $active_product_stmt->execute();
            $active_product_result = $active_product_stmt->get_result();
            $active_product_count = $active_product_result ? $active_product_result->fetch_assoc()['count'] : 0;
            $credit_product_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_credit_for_room WHERE product_id = ?");
            $credit_product_stmt->bind_param('i', $productId);
            $credit_product_stmt->execute();
            $credit_product_result = $credit_product_stmt->get_result();
            $credit_product_count = $credit_product_result ? $credit_product_result->fetch_assoc()['count'] : 0;
            if ($active_product_count > 0 || $credit_product_count > 0) {
                echo json_encode(['success' => false, 'message' => '商品有正在进行中的订单或挂单记录，无法停用！']);
                exit;
            }
            $stmt = $conn->prepare("UPDATE products SET is_enabled = 0 WHERE id = ?");
            $stmt->bind_param('i', $productId);
        }
        if ($stmt->execute()) {
            updateRefreshFlag();
            $actionText = $isEnable ? '启用' : '停用';
            echo json_encode(['success' => true, 'message' => '商品' . $actionText . '成功，请刷新前端页面更新！']);
        } else {
            echo json_encode(['success' => false, 'message' => '更新商品状态失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_stock_products') {
    header('Content-Type: application/json');
    $type = $_GET['type'] ?? '';
    $is_enabled = $_GET['is_enabled'] ?? '';
    $is_deleted = $_GET['is_deleted'] ?? '';
    $sql = "SELECT id, name, type, price, stock_quantity, allow_zero_stock, is_enabled, is_deleted 
            FROM products 
            WHERE 1=1";
    $params = [];
    $types = '';
    if (!empty($type)) {
        $sql .= " AND type = ?";
        $params[] = $type;
        $types .= 's';
    }
    if ($is_enabled !== '') {
        $sql .= " AND is_enabled = ?";
        $params[] = (int)$is_enabled;
        $types .= 'i';
    }
    if ($is_deleted !== '') {
        $sql .= " AND is_deleted = ?";
        $params[] = (int)$is_deleted;
        $types .= 'i';
    }
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $products = [];
    while ($row = $result->fetch_assoc()) {
        $products[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'type' => strtoupper($row['type']), 
            'price' => (float)$row['price'],
            'stock_quantity' => (int)$row['stock_quantity'],
            'allow_zero_stock' => (int)$row['allow_zero_stock'],
            'is_enabled' => (int)$row['is_enabled'],
            'is_deleted' => (int)$row['is_deleted']
        ];
    }
    echo json_encode(['success' => true, 'data' => $products]);
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_stock_history') {
    header('Content-Type: application/json');
    $batch_no = $_GET['batch_no'] ?? '';
    $start_date = $_GET['start_date'] ?? '';
    $end_date = $_GET['end_date'] ?? '';
    $sql = "SELECT psr.*, su.name as operator_name 
            FROM product_stock_records psr
            LEFT JOIN system_users su ON psr.operator_id = su.id
            WHERE 1=1";
    $params = [];
    $types = '';
    if (!empty($batch_no)) {
        $sql .= " AND psr.batch_no LIKE ?";
        $params[] = "%{$batch_no}%";
        $types .= 's';
    }
    if (!empty($start_date)) {
        $sql .= " AND psr.create_time >= ?";
        $params[] = $start_date . ' 00:00:00';
        $types .= 's';
    }
    if (!empty($end_date)) {
        $sql .= " AND psr.create_time <= ?";
        $params[] = $end_date . ' 23:59:59';
        $types .= 's';
    }
    $sql .= " ORDER BY psr.create_time DESC";
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = [
            'id' => (int)$row['id'],
            'batch_no' => $row['batch_no'],
            'product_id' => (int)$row['product_id'],
            'product_name' => $row['product_name'],
            'current_stock' => (int)$row['current_stock'],
            'in_quantity' => (int)$row['in_quantity'],
            'loss_quantity' => (int)$row['loss_quantity'],
            'stock_quantity' => (int)$row['stock_quantity'],
            'unit_price' => (float)$row['unit_price'],
            'total_amount' => (float)$row['total_amount'],
            'create_time' => $row['create_time'],
            'operator_name' => $row['operator_name']
        ];
    }
    echo json_encode(['success' => true, 'data' => $records]);
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'batch_stock_in') {
    header('Content-Type: application/json');
    $items_json = $_POST['items'] ?? '';
    $items = json_decode($items_json, true);
    if (!is_array($items) || empty($items)) {
        echo json_encode(['success' => false, 'message' => '没有要入库的商品']);
        exit;
    }
    try {
        $conn->begin_transaction();
        $today = date('Ymd');
        $batch_query = "SELECT IFNULL(MAX(CAST(SUBSTRING(batch_no, 11) AS UNSIGNED)), 0) as max_id 
                       FROM product_stock_records 
                       WHERE SUBSTRING(batch_no, 1, 10) = ? 
                       FOR UPDATE";
        $stmt = $conn->prepare($batch_query);
        $prefix = 'RK' . $today;
        $stmt->bind_param("s", $prefix);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $next_id = intval($row['max_id']) + 1;
        $batch_no = 'RK' . $today . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
        foreach ($items as $item) {
            $product_id = (int)($item['product_id'] ?? 0);
            $in_quantity = (int)($item['in_quantity'] ?? 0);
            $loss_quantity = (int)($item['loss_quantity'] ?? 0);
            $unit_price = (float)($item['unit_price'] ?? 0);
            $total_amount = (float)($item['total_amount'] ?? 0);
            if ($product_id <= 0) {
                throw new Exception('商品ID无效');
            }
            if ($in_quantity < 0 || $loss_quantity < 0) {
                throw new Exception('入库数量和损耗数量不能为负数');
            }
            if ($in_quantity > 9999 || $loss_quantity > 9999) {
                throw new Exception('入库数量和损耗数量不能超过9999');
            }
            if ($in_quantity == 0 && $loss_quantity == 0) {
                throw new Exception('入库数量和损耗数量不能同时为0');
            }
            if ($unit_price < 0 || $total_amount < 0) {
                throw new Exception('单价和总金额不能为负数');
            }
            if ($unit_price > 99999 || $total_amount > 99999) {
                throw new Exception('单价和总金额不能超过99999');
            }
            if (round($unit_price, 2) != $unit_price || round($total_amount, 2) != $total_amount) {
                throw new Exception('单价和总金额最多保留2位小数');
            }
            $stmt = $conn->prepare("SELECT id, name, stock_quantity FROM products WHERE id = ? AND is_deleted = 0 FOR UPDATE");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                throw new Exception('商品不存在或已被删除');
            }
            $product = $result->fetch_assoc();
            $current_stock = (int)$product['stock_quantity'];
            $product_name = $product['name'];
            $new_stock = $current_stock + $in_quantity - $loss_quantity;
            $operatorId = getCurrentOperatorId();
            $stmt = $conn->prepare("INSERT INTO product_stock_records 
                (batch_no, product_id, product_name, current_stock, in_quantity, loss_quantity, stock_quantity, unit_price, total_amount, operator_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sisiiiiddi", $batch_no, $product_id, $product_name, $current_stock, $in_quantity, $loss_quantity, $new_stock, $unit_price, $total_amount, $operatorId);
            if (!$stmt->execute()) {
                throw new Exception("商品【{$product_name}】插入入库记录失败");
            }
            $stmt = $conn->prepare("UPDATE products SET stock_quantity = ? WHERE id = ?");
            $stmt->bind_param("ii", $new_stock, $product_id);
            if (!$stmt->execute()) {
                throw new Exception("商品【{$product_name}】更新库存失败");
            }
        }
        $conn->commit();
        updateRefreshFlag();
        $_SESSION['toast'] = [
            'type' => 'success',
            'title' => '商品管理',
            'message' => '商品入库成功，请刷新前端页面更新！'
        ];
        echo json_encode([
            'success' => true,
            'message' => '入库成功',
            'data' => [
                'batch_no' => $batch_no,
                'count' => count($items)
            ]
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && $_POST['action'] === 'stock_in') {
    header('Content-Type: application/json');
    $product_id = (int)($_POST['product_id'] ?? 0);
    $in_quantity = (int)($_POST['in_quantity'] ?? 0);
    $loss_quantity = (int)($_POST['loss_quantity'] ?? 0);
    $unit_price = (float)($_POST['unit_price'] ?? 0);
    $total_amount = (float)($_POST['total_amount'] ?? 0);
    $batch_no = trim($_POST['batch_no'] ?? '');
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => '商品ID无效']);
        exit;
    }
    if ($in_quantity < 0 || $loss_quantity < 0) {
        echo json_encode(['success' => false, 'message' => '入库数量和损耗数量不能为负数']);
        exit;
    }
    if ($in_quantity > 9999 || $loss_quantity > 9999) {
        echo json_encode(['success' => false, 'message' => '入库数量和损耗数量不能超过9999']);
        exit;
    }
    if ($in_quantity == 0 && $loss_quantity == 0) {
        echo json_encode(['success' => false, 'message' => '入库数量和损耗数量不能同时为0']);
        exit;
    }
    if ($unit_price < 0 || $total_amount < 0) {
        echo json_encode(['success' => false, 'message' => '单价和总金额不能为负数']);
        exit;
    }
    if ($unit_price > 99999 || $total_amount > 99999) {
        echo json_encode(['success' => false, 'message' => '单价和总金额不能超过99999']);
        exit;
    }
    if (round($unit_price, 2) != $unit_price || round($total_amount, 2) != $total_amount) {
        echo json_encode(['success' => false, 'message' => '单价和总金额最多保留2位小数']);
        exit;
    }
    try {
        $conn->begin_transaction();
        if (empty($batch_no)) {
            $today = date('Ymd');
            $batch_query = "SELECT IFNULL(MAX(CAST(SUBSTRING(batch_no, 11) AS UNSIGNED)), 0) as max_id 
                           FROM product_stock_records 
                           WHERE SUBSTRING(batch_no, 1, 10) = ? 
                           FOR UPDATE";
            $stmt = $conn->prepare($batch_query);
            $prefix = 'RK' . $today;
            $stmt->bind_param("s", $prefix);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $next_id = intval($row['max_id']) + 1;
            $batch_no = 'RK' . $today . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
        }
        $stmt = $conn->prepare("SELECT id, name, stock_quantity FROM products WHERE id = ? AND is_deleted = 0 FOR UPDATE");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            throw new Exception('商品不存在或已被删除');
        }
        $product = $result->fetch_assoc();
        $current_stock = (int)$product['stock_quantity'];
        $product_name = $product['name'];
        $new_stock = $current_stock + $in_quantity - $loss_quantity;
        $operatorId = getCurrentOperatorId();
        $stmt = $conn->prepare("INSERT INTO product_stock_records 
            (batch_no, product_id, product_name, current_stock, in_quantity, loss_quantity, stock_quantity, unit_price, total_amount, operator_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisiiiiddi", $batch_no, $product_id, $product_name, $current_stock, $in_quantity, $loss_quantity, $new_stock, $unit_price, $total_amount, $operatorId);
        if (!$stmt->execute()) {
            throw new Exception('插入入库记录失败');
        }
        $stmt = $conn->prepare("UPDATE products SET stock_quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $new_stock, $product_id);
        if (!$stmt->execute()) {
            throw new Exception('更新商品库存失败');
        }
        $conn->commit();
        updateRefreshFlag();
        echo json_encode([
            'success' => true,
            'message' => '入库成功',
            'data' => [
                'batch_no' => $batch_no,
                'product_name' => $product_name,
                'old_stock' => $current_stock,
                'new_stock' => $new_stock,
                'unit_price' => $unit_price,
                'total_amount' => $total_amount
            ]
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
function handleProductSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['product_id']) : 0;
    $name = trim($data['product_name'] ?? '');
    $type = strtoupper(trim($data['product_type'] ?? '')); 
    $price = floatval($data['product_price']);
    $member_discount = intval($data['product_member_discount'] ?? 100);
    $allow_zero_stock = isset($data['product_allow_zero_stock']) ? intval($data['product_allow_zero_stock']) : 0;
    $enable_member_levels_discount = isset($data['product_enable_member_levels_discount']) ? intval($data['product_enable_member_levels_discount']) : 0;
    if (empty($name)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品名称不能为空！'];
        smartRedirect('productSection', false);
        exit;
    }
    if (mb_strlen($name, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品名称最多10个字符！'];
        smartRedirect('productSection', false);
        exit;
    }
    if (empty($type)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品类型不能为空！'];
        smartRedirect('productSection', false);
        exit;
    }
    if (mb_strlen($type, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品类型最多10个字符！'];
        smartRedirect('productSection', false);
        exit;
    }
    if (empty($member_discount)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '会员折扣不能为空！'];
        smartRedirect('productSection', false);
        exit;
    }
    if ($member_discount < 1 || $member_discount > 100) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '会员折扣必须在1-100之间！'];
        smartRedirect('productSection', false);
        exit;
    }
    if ($price < 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品价格不能为负数！'];
        smartRedirect('productSection', false);
        exit;
    }
    if ($price > 9999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品价格不能超过9999元！'];
        smartRedirect('productSection', false);
        exit;
    }
    if ($nameError = nameExists('products', $name, $id)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品名称' . $name . '已存在，请修改重试！'];
        smartRedirect('productSection', false);
        exit;
    }
    if ($mode === 'add') {
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM products");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO products (name, type, price, member_discount, enable_member_levels_discount, allow_zero_stock, sort_order) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('productSection', false);
            exit;
        }
        $stmt->bind_param("ssddiii", $name, $type, $price, $member_discount, $enable_member_levels_discount, $allow_zero_stock, $sortOrder);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => '商品添加成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品添加失败，请重试！'];
        }
    } else {
        $activeProductOrderStmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ? AND status = 0");
        $activeProductOrderStmt->bind_param('i', $id);
        $activeProductOrderStmt->execute();
        $activeProductOrderResult = $activeProductOrderStmt->get_result();
        $activeProductOrderCount = $activeProductOrderResult ? $activeProductOrderResult->fetch_assoc()['count'] : 0;
        $activeProductOrderStmt->close();
        $creditProductStmt = $conn->prepare("SELECT COUNT(*) as count FROM product_credit_for_room WHERE product_id = ?");
        $creditProductStmt->bind_param('i', $id);
        $creditProductStmt->execute();
        $creditProductResult = $creditProductStmt->get_result();
        $creditProductCount = $creditProductResult ? $creditProductResult->fetch_assoc()['count'] : 0;
        $creditProductStmt->close();
        if ($activeProductOrderCount > 0 || $creditProductCount > 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '有正在进行中的订单或挂单记录，请等待结账后再修改。'];
            smartRedirect('productSection', false);
            exit;
        }
        $stmt = $conn->prepare("UPDATE products SET name=?, type=?, price=?, 
                member_discount=?, enable_member_levels_discount=?, 
                allow_zero_stock=? WHERE id=?");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('productSection', false);
            exit;
        }
        $stmt->bind_param("ssddiii", $name, $type, $price, $member_discount, $enable_member_levels_discount, $allow_zero_stock, $id);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => '商品编辑成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品编辑失败，请重试！'];
        }
    }
    smartRedirect('productSection');
    exit;
}
if (isset($_GET['delete_product'])) {
    $id = intval($_GET['delete_product']);
    $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE product_id = ?");
    $check_stmt->bind_param('i', $id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $order_count = $check_result ? $check_result->fetch_assoc()['count'] : 0;
    if ($order_count > 0) {
        $stmt = $conn->prepare("UPDATE products SET is_deleted = 1 WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => '商品已隐藏，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品隐藏失败，请重试！'];
        }
    } else {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '商品管理', 'message' => '商品删除成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '商品管理', 'message' => '商品删除失败，请重试！'];
        }
    }
    smartRedirect('productSection');
    exit;
}
if (isset($_GET['restore_product'])) {
    handleRestoreItem('products', $_GET['restore_product'], 'product_restored', 'productSection');
}
if (isset($_GET['restore_user'])) {
    handleRestoreItem('system_users', $_GET['restore_user'], 'user_restored', 'usersSection');
}
if (isset($_POST['add_product'])) {
    handleProductSubmit($_POST, 'add');
}
if (isset($_POST['edit_product'])) {
    handleProductSubmit($_POST, 'edit');
}
function handleMemberLevelSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['level_id']) : 0;
    $levelName = trim($data['level_name'] ?? '');
    $minFirstRecharge = floatval($data['min_first_recharge'] ?? 0);
    $minRecharge = floatval($data['min_recharge'] ?? 0);
    $autoUpgradeAmount = floatval($data['auto_upgrade_amount'] ?? 0);
    $memberDiscount = intval($data['member_discount'] ?? 100);
    $isSystem = intval($data['is_system'] ?? 0);
    if (empty($levelName)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '卡类型名称不能为空！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($memberDiscount < 1 || $memberDiscount > 100) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '会员折扣必须在1-100之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($minFirstRecharge < 0 || $minFirstRecharge > 99999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '首次开卡最低金额必须在0-99999之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($minRecharge < 0 || $minRecharge > 99999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '续费充值最低金额必须在0-99999之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($autoUpgradeAmount < 0 || $autoUpgradeAmount > 99999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '自动升级累计充值金额必须在0-99999之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    $maxRechargeStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'member_recharge_max_amount'");
    $maxRechargeStmt->execute();
    $maxRechargeResult = $maxRechargeStmt->get_result();
    $maxRechargeAmount = 99999; 
    if ($maxRechargeResult->num_rows > 0) {
        $maxRechargeAmount = floatval($maxRechargeResult->fetch_assoc()['config_value']);
    }
    if ($minFirstRecharge > $maxRechargeAmount) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '首次开卡最低金额（¥' . number_format($minFirstRecharge, 2) . '）不能超过单次充值最大限额（¥' . number_format($maxRechargeAmount, 2) . '）！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($minRecharge > $maxRechargeAmount) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '续费充值最低金额（¥' . number_format($minRecharge, 2) . '）不能超过单次充值最大限额（¥' . number_format($maxRechargeAmount, 2) . '）！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($mode === 'add') {
        $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_levels WHERE name = ?");
        $checkStmt->bind_param('s', $levelName);
    } else {
        $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_levels WHERE name = ? AND id != ?");
        $checkStmt->bind_param('si', $levelName, $id);
    }
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result()->fetch_assoc();
    if ($checkResult['count'] > 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '卡类型名称' . $levelName . '已存在，请修改重试！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($autoUpgradeAmount > 0) {
        if ($mode === 'add') {
            $conflictStmt = $conn->prepare("SELECT name FROM member_levels WHERE auto_upgrade_amount = ?");
            $conflictStmt->bind_param('d', $autoUpgradeAmount);
        } else {
            $conflictStmt = $conn->prepare("SELECT name FROM member_levels WHERE auto_upgrade_amount = ? AND id != ?");
            $conflictStmt->bind_param('di', $autoUpgradeAmount, $id);
        }
        $conflictStmt->execute();
        $conflictResult = $conflictStmt->get_result();
        if ($conflictResult->num_rows > 0) {
            $conflictLevel = $conflictResult->fetch_assoc();
            $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '自动升级累计金额 ¥' . number_format($autoUpgradeAmount, 2) . ' 与卡类型"' . $conflictLevel['name'] . '"冲突，请修改！'];
            smartRedirect('memberInfoSection', false);
            exit;
        }
    }
    if ($mode === 'add') {
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM member_levels");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO member_levels (name, min_first_recharge, min_recharge, auto_upgrade_amount, member_discount, is_enabled, is_system, sort_order) VALUES (?, ?, ?, ?, ?, 1, 0, ?)");
        $stmt->bind_param('sdddii', $levelName, $minFirstRecharge, $minRecharge, $autoUpgradeAmount, $memberDiscount, $sortOrder);
        $result = $stmt->execute();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '会员卡类型', 'message' => '会员类型添加成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '会员类型添加失败，请重试！'];
        }
    } else {
        if ($isSystem == 1) {
            if ($minFirstRecharge != 0 || $minRecharge != 0 || $autoUpgradeAmount != 0) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '系统级卡类型的金额字段不可修改，必须为0！'];
                smartRedirect('memberInfoSection', false);
                exit;
            }
        }
        $stmt = $conn->prepare("UPDATE member_levels SET name = ?, min_first_recharge = ?, min_recharge = ?, auto_upgrade_amount = ?, member_discount = ? WHERE id = ?");
        $stmt->bind_param('sdddii', $levelName, $minFirstRecharge, $minRecharge, $autoUpgradeAmount, $memberDiscount, $id);
        $result = $stmt->execute();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '会员卡类型', 'message' => '会员类型编辑成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '会员类型编辑失败，请重试！'];
        }
    }
    smartRedirect('memberInfoSection');
    exit;
}
if (isset($_POST['add_member_level'])) {
    handleMemberLevelSubmit($_POST, 'add');
}
if (isset($_POST['edit_member_level'])) {
    handleMemberLevelSubmit($_POST, 'edit');
}
if (isset($_GET['delete_member_level'])) {
    $id = intval($_GET['delete_member_level']);
    $checkStmt = $conn->prepare("SELECT is_system, name FROM member_levels WHERE id = ?");
    $checkStmt->bind_param('i', $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    if ($checkResult->num_rows === 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '会员类型不存在！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    $levelData = $checkResult->fetch_assoc();
    if ($levelData['is_system'] == 1) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '系统级卡类型不可删除！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    $memberStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE level_id = ?");
    $memberStmt->bind_param('i', $id);
    $memberStmt->execute();
    $memberResult = $memberStmt->get_result();
    $memberCount = $memberResult->fetch_assoc()['count'];
    if ($memberCount > 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '有 ' . $memberCount . ' 个会员正在使用"' . $levelData['name'] . '"卡类型，无法删除！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    $deleteStmt = $conn->prepare("DELETE FROM member_levels WHERE id = ?");
    $deleteStmt->bind_param('i', $id);
    $result = $deleteStmt->execute();
    updateRefreshFlag();
    if ($result) {
        $_SESSION['toast'] = ['type' => 'success', 'title' => '会员卡类型', 'message' => '会员类型删除成功，请刷新前端页面更新！'];
    } else {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '会员卡类型', 'message' => '会员类型删除失败，请重试！'];
    }
    smartRedirect('memberInfoSection');
    exit;
}
function handleTimeCardSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['time_card_id']) : 0;
    $name = trim($data['time_card_name'] ?? '');
    $type = trim($data['time_card_type'] ?? '');
    $total_times = intval($data['time_card_times'] ?? 0);
    $price = floatval($data['time_card_price'] ?? 0);
    $validity_days = !empty($data['time_card_validity_days']) ? intval($data['time_card_validity_days']) : null;
    $hours = ($type === 'room' && !empty($data['time_card_deduction_hours'])) ? floatval($data['time_card_deduction_hours']) : null;
    $room_ids = isset($data['time_card_applicable_room_ids']) ? $data['time_card_applicable_room_ids'] : [];
    $product_ids = isset($data['time_card_applicable_product_ids']) ? $data['time_card_applicable_product_ids'] : [];
    $member_discount = intval($data['time_card_member_discount'] ?? 100);
    $enable_member_levels_discount = isset($data['time_card_enable_member_levels_discount']) ? 1 : 0;
    if (empty($name)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券名称不能为空！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if (mb_strlen($name, 'UTF-8') > 25) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券名称最多25个字符！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if (empty($type) || !in_array($type, ['room', 'product'])) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券类型必须选择' . $SCENE_ROOM_NAME . '或商品！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($total_times <= 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次数必须大于0！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($total_times > 9999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次数不能超过9999！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($price < 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '价格不能为负数！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($price > 9999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '价格不能超过9999元！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($validity_days !== null && ($validity_days <= 0 || $validity_days > 999)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '有效期天数必须在1-999之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($member_discount < 1 || $member_discount > 100) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '会员折扣必须在1-100之间！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($type === 'room') {
        if (empty($hours) || $hours <= 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => $SCENE_ROOM_NAME . '类型必须设置抵扣时长！'];
            smartRedirect('memberInfoSection', false);
            exit;
        }
        if ($hours > 999) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '抵扣时长不能超过999小时！'];
            smartRedirect('memberInfoSection', false);
            exit;
        }
    }
    $room_ids_json = null;
    if (is_array($room_ids) && !empty($room_ids)) {
        $room_ids_json = json_encode(array_map('intval', $room_ids));
    }
    $product_ids_json = null;
    if (is_array($product_ids) && !empty($product_ids)) {
        $product_ids_json = json_encode(array_map('intval', $product_ids));
    }
    if ($mode === 'add') {
        $checkStmt = $conn->prepare("SELECT id FROM time_card_products WHERE name = ?");
        $checkStmt->bind_param('s', $name);
    } else {
        $checkStmt = $conn->prepare("SELECT id FROM time_card_products WHERE name = ? AND id != ?");
        $checkStmt->bind_param('si', $name, $id);
    }
    $checkStmt->execute();
    if ($checkStmt->get_result()->num_rows > 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券名称' . $name . '已存在，请修改重试！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    if ($mode === 'add') {
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM time_card_products");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO time_card_products (name, type, total_times, price, validity_days, hours, room_ids, product_ids, member_discount, enable_member_levels_discount, sort_order) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('memberInfoSection', false);
            exit;
        }
        $validity_days_val = $validity_days !== null ? $validity_days : null;
        $hours_val = $hours !== null ? $hours : null;
        $room_ids_val = $room_ids_json !== null ? $room_ids_json : null;
        $product_ids_val = $product_ids_json !== null ? $product_ids_json : null;
        $types = 'ssidd';
        $params = [$name, $type, $total_times, $price, $validity_days_val];
        $types .= 'd';
        $params[] = $hours_val;
        $types .= 's';
        $params[] = $room_ids_val;
        $types .= 's';
        $params[] = $product_ids_val;
        $types .= 'iii';
        $params[] = $member_discount;
        $params[] = $enable_member_levels_discount;
        $params[] = $sortOrder;
        $stmt->bind_param($types, ...$params);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '次卡券管理', 'message' => '次卡券添加成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券添加失败，请重试！'];
        }
    } else {
        $stmt = $conn->prepare("UPDATE time_card_products SET name=?, total_times=?, price=?, validity_days=?, hours=?, room_ids=?, product_ids=?, member_discount=?, enable_member_levels_discount=? WHERE id=?");
        if (!$stmt) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '数据库准备失败: ' . $conn->error];
            smartRedirect('memberInfoSection', false);
            exit;
        }
        $validity_days_val = $validity_days !== null ? $validity_days : null;
        $hours_val = $hours !== null ? $hours : null;
        $room_ids_val = $room_ids_json !== null ? $room_ids_json : null;
        $product_ids_val = $product_ids_json !== null ? $product_ids_json : null;
        $types = 'siddd';
        $params = [$name, $total_times, $price, $validity_days_val, $hours_val];
        $types .= 's';
        $params[] = $room_ids_val;
        $types .= 's';
        $params[] = $product_ids_val;
        $types .= 'iii';
        $params[] = $member_discount;
        $params[] = $enable_member_levels_discount;
        $params[] = $id;
        $stmt->bind_param($types, ...$params);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '次卡券管理', 'message' => '次卡券编辑成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券编辑失败，请重试！'];
        }
    }
    smartRedirect('memberInfoSection');
    exit;
}
if (isset($_POST['add_time_card'])) {
    handleTimeCardSubmit($_POST, 'add');
}
if (isset($_POST['edit_time_card'])) {
    handleTimeCardSubmit($_POST, 'edit');
}
if (isset($_GET['delete_time_card'])) {
    $id = intval($_GET['delete_time_card']);
    $checkStmt = $conn->prepare("SELECT name FROM time_card_products WHERE id = ?");
    $checkStmt->bind_param('i', $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    if ($checkResult->num_rows === 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券不存在！'];
        smartRedirect('memberInfoSection', false);
        exit;
    }
    $timeCardData = $checkResult->fetch_assoc();
    $salesStmt = $conn->prepare("SELECT COUNT(*) as count FROM time_card_orders WHERE time_card_id = ?");
    $salesStmt->bind_param('i', $id);
    $salesStmt->execute();
    $salesResult = $salesStmt->get_result();
    $salesCount = $salesResult->fetch_assoc()['count'];
    if ($salesCount > 0) {
        $deleteStmt = $conn->prepare("UPDATE time_card_products SET is_deleted = 1 WHERE id = ?");
        $deleteStmt->bind_param('i', $id);
        $result = $deleteStmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '次卡券管理', 'message' => '次卡券已隐藏，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券隐藏失败，请重试！'];
        }
    } else {
        $deleteStmt = $conn->prepare("DELETE FROM time_card_products WHERE id = ?");
        $deleteStmt->bind_param('i', $id);
        $result = $deleteStmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '次卡券管理', 'message' => '次卡券删除成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券删除失败，请重试！'];
        }
    }
    smartRedirect('memberInfoSection');
    exit;
}
if (isset($_GET['restore_time_card'])) {
    $id = intval($_GET['restore_time_card']);
    $stmt = $conn->prepare("UPDATE time_card_products SET is_deleted = 0 WHERE id = ?");
    $stmt->bind_param('i', $id);
    $result = $stmt->execute();
    updateRefreshFlag();
    if ($result) {
        $_SESSION['toast'] = ['type' => 'success', 'title' => '次卡券管理', 'message' => '次卡券恢复成功，请刷新前端页面更新！'];
    } else {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '次卡券管理', 'message' => '次卡券恢复失败，请重试！'];
    }
    smartRedirect('memberInfoSection');
    exit;
}
if (isset($_POST['action']) && ($_POST['action'] === 'enable_time_card' || $_POST['action'] === 'disable_time_card')) {
    header('Content-Type: application/json');
    $timeCardId = $_POST['time_card_id'] ?? 0;
    if (empty($timeCardId)) {
        echo json_encode(['success' => false, 'message' => '次卡券ID不能为空']);
        exit;
    }
    try {
        $isEnable = $_POST['action'] === 'enable_time_card';
        if ($isEnable) {
            $stmt = $conn->prepare("UPDATE time_card_products SET is_enabled = 1 WHERE id = ?");
            $stmt->bind_param('i', $timeCardId);
        } else {
            $stmt = $conn->prepare("UPDATE time_card_products SET is_enabled = 0 WHERE id = ?");
            $stmt->bind_param('i', $timeCardId);
        }
        if ($stmt->execute()) {
            updateRefreshFlag();
            $actionText = $isEnable ? '启用' : '停用';
            echo json_encode(['success' => true, 'message' => '次卡券' . $actionText . '成功，请刷新前端页面更新！']);
        } else {
            echo json_encode(['success' => false, 'message' => '更新次卡券状态失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_rooms_list') {
    header('Content-Type: application/json');
    try {
        $stmt = $conn->prepare("SELECT id, name FROM rooms WHERE is_deleted = 0 ORDER BY sort_order, id");
        $stmt->execute();
        $result = $stmt->get_result();
        $rooms = [];
        while ($row = $result->fetch_assoc()) {
            $rooms[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $rooms]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_GET['action']) && $_GET['action'] === 'get_products_list') {
    header('Content-Type: application/json');
    try {
        $stmt = $conn->prepare("SELECT id, name FROM products WHERE is_deleted = 0 ORDER BY sort_order, id");
        $stmt->execute();
        $result = $stmt->get_result();
        $products = [];
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $products]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
define('REMOTE_UPDATE_BASE_URL', 'https://gitee.com/phproom/phproom/raw/master/');
define('REMOTE_UPDATE_BASE_URL_BACKUP', 'https://gh-proxy.org/https://raw.githubusercontent.com/tsengwentseng/phproom/main/');
define('REMOTE_UPDATE_ZIP', 'update.zip');
define('REMOTE_VERSION_FILE', 'version.txt');
define('REMOTE_VERSIONLOG_FILE', 'versionlog.txt');
define('REMOTE_API_HASH_FILE', 'room_api_hash.txt');
define('REMOTE_API_EXE_FILE', 'room_api.exe');
define('REMOTE_MACHINEID_FILE', 'devrunlog.txt');
function verifyLicenseAuthorization() {
    $keyLicPath = 'D:\\phpRoom\\server\\apache\\bin\\key.lic';
    if (!file_exists($keyLicPath)) {
        return false;
    }
    $localKey = @file_get_contents($keyLicPath);
    if ($localKey === false || empty(trim($localKey))) {
        return false;
    }
    $localKey = trim($localKey);
    try {
        $machineIdUrl = getRemoteUpdateUrl(REMOTE_MACHINEID_FILE, 0);
        $remoteMachineIds = getRemoteFileWithRetry($machineIdUrl, 3, 1);
        if ($remoteMachineIds === false) {
            $machineIdUrl = getRemoteUpdateUrl(REMOTE_MACHINEID_FILE, 1);
            $remoteMachineIds = getRemoteFileWithRetry($machineIdUrl, 3, 1);
        }
        if ($remoteMachineIds === false) {
            return true;
        }
        if (empty(trim($remoteMachineIds))) {
            return true;
        }
        $lines = explode("\n", $remoteMachineIds);
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            if ($line === $localKey) {
                return true;
            }
        }
        return false;
    } catch (Exception $e) {
        return true;
    }
}
if (isset($_GET['render_url'])) {
    $url = $_GET['render_url'];
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('/^https?:\/\//', $url)) {
        http_response_code(400);
        echo '无效的URL';
        exit;
    }
    if (strpos($url, 'gitee.com') === false && strpos($url, 'github.com') === false) {
        http_response_code(403);
        echo '只允许加载 Gitee 或 GitHub 的内容';
        exit;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $content = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode !== 200 || $content === false) {
        http_response_code(502);
        echo '无法获取远程内容';
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    echo $content;
    exit;
}
function getRemoteUpdateUrl($filename, $sourceIndex = 0) {
    if ($sourceIndex === 0) {
        return REMOTE_UPDATE_BASE_URL . $filename;
    } else {
        return REMOTE_UPDATE_BASE_URL_BACKUP . $filename;
    }
}
function getRemoteFileWithRetry($url, $maxRetries = 3, $retryDelay = 1) {
    $lastError = '';
    for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
        try {
            $context = stream_context_create([
                'http' => [
                    'timeout' => 15,
                    'ignore_errors' => true,
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ]);
            $content = @file_get_contents($url, false, $context);
            if ($content !== false) {
                if (isset($http_response_header)) {
                    $status_line = $http_response_header[0];
                    preg_match('{HTTP\/\S*\s(\d{3})}', $status_line, $match);
                    $status = intval($match[1] ?? 0);
                    if ($status >= 200 && $status < 400) {
                        return $content;
                    } else {
                        $lastError = "HTTP {$status}";
                    }
                } else {
                    return $content;
                }
            } else {
                $error = error_get_last();
                $lastError = $error['message'] ?? '未知错误';
            }
        } catch (Exception $e) {
            $lastError = $e->getMessage();
        }
        if ($attempt < $maxRetries) {
            sleep($retryDelay);
        }
    }
    return false;
}
function downloadRemoteFileWithRetry($url, $localPath, $maxRetries = 3, $retryDelay = 1) {
    $content = getRemoteFileWithRetry($url, $maxRetries, $retryDelay);
    if ($content === false) {
        return false;
    }
    $result = file_put_contents($localPath, $content);
    if ($result === false) {
        return false;
    }
    return true;
}
function handlePaymentSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['payment_id']) : 0;
    $name = trim($data['payment_name'] ?? '');
    $description = trim($data['payment_description'] ?? '');
    if (empty($name)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式名称不能为空！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    if (mb_strlen($name, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式名称最多10个字符！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    if (empty($description)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式描述不能为空！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    if (mb_strlen($description, 'UTF-8') > 20) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式描述最多20个字符！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    if ($mode === 'edit') {
        $check = $conn->prepare("SELECT is_system, name FROM payment_methods WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        $result = $check->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($row['is_system'] == 1) {
                smartRedirect('paymentMethodSection', false);
                exit;
            }
        }
    }
    if ($nameError = nameExists('payment_methods', $name, $id)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式名称' . $name . '已存在，请修改重试！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    if ($mode === 'add') {
        $maxSortResult = $conn->query("SELECT COALESCE(MAX(sort_order), 0) as max_sort FROM payment_methods");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO payment_methods (name, description, sort_order) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $name, $description, $sortOrder);
        $result = $stmt->execute();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '支付方式管理', 'message' => '支付方式添加成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式添加失败，请重试！'];
        }
    } else {
        $stmt = $conn->prepare("UPDATE payment_methods SET name = ?, description = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $description, $id);
        $result = $stmt->execute();
        if ($result) {
            updateRefreshFlag();
            $_SESSION['toast'] = ['type' => 'success', 'title' => '支付方式管理', 'message' => '支付方式编辑成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式编辑失败，请重试！'];
        }
    }
    smartRedirect('paymentMethodSection');
    exit;
}
if (isset($_GET['delete_payment'])) {
    $id = intval($_GET['delete_payment']);
    $check = $conn->prepare("SELECT is_system, name FROM payment_methods WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $result = $check->get_result();
    $row = $result->fetch_assoc();
    if ($row['is_system'] == 1) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '系统支付方式不能删除，只能隐藏！'];
        smartRedirect('paymentMethodSection', false);
        exit;
    }
    $check_orders = $conn->prepare("SELECT COUNT(*) as count FROM orders_payment_details WHERE payment_method_id = ?");
    $check_orders->bind_param("i", $id);
    $check_orders->execute();
    $orders_count = $check_orders->get_result()->fetch_assoc()['count'];
    $check_recharges = $conn->prepare("SELECT COUNT(*) as count FROM member_recharges WHERE payment_method_id = ?");
    $check_recharges->bind_param("i", $id);
    $check_recharges->execute();
    $recharges_count = $check_recharges->get_result()->fetch_assoc()['count'];
    $check_product_orders = $conn->prepare("SELECT COUNT(*) as count FROM product_orders WHERE payment_method_id = ?");
    $check_product_orders->bind_param("i", $id);
    $check_product_orders->execute();
    $product_orders_count = $check_product_orders->get_result()->fetch_assoc()['count'];
    if ($orders_count > 0 || $recharges_count > 0 || $product_orders_count > 0) {
        $stmt = $conn->prepare("UPDATE payment_methods SET is_deleted = 1 WHERE id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '支付方式管理', 'message' => '支付方式已隐藏，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式隐藏失败，请重试！'];
        }
        smartRedirect('paymentMethodSection');
    } else {
        $stmt = $conn->prepare("DELETE FROM payment_methods WHERE id = ?");
        $stmt->bind_param("i", $id);
        $result = $stmt->execute();
        updateRefreshFlag();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '支付方式管理', 'message' => '支付方式删除成功，请刷新前端页面更新！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式删除失败，请重试！'];
        }
        smartRedirect('paymentMethodSection');
    }
    exit;
}
if (isset($_GET['hide_payment'])) {
    $id = intval($_GET['hide_payment']);
    $check = $conn->prepare("SELECT is_system FROM payment_methods WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $result = $check->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['is_system'] == 1) {
            $check_active_orders = $conn->prepare("
                SELECT COUNT(*) as count FROM orders_payment_details opd
                JOIN orders o ON opd.order_id = o.id 
                WHERE opd.payment_method_id = ? AND o.status = 0
            ");
            $check_active_orders->bind_param("i", $id);
            $check_active_orders->execute();
            $active_orders_count = $check_active_orders->get_result()->fetch_assoc()['count'];
            if ($active_orders_count > 0) {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式有正在进行中的订单，无法隐藏！'];
                smartRedirect('paymentMethodSection', false);
                exit;
            }
            $stmt = $conn->prepare("UPDATE payment_methods SET is_deleted = 1 WHERE id = ?");
            $stmt->bind_param("i", $id);
            $result = $stmt->execute();
            updateRefreshFlag();
            if ($result) {
                $_SESSION['toast'] = ['type' => 'success', 'title' => '支付方式管理', 'message' => '系统支付方式已隐藏，请刷新前端页面更新！'];
            } else {
                $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式隐藏失败，请重试！'];
            }
            smartRedirect('paymentMethodSection');
            exit;
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '客户自定义支付方式不能隐藏，只能删除！'];
            smartRedirect('paymentMethodSection', false);
            exit;
        }
    } else {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '支付方式管理', 'message' => '支付方式不存在！'];
        smartRedirect('paymentMethodSection', false);
    }
    exit;
}
if (isset($_GET['restore_payment'])) {
    handleRestoreItem('payment_methods', $_GET['restore_payment'], 'payment_restored', 'paymentMethodSection');
}
if (isset($_POST['add_payment'])) {
    handlePaymentSubmit($_POST, 'add');
}
if (isset($_POST['edit_payment'])) {
    handlePaymentSubmit($_POST, 'edit');
}
if (isset($_GET['delete_promotion'])) {
    $id = intval($_GET['delete_promotion']);
    $check_stmt = $conn->prepare("SELECT usage_count FROM promotion_strategies WHERE id = ?");
    $check_stmt->bind_param('i', $id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    if ($result->num_rows === 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐不存在'];
        smartRedirect('promotionSection', false);
        exit;
    }
    $promotion = $result->fetch_assoc();
    if ($promotion['usage_count'] > 0) {
        $stmt = $conn->prepare("UPDATE promotion_strategies SET is_deleted = 1 WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '套餐管理', 'message' => '套餐已隐藏！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐隐藏失败，请重试！'];
        }
    } else {
        $stmt = $conn->prepare("DELETE FROM promotion_strategies WHERE id = ?");
        $stmt->bind_param('i', $id);
        $result = $stmt->execute();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '套餐管理', 'message' => '套餐删除成功！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐删除失败，请重试！'];
        }
    }
    smartRedirect('promotionSection');
    exit;
}
if (isset($_GET['restore_promotion'])) {
    $id = intval($_GET['restore_promotion']);
    $stmt = $conn->prepare("UPDATE promotion_strategies SET is_deleted = 0 WHERE id = ?");
    $stmt->bind_param('i', $id);
    $result = $stmt->execute();
    if ($result) {
        $_SESSION['toast'] = ['type' => 'success', 'title' => '套餐管理', 'message' => '套餐恢复成功！'];
    } else {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐恢复失败，请重试！'];
    }
    smartRedirect('promotionSection');
    exit;
}
if (isset($_POST['action']) && ($_POST['action'] === 'enable_promotion' || $_POST['action'] === 'disable_promotion')) {
    header('Content-Type: application/json');
    $promotionId = $_POST['promotion_id'] ?? 0;
    if (empty($promotionId)) {
        echo json_encode(['success' => false, 'message' => '套餐ID不能为空']);
        exit;
    }
    try {
        $isEnable = $_POST['action'] === 'enable_promotion';
        if ($isEnable) {
            $stmt = $conn->prepare("UPDATE promotion_strategies SET is_enabled = 1 WHERE id = ?");
            $stmt->bind_param('i', $promotionId);
        } else {
            $active_stmt = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM orders_payment_details opd
                JOIN orders o ON opd.order_id = o.id
                WHERE o.status = 0 
                AND opd.promotion_data IS NOT NULL 
                AND JSON_SEARCH(opd.promotion_data, 'one', ?, NULL, '$[*].id') IS NOT NULL
            ");
            $active_stmt->bind_param('i', $promotionId);
            $active_stmt->execute();
            $active_result = $active_stmt->get_result();
            $active_count = $active_result ? $active_result->fetch_assoc()['count'] : 0;
            if ($active_count > 0) {
                echo json_encode(['success' => false, 'message' => '套餐有正在使用的订单，无法停用！']);
                exit;
            }
            $stmt = $conn->prepare("UPDATE promotion_strategies SET is_enabled = 0 WHERE id = ?");
            $stmt->bind_param('i', $promotionId);
        }
        if ($stmt->execute()) {
            $actionText = $isEnable ? '启用' : '停用';
            echo json_encode(['success' => true, 'message' => '套餐' . $actionText . '成功！']);
        } else {
            echo json_encode(['success' => false, 'message' => '更新套餐状态失败']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
if (isset($_POST['action']) && strpos($_POST['action'], 'promotion_') === 0) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $response = ['success' => false, 'message' => '未知操作'];
    try {
        switch ($action) {
            case 'promotion_get_rooms':
                $stmt = $conn->prepare("SELECT id, name FROM rooms WHERE is_deleted = 0 ORDER BY sort_order, id");
                $stmt->execute();
                $result = $stmt->get_result();
                $rooms = [];
                while ($row = $result->fetch_assoc()) {
                    $rooms[] = $row;
                }
                $response = ['success' => true, 'data' => $rooms];
                break;
        }
    } catch (Exception $e) {
        $response = ['success' => false, 'message' => $e->getMessage()];
    }
    echo json_encode($response);
    exit;
}
function handlePromotionSubmit($data, $mode) {
    global $conn;
    $id = $mode === 'edit' ? intval($data['id']) : 0;
    $name = trim($data['name'] ?? '');
    $type = strtoupper(trim($data['type'] ?? '通用')); 
    $hours = floatval($data['hours'] ?? 0);
    $price = floatval($data['price'] ?? 0);
    $roomIds = isset($data['room_ids']) ? $data['room_ids'] : [];
    $weekdays = $data['weekdays'] ?? '1,2,3,4,5,6,7';
    $timeStart = $data['time_start'] ?? '00:00:00';
    $timeEnd = $data['time_end'] ?? '23:59:59';
    if (strlen($timeStart) == 5) {
        $timeStart .= ':00';
    }
    if (strlen($timeEnd) == 5) {
        if ($timeEnd == '23:59') {
            $timeEnd = '23:59:59';
        } else {
            $timeEnd .= ':00';
        }
    }
    $memberDiscount = isset($data['member_discount']) ? intval($data['member_discount']) : 100;
    $enableMemberLevelsDiscount = isset($data['enable_member_levels_discount']) ? intval($data['enable_member_levels_discount']) : 0;
    $isAllDay = isset($data['is_all_day']) ? intval($data['is_all_day']) : 0;
    if ($isAllDay == 1) {
        $hours = 999;
    }
    if (empty($name)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐名称不能为空'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if (mb_strlen($name, 'UTF-8') > 30) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐名称最多30个字符'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if (empty($type)) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐类型不能为空'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if (mb_strlen($type, 'UTF-8') > 10) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐类型最多10个字符'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if ($hours < 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '时长不能为负数'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if ($hours > 999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '时长不能超过999小时'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if (round($hours, 1) != $hours) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '时长最多只能有1位小数'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if ($price < 0) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '价格不能为负数'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if ($price > 9999) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '价格不能超过9999元'];
        smartRedirect('promotionSection', false);
        exit;
    }
    if ($memberDiscount < 1 || $memberDiscount > 100) {
        $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '会员折扣必须在1-100之间'];
        smartRedirect('promotionSection', false);
        exit;
    }
    $roomIdsJson = null;
    if (is_array($roomIds) && !empty($roomIds)) {
        $roomIdsJson = json_encode(array_map('intval', $roomIds));
    }
    if ($mode === 'add') {
        $checkStmt = $conn->prepare("SELECT id FROM promotion_strategies WHERE name = ? AND is_deleted = 0");
        $checkStmt->bind_param("s", $name);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐名称' . $name . '已存在，请修改重试！'];
            smartRedirect('promotionSection', false);
            exit;
        }
        $checkStmt->close();
        $maxSortResult = $conn->query("SELECT IFNULL(MAX(sort_order), 0) as max_sort FROM promotion_strategies WHERE is_deleted = 0");
        $maxSort = $maxSortResult->fetch_assoc()['max_sort'];
        $sortOrder = $maxSort + 1;
        $stmt = $conn->prepare("INSERT INTO promotion_strategies (name, type, hours, price, room_ids, weekdays, time_start, time_end, member_discount, enable_member_levels_discount, is_all_day, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssddssssiiii", $name, $type, $hours, $price, $roomIdsJson, $weekdays, $timeStart, $timeEnd, $memberDiscount, $enableMemberLevelsDiscount, $isAllDay, $sortOrder);
        $result = $stmt->execute();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '套餐管理', 'message' => '套餐添加成功！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐添加失败，请重试！'];
        }
    } else {
        if ($id <= 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐ID无效'];
            smartRedirect('promotionSection', false);
            exit;
        }
        $activeOrderStmt = $conn->prepare("
            SELECT COUNT(*) as count 
            FROM orders_payment_details opd
            JOIN orders o ON opd.order_id = o.id
            WHERE o.status = 0 
            AND opd.promotion_data IS NOT NULL 
            AND JSON_SEARCH(opd.promotion_data, 'one', ?, NULL, '$[*].id') IS NOT NULL
        ");
        $activeOrderStmt->bind_param('i', $id);
        $activeOrderStmt->execute();
        $activeOrderResult = $activeOrderStmt->get_result();
        $activeOrderCount = $activeOrderResult ? $activeOrderResult->fetch_assoc()['count'] : 0;
        $activeOrderStmt->close();
        if ($activeOrderCount > 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '有正在进行中的订单使用，请等待订单结账后再修改。'];
            smartRedirect('promotionSection', false);
            exit;
        }
        $checkStmt = $conn->prepare("SELECT id FROM promotion_strategies WHERE name = ? AND id != ? AND is_deleted = 0");
        $checkStmt->bind_param("si", $name, $id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();
        if ($checkResult->num_rows > 0) {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐名称' . $name . '已存在，请修改重试！'];
            smartRedirect('promotionSection', false);
            exit;
        }
        $checkStmt->close();
        $stmt = $conn->prepare("UPDATE promotion_strategies SET name = ?, type = ?, hours = ?, price = ?, room_ids = ?, weekdays = ?, time_start = ?, time_end = ?, member_discount = ?, enable_member_levels_discount = ?, is_all_day = ? WHERE id = ?");
        $stmt->bind_param("ssddssssiiii", $name, $type, $hours, $price, $roomIdsJson, $weekdays, $timeStart, $timeEnd, $memberDiscount, $enableMemberLevelsDiscount, $isAllDay, $id);
        $result = $stmt->execute();
        if ($result) {
            $_SESSION['toast'] = ['type' => 'success', 'title' => '套餐管理', 'message' => '套餐编辑成功！'];
        } else {
            $_SESSION['toast'] = ['type' => 'error', 'title' => '套餐管理', 'message' => '套餐编辑失败，请重试！'];
        }
    }
    smartRedirect('promotionSection');
    exit;
}
if (isset($_POST['add_promotion'])) {
    handlePromotionSubmit($_POST, 'add');
}
if (isset($_POST['edit_promotion'])) {
    handlePromotionSubmit($_POST, 'edit');
}
function get_system_config($group = null, $visibleOnly = false) {
    global $conn;
    $sql = "SELECT * FROM system_config WHERE 1=1";
    $params = [];
    $types = "";
    if ($group !== null) {
        $sql .= " AND config_group = ?";
        $params[] = $group;
        $types .= "s";
    }
    if ($visibleOnly) {
        $sql .= " AND is_visible = 1";
    }
    $sql .= " ORDER BY sort_order ASC, id ASC";
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $configs = [];
    while ($row = $result->fetch_assoc()) {
        $configs[] = $row;
    }
    return $configs;
}
function update_system_config($key, $value) {
    global $conn;   
    $stmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
    $stmt->bind_param("ss", $value, $key);
    $result = $stmt->execute();
    updateRefreshFlag();
    return $result;
}
function add_system_config($config) {
    global $conn;
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM system_config WHERE config_key = ?");
    $stmt->bind_param("s", $config['config_key']);
            $stmt->execute();
            $result = $stmt->get_result();
    if ($result->fetch_assoc()['count'] > 0) {
        return "配置键名已存在";
    }
    $stmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_type, config_group, config_description, is_visible) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", 
        $config['config_key'], 
        $config['config_value'], 
        $config['config_type'], 
        $config['config_group'], 
        $config['config_description'], 
        $config['is_visible']
    );
    if ($stmt->execute()) {
        updateRefreshFlag();
        return true;
    } else {
        return "添加失败: " . $conn->error;
    }
}
function delete_system_config($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT config_key FROM system_config WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        return false;
    }
    $config_key = $result->fetch_assoc()['config_key'];
    if ($config_key === 'admin_password') {
        return false;
    }
    $stmt = $conn->prepare("DELETE FROM system_config WHERE id = ?");
    $stmt->bind_param("i", $id);
    $result = $stmt->execute();
    updateRefreshFlag();
    return $result;
}
if (isset($_POST['action']) && in_array($_POST['action'], ['get_configs', 'save_configs', 'add_config', 'delete_config', 'get_current_version', 'download_update', 'extract_update', 'update_version', 'get_remote_version_info', 'check_update_room_api', 'fetch_remote_html'])) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json');
    if ($_POST['action'] === 'get_configs') {
        $group = $_POST['group'] ?? 'member';
        $configs = get_system_config($group, true);
        echo json_encode(['success' => true, 'configs' => $configs]);
        exit;
    }
    if ($_POST['action'] === 'save_configs') {
        if (!isset($_POST['configs']) || !is_array($_POST['configs'])) {
            echo json_encode(['success' => false, 'message' => '配置数据格式错误']);
            exit;
        }
        if (isset($_POST['configs']['alert_auto_mute_seconds']) || isset($_POST['configs']['alert_offset_seconds'])) {
            $stmt = $conn->prepare("SELECT config_key, config_value FROM system_config WHERE config_key IN ('alert_auto_mute_seconds', 'alert_offset_seconds')");
            $stmt->execute();
            $result = $stmt->get_result();
            $currentValues = [];
            while ($row = $result->fetch_assoc()) {
                $currentValues[$row['config_key']] = (int)$row['config_value'];
            }
            $muteSeconds = isset($_POST['configs']['alert_auto_mute_seconds']) 
                ? (int)$_POST['configs']['alert_auto_mute_seconds'] 
                : ($currentValues['alert_auto_mute_seconds'] ?? 300);
            $offsetSeconds = isset($_POST['configs']['alert_offset_seconds']) 
                ? (int)$_POST['configs']['alert_offset_seconds'] 
                : ($currentValues['alert_offset_seconds'] ?? 0);
            if ($offsetSeconds > 0) {
                $minMuteSeconds = $offsetSeconds + 60;
                if ($muteSeconds < $minMuteSeconds) {
                    echo json_encode([
                        'success' => false, 
                        'message' => "当音频提醒基准为推迟提醒（{$offsetSeconds}秒）时，系统强制订单超期静音必须至少为 {$minMuteSeconds} 秒，当前值为 {$muteSeconds} 秒。"
                    ]);
                    exit;
                }
            }
        }
        if (isset($_POST['configs']['timer_audio_auto_close_timeout']) && 
            isset($_POST['configs']['alert_auto_mute_seconds'])) {
            $timer_value = (int)$_POST['configs']['timer_audio_auto_close_timeout'];
            $alert_value = (int)$_POST['configs']['alert_auto_mute_seconds'];
            if ($timer_value >= $alert_value - 30) {
                echo json_encode([
                    'success' => false, 
                    'message' => '音频自动关闭时间必须比系统强制订单超期静音时间小至少30秒。'
                ]);
                exit;
            }
        }
        if (isset($_POST['configs']['timer_tts_template'])) {
            $template = trim($_POST['configs']['timer_tts_template']);
            if (strpos($template, '{房间名}') === false) {
                echo json_encode([
                    'success' => false, 
                    'message' => '房间播报文本模板必须包含 {房间名} 占位符'
                ]);
                exit;
            }
        if (mb_strlen($template) > 100) {
            echo json_encode([
                'success' => false, 
                'message' => '房间播报文本模板不能超过100个字符'
            ]);
            exit;
        }
    }
    if (isset($_POST['configs']['manual_tts_template'])) {
        $template = trim($_POST['configs']['manual_tts_template']);
        if (strpos($template, '{房间名}') === false) {
            echo json_encode([
                'success' => false, 
                'message' => '手动播报文本模板必须包含 {房间名} 占位符'
            ]);
            exit;
        }
        if (mb_strlen($template) > 100) {
            echo json_encode([
                'success' => false, 
                'message' => '手动播报文本模板不能超过100个字符'
            ]);
            exit;
        }
    }
    if (isset($_POST['configs']['timer_tts_reservation'])) {
            $template = trim($_POST['configs']['timer_tts_reservation']);
            if (strpos($template, '{房间名}') === false) {
                echo json_encode([
                    'success' => false,
                    'message' => '预定播报文本模板必须包含 {房间名} 占位符'
                ]);
                exit;
            }
            if (mb_strlen($template) > 100) {
                echo json_encode([
                    'success' => false,
                    'message' => '预定播报文本模板不能超过100个字符'
                ]);
                exit;
            }
        }
        if (isset($_POST['configs']['timer_call_staff_tts_template'])) {
            $template = trim($_POST['configs']['timer_call_staff_tts_template']);
            if (strpos($template, '{房间名}') === false) {
                echo json_encode([
                    'success' => false, 
                    'message' => '呼叫服务文本模板必须包含 {房间名} 占位符'
                ]);
                exit;
            }
            if (mb_strlen($template) > 100) {
                echo json_encode([
                    'success' => false, 
                    'message' => '呼叫服务文本模板不能超过100个字符'
                ]);
                exit;
            }
        }
        if (isset($_POST['configs']['timer_scan_checkin_tts_template'])) {
            $template = trim($_POST['configs']['timer_scan_checkin_tts_template']);
            if (strpos($template, '{房间名}') === false) {
                echo json_encode([
                    'success' => false, 
                    'message' => '扫码开台文本模板必须包含 {房间名} 占位符'
                ]);
                exit;
            }
            if (mb_strlen($template) > 100) {
                echo json_encode([
                    'success' => false, 
                    'message' => '扫码开台文本模板不能超过100个字符'
                ]);
                exit;
            }
        }
        if (isset($_POST['configs']['timer_verification_tts_template'])) {
            $template = trim($_POST['configs']['timer_verification_tts_template']);
            if (strpos($template, '{房间名}') === false) {
                echo json_encode([
                    'success' => false, 
                    'message' => '核销服务文本模板必须包含 {房间名} 占位符'
                ]);
                exit;
            }
            if (mb_strlen($template) > 100) {
                echo json_encode([
                    'success' => false, 
                    'message' => '核销服务文本模板不能超过100个字符'
                ]);
                exit;
            }
        }
        if (isset($_POST['configs']['member_recharge_max_amount']) && 
            floatval($_POST['configs']['member_recharge_max_amount']) > 99999) {
            echo json_encode([
                'success' => false, 
                'message' => '单次充值最大限额不能超过99999'
            ]);
            exit;
        }
            if (isset($_POST['configs']['member_gift_max_amount']) && 
                floatval($_POST['configs']['member_gift_max_amount']) > 99999) {
                echo json_encode([
                    'success' => false, 
                    'message' => '单次赠送最大限额不能超过99999'
                ]);
                exit;
            }
            $max999Configs = [
                'room_max_hours',
                'room_hours_step',
                'room_min_hours',
                'reservation_grace_minutes',
                'reservation_overlap_minutes'
            ];
            foreach ($max999Configs as $configKey) {
                if (isset($_POST['configs'][$configKey]) && 
                    floatval($_POST['configs'][$configKey]) > 999) {
                    echo json_encode([
                        'success' => false, 
                        'message' => '配置项 ' . $configKey . ' 不能超过999'
                    ]);
                    exit;
                }
            }
            $max9999Configs = [
                'room_max_amount',
                'room_default_open_hours',
                'room_default_extend_hours',
                'timer_audio_auto_close_timeout',
                'snooze_alert_seconds',
                'alert_auto_mute_seconds'
            ];
            foreach ($max9999Configs as $configKey) {
                if (isset($_POST['configs'][$configKey]) && 
                    floatval($_POST['configs'][$configKey]) > 9999) {
                    echo json_encode([
                        'success' => false, 
                        'message' => '配置项 ' . $configKey . ' 不能超过9999'
                    ]);
                    exit;
                }
            }
            if (isset($_POST['configs']['room_open_gift_minutes'])) {
                $giftMinutes = $_POST['configs']['room_open_gift_minutes'];
                if (!ctype_digit(strval($giftMinutes))) {
                    echo json_encode([
                        'success' => false,
                        'message' => '开台赠送时长必须为整数'
                    ]);
                    exit;
                }
                $giftMinutesInt = intval($giftMinutes);
                if ($giftMinutesInt < 0 || $giftMinutesInt > 120) {
                    echo json_encode([
                        'success' => false,
                        'message' => '开台赠送时长必须在 0 到 120 分钟之间'
                    ]);
                    exit;
                }
            }
            if (isset($_POST['configs']['overtime_fee_rule'])) {
                $overtimeRule = $_POST['configs']['overtime_fee_rule'];
                if (!ctype_digit(strval($overtimeRule)) && !(is_numeric($overtimeRule) && intval($overtimeRule) >= 1 && strpos($overtimeRule, '.') === false)) {
                    echo json_encode([
                        'success' => false,
                        'message' => '超时费用规则必须为正整数'
                    ]);
                    exit;
                }
                $ruleInt = intval($overtimeRule);
                if ($ruleInt < 1 || $ruleInt > 300) {
                    echo json_encode([
                        'success' => false,
                        'message' => '超时费用规则必须在 1 到 300 之间'
                    ]);
                    exit;
                }
                if ($ruleInt !== 1 && $ruleInt % 5 !== 0) {
                    echo json_encode([
                        'success' => false,
                        'message' => '超时费用规则必须是 1（按实计费）或 5 的倍数（如5、10、15、30、60等）'
                    ]);
                    exit;
                }
            }
            if (isset($_POST['configs']['alert_offset_seconds'])) {
                $offsetValue = floatval($_POST['configs']['alert_offset_seconds']);
                if ($offsetValue < -1800 || $offsetValue > 1800) {
                    echo json_encode([
                        'success' => false, 
                        'message' => '音频提醒基准必须在 -1800 到 1800 之间'
                    ]);
                    exit;
                }
            }
            if (isset($_POST['configs']['site_title'])) {
                $_POST['configs']['site_title'] = trim($_POST['configs']['site_title']);
                if (mb_strlen($_POST['configs']['site_title']) > 30) {
                    echo json_encode(['success' => false, 'message' => '店铺名称不能超过30个字符']);
                    exit;
                }
                $site_title = $_POST['configs']['site_title'];
                unset($_POST['configs']['site_title']);
                $result = update_system_config('site_title', $site_title);
                if (!$result) {
                    echo json_encode(['success' => false, 'message' => '站点标题保存失败']);
                    exit;
                }
            }
            if (isset($_POST['configs']['scene_room_name'])) {
                $_POST['configs']['scene_room_name'] = trim($_POST['configs']['scene_room_name']);
                if (mb_strlen($_POST['configs']['scene_room_name']) > 2) {
                    echo json_encode(['success' => false, 'message' => '房间称呼不能超过2个字符']);
                    exit;
                }
                if (empty($_POST['configs']['scene_room_name'])) {
                    echo json_encode(['success' => false, 'message' => '房间称呼不能为空']);
                    exit;
                }
                $scene_room_name = $_POST['configs']['scene_room_name'];
                unset($_POST['configs']['scene_room_name']);
                $result = update_system_config('scene_room_name', $scene_room_name);
                if (!$result) {
                    echo json_encode(['success' => false, 'message' => '房间称呼保存失败']);
                    exit;
                }
            }
            if (isset($_POST['configs']['printer_name'])) {
                $_POST['configs']['printer_name'] = trim($_POST['configs']['printer_name']);
                $printer_name = $_POST['configs']['printer_name'];
                unset($_POST['configs']['printer_name']);
                $result = update_system_config('printer_name', $printer_name);
                if (!$result) {
                    echo json_encode(['success' => false, 'message' => '打印机名称保存失败']);
                    exit;
                }
            }
            try {
                $conn->begin_transaction();
                $success = true;
                $errors = [];
                foreach ($_POST['configs'] as $key => $value) {
                    $result = update_system_config($key, $value);
                    if (!$result) {
                        $success = false;
                        $errors[] = "无法保存: $key";
                    }
                }
                if ($success) {
            $conn->commit();
                    updateRefreshFlag();
                    echo json_encode(['success' => true, 'message' => '配置已保存，请刷新前端页面生效配置']);
                } else {
                    $conn->rollback();
                    echo json_encode(['success' => false, 'message' => implode(', ', $errors)]);
                }
                } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
        if ($_POST['action'] === 'add_config') {
            $requiredFields = ['config_key', 'config_value', 'config_type', 'config_group'];
            foreach ($requiredFields as $field) {
                if (!isset($_POST[$field]) || empty($_POST[$field])) {
                    echo json_encode(['success' => false, 'message' => "缺少必填字段: $field"]);
                    exit;
                }
            }
            $config_key = $_POST['config_key'];
                    if (!preg_match('/^[a-zA-Z0-9_]+$/', $config_key)) {
            echo json_encode(['success' => false, 'message' => '配置键名格式错误，只能包含字母、数字和下划线']);
            exit;
        }
            $complete_key = $_POST['config_group'] . '_' . $config_key;
            $config = [
                'config_key' => $complete_key,
                'config_value' => $_POST['config_value'],
                'config_type' => $_POST['config_type'],
                'config_group' => $_POST['config_group'],
                'config_description' => $_POST['config_description'] ?? '',
                'is_visible' => (int)($_POST['is_visible'] ?? 1)
            ];
            $result = add_system_config($config);
            if ($result === true) {
                echo json_encode(['success' => true, 'message' => '']);
            } else {
                echo json_encode(['success' => false, 'message' => $result]);
            }
            exit;
        }
        if ($_POST['action'] === 'delete_config') {
                    if (!isset($_POST['id']) || empty($_POST['id'])) {
            echo json_encode(['success' => false, 'message' => '配置ID不能为空']);
            exit;
        }
            $id = (int)$_POST['id'];
            $result = delete_system_config($id);
            if ($result) {
                echo json_encode(['success' => true, 'message' => '']);
            } else {
                echo json_encode(['success' => false, 'message' => '删除配置失败']);
            }
            exit;
        }
        if ($_POST['action'] === 'get_current_version') {
            $configs = get_system_config('system');
            $version = '未知版本';
            foreach ($configs as $config) {
                if ($config['config_key'] === 'program_version') {
                    $version = $config['config_value'];
                    break;
                }
            }
            echo json_encode(['success' => true, 'version' => $version]);
            exit;
        }
        if ($_POST['action'] === 'download_update') {
            if (!verifyLicenseAuthorization()) {
                usleep(rand(50, 150) * 1000);
                echo json_encode(['success' => false, 'message' => '网络连接超时，请稍后重试']);
                exit();
            }
            $version = $_POST['version'] ?? '';
            if (empty($version)) {
                echo json_encode(['success' => false, 'message' => '版本号不能为空']);
                exit;
            }
            $localPath = $_SERVER['DOCUMENT_ROOT'] . '/update.zip';
            try {
                $updateUrl = getRemoteUpdateUrl(REMOTE_UPDATE_ZIP, 0);
                $success = downloadRemoteFileWithRetry($updateUrl, $localPath, 3, 2);
                if (!$success) {
                    $updateUrl = getRemoteUpdateUrl(REMOTE_UPDATE_ZIP, 1);
                    $success = downloadRemoteFileWithRetry($updateUrl, $localPath, 3, 2);
                }
                if (!$success) {
                    throw new Exception('更新包下载失败，请检查网络连接或稍后重试！');
                }
                $fileSize = filesize($localPath);
                if ($fileSize === 0) {
                    @unlink($localPath);
                    throw new Exception('更新包下载失败：文件大小为0');
                }
                $fp = fopen($localPath, 'r');
                $header = fread($fp, 2);
                fclose($fp);
                if ($header !== 'PK') {
                    @unlink($localPath);
                    throw new Exception('更新包下载失败：文件格式错误');
                }
                echo json_encode(['success' => true, 'message' => '下载成功']);
            } catch (Exception $e) {
                if (file_exists($localPath)) {
                    @unlink($localPath);
                }
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            exit;
        }
        if ($_POST['action'] === 'extract_update') {
            $version = $_POST['version'] ?? '';
            $zipPath = $_SERVER['DOCUMENT_ROOT'] . '/update.zip';
            if (!file_exists($zipPath)) {
                echo json_encode(['success' => false, 'message' => '更新包不存在']);
                exit;
            }
            try {
                if (!class_exists('ZipArchive')) {
                    throw new Exception('服务器不支持Zip解压功能');
                }
                $zip = new ZipArchive();
                if ($zip->open($zipPath) !== true) {
                    throw new Exception('无法打开更新包');
                }
                $extractPath = $_SERVER['DOCUMENT_ROOT'];
                if (!$zip->extractTo($extractPath)) {
                    $zip->close();
                    throw new Exception('解压失败');
                }
                $zip->close();
                @unlink($zipPath);
                echo json_encode(['success' => true, 'message' => '解压成功']);
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            exit;
        }
        if ($_POST['action'] === 'update_version') {
            $version = $_POST['version'] ?? '';
            if (empty($version)) {
                echo json_encode(['success' => false, 'message' => '版本号不能为空']);
                exit;
            }
            try {
                if (!isset($conn) || !$conn) {
                    throw new Exception('数据库连接失败');
                }
                $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM system_config WHERE config_key = 'program_version'");
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                $row = $checkResult->fetch_assoc();
                if ($row['count'] == 0) {
                    $insertStmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_group, config_type, config_description) VALUES ('program_version', ?, 'system', 'text', '程序版本号')");
                    $insertStmt->bind_param("s", $version);
                    $result = $insertStmt->execute();
                } else {
                    $result = update_system_config('program_version', $version);
                }
                if ($result) {
                    echo json_encode(['success' => true, 'message' => '版本更新成功']);
                } else {
                    echo json_encode(['success' => false, 'message' => '数据库更新失败，请检查数据库权限']);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => '更新失败：' . $e->getMessage()]);
            }
            exit;
        }
        if ($_POST['action'] === 'get_remote_version_info') {
            $type = $_POST['type'] ?? 'version'; 
            try {
                if (!verifyLicenseAuthorization()) {
                    if ($type === 'version') {
                        $configs = get_system_config('system');
                        $localVersion = '未知版本';
                        foreach ($configs as $config) {
                            if ($config['config_key'] === 'program_version') {
                                $localVersion = $config['config_value'];
                                break;
                            }
                        }
                        echo json_encode(['success' => true, 'content' => $localVersion]);
                    } else {
                        echo json_encode(['success' => true, 'content' => '']);
                    }
                    exit;
                }
                $filename = ($type === 'versionlog') ? REMOTE_VERSIONLOG_FILE : REMOTE_VERSION_FILE;
                $url = getRemoteUpdateUrl($filename, 0);
                $content = getRemoteFileWithRetry($url, 3, 1);
                if ($content === false) {
                    $url = getRemoteUpdateUrl($filename, 1);
                    $content = getRemoteFileWithRetry($url, 3, 1);
                }
                if ($content === false) {
                    if ($type === 'versionlog') {
                        echo json_encode(['success' => true, 'content' => '', 'fallback' => true]);
                    } else {
                        throw new Exception('无法获取远程信息，请检查网络连接或稍后重试！');
                    }
                } else {
                    echo json_encode(['success' => true, 'content' => $content]);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            exit;
        }
        if ($_POST['action'] === 'fetch_remote_html') {
            $url = $_POST['url'] ?? '';
            try {
                if (empty($url)) {
                    throw new Exception('URL不能为空');
                }
                if (!filter_var($url, FILTER_VALIDATE_URL)) {
                    throw new Exception('无效的URL格式');
                }
                $content = @file_get_contents($url);
                if ($content === false) {
                    throw new Exception('无法获取远程内容');
                }
                echo json_encode(['success' => true, 'content' => $content]);
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            }
            exit;
        }
        if ($_POST['action'] === 'check_update_room_api') {
            $currentUserId = $_SESSION['admin_user_id'] ?? $_SESSION['front_user_id'] ?? 0;
            if ($currentUserId != 1) {
                echo json_encode(['success' => false, 'message' => '本操作仅支持admin用户操作！']);
                exit;
            }
            try {
                $apiExePath = 'D:\\phpRoom\\server\\apache\\bin\\room_api.exe';
                $tempDir = $_SERVER['DOCUMENT_ROOT'];
                $tempApiPath = $tempDir . '\\room_api_temp.exe';
                $localHash = file_exists($apiExePath) ? hash_file('sha256', $apiExePath) : '';
                $hashUrl = getRemoteUpdateUrl(REMOTE_API_HASH_FILE, 0);
                $remoteHash = getRemoteFileWithRetry($hashUrl, 3, 1);
                if ($remoteHash === false) {
                    $hashUrl = getRemoteUpdateUrl(REMOTE_API_HASH_FILE, 1);
                    $remoteHash = getRemoteFileWithRetry($hashUrl, 3, 1);
                }
                if ($remoteHash === false) {
                    echo json_encode(['success' => true, 'skip' => true, 'message' => '本地自检失败']);
                    exit;
                }
                $remoteHash = trim($remoteHash);
                if ($localHash === $remoteHash && !empty($localHash)) {
                    echo json_encode(['success' => true]);
                    exit;
                }
                exec('tasklist /FI "IMAGENAME eq room_api.exe" 2>&1', $tasklistOutput);
                $processExists = false;
                foreach ($tasklistOutput as $line) {
                    if (stripos($line, 'room_api.exe') !== false) {
                        $processExists = true;
                        break;
                    }
                }
                if ($processExists) {
                    exec('taskkill /F /IM room_api.exe 2>&1', $killOutput, $killReturn);
                    sleep(1);
                    exec('tasklist /FI "IMAGENAME eq room_api.exe" 2>&1', $recheckOutput);
                    foreach ($recheckOutput as $line) {
                        if (stripos($line, 'room_api.exe') !== false) {
                            echo json_encode(['success' => true, 'skip' => true, 'message' => '本地自检失败']);
                            exit;
                        }
                    }
                }
                $updateSuccess = false;
                $maxAttempts = 3;
                for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
                    $apiUrl = getRemoteUpdateUrl(REMOTE_API_EXE_FILE, 0);
                    $downloadSuccess = downloadRemoteFileWithRetry($apiUrl, $tempApiPath, 3, 1);
                    if (!$downloadSuccess) {
                        $apiUrl = getRemoteUpdateUrl(REMOTE_API_EXE_FILE, 1);
                        $downloadSuccess = downloadRemoteFileWithRetry($apiUrl, $tempApiPath, 3, 1);
                    }
                    if (!$downloadSuccess) {
                        if ($attempt < $maxAttempts) {
                            sleep(2); 
                            continue;
                        } else {
                            echo json_encode(['success' => true, 'skip' => true, 'message' => '本地自检失败']);
                            exit;
                        }
                    }
                    if (!rename($tempApiPath, $apiExePath)) {
                        @unlink($tempApiPath);
                        if ($attempt < $maxAttempts) {
                            sleep(2); 
                            continue;
                        } else {
                            echo json_encode(['success' => true, 'skip' => true, 'error' => true, 'message' => '自检文件失败，可能影响程序使用，请联系卖家']);
                            exit;
                        }
                    }
                    $newLocalHash = hash_file('sha256', $apiExePath);
                    if ($newLocalHash !== $remoteHash) {
                        if ($attempt < $maxAttempts) {
                            sleep(2); 
                            continue;
                        } else {
                            echo json_encode(['success' => true, 'skip' => true, 'error' => true, 'message' => '自检文件失败，可能影响程序使用，请联系卖家']);
                            exit;
                        }
                    }
                    $updateSuccess = true;
                    break;
                }
                if ($updateSuccess) {
                    $serviceStarted = false;
                    for ($i = 0; $i < 3; $i++) {
                        exec('net start phpRoom_api 2>&1', $startOutput, $startReturn);
                        sleep(1);
                        exec('sc query phpRoom_api 2>&1', $queryOutput);
                        $serviceRunning = false;
                        foreach ($queryOutput as $line) {
                            if (stripos($line, 'RUNNING') !== false) {
                                $serviceRunning = true;
                                break;
                            }
                        }
                        if ($serviceRunning) {
                            $serviceStarted = true;
                            break;
                        }
                    }
                    if (!$serviceStarted) {
                        echo json_encode(['success' => false, 'critical' => true, 'message' => '系统服务room_api启动失败，请自行启动，或重启电脑查看是否恢复']);
                        exit;
                    }
                    echo json_encode(['success' => true]);
                }
            } catch (Exception $e) {
                echo json_encode(['success' => true, 'skip' => true, 'message' => '本地自检失败']);
            }
            exit;
        }
    }
function logOperation($operation, $message, $details = '') {
    $logFile = $_SERVER['DOCUMENT_ROOT'] . '/backups/db_manager.log';
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp][$operation] $message";
    if (!empty($details)) {
        $logMessage .= " | Details: $details";
    }
    file_put_contents($logFile, $logMessage . PHP_EOL, FILE_APPEND);
}
function performAutoBackup($password, $purpose, $operation, $memberCardNo = '') {
    global $dbHost, $dbUser, $dbPassword, $dbName;
    $backupDir = $_SERVER['DOCUMENT_ROOT'] . '/backups';
    if (!is_dir($backupDir)) {
        if (!mkdir($backupDir, 0755, true)) {
            return ['success' => false, 'message' => '创建备份目录失败'];
        }
    }
    try {
        if ($operation === 'delete' && !empty($memberCardNo)) {
            $prefix = "auto_backup_carddelete_{$memberCardNo}_";
        } elseif ($operation === 'update') {
            $prefix = 'auto_backup_before_upgrade_';
        } elseif ($operation === 'cardtype') {
            $prefix = 'auto_backup_before_cardtype_';
        } else {
            $prefix = 'auto_backup_before_restore_';
        }
        $timestamp = date('Y-m-d_H-i-s');
        $backupFileName = "{$prefix}{$timestamp}";
        $sqlFilePath = "{$backupDir}/{$backupFileName}.sql";
        $encFilePath = "{$backupDir}/{$backupFileName}.enc";
        $mysqldumpPath = findMysqldumpPath();
        if (!$mysqldumpPath) {
            return ['success' => false, 'message' => '找不到mysqldump命令'];
        }
        logOperation('AUTO_BACKUP', "开始{$purpose}", "数据库: {$dbName}");
        $command = sprintf(
            '"%s" --host=%s --user=%s --password=%s --add-drop-table --triggers --routines --events --single-transaction --set-charset --opt %s > "%s"',
            $mysqldumpPath,
            escapeshellarg($dbHost),
            escapeshellarg($dbUser),
            escapeshellarg($dbPassword),
            escapeshellarg($dbName),
            $sqlFilePath
        );
        $outputLines = [];
        $returnCode = 0;
        exec($command . ' 2>&1', $outputLines, $returnCode);
        if ($returnCode !== 0) {
            $errorOutput = implode("\n", $outputLines);
            throw new Exception("数据库备份失败: {$errorOutput}");
        }
        if (!file_exists($sqlFilePath) || filesize($sqlFilePath) === 0) {
            throw new Exception("备份文件未正常生成");
        }
        $sqlContent = file_get_contents($sqlFilePath);
        if ($sqlContent === false) {
            throw new Exception("无法读取备份文件");
        }
        $key = hash('sha256', $password, true);
        $iv = random_bytes(16);
        $encryptedContent = openssl_encrypt($sqlContent, 'AES-256-CBC', $key, 0, $iv);
        if ($encryptedContent === false) {
            throw new Exception("加密失败");
        }
        $encryptedContent = $iv . $encryptedContent;
        if (file_put_contents($encFilePath, $encryptedContent) === false) {
            throw new Exception("无法写入加密文件");
        }
        unlink($sqlFilePath);
        $encFileSize = filesize($encFilePath);
        $filename = basename($encFilePath);
        logOperation('AUTO_BACKUP', "{$purpose}完成", "文件: {$filename}, 大小: " . formatBytes($encFileSize));
        return [
            'success' => true,
            'filename' => $filename,
            'size' => formatBytes($encFileSize),
            'path' => $encFilePath
        ];
    } catch (Exception $e) {
        if (isset($sqlFilePath) && file_exists($sqlFilePath)) {
            unlink($sqlFilePath);
        }
        if (isset($encFilePath) && file_exists($encFilePath)) {
            unlink($encFilePath);
        }
        logOperation('AUTO_BACKUP', "{$purpose}失败", $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
function createAutoBackup() {
    $purpose = $_POST['purpose'] ?? '程序更新前自动备份';
    $operation = $_POST['operation'] ?? 'update';
    $result = performAutoBackup('123456', $purpose, $operation);
    echo json_encode($result);
    exit;
}
function createBackup() {
    global $dbHost, $dbUser, $dbPassword, $dbName, $backupDir;
    $backupPassword = $_POST['backup_password'] ?? '';
            if (empty($backupPassword)) {
            logOperation('BACKUP', "备份密码为空");
            echo json_encode(['success' => false, 'message' => '备份密码不能为空']);
            exit;
        }
    $timestamp = date('Y-m-d_H-i-s');
    $backupFileName = "db_backup_{$dbName}_{$timestamp}";
    $sqlFilePath = "{$backupDir}/{$backupFileName}.sql";
    $encFilePath = "{$backupDir}/{$backupFileName}.enc";
    $mysqldumpPath = findMysqldumpPath();
            if (!$mysqldumpPath) {
            logOperation('BACKUP', "找不到mysqldump命令", "请确保程序安装正确");
            echo json_encode(['success' => false, 'message' => '找不到mysqldump命令']);
            exit;
        }
    try {
        logOperation('BACKUP', "开始使用mysqldump备份", "数据库: {$dbName}");
        $command = sprintf(
            '"%s" --host=%s --user=%s --password=%s --add-drop-table --triggers --routines --events --single-transaction --set-charset --opt %s > "%s"',
            $mysqldumpPath,
            escapeshellarg($dbHost),
            escapeshellarg($dbUser),
            escapeshellarg($dbPassword),
            escapeshellarg($dbName),
            $sqlFilePath
        );
        $outputLines = [];
        $returnCode = 0;
        $tempOutputFile = "{$backupDir}/mysqldump_output.tmp";
        $execCommand = $command . " 2> \"$tempOutputFile\"";
        exec($execCommand, $outputLines, $returnCode);
        $errorOutput = file_exists($tempOutputFile) ? file_get_contents($tempOutputFile) : '';
        if (file_exists($tempOutputFile)) {
            unlink($tempOutputFile);
        }
        if ($returnCode !== 0) {
            throw new Exception("mysqldump命令执行失败: " . ($errorOutput ?: "未知错误，返回码 $returnCode"));
        }
        if (!file_exists($sqlFilePath) || filesize($sqlFilePath) === 0) {
            throw new Exception("mysqldump命令未能创建有效的SQL备份文件，请检查数据库连接");
        }
        $backupSize = filesize($sqlFilePath);
        logOperation('BACKUP', "数据库导出成功", "文件大小: " . formatBytes($backupSize));
        logOperation('BACKUP', "开始加密备份文件");
        $sqlContent = file_get_contents($sqlFilePath);
        if ($sqlContent === false) {
            throw new Exception("无法读取备份文件");
        }
        $key = hash('sha256', $backupPassword, true);
        $iv = random_bytes(16);
        $encryptedContent = openssl_encrypt($sqlContent, 'AES-256-CBC', $key, 0, $iv);
        if ($encryptedContent === false) {
            $error = openssl_error_string();
            throw new Exception("加密失败: " . ($error ?: "未知错误"));
        }
        $encryptedContent = $iv . $encryptedContent;
        if (file_put_contents($encFilePath, $encryptedContent) === false) {
            throw new Exception("无法写入加密文件");
        }
        unlink($sqlFilePath);
        $encFileSize = filesize($encFilePath);
        logOperation('BACKUP', "备份完成", "加密文件大小: " . formatBytes($encFileSize));
        echo json_encode([
            'success' => true, 
            'message' => '', 
            'filename' => basename($encFilePath),
            'size' => formatBytes($encFileSize),
            'timestamp' => $timestamp,
            'method' => 'mysqldump'
        ]);
    } catch (Exception $e) {
        if (file_exists($sqlFilePath)) {
            unlink($sqlFilePath);
        }
        if (file_exists($encFilePath)) {
            unlink($encFilePath);
        }
        logOperation('BACKUP', "备份失败", $e->getMessage());
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
function listBackups() {
    global $backupDir;
    if (!is_dir($backupDir)) {
        logOperation('LIST', "备份目录不存在", $backupDir);
        echo json_encode(['success' => false, 'message' => '备份目录不存在，请检查目录权限']);
        exit;
    }
    $files = [];
    if ($handle = opendir($backupDir)) {
        while (false !== ($entry = readdir($handle))) {
            if ($entry != "." && $entry != ".." && pathinfo($entry, PATHINFO_EXTENSION) === 'enc') {
                $files[] = $backupDir . DIRECTORY_SEPARATOR . $entry;
            }
        }
        closedir($handle);
    }
    $backups = [];
    if (is_array($files)) {
        foreach ($files as $file) {
            $filename = basename($file);
            $size = filesize($file);
            $timestamp = filemtime($file);
            $backups[] = [
                'filename' => $filename,
                'size' => formatBytes($size),
                'timestamp' => date('Y-m-d H:i:s', $timestamp),
                'method' => 'mysqldump'
            ];
        }
    }
    if (!empty($backups)) {
        usort($backups, function($a, $b) {
            $dateA = new DateTime($a['timestamp']);
            $dateB = new DateTime($b['timestamp']);
            return $dateB <=> $dateA;
        });
        $backups = array_slice($backups, 0, 10);
    }
    $totalBackups = count($files);
    $shownBackups = count($backups);
    logOperation('LIST', "获取备份列表", "找到 {$totalBackups} 个备份文件，显示最近的 {$shownBackups} 个");
    echo json_encode([
        'success' => true, 
        'backups' => $backups,
        'total' => $totalBackups,
        'shown' => $shownBackups
    ]);
}
function deleteBackup() {
    global $backupDir;
    $filename = $_POST['filename'] ?? '';
    if (empty($filename)) {
        echo json_encode(['success' => false, 'message' => '文件名不能为空']);
        exit;
    }
    if (!preg_match('/^(db_backup_|auto_backup_).*\.enc$/', $filename)) {
        logOperation('DELETE', "删除备份文件失败", "无效的文件名: {$filename}");
        echo json_encode(['success' => false, 'message' => '无效的备份文件名']);
        exit;
    }
    $filePath = "{$backupDir}/{$filename}";
    if (!file_exists($filePath)) {
        logOperation('DELETE', "删除备份文件失败", "文件不存在: {$filename}");
        echo json_encode(['success' => false, 'message' => '备份文件不存在']);
        exit;
    }
    if (unlink($filePath)) {
        logOperation('DELETE', "备份文件已删除", $filename);
        echo json_encode(['success' => true, 'message' => '']);
    } else {
        logOperation('DELETE', "删除备份文件失败", "无法删除文件: {$filename}");
        echo json_encode(['success' => false, 'message' => '无法删除备份文件']);
    }
}
function startRestore() {
    global $conn, $dbHost, $dbUser, $dbPassword, $dbName, $backupDir;
    $restorePassword = $_POST['restore_password'] ?? '';
    if (empty($restorePassword)) {
        logOperation('RESTORE', "恢复密码为空");
        echo json_encode(['success' => false, 'message' => '恢复密码不能为空']);
        exit;
    }
    if (!isset($_FILES['restore_file']) || $_FILES['restore_file']['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = '文件上传失败: ';
        if (isset($_FILES['restore_file'])) {
            switch ($_FILES['restore_file']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    $errorMessage .= '文件太大';
                    break;
                case UPLOAD_ERR_PARTIAL:
                    $errorMessage .= '文件只有部分被上传';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $errorMessage .= '没有文件被上传';
                    break;
                default:
                    $errorMessage .= '未知错误 (代码: ' . $_FILES['restore_file']['error'] . ')';
            }
        } else {
            $errorMessage .= '未提供文件';
        }
        logOperation('RESTORE', "文件上传失败", $_FILES['restore_file'] ? "错误码: " . $_FILES['restore_file']['error'] : "FILES数组中没有restore_file");
        echo json_encode(['success' => false, 'message' => '文件上传失败：' . $errorMessage]);
        exit;
    }
    $fileName = $_FILES['restore_file']['name'];
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    if ($fileExtension !== 'enc') {
        logOperation('RESTORE', "文件类型错误", "期望: enc, 实际: $fileExtension");
        echo json_encode(['success' => false, 'message' => '文件类型必须是加密备份文件(.enc)']);
        exit;
    }
    $tempDir = $backupDir . '/temp_' . time();
    if (!is_dir($tempDir)) {
        mkdir($tempDir, 0755, true);
    }
    $encryptedFilePath = $tempDir . '/' . $fileName;
    if (!move_uploaded_file($_FILES['restore_file']['tmp_name'], $encryptedFilePath)) {
        logOperation('RESTORE', "无法移动上传的文件", "从 {$_FILES['restore_file']['tmp_name']} 到 $encryptedFilePath");
        echo json_encode(['success' => false, 'message' => '无法移动上传的文件']);
        deleteDir($tempDir);
        exit;
    }
    $_SESSION['restore'] = [
        'filename' => $fileName,
        'password' => $restorePassword,
        'temp_dir' => $tempDir,
        'start_time' => time(),
        'progress' => 0,
        'status' => 'preparing',
        'message' => '正在准备恢复...',
        'warnings' => []
    ];
    try {
        $_SESSION['restore']['status'] = 'decrypting';
        $_SESSION['restore']['message'] = '正在解密备份文件...';
        $_SESSION['restore']['progress'] = 10;
        $encryptedData = file_get_contents($encryptedFilePath);
        if ($encryptedData === false) {
            throw new Exception("无法读取加密文件");
        }
        if (strlen($encryptedData) <= 16) {
            throw new Exception("加密文件格式不正确或已损坏（文件过小）");
        }
        $iv = substr($encryptedData, 0, 16);
        $encryptedContent = substr($encryptedData, 16);
        $key = hash('sha256', $restorePassword, true);
        $decryptedContent = openssl_decrypt($encryptedContent, 'AES-256-CBC', $key, 0, $iv);
        if ($decryptedContent === false) {
            $error = openssl_error_string();
            throw new Exception("备份文件密码错误，恢复失败！" . ($error ? ": $error" : ""));
        }
        if (strlen($decryptedContent) < 10 || stripos($decryptedContent, 'CREATE TABLE') === false) {
            throw new Exception("解密后的内容不是有效的SQL备份文件");
        }
        $preBackupResult = performAutoBackup('123456', '恢复前自动备份', 'delete');
        if (!$preBackupResult['success']) {
            logOperation('RESTORE', "恢复前自动备份失败", $preBackupResult['message']);
            echo json_encode(['success' => false, 'message' => '恢复前自动备份失败: ' . $preBackupResult['message']]);
            deleteDir($tempDir);
            exit;
        }
        $sqlFilePath = $tempDir . '/restore.sql';
        if (file_put_contents($sqlFilePath, $decryptedContent) === false) {
            throw new Exception("无法写入解密后的SQL文件");
        }
        unlink($encryptedFilePath);
        $_SESSION['restore']['status'] = 'restoring';
        $_SESSION['restore']['message'] = '正在清空现有数据库...';
        $_SESSION['restore']['progress'] = 25;
        $mysqlPath = findMysqlPath();
        if (!$mysqlPath) {
            throw new Exception("找不到mysql客户端命令");
        }
        logOperation('RESTORE', "开始全面清空现有数据库", "数据库: {$dbName}");
        $dropObjectsSQL = "";
        $dropObjectsSQL = "SET FOREIGN_KEY_CHECKS = 0;\n";
        $triggersResult = $conn->query("SHOW TRIGGERS");
        if ($triggersResult && $triggersResult->num_rows > 0) {
            $dropObjectsSQL .= "-- 删除所有触发器\n";
            while ($triggerRow = $triggersResult->fetch_assoc()) {
                $triggerName = $triggerRow['Trigger'];
                $dropObjectsSQL .= "DROP TRIGGER IF EXISTS `{$triggerName}`;\n";
            }
        }
        $eventsResult = $conn->query("SHOW EVENTS");
        if ($eventsResult && $eventsResult->num_rows > 0) {
            $dropObjectsSQL .= "-- 删除所有事件\n";
            while ($eventRow = $eventsResult->fetch_assoc()) {
                $eventName = $eventRow['Name'];
                $dropObjectsSQL .= "DROP EVENT IF EXISTS `{$eventName}`;\n";
            }
        }
        $tablesResult = $conn->query("SHOW TABLES");
        if ($tablesResult && $tablesResult->num_rows > 0) {
            $dropObjectsSQL .= "-- 删除所有表\n";
            $tables = [];
            while ($tableRow = $tablesResult->fetch_row()) {
                $tables[] = $tableRow[0];
            }
            foreach ($tables as $tableName) {
                $dropObjectsSQL .= "DROP TABLE IF EXISTS `{$tableName}`;\n";
            }
        }
        $dropObjectsSQL .= "SET FOREIGN_KEY_CHECKS = 1;\n";
        if (!empty($dropObjectsSQL)) {
            $dropObjectsFilePath = $tempDir . '/drop_objects.sql';
            if (file_put_contents($dropObjectsFilePath, $dropObjectsSQL) === false) {
                throw new Exception("无法写入删除数据库对象的SQL文件");
            }
            $dropCommand = sprintf(
                '"%s" --host=%s --user=%s --password=%s %s < "%s"',
                $mysqlPath,
                escapeshellarg($dbHost),
                escapeshellarg($dbUser),
                escapeshellarg($dbPassword),
                escapeshellarg($dbName),
                $dropObjectsFilePath
            );
            $dropOutputFile = "{$tempDir}/drop_output.tmp";
            $dropExecCommand = $dropCommand . " 2> \"$dropOutputFile\"";
            $dropOutputLines = [];
            $dropReturnCode = 0;
            exec($dropExecCommand, $dropOutputLines, $dropReturnCode);
            $dropErrorOutput = file_exists($dropOutputFile) ? file_get_contents($dropOutputFile) : '';
            if ($dropReturnCode !== 0 && !empty($dropErrorOutput)) {
                logOperation('RESTORE', "清空数据库时出现警告", $dropErrorOutput);
            }
            if (file_exists($dropObjectsFilePath)) {
                unlink($dropObjectsFilePath);
            }
            if (file_exists($dropOutputFile)) {
                unlink($dropOutputFile);
            }
        }
        $_SESSION['restore']['status'] = 'restoring';
        $_SESSION['restore']['message'] = '正在恢复数据库...';
        $_SESSION['restore']['progress'] = 40;
        $command = sprintf(
            '"%s" --host=%s --user=%s --password=%s %s < "%s"',
            $mysqlPath,
            escapeshellarg($dbHost),
            escapeshellarg($dbUser),
            escapeshellarg($dbPassword),
            escapeshellarg($dbName),
            $sqlFilePath
        );
        logOperation('RESTORE', "开始使用mysql客户端恢复数据库", "数据库: {$dbName}");
        $tempOutputFile = "{$tempDir}/mysql_output.tmp";
        $execCommand = $command . " 2> \"$tempOutputFile\"";
        $outputLines = [];
        $returnCode = 0;
        exec($execCommand, $outputLines, $returnCode);
        $errorOutput = file_exists($tempOutputFile) ? file_get_contents($tempOutputFile) : '';
        if ($returnCode !== 0) {
            throw new Exception("恢复数据库失败: " . ($errorOutput ?: "未知错误，返回码 $returnCode"));
        }
        if (!empty($errorOutput)) {
            $_SESSION['restore']['warnings'][] = "恢复过程中有警告: " . $errorOutput;
            logOperation('RESTORE', "恢复过程中有警告", $errorOutput);
        }
        $_SESSION['restore']['status'] = 'cleaning';
        $_SESSION['restore']['message'] = '正在清理临时文件...';
        $_SESSION['restore']['progress'] = 90;
        if (file_exists($sqlFilePath)) {
            unlink($sqlFilePath);
        }
        if (file_exists($tempOutputFile)) {
            unlink($tempOutputFile);
        }
        deleteDir($tempDir);
        $_SESSION['restore']['status'] = 'completed';
        $_SESSION['restore']['message'] = '恢复完成';
        $_SESSION['restore']['progress'] = 100;
        $_SESSION['restore']['end_time'] = time();
        updateRefreshFlag();
        $response = [
            'success' => true, 
            'message' => '',
            'elapsed_time' => $_SESSION['restore']['end_time'] - $_SESSION['restore']['start_time'] . '秒'
        ];
        if (!empty($_SESSION['restore']['warnings'])) {
            $response['warnings'] = $_SESSION['restore']['warnings'];
        }
        logOperation('RESTORE', "恢复过程完成", "耗时: " . ($_SESSION['restore']['end_time'] - $_SESSION['restore']['start_time']) . "秒");
        echo json_encode($response);
    } catch (Exception $e) {
        if (isset($sqlFilePath) && file_exists($sqlFilePath)) {
            unlink($sqlFilePath);
        }
        if (isset($tempOutputFile) && file_exists($tempOutputFile)) {
            unlink($tempOutputFile);
        }
        if (is_dir($tempDir)) {
            deleteDir($tempDir);
        }
        $_SESSION['restore']['status'] = 'failed';
        $_SESSION['restore']['message'] = '';
        $_SESSION['restore']['progress'] = 0;
        logOperation('RESTORE', "恢复失败", $e->getMessage() . "\n" . $e->getTraceAsString());
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
function getRestoreProgress() {
    if (!isset($_SESSION['restore'])) {
        echo json_encode(['success' => false, 'message' => '恢复会话不存在']);
        exit;
    }
    echo json_encode([
        'success' => true,
        'progress' => $_SESSION['restore']['progress'],
        'status' => $_SESSION['restore']['status'],
        'message' => $_SESSION['restore']['message'],
        'warnings' => $_SESSION['restore']['warnings'] ?? []
    ]);
}
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}
function findMysqldumpPath() {
    return 'D:\\phpRoom\\server\\mariadb\\bin\\mysqldump.exe';
}
function findMysqlPath() {
    return 'D:\\phpRoom\\server\\mariadb\\bin\\mysql.exe';
}
function downloadBackup() {
    global $backupDir;
    $filename = $_GET['file'] ?? '';
    if (empty($filename) || !preg_match('/^(db_backup_|auto_backup_).*\.enc$/', $filename)) {
        logOperation('DOWNLOAD', "下载备份文件失败", "无效的文件名: " . ($filename ?: "空文件名"));
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => '无效的备份文件名']);
        exit;
    }
    $filePath = $backupDir . '/' . $filename;
    if (!file_exists($filePath)) {
        logOperation('DOWNLOAD', "下载备份文件失败", "文件不存在: $filename");
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => '备份文件不存在']);
        exit;
    }
    $fileSize = filesize($filePath);
    logOperation('DOWNLOAD', "下载备份文件", "文件: $filename, 大小: " . formatBytes($fileSize));
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . $fileSize);
    ob_clean();
    flush();
    readfile($filePath);
    exit;
}
function deleteDir($dir) {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = "$dir/$file";
        if (is_dir($path)) {
            deleteDir($path);
        } else {
            unlink($path);
        }
    }
    rmdir($dir);
}
if (isset($_POST['action']) && $_POST['action'] === 'upload_background') {
    header('Content-Type: application/json');
    if (!isset($_FILES['background_file']) || $_FILES['background_file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => '上传失败，请检查文件格式和大小！']);
        exit;
    }
    $file = $_FILES['background_file'];
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!in_array($file['type'], $allowedTypes) || $file['size'] > 500 * 1024) {
        echo json_encode(['success' => false, 'message' => '上传失败，请检查文件格式和大小！']);
        exit;
    }
    if (getimagesize($file['tmp_name']) === false) {
        echo json_encode(['success' => false, 'message' => '上传失败，请检查文件格式和大小！']);
        exit;
    }
    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/asset/images';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
        exit;
    }
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $newFileName = 'background_' . date('YmdHis') . '_' . uniqid() . '.' . $fileExtension;
    $uploadPath = $uploadDir . '/' . $newFileName;
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
        exit;
    }
    $backgroundUrl = '/asset/images/' . $newFileName;
    $opacity = 70; 
    $conn->begin_transaction();
    try {
        $updateStmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
        $bgKey = 'background_image';
        $updateStmt->bind_param("ss", $backgroundUrl, $bgKey);
        $updateStmt->execute();
        $updateStmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
        $opacityKey = 'container_opacity';
        $opacityValue = strval($opacity);
        $updateStmt->bind_param("ss", $opacityValue, $opacityKey);
        $updateStmt->execute();
        $conn->commit();
        echo json_encode([
            'success' => true, 
            'message' => '图片上传成功',
            'background_url' => $backgroundUrl,
            'opacity' => $opacity
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        unlink($uploadPath); 
        echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
    }
    exit;
}
if (isset($_POST['action']) && in_array($_POST['action'], ['get_background_info', 'update_background_opacity', 'update_background_image', 'remove_background', 'get_existing_backgrounds', 'delete_background_file', 'apply_background_settings'])) {
    header('Content-Type: application/json');
    switch ($_POST['action']) {
        case 'get_background_info':
            $backgroundStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'background_image' ORDER BY id DESC LIMIT 1");
            $backgroundStmt->execute();
            $backgroundResult = $backgroundStmt->get_result();
            $backgroundUrl = $backgroundResult->num_rows > 0 ? $backgroundResult->fetch_assoc()['config_value'] : '';
            $opacityStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'container_opacity' ORDER BY id DESC LIMIT 1");
            $opacityStmt->execute();
            $opacityResult = $opacityStmt->get_result();
            $opacity = $opacityResult->num_rows > 0 ? intval($opacityResult->fetch_assoc()['config_value']) : 70;
            echo json_encode([
                'success' => true,
                'background_url' => $backgroundUrl,
                'opacity' => $opacity
            ]);
            break;
        case 'update_background_opacity':
            $opacity = intval($_POST['opacity'] ?? 70);
            $opacity = max(0, min(100, $opacity));
            $stmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_type, config_group, config_description, is_visible) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE config_value = ?");
            $configKey = 'container_opacity';
            $configValue = strval($opacity);
            $configType = 'number';
            $configGroup = 'system';
            $configDescription = '内容区域透明度百分比';
            $isVisible = 0; 
            $stmt->bind_param("sssssis", $configKey, $configValue, $configType, $configGroup, $configDescription, $isVisible, $configValue);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => '修改成功，请刷新前端页面更新！']);
            } else {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
            }
            break;
        case 'update_background_image':
            $backgroundUrl = $_POST['background_url'] ?? '';
            if (empty($backgroundUrl)) {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
                break;
            }
            $stmt = $conn->prepare("INSERT INTO system_config (config_key, config_value, config_type, config_group, config_description, is_visible) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE config_value = ?");
            $configKey = 'background_image';
            $configValue = $backgroundUrl;
            $configType = 'text';
            $configGroup = 'system';
            $configDescription = '系统背景图片路径';
            $isVisible = 0;
            $stmt->bind_param("sssssis", $configKey, $configValue, $configType, $configGroup, $configDescription, $isVisible, $configValue);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => '修改成功，请刷新前端页面更新！']);
            } else {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
            }
            break;
        case 'apply_background_settings':
            $opacity = max(0, min(100, intval($_POST['opacity'] ?? 70)));
            $backgroundUrl = $_POST['background_url'] ?? '';
            if (empty($backgroundUrl)) {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
                break;
            }
            $conn->begin_transaction();
            try {
                $updateStmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
                $opacityKey = 'container_opacity';
                $opacityValue = strval($opacity);
                $updateStmt->bind_param("ss", $opacityValue, $opacityKey);
                $updateStmt->execute();
                $updateStmt = $conn->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
                $bgKey = 'background_image';
                $updateStmt->bind_param("ss", $backgroundUrl, $bgKey);
                $updateStmt->execute();
                $conn->commit();
                updateRefreshFlag();
                echo json_encode(['success' => true, 'message' => '修改成功，请刷新前端页面更新！']);
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
            }
            break;
        case 'remove_background':
            $stmt1 = $conn->prepare("UPDATE system_config SET config_value = '' WHERE config_key = 'background_image'");
            $stmt2 = $conn->prepare("UPDATE system_config SET config_value = '' WHERE config_key = 'container_opacity'");
            if ($stmt1->execute() && $stmt2->execute()) {
                updateRefreshFlag();
                echo json_encode(['success' => true, 'message' => '修改成功，请刷新前端页面更新！']);
            } else {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
            }
            break;
        case 'get_existing_backgrounds':
            $imagesDir = $_SERVER['DOCUMENT_ROOT'] . '/asset/images';
            $backgrounds = [];
            if (is_dir($imagesDir)) {
                $files = glob($imagesDir . '/background_*');
                foreach ($files as $file) {
                    $filename = basename($file);
                    $backgrounds[] = [
                        'filename' => $filename,
                        'filepath' => '/asset/images/' . $filename,
                        'filesize' => formatBytes(filesize($file)),
                        'upload_time' => date('Y-m-d H:i:s', filemtime($file))
                    ];
                }
            }
            echo json_encode([
                'success' => true,
                'backgrounds' => $backgrounds
            ]);
            break;
        case 'delete_background_file':
            $filename = $_POST['filename'] ?? '';
            if (empty($filename) || !preg_match('/^background_.*\.jpg$/i', $filename)) {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
                break;
            }
            $filepath = $_SERVER['DOCUMENT_ROOT'] . '/asset/images/' . $filename;
            if (!file_exists($filepath)) {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
                break;
            }
            $stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'background_image' ORDER BY id DESC LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();
            $isCurrentBackground = false;
            if ($result->num_rows > 0) {
                $currentBackground = $result->fetch_assoc()['config_value'];
                if ($currentBackground === '/asset/images/' . $filename) {
                    $isCurrentBackground = true;
                    $conn->prepare("UPDATE system_config SET config_value = '' WHERE config_key = 'background_image'")->execute();
                }
            }
            if (unlink($filepath)) {
                if ($isCurrentBackground) {
                    updateRefreshFlag();
                }
                echo json_encode(['success' => true, 'message' => '图片删除成功！']);
            } else {
                echo json_encode(['success' => false, 'message' => '设置失败，请检查输入！']);
            }
            break;
    }
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'query_member') {
        header('Content-Type: application/json');
        $phoneNumber = $_POST['phone_number'] ?? '';
        if (empty($phoneNumber)) {
            echo json_encode(['success' => false, 'message' => '手机号码不能为空']);
            exit;
        }
        try {
            $stmt = $conn->prepare("SELECT member_card_no, name, balance, is_enabled, level_id FROM member_accounts WHERE member_card_no = ? LIMIT 1");
            $stmt->bind_param('s', $phoneNumber);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => '未找到该会员信息']);
                exit;
            }
            $memberData = $result->fetch_assoc();
            echo json_encode(['success' => true, 'data' => $memberData]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'update_member') {
        header('Content-Type: application/json');
        $memberCardNo = $_POST['member_card_no'] ?? '';
        $name = $_POST['name'] ?? '';
        $password = $_POST['password'] ?? '';
        $levelId = $_POST['level_id'] ?? '';
        if (empty($memberCardNo) || empty($name)) {
            echo json_encode(['success' => false, 'message' => '会员卡号和姓名不能为空']);
            exit;
        }
        if (mb_strlen($name, 'UTF-8') > 6) {
            echo json_encode(['success' => false, 'message' => '会员姓名最多6个字']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare("SELECT member_card_no, name, level_id FROM member_accounts WHERE member_card_no = ? FOR UPDATE");
            $stmt->bind_param('s', $memberCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡不存在']);
                exit;
            }
            $originalMember = $result->fetch_assoc();
            if (!empty($levelId)) {
                $stmt = $conn->prepare("SELECT id FROM member_levels WHERE id = ? LIMIT 1");
                $stmt->bind_param('i', $levelId);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($result->num_rows === 0) {
                    $conn->rollback();
                    echo json_encode(['success' => false, 'message' => '选择的会员类型不存在']);
                    exit;
                }
            }
            $hashedPassword = null;
            if (!empty($password)) {
                if (!preg_match('/^\d{6,}$/', $password)) {
                    $conn->rollback();
                    echo json_encode(['success' => false, 'message' => '密码必须至少6位数字']);
                    exit;
                }
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            }
            if (!empty($hashedPassword) && !empty($levelId)) {
                $stmt = $conn->prepare("UPDATE member_accounts SET name = ?, password = ?, level_id = ? WHERE member_card_no = ?");
                $stmt->bind_param('ssis', $name, $hashedPassword, $levelId, $memberCardNo);
            } elseif (!empty($hashedPassword)) {
                $stmt = $conn->prepare("UPDATE member_accounts SET name = ?, password = ? WHERE member_card_no = ?");
                $stmt->bind_param('sss', $name, $hashedPassword, $memberCardNo);
            } elseif (!empty($levelId)) {
                $stmt = $conn->prepare("UPDATE member_accounts SET name = ?, level_id = ? WHERE member_card_no = ?");
                $stmt->bind_param('sis', $name, $levelId, $memberCardNo);
            } else {
                $stmt = $conn->prepare("UPDATE member_accounts SET name = ? WHERE member_card_no = ?");
                $stmt->bind_param('ss', $name, $memberCardNo);
            }
            $success = $stmt->execute();
            if ($success) {
                $oldName = null;
                $newName = null;
                $passwordChange = null;
                $oldLevelId = null;
                $newLevelId = null;
                if ($name !== $originalMember['name']) {
                    $oldName = $originalMember['name'];
                    $newName = $name;
                }
                if (!empty($hashedPassword)) {
                    $passwordChange = '重置密码';
                }
                if (!empty($levelId) && $levelId != $originalMember['level_id']) {
                    $oldLevelId = $originalMember['level_id'];
                    $newLevelId = $levelId;
                }
                if (($oldName && $newName) || $passwordChange || ($oldLevelId && $newLevelId)) {
                    $operatorId = getCurrentOperatorId();
                    $historyStmt = $conn->prepare("INSERT INTO member_card_transfer_history (source_card_no, target_card_no, transfer_amount, old_name, new_name, password_change, old_level_id, new_level_id, operator_id) VALUES (?, ?, 0, ?, ?, ?, ?, ?, ?)");
                    $historyStmt->bind_param('sssssiis', $memberCardNo, $memberCardNo, $oldName, $newName, $passwordChange, $oldLevelId, $newLevelId, $operatorId);
                    $historyStmt->execute();
                }
                $conn->commit();
                echo json_encode(['success' => true, 'message' => '']);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员信息更新失败']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'delete_single_member') {
        set_time_limit(1200);
        header('Content-Type: application/json');
        $memberCardNo = $_POST['member_card_no'] ?? '';
        if (empty($memberCardNo)) {
            echo json_encode(['success' => false, 'message' => '会员卡号不能为空']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE member_card_no = ?");
            $stmt->bind_param('s', $memberCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            $memberExists = $result->fetch_assoc()['count'] > 0;
            if (!$memberExists) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡不存在']);
                exit;
            }
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE member_card_no = ? AND status = 0");
            $stmt->bind_param('s', $memberCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            $activeOrdersCount = $result->fetch_assoc()['count'];
            if ($activeOrdersCount > 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '有正在使用的订单，无法删除！']);
                exit;
            }
            $backupResult = performAutoBackup('123456', '会员卡删除前自动备份', 'delete', $memberCardNo);
            if (!$backupResult['success']) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '自动备份失败：' . $backupResult['message'] . '，为安全起见，删除操作已取消']);
                exit;
            }
            $stmt = $conn->prepare("DELETE FROM member_accounts WHERE member_card_no = ?");
            $stmt->bind_param('s', $memberCardNo);
            $deleteResult = $stmt->execute();
            if ($deleteResult && $stmt->affected_rows > 0) {
                $conn->commit();
                $detailsLog = "删除会员卡 {$memberCardNo}, 备份文件: {$backupResult['filename']}";
                logOperation('MEMBER_DELETE', "会员卡删除成功", $detailsLog);
                echo json_encode([
                    'success' => true, 
                    'message' => '删除前自动备份数据库成功。会员卡删除成功。',
                    'backup_file' => $backupResult['filename']
                ]);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '删除前自动备份数据库成功。会员卡删除过程中发生错误，操作已回滚。']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            logOperation('MEMBER_DELETE', "会员卡删除失败", $e->getMessage());
            if (isset($backupResult) && $backupResult['success']) {
                echo json_encode(['success' => false, 'message' => '删除前自动备份数据库成功。会员卡删除失败：' . $e->getMessage()]);
            } else {
                echo json_encode(['success' => false, 'message' => '会员卡删除失败：' . $e->getMessage()]);
            }
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'update_member_card_no') {
        set_time_limit(1200);
        header('Content-Type: application/json');
        $oldCardNo = $_POST['old_card_no'] ?? '';
        $newCardNo = $_POST['new_card_no'] ?? '';
        if (empty($oldCardNo) || empty($newCardNo)) {
            echo json_encode(['success' => false, 'message' => '原卡号和新卡号不能为空']);
            exit;
        }
        if ($oldCardNo === $newCardNo) {
            echo json_encode(['success' => false, 'message' => '新卡号与原卡号相同，无需修改']);
            exit;
        }
        if (!preg_match('/^1[3-9]\d{9}$/', $newCardNo)) {
            echo json_encode(['success' => false, 'message' => '新卡号格式不正确，请输入11位手机号']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare("SELECT member_card_no, name, balance FROM member_accounts WHERE member_card_no = ?");
            $stmt->bind_param('s', $oldCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '原会员卡号不存在']);
                exit;
            }
            $oldMemberInfo = $result->fetch_assoc();
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE member_card_no = ?");
            $stmt->bind_param('s', $newCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            $newCardExists = $result->fetch_assoc()['count'] > 0;
            if ($newCardExists) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '新卡号已存在，请选择其他卡号']);
                exit;
            }
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE member_card_no = ? AND status = 0");
            $stmt->bind_param('s', $oldCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            $activeOrdersCount = $result->fetch_assoc()['count'];
            if ($activeOrdersCount > 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '有正在使用的订单，无法更改！']);
                exit;
            }
            $stmt = $conn->prepare("UPDATE member_accounts SET member_card_no = ? WHERE member_card_no = ?");
            $stmt->bind_param('ss', $newCardNo, $oldCardNo);
            $result = $stmt->execute();
            $accountsCount = $stmt->affected_rows;
            if ($result && $accountsCount > 0) {
                $operatorId = getCurrentOperatorId();
                $stmt = $conn->prepare("INSERT INTO member_card_transfer_history (source_card_no, archived_card_no, target_card_no, transfer_amount, source_card_name, target_card_name, is_new_card_created, operator_id) VALUES (?, '', ?, ?, ?, ?, 0, ?)");
                $stmt->bind_param('ssdssi', $oldCardNo, $newCardNo, $oldMemberInfo['balance'], $oldMemberInfo['name'], $oldMemberInfo['name'], $operatorId);
                $stmt->execute();
                $conn->commit();
                logOperation('CARD_UPDATE', "会员卡号修改成功", "从 {$oldCardNo} 更新为 {$newCardNo}");
                echo json_encode([
                    'success' => true, 
                    'message' => '卡号修改成功。所有关联记录已自动同步更新。'
                ]);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '卡号修改失败，数据库更新异常，操作已回滚。']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            logOperation('CARD_UPDATE', "会员卡号修改失败", $e->getMessage());
            echo json_encode(['success' => false, 'message' => '卡号修改失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'disable_member_card') {
        header('Content-Type: application/json');
        $memberCardNo = $_POST['member_card_no'] ?? '';
        if (empty($memberCardNo)) {
            echo json_encode(['success' => false, 'message' => '会员卡号不能为空']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $checkStmt = $conn->prepare("SELECT member_card_no, is_enabled FROM member_accounts WHERE member_card_no = ? LIMIT 1 FOR UPDATE");
            $checkStmt->bind_param('s', $memberCardNo);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows === 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡不存在']);
                exit;
            }
            $memberData = $checkResult->fetch_assoc();
            if ($memberData['is_enabled'] == 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡已经是停用状态']);
                exit;
            }
            $orderCheckStmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE member_card_no = ? AND status = 0");
            $orderCheckStmt->bind_param('s', $memberCardNo);
            $orderCheckStmt->execute();
            $orderResult = $orderCheckStmt->get_result();
            $activeOrdersCount = $orderResult->fetch_assoc()['count'];
            if ($activeOrdersCount > 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '有正在使用的订单，无法更改！']);
                exit;
            }
            $disableStmt = $conn->prepare("UPDATE member_accounts SET is_enabled = 0 WHERE member_card_no = ?");
            $disableStmt->bind_param('s', $memberCardNo);
            $success = $disableStmt->execute();
            if ($success && $disableStmt->affected_rows > 0) {
                $conn->commit();
                echo json_encode(['success' => true, 'message' => '会员卡已停用']);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '停用失败，请重试']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            echo json_encode(['success' => false, 'message' => '停用失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'enable_member_card') {
        header('Content-Type: application/json');
        $memberCardNo = $_POST['member_card_no'] ?? '';
        if (empty($memberCardNo)) {
            echo json_encode(['success' => false, 'message' => '会员卡号不能为空']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $checkStmt = $conn->prepare("SELECT member_card_no, is_enabled FROM member_accounts WHERE member_card_no = ? LIMIT 1 FOR UPDATE");
            $checkStmt->bind_param('s', $memberCardNo);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows === 0) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡不存在']);
                exit;
            }
            $memberData = $checkResult->fetch_assoc();
            if ($memberData['is_enabled'] == 1) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '会员卡已经是启用状态']);
                exit;
            }
            $enableStmt = $conn->prepare("UPDATE member_accounts SET is_enabled = 1 WHERE member_card_no = ?");
            $enableStmt->bind_param('s', $memberCardNo);
            $success = $enableStmt->execute();
            if ($success && $enableStmt->affected_rows > 0) {
                $conn->commit();
                echo json_encode(['success' => true, 'message' => '会员卡已启用']);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '启用失败，请重试']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            echo json_encode(['success' => false, 'message' => '启用失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'check_timecard_before_transfer') {
        header('Content-Type: application/json');
        $cardNo = $_POST['card_no'] ?? '';
        if (empty($cardNo)) {
            echo json_encode(['success' => false, 'message' => '卡号不能为空']);
            exit;
        }
        try {
            $stmt = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM time_cards_member 
                WHERE member_card_no = ? 
                AND remaining_times > 0
                AND is_expired = 0
            ");
            $stmt->bind_param('s', $cardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $hasTimecard = $row['count'] > 0;
            echo json_encode([
                'success' => true, 
                'has_timecard' => $hasTimecard
            ]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => '检查失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'card_transfer') {
        header('Content-Type: application/json');
        $oldCardNo = $_POST['old_card_no'] ?? '';
        $newCardNo = $_POST['new_card_no'] ?? '';
        if (empty($oldCardNo) || empty($newCardNo)) {
            echo json_encode(['success' => false, 'message' => '所有字段都不能为空']);
            exit;
        }
        if (!preg_match('/^1[3-9]\d{9}$/', $oldCardNo) || !preg_match('/^1[3-9]\d{9}$/', $newCardNo)) {
            echo json_encode(['success' => false, 'message' => '卡号格式不正确，请输入正确的手机号']);
            exit;
        }
        if ($oldCardNo === $newCardNo) {
            echo json_encode(['success' => false, 'message' => '旧卡号和新卡号不能相同']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $stmt = $conn->prepare("SELECT member_card_no, name, password, balance, is_enabled, level_id FROM member_accounts WHERE member_card_no = ? LIMIT 1");
            $stmt->bind_param('s', $oldCardNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => '旧会员卡不存在']);
                $conn->rollback();
                exit;
            }
            $oldMember = $result->fetch_assoc();
            if ($oldMember['is_enabled'] == 0) {
                echo json_encode(['success' => false, 'message' => '旧会员卡已被停用']);
                $conn->rollback();
                exit;
            }
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM orders WHERE member_card_no = ? AND status = 0");
            $stmt->bind_param('s', $oldCardNo);
            $stmt->execute();
            $orderCheck = $stmt->get_result()->fetch_assoc();
            if ($orderCheck['count'] > 0) {
                echo json_encode(['success' => false, 'message' => '有正在使用的订单，无法更改！']);
                $conn->rollback();
                exit;
            }
            if ($oldMember['balance'] <= 0) {
                echo json_encode(['success' => false, 'message' => '旧会员卡余额为零，无需转账']);
                $conn->rollback();
                exit;
            }
            $transferAmount = $oldMember['balance'];
            $stmt = $conn->prepare("SELECT member_card_no, name, balance, is_enabled FROM member_accounts WHERE member_card_no = ? LIMIT 1");
            $stmt->bind_param('s', $newCardNo);
            $stmt->execute();
            $newMemberResult = $stmt->get_result();
            $newMemberExists = $newMemberResult->num_rows > 0;
            if ($newMemberExists) {
                $newMember = $newMemberResult->fetch_assoc();
                if ($newMember['is_enabled'] == 0) {
                    echo json_encode(['success' => false, 'message' => '新会员卡已被停用']);
                    $conn->rollback();
                    exit;
                }
            } else {
                $newMember = ['name' => $oldMember['name'], 'balance' => 0];
            }
            $maxAttempts = 999;
            $archivedCardNo = '';
            for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
                $randomSuffix = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
                $tempArchivedCardNo = $oldCardNo . '@' . $randomSuffix;
                $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE member_card_no = ?");
                $checkStmt->bind_param('s', $tempArchivedCardNo);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                $exists = $checkResult->fetch_assoc()['count'] > 0;
                if (!$exists) {
                    $archivedCardNo = $tempArchivedCardNo;
                    break;
                }
            }
            if (empty($archivedCardNo)) {
                echo json_encode(['success' => false, 'message' => '归档卡号生成失败，该卡号的归档记录已达上限（999条）']);
                $conn->rollback();
                exit;
            }
            $stmt = $conn->prepare("UPDATE member_accounts SET member_card_no = ? WHERE member_card_no = ?");
            $stmt->bind_param('ss', $archivedCardNo, $oldCardNo);
            $stmt->execute();
            if ($newMemberExists) {
                $newBalance = $newMember['balance'] + $transferAmount;
                $stmt = $conn->prepare("UPDATE member_accounts SET balance = ?, last_consumption_time = NOW() WHERE member_card_no = ?");
                $stmt->bind_param('ds', $newBalance, $newCardNo);
                $stmt->execute();
                $operatorId = getCurrentOperatorId();
                $stmt = $conn->prepare("INSERT INTO member_recharges (member_card_no, name, payment_method_id, recharge_amount, gift_amount, final_balance, operator_id) VALUES (?, ?, 2, 0.00, ?, ?, ?)");
                $stmt->bind_param('ssddi', $newCardNo, $newMember['name'], $transferAmount, $newBalance, $operatorId);
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("INSERT INTO member_accounts (member_card_no, name, password, balance, level_id) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('sssdi', $newCardNo, $oldMember['name'], $oldMember['password'], $transferAmount, $oldMember['level_id']);
                $stmt->execute();
                $operatorId = getCurrentOperatorId();
                $stmt = $conn->prepare("INSERT INTO member_recharges (member_card_no, name, payment_method_id, recharge_amount, gift_amount, final_balance, operator_id) VALUES (?, ?, 2, 0.00, ?, ?, ?)");
                $stmt->bind_param('ssddi', $newCardNo, $oldMember['name'], $transferAmount, $transferAmount, $operatorId);
                $stmt->execute();
                $newBalance = $transferAmount;
            }
            $refundAmount = -$transferAmount;
            $operatorId = getCurrentOperatorId();
            $stmt = $conn->prepare("INSERT INTO member_recharges (member_card_no, name, payment_method_id, recharge_amount, gift_amount, final_balance, operator_id) VALUES (?, ?, 2, 0.00, ?, 0.00, ?)");
            $stmt->bind_param('ssdi', $archivedCardNo, $oldMember['name'], $refundAmount, $operatorId);
            $stmt->execute();
            $stmt = $conn->prepare("UPDATE member_accounts SET balance = 0.00, is_enabled = 0, last_consumption_time = NOW() WHERE member_card_no = ?");
            $stmt->bind_param('s', $archivedCardNo);
            $stmt->execute();
            $stmt = $conn->prepare("
                UPDATE member_accounts 
                SET total_recharge_amount = (
                    SELECT IFNULL(SUM(recharge_amount), 0) 
                    FROM member_recharges 
                    WHERE member_card_no = ?
                ),
                total_gift_amount = (
                    SELECT IFNULL(SUM(gift_amount), 0) 
                    FROM member_recharges 
                    WHERE member_card_no = ?
                ),
                total_consumption_amount = (
                    SELECT IFNULL(SUM(amount), 0) 
                    FROM member_consumptions 
                    WHERE member_card_no = ?
                )
                WHERE member_card_no = ?
            ");
            $stmt->bind_param('ssss', $archivedCardNo, $archivedCardNo, $archivedCardNo, $archivedCardNo);
            $stmt->execute();
            $stmt = $conn->prepare("
                UPDATE member_accounts 
                SET total_recharge_amount = (
                    SELECT IFNULL(SUM(recharge_amount), 0) 
                    FROM member_recharges 
                    WHERE member_card_no = ?
                ),
                total_gift_amount = (
                    SELECT IFNULL(SUM(gift_amount), 0) 
                    FROM member_recharges 
                    WHERE member_card_no = ?
                ),
                total_consumption_amount = (
                    SELECT IFNULL(SUM(amount), 0) 
                    FROM member_consumptions 
                    WHERE member_card_no = ?
                )
                WHERE member_card_no = ?
            ");
            $stmt->bind_param('ssss', $newCardNo, $newCardNo, $newCardNo, $newCardNo);
            $stmt->execute();
            $operatorId = getCurrentOperatorId();
            $stmt = $conn->prepare("INSERT INTO member_card_transfer_history (source_card_no, archived_card_no, target_card_no, transfer_amount, source_card_name, target_card_name, is_new_card_created, operator_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $isNewCardCreated = $newMemberExists ? 0 : 1;
            $stmt->bind_param('sssdssii', $oldCardNo, $archivedCardNo, $newCardNo, $transferAmount, $oldMember['name'], $newMember['name'], $isNewCardCreated, $operatorId);
            $stmt->execute();
            $conn->commit();
            logOperation('CARD_TRANSFER', "会员卡转账成功", "从 {$oldCardNo} 转账到 {$newCardNo}，归档为 {$archivedCardNo}，金额：{$transferAmount}");
            $message = sprintf(
                '换卡转账成功！转账金额：%.2f元。%s当前余额：%.2f元。旧卡已归档为：%s',
                $transferAmount,
                $newMemberExists ? '新卡余额已更新，' : '已创建新卡并同步旧卡信息，',
                $newBalance,
                $archivedCardNo
            );
            echo json_encode(['success' => true, 'message' => $message, 'archived_card_no' => $archivedCardNo]);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['success' => false, 'message' => '换卡转账失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'get_transfer_history') {
        header('Content-Type: application/json');
        $cardNo = trim($_POST['card_no'] ?? '');
        try {
            if (empty($cardNo)) {
                $stmt = $conn->prepare("
                    SELECT 
                        h.id,
                        h.source_card_no,
                        h.archived_card_no,
                        h.target_card_no,
                        h.transfer_amount,
                        h.source_card_name,
                        h.target_card_name,
                        h.is_new_card_created,
                        h.old_name,
                        h.new_name,
                        h.password_change,
                        h.old_level_id,
                        h.new_level_id,
                        ml1.name as old_level_name,
                        ml2.name as new_level_name,
                        h.transfer_time,
                        su.name as operator_name
                    FROM member_card_transfer_history h
                    LEFT JOIN member_levels ml1 ON h.old_level_id = ml1.id
                    LEFT JOIN member_levels ml2 ON h.new_level_id = ml2.id
                    LEFT JOIN system_users su ON h.operator_id = su.id
                    ORDER BY h.transfer_time DESC
                ");
                $stmt->execute();
            } else {
                $stmt = $conn->prepare("
                    SELECT 
                        h.id,
                        h.source_card_no,
                        h.archived_card_no,
                        h.target_card_no,
                        h.transfer_amount,
                        h.source_card_name,
                        h.target_card_name,
                        h.is_new_card_created,
                        h.old_name,
                        h.new_name,
                        h.password_change,
                        h.old_level_id,
                        h.new_level_id,
                        ml1.name as old_level_name,
                        ml2.name as new_level_name,
                        h.transfer_time,
                        su.name as operator_name
                    FROM member_card_transfer_history h
                    LEFT JOIN member_levels ml1 ON h.old_level_id = ml1.id
                    LEFT JOIN member_levels ml2 ON h.new_level_id = ml2.id
                    LEFT JOIN system_users su ON h.operator_id = su.id
                    WHERE h.source_card_no LIKE ? 
                       OR h.target_card_no LIKE ? 
                       OR h.archived_card_no LIKE ?
                    ORDER BY h.transfer_time DESC
                ");
                $searchPattern = '%' . $cardNo . '%';
                $stmt->bind_param('sss', $searchPattern, $searchPattern, $searchPattern);
                $stmt->execute();
            }
            $result = $stmt->get_result();
            $history = [];
            while ($row = $result->fetch_assoc()) {
                $history[] = $row;
            }
            echo json_encode(['success' => true, 'data' => $history]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => '查询失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'get_member_levels') {
        header('Content-Type: application/json');
        try {
            $stmt = $conn->prepare("
                SELECT 
                    id,
                    name,
                    min_first_recharge,
                    min_recharge,
                    auto_upgrade_amount,
                    member_discount,
                    is_enabled,
                    is_system,
                    sort_order
                FROM member_levels 
                ORDER BY sort_order ASC, id ASC
            ");
            $stmt->execute();
            $result = $stmt->get_result();
            $levels = [];
            while ($row = $result->fetch_assoc()) {
                $levels[] = $row;
            }
            echo json_encode(['success' => true, 'data' => $levels]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => '获取卡类型列表失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && ($_POST['action'] === 'enable_member_level' || $_POST['action'] === 'disable_member_level')) {
        header('Content-Type: application/json');
        $levelId = $_POST['level_id'] ?? 0;
        if (empty($levelId)) {
            echo json_encode(['success' => false, 'message' => '会员类型ID不能为空']);
            exit;
        }
        try {
            $isEnable = $_POST['action'] === 'enable_member_level';
            $checkStmt = $conn->prepare("SELECT is_system FROM member_levels WHERE id = ?");
            $checkStmt->bind_param('i', $levelId);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => '会员类型不存在']);
                exit;
            }
            $levelData = $checkResult->fetch_assoc();
            if (!$isEnable && $levelData['is_system'] == 1) {
                echo json_encode(['success' => false, 'message' => '系统级卡类型不可停用']);
                exit;
            }
            if ($isEnable) {
                $stmt = $conn->prepare("UPDATE member_levels SET is_enabled = 1 WHERE id = ?");
                $stmt->bind_param('i', $levelId);
            } else {
                $stmt = $conn->prepare("UPDATE member_levels SET is_enabled = 0 WHERE id = ?");
                $stmt->bind_param('i', $levelId);
            }
            if ($stmt->execute()) {
                updateRefreshFlag();
                $actionText = $isEnable ? '启用' : '停用';
                echo json_encode(['success' => true, 'message' => '会员类型' . $actionText . '成功，请刷新前端页面更新！']);
            } else {
                echo json_encode(['success' => false, 'message' => '更新会员类型状态失败']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'convert_member_level') {
        header('Content-Type: application/json');
        $fromLevelId = intval($_POST['from_level_id'] ?? 0);
        $toLevelId = intval($_POST['to_level_id'] ?? 0);
        if ($fromLevelId <= 0 || $toLevelId <= 0) {
            echo json_encode(['success' => false, 'message' => '请选择有效的卡类型']);
            exit;
        }
        if ($fromLevelId === $toLevelId) {
            echo json_encode(['success' => false, 'message' => '当前类型和目标类型不能相同']);
            exit;
        }
        try {
            $conn->begin_transaction();
            $checkStmt = $conn->prepare("SELECT id, name FROM member_levels WHERE id IN (?, ?) FOR UPDATE");
            $checkStmt->bind_param('ii', $fromLevelId, $toLevelId);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            if ($checkResult->num_rows !== 2) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '选择的卡类型不存在']);
                exit;
            }
            $levels = [];
            while ($row = $checkResult->fetch_assoc()) {
                $levels[$row['id']] = $row['name'];
            }
            $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE level_id = ?");
            $countStmt->bind_param('i', $fromLevelId);
            $countStmt->execute();
            $memberCount = $countStmt->get_result()->fetch_assoc()['count'];
            if ($memberCount == 0) {
                $conn->rollback();
                echo json_encode([
                    'success' => false, 
                    'message' => '没有会员使用"' . $levels[$fromLevelId] . '"类型，无需转换'
                ]);
                exit;
            }
            $updateStmt = $conn->prepare("UPDATE member_accounts SET level_id = ? WHERE level_id = ?");
            $updateStmt->bind_param('ii', $toLevelId, $fromLevelId);
            if ($updateStmt->execute()) {
                $conn->commit();
                echo json_encode([
                    'success' => true, 
                    'message' => '成功将 ' . $memberCount . ' 个会员从"' . $levels[$fromLevelId] . '"转换到"' . $levels[$toLevelId] . '"',
                    'count' => $memberCount
                ]);
            } else {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => '转换失败']);
            }
        } catch (Exception $e) {
            @$conn->rollback();
            echo json_encode(['success' => false, 'message' => '转换失败：' . $e->getMessage()]);
        }
        exit;
    }
    if (isset($_POST['action']) && $_POST['action'] === 'reinit_member_levels') {
        header('Content-Type: application/json');
        try {
            $configStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'member_auto_upgrade_enabled'");
            $configStmt->execute();
            $configResult = $configStmt->get_result();
            if ($configResult->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => '系统配置不存在，请联系管理员']);
                exit;
            }
            $autoUpgradeEnabled = $configResult->fetch_assoc()['config_value'];
            if ($autoUpgradeEnabled != '1') {
                echo json_encode(['success' => false, 'message' => '请先在"系统配置>会员配置"中开启"卡类型自动升级"功能']);
                exit;
            }
            $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_levels WHERE is_enabled = 1");
            $checkStmt->execute();
            $enabledCount = $checkStmt->get_result()->fetch_assoc()['count'];
            if ($enabledCount == 0) {
                echo json_encode(['success' => false, 'message' => '没有启用的卡类型，无法初始化']);
                exit;
            }
            $upgradeStmt = $conn->prepare("
                SELECT id, name, auto_upgrade_amount 
                FROM member_levels 
                WHERE is_enabled = 1 AND auto_upgrade_amount > 0
                ORDER BY auto_upgrade_amount ASC
            ");
            $upgradeStmt->execute();
            $upgradeResult = $upgradeStmt->get_result();
            $upgradeLevels = [];
            while ($row = $upgradeResult->fetch_assoc()) {
                $upgradeLevels[] = $row;
            }
            $amounts = array_column($upgradeLevels, 'auto_upgrade_amount');
            $uniqueAmounts = array_unique($amounts);
            if (count($amounts) != count($uniqueAmounts)) {
                $duplicates = [];
                $amountMap = [];
                foreach ($upgradeLevels as $level) {
                    $amount = $level['auto_upgrade_amount'];
                    if (!isset($amountMap[$amount])) {
                        $amountMap[$amount] = [];
                    }
                    $amountMap[$amount][] = $level['name'];
                }
                foreach ($amountMap as $amount => $names) {
                    if (count($names) > 1) {
                        $duplicates[] = '累计充值 ¥' . number_format($amount, 2) . '：' . implode('、', $names);
                    }
                }
                echo json_encode([
                    'success' => false, 
                    'message' => '存在重复的自动升级累计金额，请先修改：<br>' . implode('<br>', $duplicates)
                ]);
                exit;
            }
            $backupResult = performAutoBackup('123456', '重新初始化卡类型前自动备份', 'cardtype');
            if (!$backupResult['success']) {
                echo json_encode([
                    'success' => false, 
                    'message' => '自动备份失败：' . $backupResult['message']
                ]);
                exit;
            }
            $conn->begin_transaction();
            $cleanStmt = $conn->prepare("
                UPDATE member_accounts 
                SET total_recharge_amount = 0 
                WHERE total_recharge_amount IS NULL OR total_recharge_amount < 0
            ");
            $cleanStmt->execute();
            $allLevelsStmt = $conn->prepare("
                SELECT id, name, auto_upgrade_amount 
                FROM member_levels 
                WHERE is_enabled = 1 
                ORDER BY auto_upgrade_amount DESC, id ASC
                FOR UPDATE
            ");
            $allLevelsStmt->execute();
            $allLevelsResult = $allLevelsStmt->get_result();
            $allLevels = [];
            while ($row = $allLevelsResult->fetch_assoc()) {
                $allLevels[] = $row;
            }
            $defaultLevelId = null;
            foreach ($allLevels as $level) {
                if ($level['id'] == 1) {
                    $defaultLevelId = 1;
                    break;
                }
            }
            if ($defaultLevelId === null) {
                $minLevel = end($allLevels); 
                $defaultLevelId = $minLevel['id'];
            }
            if (count($allLevels) == 1) {
                $onlyLevelId = $allLevels[0]['id'];
                $updateStmt = $conn->prepare("
                    UPDATE member_accounts ma
                    INNER JOIN member_levels ml ON ma.level_id = ml.id
                    SET ma.level_id = ?
                    WHERE ml.is_enabled = 1
                ");
                $updateStmt->bind_param('i', $onlyLevelId);
                $updateStmt->execute();
                $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE level_id = ?");
                $countStmt->bind_param('i', $onlyLevelId);
                $countStmt->execute();
                $count = $countStmt->get_result()->fetch_assoc()['count'];
                $skippedStmt = $conn->prepare("
                    SELECT COUNT(*) as count 
                    FROM member_accounts ma
                    INNER JOIN member_levels ml ON ma.level_id = ml.id
                    WHERE ml.is_enabled = 0
                ");
                $skippedStmt->execute();
                $skippedCount = $skippedStmt->get_result()->fetch_assoc()['count'];
                $conn->commit();
                $message = '初始化完成';
                if ($skippedCount > 0) {
                    $message .= '（跳过 ' . $skippedCount . ' 个禁用类型的会员）';
                }
                $message .= '。备份文件：' . $backupResult['filename'];
                echo json_encode([
                    'success' => true, 
                    'message' => $message,
                    'stats' => [
                        ['name' => $allLevels[0]['name'], 'count' => $count]
                    ],
                    'backup_file' => $backupResult['filename']
                ]);
                exit;
            }
            $caseParts = [];
            $params = [];
            $types = '';
            foreach ($allLevels as $level) {
                if ($level['auto_upgrade_amount'] > 0) {
                    $caseParts[] = "WHEN total_recharge_amount >= ? THEN ?";
                    $params[] = $level['auto_upgrade_amount'];
                    $params[] = $level['id'];
                    $types .= 'di';
                }
            }
            if (empty($caseParts)) {
                $updateSQL = "
                    UPDATE member_accounts ma
                    INNER JOIN member_levels ml ON ma.level_id = ml.id
                    SET ma.level_id = ?
                    WHERE ml.is_enabled = 1
                ";
                $params[] = $defaultLevelId;
                $types = 'i';
            } else {
                $caseParts[] = "ELSE ?";
                $params[] = $defaultLevelId;
                $types .= 'i';
                $caseSQL = "CASE " . implode(' ', $caseParts) . " END";
                $updateSQL = "
                    UPDATE member_accounts ma
                    INNER JOIN member_levels ml ON ma.level_id = ml.id
                    SET ma.level_id = " . $caseSQL . "
                    WHERE ml.is_enabled = 1
                ";
            }
            $updateStmt = $conn->prepare($updateSQL);
            $updateStmt->bind_param($types, ...$params);
            $updateStmt->execute();
            $stats = [];
            foreach ($allLevels as $level) {
                $countStmt = $conn->prepare("SELECT COUNT(*) as count FROM member_accounts WHERE level_id = ?");
                $countStmt->bind_param('i', $level['id']);
                $countStmt->execute();
                $count = $countStmt->get_result()->fetch_assoc()['count'];
                if ($count > 0) {
                    $stats[] = [
                        'name' => $level['name'],
                        'count' => $count
                    ];
                }
            }
            $skippedStmt = $conn->prepare("
                SELECT COUNT(*) as count 
                FROM member_accounts ma
                INNER JOIN member_levels ml ON ma.level_id = ml.id
                WHERE ml.is_enabled = 0
            ");
            $skippedStmt->execute();
            $skippedCount = $skippedStmt->get_result()->fetch_assoc()['count'];
            $conn->commit();
            $message = '初始化完成';
            if ($skippedCount > 0) {
                $message .= '（跳过 ' . $skippedCount . ' 个禁用类型的会员）';
            }
            $message .= '。备份文件：' . $backupResult['filename'];
            echo json_encode([
                'success' => true, 
                'message' => $message,
                'stats' => $stats,
                'backup_file' => $backupResult['filename']
            ]);
        } catch (Exception $e) {
            if (isset($conn) && is_object($conn) && method_exists($conn, 'rollback')) {
                try {
                    $conn->rollback();
                } catch (Exception $rollbackEx) {
                }
            }
            echo json_encode(['success' => false, 'message' => '初始化失败：' . $e->getMessage()]);
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>后台管理系统</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/asset/lib/css/bootstrap.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="/asset/lib/css/all.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/all.min.css') ?>" rel="stylesheet">
    <link href="/asset/admin.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/admin.css') ?>" rel="stylesheet">
    <script>
        window.SYSTEM_CONFIG = {
            sceneRoomName: '<?php echo htmlspecialchars($SCENE_ROOM_NAME, ENT_QUOTES, 'UTF-8'); ?>'
        };
    </script>
    <script src="/asset/core.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/core.js') ?>"></script>
</head>
<body>
<script>
window.APP_CONFIG = {
    serverDate: '<?= date('Y-m-d') ?>',
    <?php if (isset($_SESSION['toast'])): ?>
    toast: {
        title: <?= json_encode($_SESSION['toast']['title']) ?>,
        message: <?= json_encode($_SESSION['toast']['message']) ?>,
        type: '<?= $_SESSION['toast']['type'] ?>'
    }
    <?php unset($_SESSION['toast']); ?>
    <?php else: ?>
    toast: null
    <?php endif; ?>
};
</script>
<div class="container mt-3">
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><a href="admin.php" style="color: inherit; text-decoration: none;">后台管理系统</a></h2>
    <div>
        <?php
        $logoutUsername = $_SESSION['admin_username'] ?? '';
        $logoutName = $_SESSION['admin_name'] ?? '';
        $logoutRole = $_SESSION['admin_role'] ?? '';
        $roleText = $logoutRole === 'admin' ? '管理员' : '前台';
        $logoutTitle = "用户名：{$logoutUsername}\n姓名：{$logoutName}\n权限：{$roleText}";
        ?>
        <a href="auth.php?logout=admin&close=1&source=admin" class="btn btn-outline-danger mr-2" title="<?php echo htmlspecialchars($logoutTitle); ?>">
            <i class="fas fa-sign-out-alt mr-1"></i>退出
        </a>
    </div>
</div>
    <ul class="nav nav-tabs mb-2" id="adminTabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="nav-room" data-toggle="tab" href="#roomSection" role="tab">
                <i class="fas fa-home mr-1"></i><span><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-product" data-toggle="tab" href="#productSection" role="tab">
                <i class="fas fa-shopping-cart mr-1"></i><span>商品管理</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-payment" data-toggle="tab" href="#paymentMethodSection" role="tab">
                <i class="fas fa-credit-card mr-1"></i><span>支付方式</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-promotion" data-toggle="tab" href="#promotionSection" role="tab">
                <i class="fas fa-tags mr-1"></i><span>套餐管理</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-member" data-toggle="tab" href="#memberInfoSection" role="tab">
                <i class="fas fa-id-card mr-1"></i><span>会员服务</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-config" data-toggle="tab" href="#configSection" role="tab">
                <i class="fas fa-cogs mr-1"></i><span>系统配置</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="nav-users" data-toggle="tab" href="#usersSection" role="tab">
                <i class="fas fa-users mr-1"></i><span>用户管理</span>
            </a>
        </li>
    </ul>
    <div class="tab-content" id="adminTabContent">
    <?php
    if (isset($_SESSION['admin_error'])) {
        unset($_SESSION['admin_error']);
    }
    ?>
    <div class="modal fade" id="editModal">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit">
                    <input type="hidden" name="id" id="editId">
                    <div class="modal-header">
                        <h5 class="modal-title">编辑<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名称 <span class="text-danger">*</span> <small class="text-muted">（已使用的<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>尽量避免修改该信息）</small></label>
                            <input type="text" name="name" id="editName" class="form-control" required maxlength="10">
                        </div>
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>类型</label>
                            <div class="type-input-wrapper">
                                <input type="text" name="type" id="editType" class="form-control type-input" required maxlength="10" autocomplete="off">
                                <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                                <div class="type-dropdown-menu"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>标准价(1小时)</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" name="standard_price" id="editStandardPrice" class="form-control" step="0.01" min="0" max="9999">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>会员折扣(标准价大于0时生效)</label>
                            <div class="input-group">
                                <input type="number" name="member_discount" id="editMemberDiscount" class="form-control" step="1" min="1" max="100" value="100" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <small class="form-text text-muted">例如：80表示8折，100表示不打折</small>
                        </div>
                        <div class="form-group mb-0">
                            <label class="d-inline-block mr-3">是否参与会员类型折扣</label>
                            <div class="custom-control custom-switch d-inline-block">
                                <input type="checkbox" class="custom-control-input" id="editRoomEnableMemberLevelsDiscount" name="enable_member_levels_discount" value="1" checked>
                                <label class="custom-control-label" for="editRoomEnableMemberLevelsDiscount">启用</label>
                            </div>
                            <small class="text-danger ml-2">开启后会叠加会员类型折扣</small>
                        </div>
                        <div class="device-control-section">
                            <h6 class="text-primary">设备控制设置</h6>
                            <div class="form-group">
                                <div class="form-check">
                                    <input type="checkbox" name="device_enabled" id="editDeviceEnabled" class="form-check-input">
                                    <label class="form-check-label" for="editDeviceEnabled">启用设备控制</label>
                                </div>
                            </div>
                            <div id="deviceConfigArea">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="text-secondary mb-0">设备配置</h6>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="toggleDeviceConfig">
                                        <i class="fas fa-chevron-down"></i> 展开
                                    </button>
                                </div>
                                <div id="deviceConfigContent">
                        <div class="form-group">
                            <label>设备IP地址</label>
                            <input type="text" name="device_ip" id="editDeviceIp" class="form-control" placeholder="例如：192.168.1.100" pattern="^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$" title="请输入有效的IP地址格式，如：192.168.1.100">
                        </div>
                        <div class="form-group">
                            <label>设备端口</label>
                            <input type="number" name="device_port" id="editDevicePort" class="form-control" placeholder="例如：502" min="1" max="65535" title="端口号必须在1-65535之间">
                        </div>
                        <div class="form-group">
                            <label>设备协议</label>
                            <select name="device_protocol" id="editDeviceProtocol" class="form-control">
                                <option value="">请选择协议</option>
                                <option value="modbus_tcp">Modbus_TCP</option>
                                <option value="tcp_hex">TCP_Hex</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>设备指令配置</label>
                            <div id="deviceCommandsContainer">
                                <div class="device-command-item mb-3">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <input type="text" class="form-control device-name" placeholder="设备名称（如：照明）">
                                        </div>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control device-on" placeholder="开指令">
                                        </div>
                                        <div class="col-md-4">
                                            <div class="d-flex align-items-center">
                                                <input type="text" class="form-control device-off" placeholder="关指令">
                                                <button type="button" class="btn btn-outline-danger remove-device ml-2" title="删除设备">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary" id="addDeviceCommand">
                                <i class="fas fa-plus"></i> 添加设备
                            </button>
                            <input type="hidden" name="device_commands" id="editDeviceCommands">
                            <small class="form-text text-muted">为每个设备配置开和关的指令</small>
                        </div>
                        <div class="form-group">
                            <label>设备工作流配置</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="workflow-node">
                                        <h6 class="text-info">开台流程</h6>
                                        <div id="openWorkflowContainer">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="workflow-node">
                                        <h6 class="text-info">加时流程</h6>
                                        <div id="extendWorkflowContainer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="workflow-node">
                                        <h6 class="text-info">结账流程</h6>
                                        <div id="checkoutWorkflowContainer">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="workflow-node">
                                        <h6 class="text-info">订单超时流程</h6>
                                        <div id="forceCloseWorkflowContainer">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="device_workflow" id="editDeviceWorkflow">
                            <small class="form-text text-muted">为每个流程节点选择要执行的设备操作</small>
                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">保存</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="batchAddModal">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">批量添加<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="batchAddForm">
                        <div class="form-group">
                            <label><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名模式 <span class="text-danger">*</span></label>
                            <input type="text" name="name_pattern" id="batchNamePattern" class="form-control" placeholder="例如：桌号%A% 或 房号%1%" required maxlength="20">
                            <small class="form-text text-muted">通配符：字母类型<span class="text-success font-weight-bold">%A%</span>，数字类型<span class="text-success font-weight-bold">%1%</span>。最多允许2个通配符。例如：<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?><span class="text-success">%A%</span>，数量2，则生成<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>A，<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>B</small>
                        </div>
                        <div class="form-group">
                            <label>生成数量 <span class="text-danger">*</span></label>
                            <input type="number" name="quantity" id="batchQuantity" class="form-control" min="1" max="99" value="1" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>类型</label>
                                <div class="type-input-wrapper">
                                    <input type="text" name="type" id="batchType" class="form-control type-input" required maxlength="10" autocomplete="off">
                                    <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                        <i class="fas fa-chevron-down"></i>
                                    </button>
                                    <div class="type-dropdown-menu"></div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label>标准价(1小时)</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">¥</span>
                                    </div>
                                    <input type="number" name="standard_price" id="batchStandardPrice" class="form-control" step="0.01" min="0" max="9999" value="0.00">
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label>会员折扣</label>
                                <div class="input-group">
                                    <input type="number" name="member_discount" id="batchMemberDiscount" class="form-control" step="1" min="1" max="100" value="100" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-0">
                            <label class="d-inline-block mr-3">是否参与会员类型折扣</label>
                            <div class="custom-control custom-switch d-inline-block">
                                <input type="checkbox" class="custom-control-input" id="batchEnableMemberLevelsDiscount" name="enable_member_levels_discount" value="1" checked>
                                <label class="custom-control-label" for="batchEnableMemberLevelsDiscount">启用</label>
                            </div>
                        </div>
                        <div class="mt-4">
                            <h6 class="text-secondary">预览 (最多显示5个)</h6>
                            <div id="batchPreviewList" class="p-2 border rounded bg-light" style="min-height: 40px; display: flex; flex-wrap: wrap; gap: 8px;">
                                <span class="text-muted">等待输入有效模式和数量...</span>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" id="confirmBatchAddBtn">确认批量添加</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editProductModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_product">
                    <input type="hidden" name="product_id" id="editProductId">
                    <div class="modal-header">
                        <h5 class="modal-title">编辑商品</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>商品名称 <span class="text-danger">*</span> <small class="text-muted">（已使用的商品尽量避免修改该信息）</small></label>
                            <input type="text" name="product_name" id="editProductName" class="form-control" required maxlength="10">
                        </div>
                        <div class="form-group">
                            <label>商品类型</label>
                            <div class="type-input-wrapper">
                                <input type="text" name="product_type" id="editProductType" class="form-control type-input" required maxlength="10" autocomplete="off">
                                <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                                <div class="type-dropdown-menu"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>商品价格</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" name="product_price" id="editProductPrice" class="form-control" step="0.01" min="0" max="9999" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>会员折扣</label>
                            <div class="input-group">
                                <input type="number" name="product_member_discount" id="editProductMemberDiscount" class="form-control" step="1" min="1" max="100" value="100" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <small class="form-text text-muted">例如：80表示8折，100表示不打折</small>
                        </div>
                        <div class="form-group mb-0">
                            <label class="d-inline-block mr-3">是否参与会员类型折扣</label>
                            <div class="custom-control custom-switch d-inline-block">
                                <input type="checkbox" class="custom-control-input" id="editProductEnableMemberLevelsDiscount" name="product_enable_member_levels_discount" value="1" checked>
                                <label class="custom-control-label" for="editProductEnableMemberLevelsDiscount">启用</label>
                            </div>
                            <small class="text-danger ml-2">开启后会叠加会员类型折扣</small>
                        </div>
                        <div class="form-group mb-0">
                            <label class="d-inline-block mr-3">是否允许0库存销售</label>
                            <div class="custom-control custom-switch d-inline-block">
                                <input type="checkbox" class="custom-control-input" id="editProductAllowZeroStock" name="product_allow_zero_stock" value="1" checked>
                                <label class="custom-control-label" for="editProductAllowZeroStock">启用</label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">保存</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<div class="modal fade" id="stockInModal">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <form id="stockInForm">
            <div class="modal-header">
                <h5 class="modal-title">商品入库</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="form-row mb-3">
                    <div class="col-md-4">
                        <label>商品类型筛选</label>
                        <select class="form-control" id="stockInTypeFilter">
                            <option value="">全部类型</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>启售状态</label>
                        <select class="form-control" id="stockInEnabledFilter">
                            <option value="">全部</option>
                            <option value="1" selected>已启用</option>
                            <option value="0">已停用</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label>是否已隐藏</label>
                        <select class="form-control" id="stockInDeletedFilter">
                            <option value="">全部</option>
                            <option value="0" selected>未隐藏</option>
                            <option value="1">已隐藏</option>
                        </select>
                    </div>
                </div>
                <div class="table-responsive" style="height: 500px; overflow-y: auto;">
                    <table class="table table-hover table-sm">
                        <thead class="thead-light" style="position: sticky; top: 0; z-index: 1;">
                            <tr>
                                <th>商品名称</th>
                                <th>类型</th>
                                <th>售价</th>
                                <th>当前库存</th>
                                <th>入库数量</th>
                                <th>损耗数量</th>
                                <th>入库单价</th>
                                <th>入库总金额</th>
                            </tr>
                        </thead>
                        <tbody id="stockInProductList">
                            <tr>
                                <td colspan="8" class="text-center">加载中...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                <button type="submit" class="btn btn-primary" id="batchStockInSubmit">保存提交</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="stockHistoryModal">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">入库查询</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="stockHistorySearchForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-3">
                            <input type="text" class="form-control" id="searchBatchNo" placeholder="批次号">
                        </div>
                        <div class="col-md-3">
                            <input type="date" class="form-control" id="searchStartDate" placeholder="开始日期">
                        </div>
                        <div class="col-md-3">
                            <input type="date" class="form-control" id="searchEndDate" placeholder="结束日期">
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> 查询
                            </button>
                            <button type="button" class="btn btn-success ml-2" id="exportStockHistoryBtn">
                                <i class="fas fa-file-excel"></i> 导出Excel
                            </button>
                        </div>
                    </div>
                </form>
                <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-sm">
                        <thead class="thead-light" style="position: sticky; top: 0; z-index: 1;">
                            <tr>
                                <th>批次号</th>
                                <th>商品名称</th>
                                <th>当前库存</th>
                                <th>入库数量</th>
                                <th>损耗数量</th>
                                <th>库存数量</th>
                                <th>单价</th>
                                <th>总金额</th>
                                <th>操作员</th>
                                <th>创建时间</th>
                            </tr>
                        </thead>
                        <tbody id="stockHistoryList">
                            <tr>
                                <td colspan="10" class="text-center">暂无记录</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editPaymentModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="edit_payment">
                <input type="hidden" name="payment_id" id="editPaymentId">
                <div class="modal-header">
                    <h5 class="modal-title">编辑支付方式</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>支付方式名称 <span class="text-danger">*</span> <small class="text-muted">（已使用的支付方式尽量避免修改该信息）</small></label>
                        <input type="text" name="payment_name" id="editPaymentName" class="form-control" required maxlength="10">
                    </div>
                    <div class="form-group">
                        <label>描述</label>
                        <input type="text" name="payment_description" id="editPaymentDescription" class="form-control" required maxlength="20">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="editPromotionModal">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="promotionModalTitle">添加套餐</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="promotionForm" method="POST">
                    <input type="hidden" id="promotionId" name="id">
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <label>套餐名称 <span class="text-danger">*</span> <small class="text-muted">（已使用的套餐尽量避免修改该信息）</small></label>
                            <input type="text" class="form-control" id="promotionName" name="name" required maxlength="30">
                        </div>
                        <div class="form-group col-md-4">
                            <label>套餐类型</label>
                            <div class="type-input-wrapper">
                                <input type="text" class="form-control type-input" id="promotionType" name="type" required maxlength="10" autocomplete="off">
                                <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                    <i class="fas fa-chevron-down"></i>
                                </button>
                                <div class="type-dropdown-menu"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>全天时间套餐</label>
                            <div class="custom-control custom-switch d-inline-block ml-2">
                                <input type="checkbox" class="custom-control-input" id="promotionIsAllDay" name="is_all_day" value="1">
                                <label class="custom-control-label" for="promotionIsAllDay">启用</label>
                            </div>
                            <small class="form-text text-muted">启用后，开台时订单到期时间为当天23:59:59；加时时根据超期情况计算：未超期或超期≤24小时续到当前自然日23:59:59，超期>24小时则为原到期时间+24小时（仍为23:59:59）。</small>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>时长（小时）</label>
                            <input type="number" class="form-control" id="promotionHours" name="hours" step="0.1" min="0" max="999" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label>价格（元）</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" class="form-control" id="promotionPrice" name="price" step="0.01" min="0" max="9999" required>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label>会员折扣</label>
                            <div class="input-group">
                                <input type="number" class="form-control" id="promotionMemberDiscount" name="member_discount" step="1" min="1" max="100" value="100" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <small class="form-text text-muted">例如：80表示8折，100表示不打折</small>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <label class="d-inline-block mr-3">是否参与会员类型折扣</label>
                        <div class="custom-control custom-switch d-inline-block">
                            <input type="checkbox" class="custom-control-input" id="promotionEnableMemberLevelsDiscount" name="enable_member_levels_discount" value="1" checked>
                            <label class="custom-control-label" for="promotionEnableMemberLevelsDiscount">启用</label>
                        </div>
                        <small class="text-danger ml-2">开启后会叠加会员类型折扣</small>
                    </div>
                    <div class="form-group">
                        <label>适用<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></label>
                        <div class="border rounded p-2" style="max-height: 150px; overflow-y: auto;">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="allRooms" checked>
                                <label class="form-check-label font-weight-bold" for="allRooms">
                                    全部<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>
                                </label>
                            </div>
                            <hr class="my-2">
                            <div id="roomCheckboxes">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>适用星期</label>
                            <div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday1" value="1" checked>
                                    <label class="form-check-label" for="weekday1">周一</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday2" value="2" checked>
                                    <label class="form-check-label" for="weekday2">周二</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday3" value="3" checked>
                                    <label class="form-check-label" for="weekday3">周三</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday4" value="4" checked>
                                    <label class="form-check-label" for="weekday4">周四</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday5" value="5" checked>
                                    <label class="form-check-label" for="weekday5">周五</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday6" value="6" checked>
                                    <label class="form-check-label" for="weekday6">周六</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input weekday-check" type="checkbox" id="weekday7" value="7" checked>
                                    <label class="form-check-label" for="weekday7">周日</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>开始时间</label>
                            <input type="time" class="form-control" id="promotionTimeStart" name="time_start" value="00:00:00" step="1">
                        </div>
                        <div class="form-group col-md-6">
                            <label>结束时间</label>
                            <input type="time" class="form-control" id="promotionTimeEnd" name="time_end" value="23:59:59" step="1">
                        </div>
                    </div>
                    <button type="submit" style="display: none;"></button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" id="savePromotionBtn">保存</button>
            </div>
        </div>
    </div>
</div>
    <div class="tab-pane fade show active" id="roomSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理</h5>
            <?php
            if (isset($_SESSION['admin_error']) && strpos($_SESSION['admin_error'], '房间') !== false) {
                unset($_SESSION['admin_error']);
            }
            ?>
            <form method="POST" class="mb-4" id="quickAddRoomForm">
                <input type="hidden" name="enable_member_levels_discount" value="1">
                <div class="form-row">
                    <div class="col">
                        <input type="text" name="name" class="form-control" placeholder="<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名称" maxlength="10">
                    </div>
                    <div class="col">
                        <div class="type-input-wrapper">
                            <input type="text" name="type" class="form-control type-input" placeholder="<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>类型" maxlength="10" autocomplete="off">
                            <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="type-dropdown-menu"></div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">¥</span>
                            </div>
                            <input type="number" name="standard_price" class="form-control" placeholder="标准价(1小时)" step="0.01" min="0" max="9999">
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <input type="number" name="member_discount" class="form-control" value="100" step="1" min="1" max="100" placeholder="会员折扣">
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="button" id="addRoomBtn" class="btn btn-primary mr-2"><i class="fas fa-plus"></i> 添加<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></button>
                        <button type="button" id="batchAddBtn" class="btn btn-primary"><i class="fas fa-layer-group"></i> 批量添加</button>
                    </div>
                </div>
            </form>
            <div class="mb-3">
                <button type="button" class="btn btn-primary" id="batchOperateRoomsBtn" style="display:none;">
                    <i class="fas fa-tasks"></i> 批量操作
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th style="width: 40px;">
                                <input type="checkbox" id="selectAllRooms" title="全选/取消全选">
                            </th>
                            <th>名称</th>
                            <th>类型</th>
                            <th>标准价</th>
                            <th>会员折扣</th>
                            <th>设备控制</th>
                            <th>订单数</th>
                            <th>操作</th>
                            <th>拖动排序</th>
                        </tr>
                    </thead>
                    <tbody id="sortable">
        <?php
                        $result = $conn->query("SELECT r.*, (SELECT COUNT(*) FROM orders WHERE room_id = r.id) as order_count FROM rooms r WHERE r.is_deleted=0 ORDER BY r.sort_order, r.id");
        while ($row = $result->fetch_assoc()):
                        ?>
                        <tr data-id="<?= $row['id'] ?>">
                            <td>
                                <input type="checkbox" class="room-checkbox" value="<?= $row['id'] ?>">
                            </td>
                            <td>
                                <?= htmlspecialchars($row['name']) ?>
                            </td>
                            <td><?= htmlspecialchars(strtoupper($row['type'])) ?></td>
                            <td><?= $row['standard_price'] > 0 ? '¥' . number_format((float)$row['standard_price'], 2) : '-' ?></td>
                            <td><?= $row['member_discount'] ?>%</td>
                            <td>
                                <?php if ($row['device_enabled']): ?>
                                    <?php 
                                    $protocol = $row['device_protocol'] ?? '';
                                    $protocolDisplay = '';
                                    if ($protocol === 'tcp_hex') {
                                        $protocolDisplay = 'TCP_Hex';
                                    } elseif ($protocol === 'modbus_tcp') {
                                        $protocolDisplay = 'Modbus_TCP';
                                    } else {
                                        $protocolDisplay = $protocol ?: '未设置';
                                    }
                                    ?>
                                    <span class="badge badge-success">启用</span>
                                    <small class="text-muted ml-1"><?= $protocolDisplay ?></small>
                                <?php else: ?>
                                    <span class="badge badge-secondary">停用</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $row['order_count'] ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-btn" 
                    data-id="<?= $row['id'] ?>"
                                        data-name="<?= htmlspecialchars($row['name']) ?>" 
                                        data-type="<?= htmlspecialchars(strtoupper($row['type'])) ?>"
                    data-standard-price="<?= $row['standard_price'] ?>"
                    data-enable-standard-price="<?= $row['enable_standard_price'] ?>"
                    data-member-discount="<?= $row['member_discount'] ?>"
                    data-enable-member-levels-discount="<?= $row['enable_member_levels_discount'] ?? 1 ?>"
                    data-device-enabled="<?= $row['device_enabled'] ?>"
                    data-device-ip="<?= htmlspecialchars($row['device_ip'] ?? '') ?>"
                    data-device-port="<?= $row['device_port'] ?? '' ?>"
                    data-device-protocol="<?= htmlspecialchars($row['device_protocol'] ?? '') ?>"
                    data-device-commands="<?= htmlspecialchars($row['device_commands'] ?? '') ?>"
                    data-device-workflow="<?= htmlspecialchars($row['device_workflow'] ?? '') ?>">
                                    编辑
                </button>
                                <?php if ($row['is_enabled'] == 0): ?>
                                    <button class="btn btn-sm btn-secondary disable-room-btn" data-id="<?= $row['id'] ?>">
                                        已停用
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success enable-room-btn" data-id="<?= $row['id'] ?>">
                                        已启用
                                    </button>
                                <?php endif; ?>
                                <a href="admin.php?delete_rooms=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定要删除该<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>吗？')">
                                    删除
                                </a>
                            </td>
                            <td><i class="fas fa-grip-vertical handle"></i></td>
                        </tr>
        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($conn->query("SELECT COUNT(*) as count FROM rooms WHERE is_deleted=1")->fetch_assoc()['count'] > 0): ?>
            <div class="custom-collapse">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的房间
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>名称</th>
                                    <th>类型</th>
                                    <th>标准价</th>
                                    <th>订单数</th>
                                    <th>删除时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                    <?php
                                        $result = $conn->query("SELECT r.*, (SELECT COUNT(*) FROM orders WHERE room_id = r.id) as order_count FROM rooms r WHERE r.is_deleted=1 ORDER BY r.sort_order, r.id");
                                        while ($row = $result->fetch_assoc()):
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['name']) ?></td>
                                            <td><?= htmlspecialchars(strtoupper($row['type'])) ?></td>
                                            <td><?= $row['standard_price'] > 0 ? '¥' . number_format((float)$row['standard_price'], 2) : '-' ?></td>
                                            <td><?= $row['order_count'] ?></td>
                                            <td><?= $row['update_time'] ?></td>
                                            <td>
                                                <a href="admin.php?restore_room=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                                                    恢复
                                                </a>
                                            </td>
                                        </tr>
                    <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <hr class="my-4">
            <div class="d-flex align-items-center mb-3">
                <h5 class="mb-0" style="margin-right: 30px;">
                    用途标签管理 <small class="text-muted" style="font-size: 0.75rem;">（双击标签名可进行修改）</small>
                </h5>
                <input type="text" id="purposeTagInput" class="form-control mr-2" placeholder="标签名称" maxlength="30" style="flex: 1; max-width: 300px;">
                <button type="button" id="addPurposeTagBtn" class="btn btn-primary mr-2">
                    <i class="fas fa-plus"></i> 添加
                </button>
                <input type="text" id="purposeTagSearchInput" class="form-control ml-auto" placeholder="搜索标签" style="flex: 1; max-width: 300px;">
            </div>
            <div id="purposeTagsContainer" class="purpose-tags-display mt-3">
            </div>
            <?php
            $hidden_tags_result = $conn->query("SELECT * FROM purpose_tags WHERE is_deleted=1 ORDER BY usage_count DESC, id ASC");
            if ($hidden_tags_result->num_rows > 0):
            ?>
            <div class="custom-collapse mt-4">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的标签
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div id="hiddenPurposeTagsContainer" class="purpose-tags-display">
                        <?php while ($tag = $hidden_tags_result->fetch_assoc()): ?>
                        <div class="purpose-tag-item purpose-tag-hidden" data-id="<?= $tag['id'] ?>">
                            <span><?= htmlspecialchars($tag['name']) ?></span>
                            <button class="restore-tag-btn" data-id="<?= $tag['id'] ?>" data-name="<?= htmlspecialchars($tag['name']) ?>" title="恢复">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <hr class="my-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>桌码管理</h5>
                <div class="d-flex" style="gap: 10px;">
                    <button type="button" id="syncQRCodesBtn" class="btn btn-warning">
                        <i class="fas fa-sync-alt mr-1"></i>同步
                    </button>
                    <button type="button" id="batchGenerateBtn" class="btn btn-success">
                        <i class="fas fa-redo mr-1"></i>重新生成
                    </button>
                    <button type="button" id="batchDownloadQRBtn" class="btn btn-info">
                        <i class="fas fa-download mr-1"></i>批量下载二维码
                    </button>
                </div>
            </div>
            <div class="bg-light border-0 mb-4 p-3" style="border-radius: 12px;">
                <div class="d-flex align-items-center">
                    <div class="d-flex align-items-center flex-grow-1 mr-3" style="gap: 15px;">
                        <label for="qrDomain" class="mb-0 text-nowrap" style="min-width: 85px;">二维码域名</label>
                        <input type="text" id="qrDomain" class="form-control" placeholder="例如：http://192.168.1.100:9000" style="border-radius: 8px;">
                    </div>
                    <button type="button" id="saveDomainBtn" class="btn btn-primary px-4 flex-shrink-0" style="border-radius: 8px; height: 38px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        <i class="fas fa-save"></i>
                        <span>网站保存</span>
                    </button>
                </div>
            </div>
            <div class="bg-light border-0 mb-4 p-3" style="border-radius: 12px;">
                <div class="d-flex align-items-center">
                    <div class="d-flex align-items-center flex-grow-1 mr-3" style="gap: 15px;">
                        <label for="qrNotice" class="mb-0 text-nowrap" style="min-width: 85px;">商家公告</label>
                        <input type="text" id="qrNotice" class="form-control" placeholder="请输入商家公告内容，支持换行（最多 200 字）" maxlength="200" style="border-radius: 8px;">
                    </div>
                    <button type="button" id="saveNoticeBtn" class="btn btn-primary px-4 flex-shrink-0" style="border-radius: 8px; height: 38px; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        <i class="fas fa-save"></i>
                        <span>公告保存</span>
                    </button>
                </div>
                <div class="mt-2">
                    <small class="text-muted">仅支持文字和换行&lt;br&gt;，最大 200 字。</small>
                    <small class="text-muted float-right" id="noticeCharCount">0/200</small>
                </div>
            </div>
            <div class="alert alert-info small border-0 mb-3" style="border-radius: 8px;">
                1、此域名将用于生成<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>二维码，顾客扫码后访问的地址，修改域名后需重新生成所有<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>二维码。<br>
                2、建议做好内网穿透方便扫码，不然只能局域网使用。映射本地端口固定为 9000，和程序端口隔离。<br>
                3、如果开启了防火墙，需把 D:\phpRoom\server\apache\bin\api_room.exe 加入到允许通过防火墙。<br>
                4、定期检查异常高频率扫码记录，如存在二维码泄露，可更新房间访问码。
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th class="px-4" style="width: 250px;"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>信息</th>
                            <th>访问码</th>
                            <th>二维码</th>
                            <th>数据统计</th>
                            <th class="text-left px-4" style="width: 280px;">操作</th>
                        </tr>
                    </thead>
                    <tbody id="roomQRCodeList">
                    </tbody>
                </table>
            </div>
        </div> 
        <div class="modal fade" id="qrDetailModal">
            <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
                <div class="modal-content border-0 shadow-lg" style="border-radius: 20px; overflow: hidden;">
                    <div class="modal-header border-0 bg-light px-4 py-3">
                        <h5 class="modal-title font-weight-bold" id="qrDetailRoomName"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名称</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body text-center p-4">
                        <div id="qrDetailContainer" class="mb-4" style="background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.08); display: inline-block;">
                            <div id="qrDetailCanvas"></div>
                        </div>
                        <div class="alert alert-info py-2 px-3 small mb-2" style="border-radius: 10px; opacity: 0.8;">
                            扫码即可快速进入房间查看信息<br>
                            如遇二维码无法加载，可以复制下方网址自行生成二维码
                        </div>
                        <div id="qrDetailUrlDisplay" class="text-muted small mb-4 text-break p-2 bg-light border-0" style="border-radius: 8px; font-family: monospace; word-break: break-all;">
                            加载中...
                        </div>
                        <button type="button" class="btn btn-primary btn-block py-3 font-weight-bold" id="downloadQRBtn" style="border-radius: 12px; font-size: 1.1rem; box-shadow: 0 4px 15px rgba(0,123,255,0.3);">
                            下载二维码
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="productSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">商品管理</h5>
            <?php
            if (isset($_SESSION['admin_error']) && strpos($_SESSION['admin_error'], '商品') !== false) {
                unset($_SESSION['admin_error']);
            }
            ?>
            <form method="POST" class="mb-4" id="quickAddProductForm">
                <input type="hidden" name="product_allow_zero_stock" value="1">
                <input type="hidden" name="product_enable_member_levels_discount" value="1">
                <div class="form-row">
                    <div class="col">
                        <input type="text" name="product_name" class="form-control" placeholder="商品名称" maxlength="10">
                    </div>
                    <div class="col">
                        <div class="type-input-wrapper">
                            <input type="text" name="product_type" class="form-control type-input" placeholder="商品类型" maxlength="10" autocomplete="off">
                            <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="type-dropdown-menu"></div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">¥</span>
                            </div>
                            <input type="number" name="product_price" class="form-control" step="0.01" min="0" max="9999" placeholder="单价">
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <input type="number" name="product_member_discount" class="form-control" value="100" step="1" min="1" max="100" placeholder="会员折扣">
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="button" id="addProductBtn" class="btn btn-primary"><i class="fas fa-plus"></i> 添加商品</button>
                        <button type="button" class="btn btn-info ml-2" data-toggle="modal" data-target="#stockInModal">商品入库</button>
                        <button type="button" class="btn btn-secondary ml-2" data-toggle="modal" data-target="#stockHistoryModal">入库查询</button>
                    </div>
                </div>
            </form>
            <div class="mb-3">
                <button type="button" class="btn btn-primary" id="batchOperateProductsBtn" style="display:none;">
                    <i class="fas fa-tasks"></i> 批量操作
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th style="width: 40px;">
                                <input type="checkbox" id="selectAllProducts" title="全选/取消全选">
                            </th>
                            <th>名称</th>
                            <th>类型</th>
                            <th>单价</th>
                            <th>会员折扣</th>
                            <th>库存</th>
                            <th>订单数</th>
                            <th>操作</th>
                            <th>拖动排序</th>
                        </tr>
                    </thead>
                    <tbody id="productSortable">
                    <?php
                    $product_result = $conn->query("SELECT p.*, (SELECT COUNT(*) FROM product_orders WHERE product_id = p.id) as order_count FROM products p WHERE p.is_deleted=0 ORDER BY p.sort_order, p.id");
                    while ($row = $product_result->fetch_assoc()):
                        $member_price = round($row['price'] * $row['member_discount'] / 100, 2);
                    ?>
                        <tr data-id="<?= $row['id'] ?>">
                            <td>
                                <input type="checkbox" class="product-checkbox" value="<?= $row['id'] ?>">
                            </td>
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars(strtoupper($row['type'])) ?></td>
                            <td>¥<?= number_format($row['price'], 2) ?></td>
                            <td><?= $row['member_discount'] ?>%</td>
                            <td><?= $row['stock_quantity'] ?></td>
                            <td><?= $row['order_count'] ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-product-btn" 
                                    data-id="<?= $row['id'] ?>"
                                    data-name="<?= htmlspecialchars($row['name']) ?>"
                                    data-type="<?= htmlspecialchars(strtoupper($row['type'])) ?>"
                                    data-price="<?= $row['price'] ?>"
                                    data-member-discount="<?= $row['member_discount'] ?>"
                                    data-enable-member-levels-discount="<?= $row['enable_member_levels_discount'] ?? 1 ?>"
                                    data-allow-zero-stock="<?= $row['allow_zero_stock'] ?>">
                                    编辑
                                </button>
                                <?php if ($row['is_enabled'] == 0): ?>
                                    <button class="btn btn-sm btn-secondary disable-product-btn" data-id="<?= $row['id'] ?>">
                                        已停用
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success enable-product-btn" data-id="<?= $row['id'] ?>">
                                        已启用
                                    </button>
                                <?php endif; ?>
                                <a href="admin.php?delete_product=<?= $row['id'] ?>" class="btn btn-sm btn-danger" 
                                    onclick="return confirm('确定要删除该商品吗？')">
                                    删除
                                </a>
                            </td>
                            <td><i class="fas fa-grip-vertical handle"></i></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $hidden_products = $conn->query("SELECT * FROM products WHERE is_deleted=1 ORDER BY sort_order, id");
            if ($hidden_products->num_rows > 0):
            ?>
            <div class="custom-collapse">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的商品
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>名称</th>
                                    <th>类型</th>
                                    <th>单价</th>
                                    <th>订单数</th>
                                    <th>删除时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $hidden_products = $conn->query("SELECT p.*, (SELECT COUNT(*) FROM product_orders WHERE product_id = p.id) as order_count FROM products p WHERE p.is_deleted=1 ORDER BY p.sort_order, p.id");
                            while ($row = $hidden_products->fetch_assoc()): 
                                $member_price = round($row['price'] * $row['member_discount'] / 100, 2);
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars(strtoupper($row['type'])) ?></td>
                                    <td>¥<?= number_format($row['price'], 2) ?></td>
                                    <td><?= $row['order_count'] ?></td>
                                    <td><?= $row['update_time'] ?></td>
                                    <td>
                                        <a href="admin.php?restore_product=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                                            恢复
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="tab-pane fade" id="paymentMethodSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">支付方式</h5>
            <?php
            if (isset($_SESSION['admin_error']) && strpos($_SESSION['admin_error'], '支付方式') !== false) {
                unset($_SESSION['admin_error']);
            }
            ?>
            <form method="POST" class="mb-4" id="quickAddPaymentForm">
                <div class="form-row">
                    <div class="col">
                        <input type="text" name="payment_name" class="form-control" placeholder="支付方式名称" maxlength="10">
                    </div>
                    <div class="col">
                        <input type="text" name="payment_description" class="form-control" placeholder="支付方式描述" maxlength="20">
                    </div>
                  <div class="col-auto">
                        <button type="button" id="addPaymentBtn" class="btn btn-primary"><i class="fas fa-plus"></i> 添加支付方式</button>
                    </div>
                </div>
            </form>
            <div class="alert alert-info mb-4" style="font-size: 0.9rem;">
                <i class="fas fa-info-circle mr-1"></i>
                微信、支付宝支付方式配置了客显金额，一些电脑版收款软件可获取客显金额，实现扫码收款。
            </div>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>名称</th>
                            <th>描述</th>
                            <th>操作</th>
                            <th>拖动排序</th>
                        </tr>
                    </thead>
                    <tbody id="paymentSortable">
                    <?php
                    $result = $conn->query("SELECT * FROM payment_methods WHERE is_deleted=0 ORDER BY sort_order, id");
                    while ($row = $result->fetch_assoc()):
                    ?>
                        <tr data-id="<?= $row['id'] ?>">
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['description'] ?: '-') ?></td>
                            <td>
                                <?php if ($row['is_system'] == 1): ?>
                                    <span class="text-muted small">系统预设</span>
                                    <a href="admin.php?hide_payment=<?= $row['id'] ?>" class="btn btn-sm btn-warning ml-1" 
                                        onclick="return confirm('确定要隐藏该系统支付方式吗？')">
                                        隐藏
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="btn btn-sm btn-primary edit-payment-btn" 
                                        data-id="<?= $row['id'] ?>"
                                        data-name="<?= htmlspecialchars($row['name']) ?>"
                                        data-description="<?= htmlspecialchars($row['description'] ?: '') ?>">
                                        编辑
                                    </button>
                                    <a href="admin.php?delete_payment=<?= $row['id'] ?>" class="btn btn-sm btn-danger ml-1" 
                                        onclick="return confirm('确定要删除该支付方式吗？')">
                                        删除
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td><i class="fas fa-grip-vertical handle"></i></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $hidden_result = $conn->query("SELECT * FROM payment_methods WHERE is_deleted=1 ORDER BY sort_order, id");
            if ($hidden_result->num_rows > 0):
            ?>
            <div class="custom-collapse">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的支付方式
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>名称</th>
                                    <th>描述</th>
                                    <th>删除时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $hidden_result = $conn->query("SELECT * FROM payment_methods WHERE is_deleted=1 ORDER BY sort_order, id");
                            while ($row = $hidden_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['description'] ?: '-') ?></td>
                                    <td><?= $row['update_time'] ?></td>
                                    <td>
                                        <?php if ($row['is_system'] == 1): ?>
                                            <span class="text-muted small">系统预设</span>
                                            <a href="admin.php?restore_payment=<?= $row['id'] ?>" class="btn btn-sm btn-success ml-1">
                                                显示
                                            </a>
                                        <?php else: ?>
                                            <a href="admin.php?restore_payment=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                                                恢复
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="tab-pane fade" id="promotionSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">套餐管理</h5>
            <form method="POST" class="mb-4" id="quickAddPromotionForm">
                <input type="hidden" name="add_promotion" value="1">
                <input type="hidden" name="room_ids" value="[]">
                <input type="hidden" name="weekdays" value="1,2,3,4,5,6,7">
                <input type="hidden" name="time_start" value="00:00:00">
                <input type="hidden" name="time_end" value="23:59:59">
                <input type="hidden" name="enable_member_levels_discount" value="1">
                <div class="form-row">
                    <div class="col">
                        <input type="text" name="name" class="form-control" placeholder="套餐名称" required maxlength="30">
                    </div>
                    <div class="col">
                        <div class="type-input-wrapper">
                            <input type="text" name="type" class="form-control type-input" placeholder="套餐类型" required maxlength="10" autocomplete="off">
                            <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="type-dropdown-menu"></div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <input type="number" name="hours" class="form-control" placeholder="时长" step="0.1" min="0" max="999" required>
                            <div class="input-group-append">
                                <span class="input-group-text">小时</span>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">¥</span>
                            </div>
                            <input type="number" name="price" class="form-control" placeholder="金额" step="0.01" min="0" max="9999" required>
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-group">
                            <input type="number" name="member_discount" class="form-control" value="100" step="1" min="1" max="100" placeholder="会员折扣" required>
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-primary" id="addPromotionBtn"><i class="fas fa-plus"></i> 添加套餐</button>
                    </div>
                </div>
            </form>
            <div class="alert alert-info py-2 px-3 mb-3 small" style="font-size:13px; line-height:1.6;">
                <i class="fas fa-info-circle mr-1"></i>如果需要扫码开台使用套餐，则类型输入 <strong>桌码</strong>，扫码开台会自动匹配。如不配置套餐，扫码开台将按照标准价计费。
            </div>
            <div class="table-responsive">
                <table class="table table-hover" id="promotionTable">
                    <thead class="thead-light">
                        <tr>
                            <th>名称</th>
                            <th>类型</th>
                            <th>时长</th>
                            <th>价格</th>
                            <th>适用<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></th>
                            <th>适用星期</th>
                            <th>适用时间</th>
                            <th>会员折扣</th>
                            <th>操作</th>
                            <th>拖动排序</th>
                        </tr>
                    </thead>
                    <tbody id="sortablePromotions">
                        <?php
                        $result = $conn->query("SELECT * FROM promotion_strategies WHERE is_deleted = 0 ORDER BY sort_order ASC, id ASC");
                        while ($row = $result->fetch_assoc()):
                            $roomIds = !empty($row['room_ids']) ? json_decode($row['room_ids'], true) : [];
                            $roomsText = empty($roomIds) ? '全部' . htmlspecialchars($SCENE_ROOM_NAME) : count($roomIds) . '个' . htmlspecialchars($SCENE_ROOM_NAME);
                            $weekdayNames = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
                            $weekdays = explode(',', $row['weekdays']);
                            $weekdaysText = (count($weekdays) == 7) ? '全周' : implode(',', array_map(function($d) use ($weekdayNames) {
                                return $weekdayNames[intval($d) - 1];
                            }, $weekdays));
                            $timeText = ($row['time_start'] == '00:00:00' && $row['time_end'] == '23:59:59') 
                                ? '全天' 
                                : substr($row['time_start'], 0, 5) . '-' . substr($row['time_end'], 0, 5);
                        ?>
                        <tr data-id="<?= $row['id'] ?>">
                            <td><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars(strtoupper($row['type'] ?? '通用')) ?></td>
                            <td><?= number_format($row['hours'], 1, '.', '') ?>小时</td>
                            <td>¥<?= number_format($row['price'], 2) ?></td>
                            <td><?= $roomsText ?></td>
                            <td><?= $weekdaysText ?></td>
                            <td><?= $timeText ?></td>
                            <td><?= $row['member_discount'] ?>%</td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-promotion-btn" 
                                        data-id="<?= $row['id'] ?>"
                                        data-name="<?= htmlspecialchars($row['name'] ?? '') ?>"
                                        data-type="<?= htmlspecialchars(strtoupper($row['type'] ?? '通用')) ?>"
                                        data-hours="<?= $row['hours'] ?? '' ?>"
                                        data-price="<?= $row['price'] ?? '' ?>"
                                        data-room-ids='<?= $row['room_ids'] ?? '' ?>'
                                        data-weekdays="<?= htmlspecialchars($row['weekdays'] ?? '') ?>"
                                        data-time-start="<?= $row['time_start'] ?? '' ?>"
                                        data-time-end="<?= $row['time_end'] ?? '' ?>"
                                        data-member-discount="<?= $row['member_discount'] ?? '' ?>"
                                        data-enable-member-levels-discount="<?= $row['enable_member_levels_discount'] ?? 1 ?>"
                                        data-is-all-day="<?= $row['is_all_day'] ?? 0 ?>">
                                    编辑
                                </button>
                                <?php if ($row['is_enabled'] == 0): ?>
                                    <button class="btn btn-sm btn-secondary disable-promotion-btn" data-id="<?= $row['id'] ?>">
                                        已停用
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-success enable-promotion-btn" data-id="<?= $row['id'] ?>">
                                        已启用
                                    </button>
                                <?php endif; ?>
                                <a href="admin.php?delete_promotion=<?= $row['id'] ?>" class="btn btn-sm btn-danger" 
                                   onclick="return confirm('确定要删除该套餐吗？')">
                                    删除
                                </a>
                            </td>
                            <td><i class="fas fa-grip-vertical handle"></i></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($conn->query("SELECT COUNT(*) as count FROM promotion_strategies WHERE is_deleted=1")->fetch_assoc()['count'] > 0): ?>
            <div class="custom-collapse mt-3">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的套餐
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>名称</th>
                                    <th>类型</th>
                                    <th>时长</th>
                                    <th>价格</th>
                                    <th>删除时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $hidden_promotions = $conn->query("SELECT * FROM promotion_strategies WHERE is_deleted=1 ORDER BY update_time DESC");
                                while ($row = $hidden_promotions->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars(strtoupper($row['type'] ?? '通用')) ?></td>
                                    <td><?= number_format($row['hours'], 1, '.', '') ?>小时</td>
                                    <td>¥<?= number_format($row['price'], 2) ?></td>
                                    <td><?= $row['update_time'] ?></td>
                                    <td>
                                        <a href="admin.php?restore_promotion=<?= $row['id'] ?>" class="btn btn-sm btn-success">
                                            恢复
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="tab-pane fade" id="configSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">系统配置</h5>
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs" id="configTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="room-tab" data-toggle="tab" href="#roomConfig" role="tab"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>配置</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="audio-tab" data-toggle="tab" href="#audioConfig" role="tab">超时提醒</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="member-tab" data-toggle="tab" href="#memberConfig" role="tab">会员配置</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="system-tab" data-toggle="tab" href="#systemConfig" role="tab">系统设置</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="background-tab" data-toggle="tab" href="#backgroundConfig" role="tab">背景设置</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="database-tab" data-toggle="tab" href="#databaseConfig" role="tab">数据备份</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="update-tab" data-toggle="tab" href="#updateConfig" role="tab">程序更新</a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content" id="configTabContent">
                        <div class="tab-pane fade show active" id="roomConfig" role="tabpanel">
                            <form class="config-form" data-group="room">
                                <div class="config-items">
                                    <div class="text-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="sr-only">加载中...</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">保存配置</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="audioConfig" role="tabpanel">
                            <div class="alert alert-info mb-3" role="alert" style="font-size: 0.9rem;">
                                本功能依赖浏览器的声音自动播放权限。若浏览器不支持自动播放，系统将弹出交互窗口提示用户授权。您可以通过修改浏览器设置，允许声音自动播放或将当前网址添加到例外列表中。
                                <div class="mt-2" style="font-size: 0.9rem;">
                                    <div>浏览器设置：<small class="text-muted">（点击地址复制，粘贴到浏览器地址栏打开）</small></div>
                                    <div>
                                        Chrome浏览器：<code id="chromeSettingUrl" onclick="copyToClipboard('chromeSettingUrl')" style="cursor: pointer;">chrome://settings/content/sound</code>
                                        Edge浏览器：<code id="edgeSettingUrl" onclick="copyToClipboard('edgeSettingUrl')" style="cursor: pointer;">edge://settings/content/mediaAutoplay</code>
                                    </div>
                                </div>
                            </div>
                            <form class="config-form" data-group="audio">
                                <div class="config-items">
                                </div>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">保存配置</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="memberConfig" role="tabpanel">
                            <form class="config-form" data-group="member">
                                <div class="config-items">
                                </div>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">保存配置</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="systemConfig" role="tabpanel">
                            <form class="config-form" data-group="system">
                                <div class="config-items">
                                </div>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">保存配置</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="databaseConfig" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5 class="mb-3"><i class="fas fa-download mr-2"></i>备份数据库</h5>
                                        <form id="dbBackupForm" method="POST" action="admin.php?db_manager=1">
                                            <div class="form-group">
                                                <label for="backupPassword">备份密码</label>
                                                <input type="password" id="backupPassword" name="backup_password" class="form-control" required placeholder="设置备份文件的加密密码">
                                                <small class="form-text text-muted">此密码用于加密备份文件，恢复时需要使用相同的密码。</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="backupConfirmPassword">确认备份密码</label>
                                                <input type="password" id="backupConfirmPassword" name="backup_confirm_password" class="form-control" required placeholder="再次输入备份密码">
                                            </div>
                                            <div class="text-right mt-3">
                                                <button type="submit" class="btn btn-primary" id="startBackupBtn">开始备份</button>
                                            </div>
                                        </form>
                                        <div id="backupMessage" class="mt-3"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5 class="mb-3"><i class="fas fa-upload mr-2"></i>恢复数据库</h5>
                                        <form id="dbRestoreForm" method="POST" action="admin.php?db_manager=1" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="restoreFile">选择备份文件</label>
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" id="restoreFile" name="restore_file" required accept=".enc">
                                                    <label class="custom-file-label" for="restoreFile">选择文件(*.enc)...</label>
                                                </div>
                                                <small class="form-text text-muted">请选择加密的备份文件(.enc格式)</small>
                                            </div>
                                            <div class="form-group">
                                                <label for="restorePassword">备份密码</label>
                                                <input type="password" id="restorePassword" name="restore_password" class="form-control" required placeholder="输入备份文件的加密密码">
                                            </div>
                                            <div class="text-right mt-3">
                                                <button type="submit" class="btn btn-primary" id="startRestoreBtn">开始恢复</button>
                                            </div>
                                        </form>
                                        <div id="restoreMessage" class="mt-3"></div>
                                        <div id="restoreWarnings" class="mt-3"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <div class="border p-3 rounded">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-sm" id="backupFilesTable">
                                                <thead class="thead-light">
                                                    <tr>
                                                        <th>文件名 <i class="fas fa-info-circle config-info-icon" style="cursor: pointer;" data-info="展示最近的10个备份，如需更多请浏览backups目录"></i></th>                                                        <th>大小</th>
                                                        <th>创建时间</th>
                                                        <th>操作</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div id="backupFilesMessage" class="mt-3 text-center">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="sr-only">加载中...</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="updateConfig" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5><i class="fas fa-code mr-1"></i>程序版本信息</h5>
                                        <div class="form-group mb-3">
                                            <label class="mb-0">
                                                当前程序版本号：<span id="currentVersion" class="text-primary" style="font-size: 1.1rem;">
                                                    <span class="spinner-border spinner-border-sm mr-1" role="status"></span>加载中...
                                                </span>
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <div class="d-flex align-items-center">
                                                <button type="button" class="btn btn-primary mr-3" id="checkUpdateBtn">
                                                    检查更新
                                                </button>
                                                <button type="button" class="btn btn-success d-none" id="updateBtn">
                                                    立即更新
                                                </button>
                                            </div>
                                            <div class="text-danger small mt-2 d-none" id="updateWarning">
                                                <i class="fas fa-exclamation-triangle mr-1"></i>更新时，请确保项目文件没有被其他程序打开，以免覆盖出错,（如遇安全软件拦截，请添加信任或放行！）
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="updateStatus">新版状态：</label>
                                            <div id="updateStatus" class="alert alert-info mb-0">
                                                <i class="fas fa-info-circle mr-2"></i>请点击"检查更新"按钮检查是否有新版本
                                            </div>
                                            <div id="updateProgress" class="mt-3 d-none">
                                                <div class="progress mb-2" style="height: 25px;">
                                                    <div id="updateProgressBar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div id="updateProgressLog" class="text-muted small" style="max-height: 150px; overflow-y: auto;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5><i class="fas fa-history mr-1"></i>历史版本更新日志</h5>
                                        <div id="versionLogs">
                                            <div class="text-center py-4">
                                                <div class="spinner-border text-primary" role="status">
                                                    <span class="sr-only">加载中...</span>
                                                </div>
                                                <div class="mt-2">正在加载更新日志...</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="backgroundConfig" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5><i class="fas fa-edit mr-1"></i>背景图片编辑</h5>
                                        <div class="form-group">
                                            <label for="backgroundFile">选择并上传图片</label>
                                            <div class="d-flex align-items-center">
                                                <div class="custom-file" style="flex: 1 1 auto; max-width: calc(100% - 100px);">
                                                    <input type="file" class="custom-file-input" id="backgroundFile" accept="image/jpeg, image/jpg, image/png">
                                                    <label class="custom-file-label" for="backgroundFile">请选择图片...</label>
                                                </div>
                                                <button type="button" class="btn btn-primary ml-2" id="uploadBackgroundBtn" style="flex: 0 0 auto;">
                                                    <i class="fas fa-upload mr-1"></i>上传
                                                </button>
                                            </div>
                                            <small class="form-text text-muted mt-1">请选择小于500kb的jpg图片上传</small>
                                        </div>
                                        <div class="form-group">
                                            <button type="button" class="btn btn-warning w-100" id="removeBackgroundBtn">
                                                <i class="fas fa-ban mr-1"></i>停用背景
                                            </button>
                                        </div>
                                        <div class="form-group">
                                            <label>图片预览</label>
                                            <div id="imagePreviewContainer" class="text-center" style="display: none;">
                                                <img id="imagePreview" src="" alt="预览图片" style="max-width: 100%; max-height: 200px; border-radius: 8px; border: 2px solid #ddd;">
                                            </div>
                                            <div id="noImageText" class="text-muted text-center py-3">
                                                请选择或上传图片
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="backgroundOpacity">内容透明度</label>
                                            <div class="input-group">
                                                <input type="range" class="form-control-range" id="backgroundOpacity" min="0" max="100" value="70">
                                                <span class="input-group-append">
                                                    <span class="input-group-text" id="opacityValue">70%</span>
                                                </span>
                                            </div>
                                            <small class="form-text text-muted">调整内容区域透明度，0%为完全透明，100%为完全不透明</small>
                                        </div>
                                        <div class="form-group">
                                            <div class="btn-group-vertical w-100">
                                                <button type="button" class="btn btn-secondary mb-2" id="previewBackgroundBtn" disabled>
                                                    <i class="fas fa-eye mr-1"></i>预览效果
                                                </button>
                                                <button type="button" class="btn btn-secondary mb-2" id="applyBackgroundBtn" disabled>
                                                    <i class="fas fa-check mr-1"></i>应用设置
                                                </button>
                                                <button type="button" class="btn btn-secondary" id="deleteBackgroundBtn" disabled>
                                                    <i class="fas fa-trash mr-1"></i>删除图片
                                                </button>
                                            </div>
                                        </div>
                                        <div id="backgroundMessage" class="mt-3"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="border p-3 rounded mb-3">
                                        <h5><i class="fas fa-images mr-1"></i>现有图片库</h5>
                                        <div id="backgroundThumbnailsContainer" style="max-height: 400px; overflow-y: auto;">
                                            <div id="backgroundThumbnails" class="row">
                                            </div>
                                        </div>
                                        <div id="noBackgroundsText" class="text-muted text-center py-3">
                                            暂无背景图片
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="memberInfoSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">会员服务</h5>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="border p-3 rounded">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0"><i class="fas fa-layer-group mr-2"></i>会员类型管理</h5>
                            <button type="button" class="btn btn-warning btn-sm" id="reinitMemberLevelsBtn">
                                <i class="fas fa-sync-alt"></i> 重新初始化会员卡类型
                            </button>
                        </div>
                        <div class="alert alert-info small mb-3">
                            1、如需实现自动卡类型升级，需开启-系统配置>会员配置>卡类型自动升级，开启后将根据配置自动对卡类型进行升降级操作。<br>
                            2、首次开卡最低金额和续费充值最低金额的值需是-系统配置>会员配置>充值金额倍数配置值的倍数，且不可超过单次充值最大限额。<br>
                            3、如果当前会员所属的类型已停用，则不会对此类型的卡进行自动升级。
                        </div>
                        <form method="POST" class="mb-3" id="quickAddMemberLevelForm">
                            <input type="hidden" name="is_system" value="0">
                            <div class="form-row">
                                <div class="col">
                                    <input type="text" class="form-control" name="level_name" id="quickLevelName" placeholder="卡类型名称" maxlength="20">
                                </div>
                                <div class="col">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">¥</span>
                                        </div>
                                        <input type="number" class="form-control" name="min_first_recharge" id="quickMinFirstRecharge" placeholder="首次开卡最低" min="0" max="99999" step="0.01">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">¥</span>
                                        </div>
                                        <input type="number" class="form-control" name="min_recharge" id="quickMinRecharge" placeholder="续费充值最低" min="0" max="99999" step="0.01">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">¥</span>
                                        </div>
                                        <input type="number" class="form-control" name="auto_upgrade_amount" id="quickAutoUpgrade" placeholder="自动升级累计" min="0" max="99999" step="0.01">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="input-group">
                                        <input type="number" class="form-control" name="member_discount" id="quickMemberDiscount" placeholder="会员折扣" min="1" max="100" step="1" value="100">
                                        <div class="input-group-append">
                                            <span class="input-group-text">%</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <button type="button" class="btn btn-primary btn-sm" id="addLevelBtn">
                                        <i class="fas fa-plus"></i> 添加会员类型
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>卡类型名称</th>
                                        <th>首次开卡最低</th>
                                        <th>续费充值最低</th>
                                        <th>自动升级累计</th>
                                        <th>会员折扣</th>
                                        <th>操作</th>
                                        <th>拖动排序</th>
                                    </tr>
                                </thead>
                                <tbody id="memberLevelsSortable">
                                <?php
                                $level_result = $conn->query("SELECT * FROM member_levels ORDER BY sort_order ASC, id ASC");
                                while ($level = $level_result->fetch_assoc()):
                                    $isSystem = $level['is_system'] == 1;
                                    $isEnabled = $level['is_enabled'] == 1;
                                ?>
                                    <tr data-id="<?= $level['id'] ?>">
                                        <td><?= htmlspecialchars($level['name']) ?></td>
                                        <td>¥<?= number_format($level['min_first_recharge'], 2) ?></td>
                                        <td>¥<?= number_format($level['min_recharge'], 2) ?></td>
                                        <td>¥<?= number_format($level['auto_upgrade_amount'], 2) ?></td>
                                        <td><?= intval($level['member_discount']) ?>%</td>
                                        <td>
                                            <button class="btn btn-sm btn-primary edit-member-level-btn" 
                                                data-id="<?= $level['id'] ?>"
                                                data-name="<?= htmlspecialchars($level['name']) ?>"
                                                data-min-first-recharge="<?= $level['min_first_recharge'] ?>"
                                                data-min-recharge="<?= $level['min_recharge'] ?>"
                                                data-auto-upgrade-amount="<?= $level['auto_upgrade_amount'] ?>"
                                                data-member-discount="<?= $level['member_discount'] ?>"
                                                data-is-system="<?= $isSystem ? '1' : '0' ?>">
                                                编辑
                                            </button>
                                            <?php if (!$isSystem): ?>
                                                <?php if ($isEnabled): ?>
                                                    <button class="btn btn-sm btn-success enable-level-btn" data-id="<?= $level['id'] ?>">
                                                        已启用
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-secondary disable-level-btn" data-id="<?= $level['id'] ?>">
                                                        已停用
                                                    </button>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-danger delete-level-btn" data-id="<?= $level['id'] ?>" data-name="<?= htmlspecialchars($level['name']) ?>">
                                                    删除
                                                </button>
                                            <?php else: ?>
                                                <span class="text-muted small">不可停用</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><i class="fas fa-grip-vertical handle"></i></td>
                                    </tr>
                                <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="border-top pt-3 mt-3">
                            <h6 class="mb-3">批量类型转换</h6>
                            <div class="alert alert-warning small mb-3">
                                <i class="fas fa-exclamation-triangle mr-1"></i>
                                此功能将所有使用"当前类型"的会员批量转换到"目标类型"，操作不可撤销，请谨慎使用！
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="mr-2">当前类型</span>
                                <select class="form-control mr-3" id="convertFromLevel" style="width: 200px;">
                                    <option value="">请选择</option>
                                </select>
                                <i class="fas fa-arrow-right text-primary mr-3" style="font-size: 1.2rem;"></i>
                                <span class="mr-2">目标类型</span>
                                <select class="form-control mr-3" id="convertToLevel" style="width: 200px;">
                                    <option value="">请选择</option>
                                </select>
                                <button type="button" class="btn btn-primary" id="executeLevelConvertBtn">
                                    执行类型转换
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-12">
                    <div class="border p-3 rounded">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0"><i class="fas fa-ticket-alt mr-2"></i>次卡券管理</h5>
                            <button type="button" class="btn btn-primary btn-sm" id="addTimeCardBtn">
                                <i class="fas fa-plus"></i> 添加次卡券
                            </button>
                        </div>
                        <div class="table-responsive" id="timeCardSection">
                            <table class="table table-hover">
                                <thead class="thead-light">
                                    <tr>
                                        <th>名称</th>
                                        <th>类型</th>
                                        <th>适配</th>
                                        <th>次数</th>
                                        <th>销售价</th>
                                        <th>有效期</th>
                                        <th>抵扣时长</th>
                                        <th>会员折扣</th>
                                        <th>操作</th>
                                        <th>拖动排序</th>
                                    </tr>
                                </thead>
                                <tbody id="timeCardSortable">
                                <?php
                                $time_card_result = $conn->query("SELECT * FROM time_card_products WHERE is_deleted=0 ORDER BY sort_order, id");
                                while ($tc = $time_card_result->fetch_assoc()):
                                    $isEnabled = $tc['is_enabled'] == 1;
                                    $typeText = $tc['type'] === 'room' ? $SCENE_ROOM_NAME : '商品';
                                    $applicableText = '';
                                    if ($tc['type'] === 'room') {
                                        $room_ids = !empty($tc['room_ids']) ? json_decode($tc['room_ids'], true) : [];
                                        if (empty($room_ids)) {
                                            $applicableText = '全部' . htmlspecialchars($SCENE_ROOM_NAME);
                                        } else {
                                            $applicableText = count($room_ids) . '个' . htmlspecialchars($SCENE_ROOM_NAME);
                                        }
                                    } else {
                                        $product_ids = !empty($tc['product_ids']) ? json_decode($tc['product_ids'], true) : [];
                                        if (empty($product_ids)) {
                                            $applicableText = '全部商品';
                                        } else {
                                            $applicableText = count($product_ids) . '个商品';
                                        }
                                    }
                                ?>
                                    <tr data-id="<?= $tc['id'] ?>">
                                        <td><?= htmlspecialchars($tc['name']) ?></td>
                                        <td><span class="badge badge-<?= $tc['type'] === 'room' ? 'primary' : 'success' ?>"><?= $typeText ?></span></td>
                                        <td><?= $applicableText ?></td>
                                        <td><?= $tc['total_times'] ?></td>
                                        <td>¥<?= number_format($tc['price'], 2) ?></td>
                                        <td><?= $tc['validity_days'] ? $tc['validity_days'] : '永久' ?></td>
                                        <td><?= $tc['hours'] ? $tc['hours'] : '-' ?></td>
                                        <td><?= intval($tc['member_discount']) ?>%</td>
                                        <td>
                                            <button class="btn btn-sm btn-primary edit-time-card-btn" 
                                                data-id="<?= $tc['id'] ?>"
                                                data-name="<?= htmlspecialchars($tc['name']) ?>"
                                                data-type="<?= $tc['type'] ?>"
                                                data-times="<?= $tc['total_times'] ?>"
                                                data-price="<?= $tc['price'] ?>"
                                                data-validity-days="<?= $tc['validity_days'] ?>"
                                                data-deduction-hours="<?= $tc['hours'] ?>"
                                                data-applicable-room-ids='<?= $tc['room_ids'] ?? '' ?>'
                                                data-applicable-product-ids='<?= $tc['product_ids'] ?? '' ?>'
                                                data-member-discount="<?= $tc['member_discount'] ?>"
                                                data-enable-member-levels-discount="<?= $tc['enable_member_levels_discount'] ?? 1 ?>">
                                                编辑
                                            </button>
                                            <?php if ($isEnabled): ?>
                                                <button class="btn btn-sm btn-success enable-time-card-btn" data-id="<?= $tc['id'] ?>">
                                                    已启用
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-secondary disable-time-card-btn" data-id="<?= $tc['id'] ?>">
                                                    已停用
                                                </button>
                                            <?php endif; ?>
                                            <a href="admin.php?delete_time_card=<?= $tc['id'] ?>" class="btn btn-sm btn-danger" 
                                                onclick="return confirm('确定要删除该次卡券吗？')">
                                                删除
                                            </a>
                                        </td>
                                        <td><i class="fas fa-grip-vertical handle"></i></td>
                                    </tr>
                                <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                        $hidden_time_cards = $conn->query("SELECT * FROM time_card_products WHERE is_deleted=1 ORDER BY id DESC");
                        if ($hidden_time_cards->num_rows > 0):
                        ?>
                        <div class="custom-collapse">
                            <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                                已隐藏的次卡券
                                <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                            </div>
                            <div class="custom-collapse-content" style="display:none;">
                                <div class="table-responsive">
                                    <table class="table table-hover table-sm mb-0">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>名称</th>
                                                <th>类型</th>
                                                <th>次数</th>
                                                <th>销售价</th>
                                                <th>删除时间</th>
                                                <th>操作</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                        $hidden_time_cards = $conn->query("SELECT * FROM time_card_products WHERE is_deleted=1 ORDER BY id DESC");
                                        while ($tc = $hidden_time_cards->fetch_assoc()): 
                                            $typeText = $tc['type'] === 'room' ? $SCENE_ROOM_NAME : '商品';
                                        ?>
                                            <tr>
                                                <td><?= htmlspecialchars($tc['name']) ?></td>
                                                <td><span class="badge badge-<?= $tc['type'] === 'room' ? 'primary' : 'success' ?>"><?= $typeText ?></span></td>
                                                <td><?= $tc['total_times'] ?>次</td>
                                                <td>¥<?= number_format($tc['price'], 2) ?></td>
                                                <td><?= $tc['update_time'] ?></td>
                                                <td>
                                                    <a href="admin.php?restore_time_card=<?= $tc['id'] ?>" class="btn btn-sm btn-warning">
                                                        恢复
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="border p-3 rounded mb-3">
                        <h5 class="mb-3"><i class="fas fa-user-edit mr-2"></i>修改会员信息</h5>
                        <div class="alert alert-info small mb-3">
                            <i class="fas fa-info-circle mr-1"></i>可修改会员手机号，姓名，密码，停用会员卡功能。
                        </div>
                        <form id="memberQueryForm">
                            <div class="form-group">
                                <label for="memberPhoneNumber">会员手机号</label>
                                <div class="form-row">
                                    <div class="col">
                                        <input type="tel" class="form-control" id="memberPhoneNumber" placeholder="请输入会员手机号" maxlength="11" inputmode="numeric" pattern="^1[3-9]\d{9}$">
                                    </div>
                                    <div class="col-auto">
                                        <button class="btn btn-primary" type="button" id="queryMemberBtn">查询</button>
                                    </div>
                                </div>
                                <small class="form-text text-muted">输入会员手机号查询会员信息</small>
                            </div>
                        </form>
                        <div class="mt-3" id="memberMessage"></div>
                        <div id="memberInfoContainer" style="display: none;" class="mt-4 pt-3 border-top">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>会员卡号</label>
                                        <div class="input-group input-group-sm">
                                            <input type="text" id="memberCardNo" class="form-control" readonly>
                                            <div class="input-group-append ml-2">
                                                <button type="button" id="editCardNoBtn" class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center" style="min-width: 50px;">
                                                    编辑
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>会员余额（仅供查看）</label>
                                        <div class="input-group input-group-sm">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">¥</span>
                                            </div>
                                            <input type="text" id="memberBalance" class="form-control form-control-sm" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" id="newCardNoRow" style="display: none;">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>新会员卡号</label>
                                        <input type="text" id="newMemberCardNo" class="form-control" placeholder="输入11位手机号" maxlength="11" inputmode="numeric" pattern="[0-9DELTdelt]*" autocomplete="off" spellcheck="false">
                                        <small class="text-danger font-weight-bold">修改卡号会更新所有相关订单记录。</small>
                                        <div class="mt-2">
                                            <button type="button" id="confirmCardNoChangeBtn" class="btn btn-warning btn-sm mr-2">
                                                更新卡号
                                            </button>
                                            <button type="button" id="cancelCardNoChangeBtn" class="btn btn-secondary btn-sm">
                                                取消
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>会员姓名（可修改）</label>
                                        <input type="text" id="memberName" class="form-control" placeholder="请输入会员姓名" autocomplete="off" maxlength="6">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>会员类型</label>
                                        <select id="memberLevel" class="form-control">
                                            <option value="">加载中...</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>会员密码</label>
                                        <input type="password" id="memberPassword" class="form-control" placeholder="如需修改请输入，不修改请留空" autocomplete="off" style="font-size:13px;color:#6c757d;">
                                        <small class="form-text text-muted">不修改请留空，修改请输入至少6位数字</small>
                                        <div class="invalid-feedback">密码必须为至少6位数字</div>
                                    </div>
                                </div>
                            </div>
                        <div class="text-right mt-3">
                            <button type="button" id="disableMemberBtn" class="btn btn-danger mr-2">
                                停用此卡
                            </button>
                            <button type="button" id="updateMemberBtn" class="btn btn-primary">
                                <span id="updateBtnText">保存修改</span>
                            </button>
                        </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="border p-3 rounded mb-3">
                        <div class="d-flex justify-content-between align-items-start flex-wrap mb-3">
                            <h5 class="mb-2 mb-sm-0"><i class="fas fa-exchange-alt mr-2"></i>换卡转账</h5>
                            <button type="button" class="btn btn-info btn-sm" id="viewTransferHistoryBtn">
                                <i class="fas fa-history"></i> 卡操作历史
                            </button>
                        </div>
                        <div class="alert alert-info small mb-3">
                            <i class="fas fa-info-circle mr-1"></i>旧卡余额将以赠送方式转移到新卡，旧卡将自动归档为"手机号@3位随机数"格式，保留完整历史记录。如新卡不存在则直接办理新卡，同步旧卡姓名和密码信息。<span style="color: red; font-weight: bold;">旧卡的次卡券余数无法转入新卡。</span>
                        </div>
                            <form id="cardTransferForm">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="oldCardNo">旧会员卡号</label>
                                            <input type="tel" class="form-control" id="oldCardNo" placeholder="请输入旧会员卡号" maxlength="11" inputmode="numeric" pattern="^1[3-9]\d{9}$">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="newCardNo">新会员卡号</label>
                                            <input type="tel" class="form-control" id="newCardNo" placeholder="请输入新会员卡号" maxlength="11" inputmode="numeric" pattern="^1[3-9]\d{9}$">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12 text-right">
                                        <button type="button" id="cardTransferBtn" class="btn btn-primary">
                                            执行换卡转账
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="mt-3" id="cardTransferMessage"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="usersSection" role="tabpanel">
        <div class="module-card">
            <h5 class="mb-3 tab-title-mobile text-primary">用户管理</h5>
            <form class="mb-4" id="quickAddUserForm">
                <div class="form-row">
                    <div class="col">
                        <input type="text" class="form-control" id="quickUsername" placeholder="用户名" maxlength="10" required>
                    </div>
                    <div class="col">
                        <input type="text" class="form-control" id="quickName" placeholder="姓名" maxlength="10" required>
                    </div>
                    <div class="col">
                        <select class="form-control" id="quickRole" required <?= !$isSuperAdmin ? 'disabled' : '' ?>>
                            <?php if ($isSuperAdmin): ?>
                                <option value="admin">管理员</option>
                                <option value="front">前台</option>
                            <?php else: ?>
                                <option value="front" selected>前台</option>
                            <?php endif; ?>
                        </select>
                        <?php if (!$isSuperAdmin): ?>
                            <input type="hidden" name="role" value="front">
                        <?php endif; ?>
                    </div>
                    <div class="col">
                        <input type="password" class="form-control" id="quickPassword" placeholder="密码" minlength="6" maxlength="20" required>
                    </div>
                    <div class="col-auto">
                        <button type="button" id="addUserBtn" class="btn btn-primary"><i class="fas fa-plus"></i> 添加用户</button>
                    </div>
                </div>
            </form>
            <div class="alert alert-info mb-4" style="font-size: 0.9rem;">
                <i class="fas fa-info-circle mr-1"></i>
                <?php if ($isSuperAdmin): ?>
                    超级管理员拥有所有权限。可以管理所有用户（管理员和前台）
                <?php else: ?>
                    您可以修改自己的姓名和密码，或添加和管理前台账户（编辑、启用/停用、删除）。
                <?php endif; ?>
            </div>
            <div class="table-responsive mb-3">
                <table class="table table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>用户名</th>
                            <th>姓名</th>
                            <th>权限</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                    <?php
                    $user_result = $conn->query("SELECT * FROM system_users WHERE is_deleted=0 ORDER BY id");
                    while ($user = $user_result->fetch_assoc()):
                        $role_badge = $user['role'] === 'admin' ? '<span class="badge badge-success">管理员</span>' : '<span class="badge badge-info">前台</span>';
                    ?>
                        <tr data-id="<?= $user['id'] ?>">
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><?= htmlspecialchars($user['name']) ?></td>
                            <td><?= $role_badge ?></td>
                            <td>
                                <?php if ($isSuperAdmin || $user['role'] === 'front' || $user['id'] == $currentUserId): ?>
                                    <button type="button" class="btn btn-sm btn-primary edit-user-btn" 
                                        data-id="<?= $user['id'] ?>"
                                        data-username="<?= htmlspecialchars($user['username']) ?>"
                                        data-name="<?= htmlspecialchars($user['name']) ?>"
                                        data-role="<?= $user['role'] ?>">
                                        编辑
                                    </button>
                                <?php endif; ?>
                                <?php if ($user['id'] != 1 && ($isSuperAdmin || $user['role'] === 'front')): ?>
                                    <?php if ($user['is_enabled'] == 0): ?>
                                        <button type="button" class="btn btn-sm btn-secondary disable-user-btn" data-id="<?= $user['id'] ?>">
                                            已停用
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-success enable-user-btn" data-id="<?= $user['id'] ?>">
                                            已启用
                                        </button>
                                    <?php endif; ?>
                                    <a href="admin.php?delete_user=<?= $user['id'] ?>" class="btn btn-sm btn-danger ml-1" 
                                        onclick="return confirm('确定要删除该用户吗？')">
                                        删除
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php
            $deleted_users = $conn->query("SELECT * FROM system_users WHERE is_deleted=1 ORDER BY id");
            if ($deleted_users->num_rows > 0):
            ?>
            <div class="custom-collapse">
                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                    已隐藏的用户
                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                </div>
                <div class="custom-collapse-content" style="display:none;">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm mb-0">
                            <thead class="thead-light">
                                <tr>
                                    <th>用户名</th>
                                    <th>姓名</th>
                                    <th>权限</th>
                                    <th>删除时间</th>
                                    <th style="min-width: 70px;">操作</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            $deleted_users = $conn->query("SELECT * FROM system_users WHERE is_deleted=1 ORDER BY id");
                            while ($row = $deleted_users->fetch_assoc()): 
                                $role_badge = $row['role'] === 'admin' ? '<span class="badge badge-success">管理员</span>' : '<span class="badge badge-info">前台</span>';
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['username']) ?></td>
                                    <td><?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= $role_badge ?></td>
                                    <td><?= $row['update_time'] ?></td>
                                    <td>
                                        <a href="admin.php?restore_user=<?= $row['id'] ?>" class="btn btn-sm btn-warning" onclick="return confirm('确定要恢复该用户吗？')">恢复</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="modal fade" id="userModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userModalTitle">添加用户</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <input type="hidden" id="userId" name="id">
                        <input type="hidden" id="currentUserId" value="<?= $currentUserId ?>">
                        <input type="hidden" id="isSuperAdmin" value="<?= $isSuperAdmin ? '1' : '0' ?>">
                        <div class="form-group">
                            <label for="userUsername">用户名</label>
                            <input type="text" class="form-control" id="userUsername" name="username" maxlength="10" readonly disabled style="background-color: #e9ecef;">
                            <small class="text-muted" id="usernameHint">用户名不可修改</small>
                        </div>
                        <div class="form-group">
                            <label for="userName">姓名 <span class="text-danger">*</span> <small class="text-muted">（已使用的用户尽量避免修改该信息）</small></label>
                            <input type="text" class="form-control" id="userName" name="name" maxlength="10" required>
                        </div>
                        <div class="form-group">
                            <label for="userPassword">密码 <small class="text-muted">（不填写则不修改密码）</small></label>
                            <input type="password" class="form-control" id="userPassword" name="password" minlength="6" maxlength="20">
                        </div>
                        <div class="form-group">
                            <label for="userRole">权限</label>
                            <select class="form-control" id="userRole" name="role" required>
                                <option value="front">前台</option>
                                <?php if ($isSuperAdmin): ?>
                                    <option value="admin">管理员</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" id="saveUserBtn">保存</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="transferHistoryModal">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" style="max-width: 95%;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-history mr-2"></i>卡操作历史</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group mb-3">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <input type="text" class="form-control form-control-sm" id="historySearchCardNo" placeholder="输入卡号查询（支持原卡、新卡、归档卡）">
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-sm btn-primary mr-2" type="button" id="searchTransferHistoryBtn">
                                    <i class="fas fa-search mr-1"></i>查询
                                </button>
                                <button class="btn btn-sm btn-secondary mr-2" type="button" id="resetTransferHistoryBtn">
                                    <i class="fas fa-redo mr-1"></i>显示全部
                                </button>
                                <button class="btn btn-sm btn-success" type="button" id="exportTransferHistoryBtn">
                                    <i class="fas fa-file-excel mr-1"></i>导出Excel
                                </button>
                            </div>
                        </div>
                    </div>
                    <div id="transferHistoryContent">
                        <div class="text-center text-muted py-5">
                            <i class="fas fa-spinner fa-spin fa-3x mb-3"></i>
                            <p>加载中...</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editMemberLevelModal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="edit_member_level">
                    <input type="hidden" name="level_id" id="editLevelId">
                    <input type="hidden" name="is_system" id="editLevelIsSystem">
                    <div class="modal-header">
                        <h5 class="modal-title">编辑卡类型</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>卡类型名称 <span class="text-danger">*</span> <span class="text-muted small">（已使用的卡类型尽量避免修改该信息）</span></label>
                            <input type="text" class="form-control" name="level_name" id="editLevelName" maxlength="20" required>
                        </div>
                        <div class="form-group">
                            <label>首次开卡最低金额（元）</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" class="form-control" name="min_first_recharge" id="editMinFirstRecharge" min="0" max="99999" step="0.01" required>
                            </div>
                            <small class="text-muted">会员首次开卡时的最低充值金额，0表示无限制</small>
                        </div>
                        <div class="form-group">
                            <label>续费充值最低金额（元）</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" class="form-control" name="min_recharge" id="editMinRecharge" min="0" max="99999" step="0.01" required>
                            </div>
                            <small class="text-muted">会员续费充值时的最低金额，0表示无限制</small>
                        </div>
                        <div class="form-group">
                            <label>自动升级累计充值金额（元）</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" class="form-control" name="auto_upgrade_amount" id="editAutoUpgrade" min="0" max="99999" step="0.01" required>
                            </div>
                            <small class="text-muted">会员累计充值达到此金额自动升级到此类型，0表示不参与自动升级</small>
                        </div>
                        <div class="form-group">
                            <label>会员折扣</label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="member_discount" id="editLevelMemberDiscount" min="1" max="100" step="1" value="100" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <small class="form-text text-muted">例如：80表示8折，100表示不打折</small>
                            <small class="form-text text-danger">折扣为全局折扣，对标准价房间、商品、套餐、次卡券生效</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                        <button type="submit" class="btn btn-primary">保存</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="editTimeCardModal">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="edit_time_card">
                <input type="hidden" name="time_card_id" id="editTimeCardId">
                <input type="hidden" name="time_card_type" id="editTimeCardTypeHidden">
                <div class="modal-header">
                    <h5 class="modal-title" id="timeCardModalTitle">编辑次卡券</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>次卡券名称 <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="time_card_name" id="editTimeCardName" maxlength="25" required>
                            <small class="form-text text-muted">（已使用的次卡券尽量避免修改该信息）</small>
                        </div>
                        <div class="form-group col-md-4" id="editTimeCardTypeSelectGroup">
                            <label>类型 <span class="text-danger">*</span></label>
                            <select class="form-control" name="time_card_type" id="editTimeCardType" required>
                                <option value="">请选择</option>
                                <option value="room"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></option>
                                <option value="product">商品</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4" id="editTimeCardTypeDisplayGroup" style="display:none;">
                            <label>类型 <small class="text-danger">类型不可修改</small></label>
                            <input type="text" class="form-control" id="editTimeCardTypeDisplay" readonly>
                        </div>
                        <div class="form-group col-md-4">
                            <label>抵扣时长（小时）</label>
                            <input type="number" class="form-control time-card-number-input" name="time_card_deduction_hours" id="editTimeCardDeductionHours" min="0" max="999" step="0.1" data-max="999">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label>次数</label>
                            <input type="number" class="form-control time-card-number-input" name="time_card_times" id="editTimeCardTimes" min="1" max="9999" step="1" data-max="9999" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>销售价（元）</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">¥</span>
                                </div>
                                <input type="number" class="form-control time-card-number-input" name="time_card_price" id="editTimeCardPrice" min="0" max="9999" step="0.01" data-max="9999" required>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label>有效期（天）</label>
                            <input type="number" class="form-control time-card-number-input" name="time_card_validity_days" id="editTimeCardValidityDays" min="1" max="999" step="1" data-max="999" placeholder="留空=永久">
                        </div>
                        <div class="form-group col-md-3">
                            <label>会员折扣</label>
                            <div class="input-group">
                                <input type="number" class="form-control time-card-number-input" name="time_card_member_discount" id="editTimeCardMemberDiscount" min="1" max="100" step="1" data-max="100" value="100" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-0">
                        <label class="d-inline-block mr-3">是否参与会员类型折扣</label>
                        <div class="custom-control custom-switch d-inline-block">
                            <input type="checkbox" class="custom-control-input" id="editTimeCardEnableMemberLevelsDiscount" name="time_card_enable_member_levels_discount" value="1" checked>
                            <label class="custom-control-label" for="editTimeCardEnableMemberLevelsDiscount">启用</label>
                        </div>
                        <small class="text-danger ml-2">开启后会叠加会员类型折扣</small>
                    </div>
                    <div class="form-group" id="editApplicableRoomsGroup" style="display:none;">
                        <label>适用<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?> <small class="text-danger">此修改会影响已购用户的权益</small></label>
                        <div class="border rounded p-2" style="max-height: 150px; overflow-y: auto;">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editAllRooms" checked>
                                <label class="form-check-label font-weight-bold" for="editAllRooms">
                                    全部<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>
                                </label>
                            </div>
                            <hr class="my-2">
                            <div id="editRoomCheckboxes">
                            </div>
                        </div>
                    </div>
                    <div class="form-group" id="editApplicableProductsGroup" style="display:none;">
                        <label>适用商品 <small class="text-danger">此修改会影响已购用户的权益</small></label>
                        <div class="border rounded p-2" style="max-height: 150px; overflow-y: auto;">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editAllProducts" checked>
                                <label class="form-check-label font-weight-bold" for="editAllProducts">
                                    全部商品
                                </label>
                            </div>
                            <hr class="my-2">
                            <div id="editProductCheckboxes">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="back-to-top">
    <i class="fas fa-arrow-up"></i>
</div>
<script src="/asset/lib/js/jquery.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/jquery.min.js') ?>"></script>
<script src="/asset/lib/js/bootstrap.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/bootstrap.min.js') ?>"></script>
<script src="/asset/lib/js/jszip.min.js"></script>
<script src="/asset/admin.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/admin.js') ?>"></script>
<script>
function copyToClipboard(elementId) {
    const text = document.getElementById(elementId).textContent;
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(() => {
            showToast('复制成功', '已复制到剪贴板', 'success');
        }).catch(() => {
            fallbackCopy(text);
        });
    } else {
        fallbackCopy(text);
    }
    function fallbackCopy(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '0';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();
        try {
            const successful = document.execCommand('copy');
            if (successful) {
                showToast('复制成功', '已复制到剪贴板', 'success');
            } else {
                showToast('复制失败', '请手动复制', 'error');
            }
        } catch (err) {
            showToast('复制失败', '请手动复制', 'error');
        }
        document.body.removeChild(textarea);
    }
}
let allPurposeTags = [];
$(document).ready(function() {
    window.currentUserId = <?= $currentUserId ?>;
    $('.nav-link[data-toggle="tab"]').on('mouseenter', function() {
        const $this = $(this);
        const href = $this.attr('href');
        if (href) {
            $this.data('temp-href', href).removeAttr('href');
        }
    }).on('mouseleave', function() {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href && !$this.attr('href')) {
            $this.attr('href', href);
        }
    }).on('mousedown', function(e) {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href) {
            const scrollTop = $(window).scrollTop();
            $this.attr('href', href);
            $this.tab('show');
            setTimeout(function() {
                $(window).scrollTop(scrollTop);
                $this.removeAttr('href');
            }, 0);
            e.preventDefault();
        }
    });
    $('a[href*="auth.php?logout"]').on('mouseenter', function() {
        const $this = $(this);
        const href = $this.attr('href');
        if (href) {
            $this.data('temp-href', href).removeAttr('href');
        }
    }).on('mouseleave click', function() {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href) {
            $this.attr('href', href);
        }
    });
    loadPurposeTags();
    function performTagAction(action, data, successMessage) {
        $.post('admin.php', {
            action: action,
            ...data
        }, function(response) {
            if (response.success) {
                if (successMessage) {
                    showToast('用途标签', successMessage, 'success');
                }
                location.reload(); 
            } else {
                showToast('用途标签', response.message, 'error');
            }
        }, 'json').fail(function() {
            showToast('用途标签', '操作失败，请重试', 'error');
        });
    }
    $('#addPurposeTagBtn').click(function() {
        const name = $('#purposeTagInput').val().trim();
        if (!name) {
            showToast('用途标签', '请输入标签名称', 'error');
            return;
        }
        performTagAction('add_purpose_tag', { name: name });
        $('#purposeTagInput').val('');
    });
    $('#purposeTagInput').keypress(function(e) {
        if (e.which === 13) {
            $('#addPurposeTagBtn').click();
        }
    });
    $('#purposeTagSearchInput').on('input', function() {
        const keyword = $(this).val().trim().toLowerCase();
        if (keyword === '') {
            renderPurposeTags(allPurposeTags);
        } else {
            const filtered = allPurposeTags.filter(tag => tag.name.toLowerCase().includes(keyword));
            renderPurposeTags(filtered);
        }
    });
    $(document).on('click', '.delete-tag-btn', function() {
        const id = $(this).data('id');
        performTagAction('delete_purpose_tag', { id: id });
    });
    $(document).on('click', '.restore-tag-btn', function() {
        const id = $(this).data('id');
        performTagAction('restore_purpose_tag', { id: id });
    });
    $(document).on('dblclick', '.purpose-tag-item:not(.purpose-tag-hidden) span', function() {
        const $span = $(this);
        const $item = $span.closest('.purpose-tag-item');
        const id = $item.data('id');
        const oldName = $span.text();
        if ($item.find('input').length > 0) {
            return;
        }
        const $input = $('<input type="text" class="form-control form-control-sm" maxlength="30" style="width: auto; min-width: 80px; display: inline-block;">');
        $input.val(oldName);
        $span.hide();
        $span.after($input);
        $input.focus().select();
        const updateCharCount = () => {
            const currentLength = $input.val().length;
            if (currentLength >= 30) {
                $input.css('border-color', '#dc3545'); 
            } else {
                $input.css('border-color', ''); 
            }
        };
        $input.on('input', updateCharCount);
        const saveEdit = () => {
            const newName = $input.val().trim();
            if (!newName) {
                showToast('用途标签', '标签名称不能为空', 'error');
                $input.focus();
                return;
            }
            if (newName === oldName) {
                cancelEdit();
                return;
            }
            $.post('admin.php', {
                action: 'edit_purpose_tag',
                id: id,
                name: newName
            }, function(response) {
                if (response.success) {
                    $span.text(newName);
                    $input.remove();
                    $span.show();
                    showToast('用途标签', response.message, 'success');
                } else {
                    showToast('用途标签', response.message, 'error');
                    $input.focus();
                }
            }, 'json').fail(function() {
                showToast('用途标签', '编辑失败，请重试', 'error');
                $input.focus();
            });
        };
        const cancelEdit = () => {
            $input.remove();
            $span.show();
        };
        $input.keypress(function(e) {
            if (e.which === 13) {
                e.preventDefault();
                saveEdit();
            }
        });
        $input.keydown(function(e) {
            if (e.which === 27) {
                e.preventDefault();
                cancelEdit();
            }
        });
        $input.blur(function() {
            setTimeout(function() {
                if ($input.is(':visible')) {
                    saveEdit();
                }
            }, 200);
        });
    });
});
function loadPurposeTags() {
    $.post('admin.php', {
        action: 'get_purpose_tags'
    }, function(response) {
        if (response.success) {
            allPurposeTags = response.data;
            renderPurposeTags(allPurposeTags);
        }
    }, 'json');
}
function renderPurposeTags(tags) {
    const container = $('#purposeTagsContainer');
    container.empty();
    if (tags.length === 0) {
        container.html('<div class="text-muted">暂无标签</div>');
        return;
    }
    tags.forEach(function(tag) {
        const tagHtml = `
            <div class="purpose-tag-item" data-id="${tag.id}">
                <span>${escapeHtml(tag.name)}</span>
                <button class="delete-tag-btn" data-id="${tag.id}" data-name="${escapeHtml(tag.name)}"><i class="fas fa-times"></i></button>
            </div>
        `;
        container.append(tagHtml);
    });
}
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}
</script>
<div class="modal fade" id="batchRoomModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">批量操作<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-muted">已选择 <span id="selectedRoomCount">0</span> 个<span class="scene-room-name-placeholder"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></span></p>
                <form id="batchRoomForm">
                    <div class="form-group">
                        <label>类型</label>
                        <div class="type-input-wrapper">
                            <input type="text" class="form-control type-input" id="batchRoomType" maxlength="10" placeholder="留空则保持原本设置">
                            <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="type-dropdown-menu"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>标准价</label>
                        <input type="number" class="form-control" id="batchRoomStandardPrice" step="0.01" min="0" max="9999" placeholder="留空则保持原本设置">
                    </div>
                    <div class="form-group">
                        <label>会员折扣</label>
                        <input type="number" class="form-control" id="batchRoomMemberDiscount" step="1" min="1" max="100" placeholder="留空则保持原本设置">
                    </div>
                    <div class="form-group">
                        <label>是否参与会员类型折扣</label>
                        <select class="form-control" id="batchRoomEnableMemberLevelsDiscount">
                            <option value="">不修改</option>
                            <option value="1">启用</option>
                            <option value="0">停用</option>
                        </select>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label>批量操作</label>
                        <div>
                            <button type="button" class="btn btn-success btn-sm mr-2" id="batchEnableRooms">
                                <i class="fas fa-check"></i> 启用
                            </button>
                            <button type="button" class="btn btn-secondary btn-sm mr-2" id="batchDisableRooms">
                                <i class="fas fa-ban"></i> 停用
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" id="batchDeleteRooms">
                                <i class="fas fa-trash"></i> 删除
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" id="batchRoomSubmit">保存修改</button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="batchProductModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">批量操作商品</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="text-muted">已选择 <span id="selectedProductCount">0</span> 个商品</p>
                <form id="batchProductForm">
                    <div class="form-group">
                        <label>类型</label>
                        <div class="type-input-wrapper">
                            <input type="text" class="form-control type-input" id="batchProductType" maxlength="10" placeholder="留空则保持原本设置">
                            <button type="button" class="btn btn-sm btn-outline-secondary type-dropdown-btn" tabindex="-1">
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="type-dropdown-menu"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>单价</label>
                        <input type="number" class="form-control" id="batchProductPrice" step="0.01" min="0" max="9999" placeholder="留空则保持原本设置">
                    </div>
                    <div class="form-group">
                        <label>会员折扣</label>
                        <input type="number" class="form-control" id="batchProductMemberDiscount" step="1" min="1" max="100" placeholder="留空则保持原本设置">
                    </div>
                    <div class="form-group">
                        <label>是否参与会员类型折扣</label>
                        <select class="form-control" id="batchProductEnableMemberLevelsDiscount">
                            <option value="">不修改</option>
                            <option value="1">启用</option>
                            <option value="0">停用</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>是否允许0库存销售</label>
                        <select class="form-control" id="batchProductAllowZeroStock">
                            <option value="">不修改</option>
                            <option value="1">启用</option>
                            <option value="0">停用</option>
                        </select>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label>批量操作</label>
                        <div>
                            <button type="button" class="btn btn-success btn-sm mr-2" id="batchEnableProducts">
                                <i class="fas fa-check"></i> 启用
                            </button>
                            <button type="button" class="btn btn-secondary btn-sm mr-2" id="batchDisableProducts">
                                <i class="fas fa-ban"></i> 停用
                            </button>
                            <button type="button" class="btn btn-danger btn-sm" id="batchDeleteProducts">
                                <i class="fas fa-trash"></i> 删除
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" id="batchProductSubmit">保存修改</button>
            </div>
        </div>
    </div>
</div>
</body>
</html>
