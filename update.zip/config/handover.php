<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
require_once 'auth.php';
requirePageAccess('admin', SESSION_TIMEOUT_ADMIN, '交班管理');
$config_path = __DIR__ . '/config.php';
if (file_exists($config_path)) {
    include($config_path);
} else {
    http_response_code(500);
    echo json_encode(['error' => '配置文件不存在']);
    exit;
}
$SCENE_ROOM_NAME = '房间'; 
$scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'");
if ($scene_stmt) {
    $scene_stmt->execute();
    $scene_result = $scene_stmt->get_result();
    if ($scene_result && $scene_row = $scene_result->fetch_assoc()) {
        $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间';
    }
    $scene_stmt->close();
}
if (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest' && isset($_GET['keys'])) {
    header('Content-Type: application/json; charset=utf-8');
    $keys = explode(',', $_GET['keys']);
    $response = ['success' => true, 'data' => []];
    $validKeys = array_filter($keys, function($key) {
        $key = trim($key);
        return !empty($key) && preg_match('/^[a-zA-Z0-9_]+$/', $key);
    });
    if (!empty($validKeys)) {
        $placeholders = implode(',', array_fill(0, count($validKeys), '?'));
        $stmt = $conn->prepare("SELECT config_key, config_value FROM system_config WHERE config_key IN ($placeholders)");
        if ($stmt) {
            $types = str_repeat('s', count($validKeys));
            $stmt->bind_param($types, ...array_values($validKeys));
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $response['data'][$row['config_key']] = $row['config_value'];
                }
            }
            $stmt->close();
        }
    }
    echo json_encode($response);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>交班管理</title>
    <link rel="stylesheet" href="/asset/lib/css/bootstrap.min.css">
    <link rel="stylesheet" href="/asset/lib/css/all.min.css">
    <style>
        .modal-dialog-centered {
            display: flex !important;
            align-items: center !important;
            min-height: calc(100% - 3.5rem) !important;
        }
        @media (min-width: 576px) {
            .modal-dialog-centered {
                min-height: calc(100% - 3.5rem) !important;
                margin-top: 1.75rem !important;
                margin-bottom: 1.75rem !important;
            }
        }
        body {
            padding-top: 0;
            margin-top: 0;
        }
        .nav-tabs .nav-link,
        .nav-tabs .nav-link:hover,
        .nav-tabs .nav-link:focus,
        .nav-tabs .nav-link:active {
            cursor: pointer !important;
        }
        body > .container {
            background-color: #fff;
            border-radius: 10px;
            padding: 15px;
            margin-top: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            max-width: 98% !important;
            width: 98% !important;
        }
        @media (min-width: 576px) {
            body > .container {
                max-width: 75% !important;
                width: 75% !important;
            }
        }
        .handover-container {
            max-width: 1400px;
            margin: 0 auto;
            padding-top: 15px;
        }
        @media (max-width: 768px) {
            .handover-container {
                padding-top: 10px;
            }
        }
        .form-row-custom {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .form-group-custom {
            flex: 1;
            margin-bottom: 0;
            min-width: 200px;
        }
        .form-group-custom label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #495057;
        }
        .operator-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .operator-wrapper select {
            flex: 1;
        }
        .operator-wrapper .custom-checkbox {
            white-space: nowrap;
            padding-top: 8px;
        }
        .btn-query {
            min-width: 100px;
        }
        .btn-query:focus,
        .btn-query:active:focus,
        .btn-query.active:focus {
            outline: none !important;
            box-shadow: none !important;
        }
        @media (max-width: 768px) {
            .form-row-custom {
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
            }
            .form-group-custom {
                width: 100% !important;
                flex: none !important;
                margin-bottom: 0;
            }
            .btn-query {
                width: 100%;
                margin-top: 5px;
            }
            .table-responsive {
                font-size: 0.875rem;
            }
            .table thead th,
            .table tbody td,
            .table tfoot td {
                padding: 0.5rem;
            }
            .actual-qty-input,
            .actual-amount-input {
                width: 100% !important;
                max-width: none;
            }
            .total-card {
                padding: 1rem;
            }
            .total-card .table {
                font-size: 0.875rem;
            }
        }
        .module-card {
            border-left: 4px solid #007bff;
            margin-bottom: 20px;
        }
        .module-card.room { border-left-color: #28a745; }
        .module-card.product { border-left-color: #ffc107; }
        .module-card.member { border-left-color: #17a2b8; }
        .module-title {
            font-size: 1.1rem;
            font-weight: 600;
            padding: 10px 15px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        .table-responsive {
            border-radius: 0.25rem;
        }
        .table-bordered {
            border: 1px solid #dee2e6;
        }
        .table thead th {
            background-color: #f8f9fa;
            border-bottom: 2px solid #dee2e6;
            font-weight: 600;
            color: #495057;
            padding: 0.75rem;
            font-size: 0.875rem;
        }
        .table tbody td {
            padding: 0.75rem;
            vertical-align: middle;
        }
        .table tbody tr:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        .table tfoot {
            background-color: #f8f9fa;
        }
        .table tfoot td {
            font-weight: 600;
            padding: 0.75rem;
            border-top: 2px solid #dee2e6;
        }
        .actual-qty-input,
        .actual-amount-input {
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            padding: 0.375rem 0.5rem;
            width: 120px;
            display: inline-block;
        }
        .actual-qty-input:focus,
        .actual-amount-input:focus {
            border-color: #80bdff;
            outline: none;
        }
        .diff-cell {
            font-weight: 500;
        }
        .total-card {
            border: 1px solid #dee2e6;
            border-radius: 0.25rem;
            padding: 1.25rem;
            margin-top: 1.5rem;
        }
        .total-card h6 {
            margin-bottom: 1rem;
            font-size: 1rem;
            font-weight: 600;
        }
        .total-card .table {
            margin-bottom: 0;
        }
        .total-card .table thead th {
            background-color: #f8f9fa;
            font-weight: 600;
            font-size: 0.875rem;
            border-bottom: 2px solid #dee2e6;
        }
        .total-card .table td {
            font-size: 1rem;
            font-weight: 500;
        }
        .total-card .table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .btn-primary {
            background-color: #3498db;
            border-color: #3498db;
        }
        .btn-primary:hover {
            background-color: #2980b9;
            border-color: #2980b9;
        }
        .btn-success {
            background-color: #27ae60;
            border-color: #27ae60;
        }
        .btn-success:hover {
            background-color: #229a52;
            border-color: #229a52;
        }
        .btn-outline-danger {
            border-color: #e74c3c;
            color: #e74c3c;
            background: transparent;
            border-radius: 0.25rem !important;
            padding: 4px 14px !important;
            cursor: pointer !important;
            font-size: 14px !important;
            line-height: 1.2 !important;
            height: 30px !important;
            min-width: 60px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
        }
        .btn-outline-danger:hover {
            background-color: #e74c3c;
            border-color: #e74c3c;
            color: white;
        }
        a[href*="auth.php?logout"] {
            cursor: pointer !important;
        }
        .d-flex.justify-content-between.align-items-center {
            border-bottom: 2px solid #007bff;
            padding-bottom: 8px;
        }
        .d-flex.justify-content-between.align-items-center h2 {
            font-size: 1.5rem;
            font-weight: 500;
            margin: 0;
            line-height: 1.2;
        }
    </style>
    <script>
        window.SYSTEM_CONFIG = {
          serverTime: <?php echo time() * 1000; ?>, 
          clientTime: Date.now(),
          sceneRoomName: '<?php echo addslashes($SCENE_ROOM_NAME); ?>' 
        };
        window.SERVER_TIME = window.SYSTEM_CONFIG.serverTime; 
    </script>
    <script src="/asset/lib/js/jquery.min.js"></script>
    <script src="/asset/lib/js/bootstrap.min.js"></script>
    <script src="/asset/core.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/core.js') ?>"></script>
</head>
<body>
<div class="container mt-3">
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><a href="handover.php" style="color: inherit; text-decoration: none;">交班管理</a></h2>
    <div>
        <?php
        $logoutUsername = $_SESSION['admin_username'] ?? '';
        $logoutName = $_SESSION['admin_name'] ?? '';
        $logoutRole = $_SESSION['admin_role'] ?? '';
        $roleText = $logoutRole === 'admin' ? '管理员' : '前台';
        $logoutTitle = "用户名：{$logoutUsername}\n姓名：{$logoutName}\n权限：{$roleText}";
        ?>
        <a href="auth.php?logout=admin&close=1&source=handover" class="btn btn-outline-danger mr-2" title="<?php echo htmlspecialchars($logoutTitle); ?>">
            <i class="fas fa-sign-out-alt mr-1"></i>退出
        </a>
    </div>
</div>
    <ul class="nav nav-tabs mb-2" id="handoverTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="current-tab" data-toggle="tab" href="#currentShift" role="tab">
                        <i class="fas fa-user-clock"></i> 当前交班
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="history-tab" data-toggle="tab" href="#historyRecords" role="tab">
                        <i class="fas fa-history"></i> 历史记录
                    </a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="currentShift" role="tabpanel">
                    <div class="form-row-custom">
                        <div class="form-group-custom" style="flex: 0 0 280px;">
                            <label>选择操作员</label>
                            <select class="form-control" id="handoverOperatorSelect">
                                <option value="">请选择操作员</option>
                            </select>
                        </div>
                        <div class="form-group-custom">
                            <label>查询时间区间</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryStartTime" class="form-control" step="1">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="datetime-local" id="queryEndTime" class="form-control" step="1">
                            </div>
                        </div>
                        <div class="form-group-custom" style="flex: 0 0 100px;">
                            <button class="btn btn-primary btn-block btn-query" id="queryHandoverBtn">
                                <i class="fas fa-search"></i> 查询
                            </button>
                        </div>
                    </div>
                    <div id="handoverDataArea">
                        <div class="text-center py-5 text-muted">
                            <i class="fas fa-clipboard-list fa-3x mb-3"></i>
                            <p>请选择操作员并点击查询</p>
                        </div>
                    </div>
                    <div class="text-center mt-4" id="completeHandoverArea" style="display:none;">
                        <div class="form-group">
                            <label class="font-weight-bold">交班备注</label>
                            <textarea class="form-control" id="handoverNotes" rows="2" maxlength="200" placeholder="请输入交班备注（选填，最多200字）"></textarea>
                        </div>
                        <button class="btn btn-success" id="completeHandoverBtn">
                            <i class="fas fa-check"></i> 完成交班
                        </button>
                    </div>
                </div>
                <div class="tab-pane fade" id="historyRecords" role="tabpanel">
                    <div class="form-row-custom">
                        <div class="form-group-custom" style="flex: 0 0 280px;">
                            <label>选择操作员</label>
                            <select class="form-control" id="historyOperatorSelect">
                                <option value="">全部</option>
                            </select>
                        </div>
                        <div class="form-group-custom">
                            <label>查询日期区间</label>
                            <div class="input-group">
                                <input type="date" class="form-control" id="historyStartDate">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="date" class="form-control" id="historyEndDate">
                            </div>
                        </div>
                        <div class="form-group-custom" style="flex: 0 0 100px;">
                            <button class="btn btn-primary btn-block btn-query" id="searchHistoryBtn">
                                <i class="fas fa-search"></i> 查询
                            </button>
                        </div>
                    </div>
                    <div id="historyListArea">
                        <div class="text-center py-5 text-muted">
                            <i class="fas fa-clipboard-list fa-3x mb-3"></i>
                            <p>请点击查询按钮加载历史记录</p>
                        </div>
                    </div>
                    <div id="historyPagination" class="mt-3" style="display:none;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="/asset/handover.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/handover.js') ?>"></script>
<script>
$(function() {
    setTimeout(function() {
        $('.nav-tabs .nav-link[data-toggle="tab"]').on('mouseenter', function() {
            const $this = $(this);
            const href = $this.attr('href');
            if (href) {
                $this.data('temp-href', href).removeAttr('href');
            }
        }).on('mouseleave', function() {
            const $this = $(this);
            const href = $this.data('temp-href');
            if (href && !$this.attr('href')) {
                $this.attr('href', href);
            }
        }).on('mousedown', function(e) {
            const $this = $(this);
            const href = $this.data('temp-href');
            if (href) {
                $this.attr('href', href);
                $this.tab('show');
                setTimeout(function() {
                    $this.removeAttr('href');
                }, 0);
                e.preventDefault();
            }
        });
    }, 200); 
});
</script>
</body>
</html>
