<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
$config_path = __DIR__ . '/config.php';
if (file_exists($config_path)) {
    include($config_path);
} else {
    http_response_code(500);
    echo json_encode(['error' => '配置文件不存在']);
    exit;
}
$SCENE_ROOM_NAME = '房间'; 
$scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'");
if ($scene_stmt) {
    $scene_stmt->execute();
    $scene_result = $scene_stmt->get_result();
    if ($scene_result && $scene_row = $scene_result->fetch_assoc()) {
        $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间';
    }
    $scene_stmt->close();
}
$GUEST_COUNT_ENABLED = '0'; 
$gc_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'guest_count_enabled'");
if ($gc_stmt) {
    $gc_stmt->execute();
    $gc_result = $gc_stmt->get_result();
    if ($gc_result && $gc_row = $gc_result->fetch_assoc()) {
        $GUEST_COUNT_ENABLED = $gc_row['config_value'] ?: '0';
    }
    $gc_stmt->close();
}
require_once 'auth.php';
requirePageAccess('admin', SESSION_TIMEOUT_ADMIN, '报表查询');
if (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest') {
    header('Content-Type: application/json; charset=utf-8');
    match ($_SERVER['REQUEST_METHOD']) {
        'GET' => handleGetRequest(),
        default => handleDefaultRequest()
    };
    exit;
}
function handleGetRequest(): void {
    global $conn;
    if (!isset($_GET['keys'])) {
        echo json_encode(['success' => false, 'message' => '缺少必要参数']);
        return;
    }
    $keys = explode(',', $_GET['keys']);
    $response = ['success' => true, 'data' => []];
    $validKeys = array_filter($keys, function($key) {
        $key = trim($key);
        return !empty($key) && preg_match('/^[a-zA-Z0-9_]+$/', $key);
    });
    if (!empty($validKeys)) {
        $placeholders = implode(',', array_fill(0, count($validKeys), '?'));
        $stmt = $conn->prepare("SELECT config_key, config_value FROM system_config WHERE config_key IN ($placeholders)");
        if ($stmt) {
            $types = str_repeat('s', count($validKeys));
            $stmt->bind_param($types, ...array_values($validKeys));
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $response['data'][$row['config_key']] = $row['config_value'];
                }
            }
            $stmt->close();
        }
    }
    echo json_encode($response);
}
function handleDefaultRequest(): void {
    echo json_encode(['success' => false, 'message' => '无效的请求']);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>报表查询系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/asset/lib/css/bootstrap.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="/asset/lib/css/all.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/all.min.css') ?>" rel="stylesheet">
    <link rel="stylesheet" href="/asset/main.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/main.css') ?>">
    <script>
        window.SYSTEM_CONFIG = {
          serverTime: '<?php echo date('c'); ?>',
          clientTime: Date.now(),
          sceneRoomName: '<?php echo addslashes($SCENE_ROOM_NAME); ?>', 
          guest_count_enabled: '<?php echo addslashes($GUEST_COUNT_ENABLED); ?>' 
        };
        window.SERVER_TIME = new Date(window.SYSTEM_CONFIG.serverTime).getTime(); 
    </script>
    <script src="/asset/core.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/core.js') ?>"></script>
    <style>
html {
    font-size: 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}
body {
    background: #f5f7fa;
    padding-top: 0;
    margin-top: 0;
    overflow-x: auto;
}
body > .container {
    background-color: #fff;
    border-radius: 10px;
    padding: 15px;
    margin-top: 15px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    max-width: 98% !important;
    width: 98% !important;
}
.d-flex.justify-content-between.align-items-center {
    border-bottom: 2px solid #007bff;
    padding-bottom: 4px;
}
.d-flex.justify-content-between.align-items-center h2 {
    font-size: 1.5rem;
    font-weight: 500;
    margin: 0;
    line-height: 1.2;
}
.d-flex.justify-content-between.align-items-center h2 a {
    color: inherit;
    text-decoration: none;
}
.btn-outline-danger {
    border-radius: 0.25rem !important;
    padding: 4px 14px !important;
    cursor: pointer !important;
}
    font-size: 14px !important;
    line-height: 1.2 !important;
    height: 30px !important;
    min-width: 60px !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
}
.nav-tabs .nav-link {
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
}
.nav-tabs .nav-link,
.nav-tabs .nav-link:hover,
.nav-tabs .nav-link:focus,
.nav-tabs .nav-link:active {
    cursor: pointer !important;
}
a[href*="auth.php?logout"] {
    cursor: pointer !important;
}
.report-label-prefix {
    color: #007bff;
}
.tab-content {
    display: block !important;
}
.tab-pane {
    display: none;
}
.tab-pane.active {
    display: block !important;
}
.order-details {
    background-color: #f8f9fa;
    padding: 10px;
    margin-top: 5px;
}
.toggle-detail {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-left: auto;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.toggle-detail:hover {
    background-color: #f8f9fa;
    border-color: #007bff;
}
.toggle-detail i {
    font-size: 14px;
    transition: transform 0.2s;
}
.order-detail-row,
.product-order-detail-row {
    display: none;
    background-color: #f8f9fa;
}
.order-detail-content {
    padding: 15px;
}
.order-detail-content .table th,
.order-detail-content .table td {
    white-space: nowrap;
}
.order-detail-content .col-md-6 {
    overflow-x: auto;
}
.order-query-header {
    margin-top: 0;
    margin-bottom: 20px;
    padding: 15px;
    background-color: #f8f9fa;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}
.stats-summary {
    margin: 15px 0;
    padding: 15px;
    border-radius: 8px;
    background-color: #f9f9f9;
}
.stats-box {
    padding: 15px;
    border-radius: 6px;
    margin-bottom: 10px;
    background-color: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.stats-value {
    font-size: 18px;
    font-weight: bold;
    color: #007bff;
    display: inline-block;
    vertical-align: middle;
}
.overview-card {
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.overview-card-header {
    padding: 15px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    font-weight: bold;
    font-size: 16px;
    color: #495057;
}
.overview-card-body {
    padding: 15px;
}
.overview-icon {
    font-size: 32px;
    color: #17a2b8;
    margin-bottom: 10px;
}
.overview-title {
    font-size: 14px;
    color: #6c757d;
}
.overview-value {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 0;
    color: #007bff;
}
.overview-trend {
    font-size: 12px;
    margin-top: 5px;
}
.overview-trend-up {
    color: #28a745;
}
.overview-trend-down {
    color: #dc3545;
}
.overview-period-selector {
    margin-bottom: 20px;
}
.overview-info-icon {
    font-size: 16px;
    margin-left: 6px;
    vertical-align: middle;
    color: #007bff !important;
}
.records-container {
    overflow-x: auto;
    max-width: 100%;
    padding-bottom: 60px;
}
.records-container,
.tab-pane.fade,
.tab-pane.fade.active.show,
.tab-content {
    overflow: visible !important;
}
.table {
    margin-bottom: 0;
}
.table thead th {
    position: sticky;
    top: 0;
    background-color: #f8f9fa;
    z-index: 1;
}
.table th,
.table td {
    white-space: nowrap;
}
.bg-light-yellow {
    background-color: #fffaf0 !important;
    border: 1px solid white !important;
}
.table-hover .order-row.bg-light-yellow:hover {
    background-color: #ffeeb0 !important;
}
.table-hover .payment-detail-row:hover {
    background-color: #f5f5f5 !important;
}
.table-hover tbody tr:hover {
    background-color: #ffeeb0 !important;
}
.datetime-display {
    display: inline-block;
    line-height: 1.2;
    white-space: nowrap;
}
.datetime-display .date {
    display: inline;
    font-weight: 500;
}
.datetime-display .time {
    display: inline;
    color: #666;
    font-size: 0.9em;
    margin-left: 5px;
}
.badge-status-0 {
    background-color: #17a2b8;
}
.badge-status-1 {
    background-color: #28a745;
}
#orderTable thead th,
#productOrderTable thead th,
#reserveRecordTable thead th,
#rechargeOrderTable thead th,
#consumptionOrderTable thead th,
#memberDetailTable thead th,
#timecardOrderTable thead th,
#timecardUsageTable thead th,
#timecardHoldingTable thead th {
    position: sticky;
    top: 0;
    background: #f5f7fa;
    color: #222;
    font-weight: bold;
    border-bottom: 2px solid #007bff;
    box-shadow: 0 2px 4px rgba(0,0,0,0.04);
    letter-spacing: 0.5px;
    font-size: 1.05em;
    z-index: 3;
}
#orderTable,
#productOrderTable,
#reserveRecordTable,
#rechargeOrderTable,
#consumptionOrderTable,
#memberDetailTable,
#timecardOrderTable,
#timecardUsageTable,
#timecardHoldingTable {
    border-collapse: separate;
    border-spacing: 0;
}
#orderTable th, #orderTable td,
#productOrderTable th, #productOrderTable td,
#reserveRecordTable th, #reserveRecordTable td,
#rechargeOrderTable th, #rechargeOrderTable td,
#consumptionOrderTable th, #consumptionOrderTable td,
#memberDetailTable th, #memberDetailTable td,
#timecardOrderTable th, #timecardOrderTable td,
#timecardUsageTable th, #timecardUsageTable td,
#timecardHoldingTable th, #timecardHoldingTable td {
    border: 1px solid rgba(189,189,189,0.4);
    border-width: 1px 0 0 1px;
}
#orderTable th,
#productOrderTable th,
#reserveRecordTable th,
#rechargeOrderTable th,
#consumptionOrderTable th,
#memberDetailTable th,
#timecardOrderTable th,
#timecardUsageTable th,
#timecardHoldingTable th {
    border: none;
}
#orderTable td,
#productOrderTable td,
#reserveRecordTable td,
#rechargeOrderTable td,
#consumptionOrderTable td,
#memberDetailTable td,
#timecardOrderTable td,
#timecardUsageTable td,
#timecardHoldingTable td {
    border: 1px solid rgba(189,189,189,0.4);
    border-width: 0.5px 0 0 0.5px;
}
.col-wrap-text {
    min-width: 150px;
    max-width: 300px;
    white-space: normal !important;
    word-wrap: break-word;
    word-break: break-word;
    overflow-wrap: break-word;
    line-height: 1.4;
}
@media (max-width: 991.98px) {
    .overview-card {
        margin-bottom: 15px;
    }
    .row-eq-height {
        display: flex;
        flex-wrap: wrap;
    }
    .col-md-3 .overview-card,
    .col-md-4 .overview-card {
        height: 100%;
    }
    .overview-icon {
        font-size: 24px;
        margin-bottom: 5px;
    }
    .overview-title {
        font-size: 12px;
    }
    .overview-value {
        font-size: 16px;
    }
    .overview-card-header {
        padding: 10px 15px;
        font-size: 14px;
    }
    .overview-card-body {
        padding: 10px;
    }
    .stats-summary .row .col-md-3 {
        flex: 0 0 50%;
        max-width: 50%;
    }
}
@media (max-width: 767.98px) {
    .order-query-header .btn-group {
        display: flex;
        flex-wrap: wrap;
        margin-bottom: 10px;
    }
    .order-query-header .btn-group .btn {
        flex: 1 0 auto;
        margin-bottom: 5px;
    }
    .overview-stat-col {
        flex: 0 0 50%;
        max-width: 50%;
        margin-bottom: 10px;
    }
    .stats-value {
        font-size: 16px;
    }
}
@media (max-width: 600px) {
    .nav-tabs .nav-link span {
        display: none !important;
    }
    .nav-tabs .nav-link i {
        margin-right: 0 !important;
        font-size: 1.1rem;
    }
    .nav-tabs .nav-link {
        padding: 0.5rem 0.4rem !important;
        text-align: center !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
    }
    .nav-tabs .nav-item {
        flex: 1 1 auto;
    }
    .nav-tabs {
        display: flex;
        flex-wrap: nowrap;
    }
}
@media (min-width: 601px) {
    .nav-tabs .nav-link span {
        display: inline !important;
    }
    .nav-tabs .nav-link i {
        margin-right: 6px !important;
        font-size: 1.2rem;
    }
}
    </style>
</head>
<body>
<div class="container mt-3">
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2><a href="sys_query.php" style="color: inherit; text-decoration: none;">报表查询系统</a></h2>
    <div>
        <?php
        $logoutUsername = $_SESSION['admin_username'] ?? '';
        $logoutName = $_SESSION['admin_name'] ?? '';
        $logoutRole = $_SESSION['admin_role'] ?? '';
        $roleText = $logoutRole === 'admin' ? '管理员' : '前台';
        $logoutTitle = "用户名：{$logoutUsername}\n姓名：{$logoutName}\n权限：{$roleText}";
        ?>
        <a href="auth.php?logout=admin&close=1&source=sys_query" class="btn btn-outline-danger mr-2" title="<?php echo htmlspecialchars($logoutTitle); ?>">
            <i class="fas fa-sign-out-alt mr-1"></i>退出
        </a>
    </div>
</div>
    <ul class="nav nav-tabs mb-2" id="orderTabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="overview-tab" data-toggle="tab" href="#overview" role="tab">
                <i class="fas fa-chart-pie mr-1"></i><span>概览</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="room-tab" data-toggle="tab" href="#room-orders" role="tab">
                <i class="fas fa-home mr-1"></i><span><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>订单</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="reserve-tab" data-toggle="tab" href="#reserve-records" role="tab">
                <i class="fas fa-calendar-alt mr-1"></i><span>预定记录</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="product-tab" data-toggle="tab" href="#product-orders" role="tab">
                <i class="fas fa-shopping-cart mr-1"></i><span>商品订单</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="timecard-order-tab" data-toggle="tab" href="#timecard-orders" role="tab">
                <i class="fas fa-ticket-alt mr-1"></i><span>次卡券订单</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="timecard-usage-tab" data-toggle="tab" href="#timecard-usage" role="tab">
                <i class="fas fa-history mr-1"></i><span>次卡券使用</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="timecard-holding-tab" data-toggle="tab" href="#timecard-holdings" role="tab">
                <i class="fas fa-wallet mr-1"></i><span>次卡券持有</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="recharge-tab" data-toggle="tab" href="#recharge-orders" role="tab">
                <i class="fas fa-credit-card mr-1"></i><span>会员充值订单</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="consumption-tab" data-toggle="tab" href="#consumption-orders" role="tab">
                <i class="fas fa-receipt mr-1"></i><span>会员消费订单</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="member-tab" data-toggle="tab" href="#member-details" role="tab">
                <i class="fas fa-user-friends mr-1"></i><span>会员明细表</span>
            </a>
        </li>
    </ul>
    <div class="tab-content" id="orderTabContent">
        <div class="tab-pane fade show active" id="overview" role="tabpanel">
            <div class="order-query-header">
                <form id="overviewQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-11 col-sm-10 mb-2">
                            <label class="font-weight-bold">统计日期范围<span style="font-size:13px;">（支付日期）</span></label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryOverviewStartDate" class="form-control" step="1">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="datetime-local" id="queryOverviewEndDate" class="form-control" step="1">
                            </div>
                                </div>
                        <div class="col-md-1 col-sm-2 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group overview-period-selector">
                        <button type="button" class="btn btn-sm btn-outline-primary query-overview-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary query-overview-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary query-overview-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary query-overview-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary query-overview-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary query-overview-date-btn" data-days="9999">所有记录</button>
                    </div>
                </form>
            </div>
            <div class="row row-eq-height mb-4">
                <div class="col-md-3 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-calculator mr-2"></i>净收入<i class="fas fa-info-circle text-info overview-info-icon" style="cursor: pointer;" data-info="净收入计算公式：<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>收入 + 商品收入 + 次卡券收入 + 会员充值 - 赠送金额 - 会员消费"></i>
                        </div>
                        <div class="overview-card-body">
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-file-invoice"></i>
                                    </div>
                                    <div class="overview-title">总订单数</div>
                                    <h4 class="overview-value overview-total-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">总收入</div>
                                    <h4 class="overview-value overview-total-income">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-home mr-2"></i><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>订单
                        </div>
                        <div class="overview-card-body">
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-file-invoice"></i>
                                    </div>
                                    <div class="overview-title">订单数</div>
                                    <h4 class="overview-value overview-room-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">收入</div>
                                    <h4 class="overview-value overview-room-income">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-shopping-cart mr-2"></i>商品订单
                        </div>
                        <div class="overview-card-body">
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-file-invoice"></i>
                                    </div>
                                    <div class="overview-title">订单总数</div>
                                    <h4 class="overview-value overview-product-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">收入</div>
                                    <h4 class="overview-value overview-product-income">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-ticket-alt mr-2"></i>次卡券订单
                        </div>
                        <div class="overview-card-body">
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-file-invoice"></i>
                                    </div>
                                    <div class="overview-title">总订单</div>
                                    <h4 class="overview-value overview-timecard-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">总收入</div>
                                    <h4 class="overview-value overview-timecard-income">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row row-eq-height mb-4">
                <div class="col-md-4 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-credit-card mr-2"></i>会员充值
                        </div>
                        <div class="overview-card-body">
                            <div class="row mb-3">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-wallet"></i>
                                    </div>
                                    <div class="overview-title">充值笔数</div>
                                    <h4 class="overview-value overview-recharge-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">总充值金额</div>
                                    <h4 class="overview-value overview-total-recharge-amount">¥0.00</h4>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-money-bill-alt"></i>
                                    </div>
                                    <div class="overview-title">充值金额</div>
                                    <h4 class="overview-value overview-recharge-amount">¥0.00</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-gift"></i>
                                    </div>
                                    <div class="overview-title">赠送金额</div>
                                    <h4 class="overview-value overview-gift-amount">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-receipt mr-2"></i>会员消费
                        </div>
                        <div class="overview-card-body">
                            <div class="row mb-3">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-file-invoice-dollar"></i>
                                    </div>
                                    <div class="overview-title">消费笔数</div>
                                    <h4 class="overview-value overview-consumption-orders">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-yen-sign"></i>
                                    </div>
                                    <div class="overview-title">总消费金额</div>
                                    <h4 class="overview-value overview-consumption-amount">¥0.00</h4>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-home"></i>
                                    </div>
                                    <div class="overview-title"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>消费</div>
                                    <h4 class="overview-value overview-room-consumption">¥0.00</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-shopping-cart"></i>
                                    </div>
                                    <div class="overview-title">商品/次卡券消费</div>
                                    <h4 class="overview-value overview-product-consumption">¥0.00</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 mb-3 mb-md-0">
                    <div class="overview-card">
                        <div class="overview-card-header">
                            <i class="fas fa-user-friends mr-2"></i>会员概况
                        </div>
                        <div class="overview-card-body">
                            <div class="row mb-3">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                    <div class="overview-title">总会员数</div>
                                    <h4 class="overview-value overview-total-members">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-wallet"></i>
                                    </div>
                                    <div class="overview-title">会员总余额</div>
                                    <h4 class="overview-value overview-total-balance">¥0.00</h4>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-user-plus"></i>
                                    </div>
                                    <div class="overview-title">新开卡数</div>
                                    <h4 class="overview-value overview-new-members">0</h4>
                                </div>
                                <div class="col-6 text-center overview-stat-col">
                                    <div class="overview-icon">
                                        <i class="fas fa-user-check"></i>
                                    </div>
                                    <div class="overview-title">活跃会员数</div>
                                    <h4 class="overview-value overview-active-members">0</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="room-orders" role="tabpanel">
    <div class="order-query-header">
        <form id="orderQueryForm" class="mb-3">
            <div class="form-row">
                <div class="col-md-3 mb-2">
                    <label for="queryOrderInput" class="font-weight-bold"><span class="report-label-prefix">（<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>订单）</span>订单号/<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名</label>
                    <input type="text" class="form-control" id="queryOrderInput" 
                        placeholder="请输入订单号或<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名称">
                </div>
                <div class="col-md-6 mb-2">
                    <label class="font-weight-bold">日期范围</label>
                    <div class="input-group">
                        <input type="datetime-local" id="queryStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryEndDate" class="form-control" step="1">
                    </div>
                </div>
                <div class="col-md-2 mb-2">
                    <label class="font-weight-bold">查询类型</label>
                    <select class="form-control" id="queryTypeSelect">
                        <option value="payment" selected>按支付日期</option>
                        <option value="order">按订单日期</option>
                    </select>
                </div>
                <div class="col-md-1 mb-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            <div class="btn-group">
                <button type="button" class="btn btn-outline-primary query-date-btn" data-days="1">今天</button>
                <button type="button" class="btn btn-outline-secondary query-date-btn" data-days="7">近7天</button>
                <button type="button" class="btn btn-outline-secondary query-date-btn" data-days="30">近30天</button>
                <button type="button" class="btn btn-outline-secondary query-date-btn" data-days="90">近90天</button>
                <button type="button" class="btn btn-outline-secondary query-date-btn" data-days="365">近一年</button>
                <button type="button" class="btn btn-outline-secondary query-date-btn" data-days="9999">所有记录</button>
            </div>
            <div class="btn-group ml-3" role="group">
                <button type="button" class="btn btn-outline-primary active filter-status-btn" data-status="all">全部订单</button>
                <button type="button" class="btn btn-outline-secondary filter-status-btn" data-status="0">进行中</button>
                <button type="button" class="btn btn-outline-secondary filter-status-btn" data-status="1">已结账</button>
            </div>
            <button type="button" class="btn btn-outline-info ml-3" id="purposeAnalysisBtn">
                用途分析
            </button>
            <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="orderTable">
                <i class="fas fa-file-excel"></i> 导出Excel
            </button>
        </form>
    </div>
    <div class="stats-summary mb-4">
        <div class="row">
            <div class="col-md-3">
                <div class="stats-box">
                    <h6 class="text-muted">订单总数</h6>
                    <div class="stats-value total-orders" style="color: #dc3545;">0</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h6 class="text-muted">总收入</h6>
                    <div class="stats-value total-income" style="color: #dc3545;">¥0.00</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h6 class="text-muted">会员卡收入</h6>
                    <div class="stats-value card-income">¥0.00</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-box">
                    <h6 class="text-muted">
                        <span class="other-payment-link view-payment-details-btn" style="cursor:pointer;color:#007bff;font-weight:bold;" data-type="<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>订单_other">其他支付收入&gt;&gt;</span>
                    </h6>
                    <div style="display:flex;align-items:center;gap:8px;justify-content:center;">
                        <span class="stats-value cash-income">¥0.00</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="records-container">
    <div class="mb-2">
                    <span class="text-success">绿色金额(+¥)</span>代表正常收入，<span class="text-danger">红色金额(-¥)</span>代表收入退款，挂单金额仅作为参考，不参与实际营收计算</span>
                </div>
        <table class="table table-striped table-hover<?php echo $GUEST_COUNT_ENABLED === '1' ? '' : ' hide-guest-count'; ?>" id="orderTable">
            <thead class="thead-light">
                <tr>
                    <th>序号</th>
                    <th>订单号</th>
                    <th><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></th>
                    <th>开始时间</th>
                    <th>结束时间</th>
                    <th>实际时长</th>
                    <th>支付方式</th>
                    <th>支付时间</th>
                    <th>套餐</th>
                    <th>次卡券</th>
                    <th>时长</th>
                    <th>会员信息</th>
                    <th>挂单金额</th>
                                    <th>总金额</th>
                                    <th class="guest-count-col">人次</th>
                                    <th>备注</th>
                    <th>用途</th>
                    <th>操作员</th>
                    <th>状态</th>
                    <th width="5%">
                        <button type="button" class="btn btn-sm btn-outline-info expand-all-btn" data-target="order">
                            展开
                        </button>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="<?php echo $GUEST_COUNT_ENABLED === '1' ? 20 : 19; ?>" class="text-center py-3 text-muted">未找到匹配的订单记录</td>
                </tr>
            </tbody>
        </table>
        <div id="orderPaginationContainer" class="mt-3"></div>
    </div>
</div>
        <div class="tab-pane fade" id="product-orders" role="tabpanel">
            <div class="order-query-header">
                <form id="productOrderQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryProductOrderInput" class="font-weight-bold"><span class="report-label-prefix">（商品订单）</span>订单号/商品名/批次号</label>
                            <input type="text" class="form-control" id="queryProductOrderInput" 
                                placeholder="请输入订单号、商品名或批次号">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryProductStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryProductEndDate" class="form-control" step="1">
                            </div>
                                </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-product-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-product-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-product-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-product-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-product-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-product-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-product-status-btn" data-status="all">全部订单</button>
                        <button type="button" class="btn btn-outline-secondary filter-product-status-btn" data-status="0">未退款</button>
                        <button type="button" class="btn btn-outline-secondary filter-product-status-btn" data-status="1">已退款</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="productOrderTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">订单总数</h6>
                            <div class="stats-value total-product-orders" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">总收入</h6>
                            <div class="stats-value total-product-income" style="color: #dc3545;">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">会员卡收入</h6>
                            <div class="stats-value card-product-income" style="color: #007bff;">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">
                                <span class="other-payment-link view-product-payment-details-btn" style="cursor:pointer;color:#007bff;font-weight:bold;" data-type="商品销售_other">其他支付收入&gt;&gt;</span>
                            </h6>
                            <div style="display:flex;align-items:center;gap:8px;justify-content:center;">
                                <span class="stats-value cash-product-income">¥0.00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <table class="table table-striped table-hover" id="productOrderTable">
                    <thead class="thead-light">
                        <tr>
                    <th>序号</th>
                            <th>订单号</th>
                            <th>批次号</th>
                            <th>时间</th>
                            <th>商品名称</th>
                            <th>数量</th>
                            <th>单价</th>
                            <th>支付方式</th>
                            <th>会员卡号</th>
                            <th>次卡券</th>
                            <th>总金额</th>
                            <th>备注</th>
                            <th>操作员</th>
                    <th>状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                    <td colspan="14" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="productOrderPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="reserve-records" role="tabpanel">
            <div class="order-query-header">
                <form id="reserveRecordQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryReserveRecordInput" class="font-weight-bold"><span class="report-label-prefix">（预定记录）</span><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名/电话</label>
                            <input type="text" class="form-control" id="queryReserveRecordInput" 
                                placeholder="请输入<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>名或电话">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryReserveStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryReserveEndDate" class="form-control" step="1">
                            </div>
                                </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-reserve-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-reserve-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-reserve-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-reserve-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-reserve-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-reserve-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-reserve-status-btn" data-status="all">全部记录</button>
                        <button type="button" class="btn btn-outline-secondary filter-reserve-status-btn" data-status="0">未到期</button>
                        <button type="button" class="btn btn-outline-secondary filter-reserve-status-btn" data-status="1">已超时</button>
                        <button type="button" class="btn btn-outline-secondary filter-reserve-status-btn" data-status="2">已取消</button>
                        <button type="button" class="btn btn-outline-secondary filter-reserve-status-btn" data-status="4">已使用</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="reserveRecordTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row reserve-stats-row">
                    <div class="col-md-2 col-6">
                        <div class="stats-box">
                            <h6 class="text-muted">订单总数</h6>
                            <div class="stats-value total-reserve-orders" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <div class="stats-box">
                            <h6 class="text-muted">未到期</h6>
                            <div class="stats-value active-reserve-count" style="color: #ffc107;">0</div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <div class="stats-box">
                            <h6 class="text-muted">已超时</h6>
                            <div class="stats-value timeout-reserve-count" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <div class="stats-box">
                            <h6 class="text-muted">已取消</h6>
                            <div class="stats-value canceled-reserve-count" style="color: #6c757d;">0</div>
                        </div>
                    </div>
                    <div class="col-md-2 col-6">
                        <div class="stats-box">
                            <h6 class="text-muted">已使用</h6>
                            <div class="stats-value used-reserve-count" style="color: #28a745;">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <style>
            @media (min-width: 992px) {
                .reserve-stats-row > [class^='col-'] {
                    flex: 0 0 20%;
                    max-width: 20%;
                    margin-bottom: 0;
                }
                .reserve-stats-row .stats-box {
                    height: 100px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                }
            }
            </style>
            <div class="records-container">
                <table class="table table-striped table-hover" id="reserveRecordTable">
                    <thead class="thead-light">
                        <tr>
                            <th>序号</th>
                            <th>订单号</th>
                            <th>记录时间</th>
                            <th>预定时间</th>
                            <th>预定<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></th>
                            <th>电话</th>
                            <th>备注</th>
                            <th>最后操作时间</th>
                            <th>操作员</th>
                            <th>状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="10" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="reserveRecordPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="recharge-orders" role="tabpanel">
            <div class="order-query-header">
                <form id="rechargeOrderQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryRechargeOrderInput" class="font-weight-bold"><span class="report-label-prefix">（会员充值）</span>订单号/手机号/姓名</label>
                            <input type="text" class="form-control" id="queryRechargeOrderInput" 
                                placeholder="请输入订单号、会员手机号或姓名">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryRechargeStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryRechargeEndDate" class="form-control" step="1">
                            </div>
                                </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-recharge-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-recharge-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-recharge-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-recharge-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-recharge-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-recharge-date-btn" data-days="9999">所有记录</button>
                        <div class="d-inline-block mx-2"></div>
                        <button type="button" class="btn btn-outline-success export-excel-btn" data-table="rechargeOrderTable">
                            <i class="fas fa-file-excel"></i> 导出Excel
                        </button>
                    </div>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">充值笔数</h6>
                            <div class="stats-value total-recharge-orders" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">总金额</h6>
                            <div class="stats-value total-recharge-income" style="color: #dc3545;">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">赠送金额</h6>
                            <div class="stats-value total-gift-amount">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">
                                <span class="other-payment-link view-recharge-payment-details-btn" style="cursor:pointer;color:#007bff;font-weight:bold;" data-type="recharge">支付详细&gt;&gt;</span>
                            </h6>
                            <div style="display:flex;align-items:center;gap:8px;justify-content:center;">
                                <span class="stats-value total-recharge-amount">¥0.00</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div class="mb-2">
                    <span class="text-success">绿色金额(+¥)</span>代表正常充值收入，<span class="text-danger">红色金额(-¥)</span>代表充值退款支出<br>
                    <small>注：对于同时包含充值和赠送金额的订单，支付方式对应的是正常充值的金额。赠送金额默认为系统的赠送支付方式。</small></span>
                </div>
                <table class="table table-striped table-hover" id="rechargeOrderTable">
                    <thead class="thead-light">
                        <tr>
                    <th>序号</th>
                            <th>订单号</th>
                            <th>时间</th>
                            <th>手机号</th>
                            <th>姓名</th>
                            <th>类型</th>
                            <th>支付方式</th>
                            <th>充值金额</th>
                            <th>赠送金额</th>
                    <th>充值后余额</th>
                    <th>操作员</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                    <td colspan="11" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="rechargeOrderPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="consumption-orders" role="tabpanel">
            <div class="order-query-header">
                <form id="consumptionOrderQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryConsumptionOrderInput" class="font-weight-bold"><span class="report-label-prefix">（会员消费）</span>订单号/手机号/姓名/批次号</label>
                            <input type="text" class="form-control" id="queryConsumptionOrderInput" 
                                placeholder="请输入订单号、手机号、姓名或批次号">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryConsumptionStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryConsumptionEndDate" class="form-control" step="1">
                            </div>
                                </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-consumption-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-consumption-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-consumption-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-consumption-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-consumption-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-consumption-date-btn" data-days="9999">所有记录</button>
                        <div class="d-inline-block mx-2"></div>
                        <button type="button" class="btn btn-outline-success export-excel-btn" data-table="consumptionOrderTable">
                            <i class="fas fa-file-excel"></i> 导出Excel
                        </button>
                    </div>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">消费笔数</h6>
                            <div class="stats-value total-consumption-orders" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">总消费金额</h6>
                            <div class="stats-value total-consumption-amount" style="color: #dc3545;">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>消费</h6>
                            <div class="stats-value room-consumption-amount">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">商品/次卡券消费</h6>
                            <div class="stats-value product-consumption-amount">¥0.00</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div class="mb-2">
                    <span class="text-success">绿色金额(-¥)</span>代表正常消费支出，<span class="text-danger">红色金额(+¥)</span>代表消费退款收入
                </div>
                <table class="table table-striped table-hover" id="consumptionOrderTable">
                    <thead class="thead-light">
                        <tr>
                    <th>序号</th>
                            <th>订单号</th>
                            <th>时间</th>
                            <th>手机号</th>
                            <th>姓名</th>
                            <th>消费类型</th>
                            <th><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>/商品/次卡券</th>
                            <th>批次号</th>
                            <th>消费金额</th>
                    <th>消费后余额</th>
                    <th>操作员</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                    <td colspan="11" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="consumptionOrderPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="member-details" role="tabpanel">
            <div class="order-query-header">
                <form id="memberDetailQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-3 mb-2">
                            <label for="queryMemberDetailInput" class="font-weight-bold"><span class="report-label-prefix">（会员明细）</span>手机号/姓名</label>
                            <input type="text" class="form-control" id="queryMemberDetailInput" 
                                placeholder="请输入会员手机号或姓名">
                        </div>
                        <div class="col-md-6 mb-2">
                            <div class="d-flex align-items-center mb-1">
                                <label class="font-weight-bold mb-0">
                                    <span id="memberDateTypeLabel">最后消费日期范围</span>
                                </label>
                                <div class="btn-group btn-group-sm ml-2" role="group">
                                    <button type="button" class="btn btn-primary active filter-member-date-type-btn" data-type="last_consumption" style="font-size: 0.75rem; padding: 0.15rem 0.5rem;">最后消费</button>
                                    <button type="button" class="btn btn-secondary filter-member-date-type-btn" data-type="create" style="font-size: 0.75rem; padding: 0.15rem 0.5rem;">开卡</button>
                                </div>
                            </div>
                            <div class="input-group">
                                <input type="datetime-local" id="queryMemberStartDate" class="form-control" step="1">
                            <div class="input-group-append input-group-prepend">
                                <span class="input-group-text">至</span>
                            </div>
                            <input type="datetime-local" id="queryMemberEndDate" class="form-control" step="1">
                            </div>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="font-weight-bold">会员类型</label>
                            <select id="memberLevelFilter" class="form-control">
                                <option value="all">全部类型</option>
                            </select>
                        </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-member-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-member-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-member-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-member-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-member-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-member-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-member-status-btn" data-status="all">全部状态</button>
                        <button type="button" class="btn btn-outline-secondary filter-member-status-btn" data-status="1">正常</button>
                        <button type="button" class="btn btn-outline-secondary filter-member-status-btn" data-status="0">停用</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="memberDetailTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">总会员数</h6>
                            <div class="stats-value total-members" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">总余额</h6>
                            <div class="stats-value total-balance" style="color: #dc3545;">¥0.00</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">新开卡数</h6>
                            <div class="stats-value new-member-count">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">活跃会员数</h6>
                            <div class="stats-value active-member-count">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div id="member-detail-message"></div>
                <table class="table table-striped table-hover" id="memberDetailTable">
                    <thead class="thead-light">
                        <tr>
                    <th>序号</th>
                            <th>手机号</th>
                            <th>姓名</th>
                            <th>卡类型</th>
                            <th>余额</th>
                            <th>充值总额</th>
                            <th>赠送总额</th>
                            <th>消费总额</th>
                            <th>状态</th>
                            <th>开卡时间</th>
                    <th>最后消费时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                    <td colspan="11" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="memberDetailPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="timecard-orders" role="tabpanel">
            <div class="order-query-header">
                <form id="timecardOrderQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryTimecardOrderInput" class="font-weight-bold"><span class="report-label-prefix">（次卡券订单）</span>订单号/券名称/手机号</label>
                            <input type="text" class="form-control" id="queryTimecardOrderInput" 
                                placeholder="请输入订单号、券名称或手机号">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">购买日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryTimecardOrderStartDate" class="form-control" step="1">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="datetime-local" id="queryTimecardOrderEndDate" class="form-control" step="1">
                            </div>
                        </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-timecard-order-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-order-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-order-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-order-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-order-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-order-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-timecard-order-status-btn" data-status="all">全部订单</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-order-status-btn" data-status="0">未退款</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-order-status-btn" data-status="1">已退款</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="timecardOrderTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <div class="stats-box">
                            <h6 class="text-muted">订单总数</h6>
                            <div class="stats-value timecard-order-total-orders">0</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-box">
                            <h6 class="text-muted">售出总次数</h6>
                            <div class="stats-value timecard-order-total-quantity">0</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stats-box">
                            <h6 class="text-muted">总收入</h6>
                            <div class="stats-value timecard-order-total-income" style="color: #28a745;">¥0.00</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div id="timecard-order-message"></div>
                <table class="table table-striped table-hover" id="timecardOrderTable">
                    <thead class="thead-light">
                        <tr>
                            <th>序号</th>
                            <th>订单号</th>
                            <th>时间</th>
                            <th>券名称</th>
                            <th>类型</th>
                            <th>总次数</th>
                            <th>时长</th>
                            <th>有效期</th>
                            <th>单价</th>
                            <th>数量</th>
                            <th>总金额</th>
                            <th>手机号</th>
                            <th>备注</th>
                            <th>操作员</th>
                            <th>状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="15" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="timecardOrderPaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="timecard-usage" role="tabpanel">
            <div class="order-query-header">
                <form id="timecardUsageQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryTimecardUsageInput" class="font-weight-bold"><span class="report-label-prefix">（次卡券使用）</span>订单号/使用订单号/券名称/手机号</label>
                            <input type="text" class="form-control" id="queryTimecardUsageInput" 
                                placeholder="请输入订单号、使用订单号、券名称或手机号">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">使用日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryTimecardUsageStartDate" class="form-control" step="1">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="datetime-local" id="queryTimecardUsageEndDate" class="form-control" step="1">
                            </div>
                        </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-timecard-usage-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-usage-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-usage-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-usage-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-usage-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-usage-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-timecard-usage-status-btn" data-status="all">全部记录</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-usage-status-btn" data-status="0">已使用</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-usage-status-btn" data-status="1">已退款</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="timecardUsageTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">使用总次数</h6>
                            <div class="stats-value timecard-usage-total-consumptions">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">消耗次数</h6>
                            <div class="stats-value timecard-usage-total-used" style="color: #dc3545;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>消耗</h6>
                            <div class="stats-value timecard-usage-room-consumptions">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">商品消耗</h6>
                            <div class="stats-value timecard-usage-product-consumptions">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div id="timecard-usage-message"></div>
                <table class="table table-striped table-hover" id="timecardUsageTable">
                    <thead class="thead-light">
                        <tr>
                            <th>序号</th>
                            <th>购买订单号</th>
                            <th>时间</th>
                            <th>使用订单号</th>
                            <th>券名称</th>
                            <th>使用类型</th>
                            <th>使用详情</th>
                            <th>抵扣时长</th>
                            <th>使用次数</th>
                            <th>剩余次数</th>
                            <th>手机号</th>
                            <th>操作员</th>
                            <th>状态</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="13" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="timecardUsagePaginationContainer" class="mt-3"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="timecard-holdings" role="tabpanel">
            <div class="order-query-header">
                <form id="timecardHoldingQueryForm" class="mb-3">
                    <div class="form-row">
                        <div class="col-md-4 mb-2">
                            <label for="queryTimecardHoldingInput" class="font-weight-bold"><span class="report-label-prefix">（次卡券持有）</span>订单号/券名称/手机号</label>
                            <input type="text" class="form-control" id="queryTimecardHoldingInput" 
                                placeholder="请输入订单号、券名称或手机号">
                        </div>
                        <div class="col-md-7 mb-2">
                            <label class="font-weight-bold">购买日期范围</label>
                            <div class="input-group">
                                <input type="datetime-local" id="queryTimecardHoldingStartDate" class="form-control" step="1">
                                <div class="input-group-append input-group-prepend">
                                    <span class="input-group-text">至</span>
                                </div>
                                <input type="datetime-local" id="queryTimecardHoldingEndDate" class="form-control" step="1">
                            </div>
                        </div>
                        <div class="col-md-1 mb-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-outline-primary query-timecard-holding-date-btn" data-days="1">今天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-holding-date-btn" data-days="7">近7天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-holding-date-btn" data-days="30">近30天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-holding-date-btn" data-days="90">近90天</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-holding-date-btn" data-days="365">近一年</button>
                        <button type="button" class="btn btn-outline-secondary query-timecard-holding-date-btn" data-days="9999">所有记录</button>
                    </div>
                    <div class="btn-group ml-3" role="group">
                        <button type="button" class="btn btn-outline-primary active filter-timecard-holding-status-btn" data-status="all">全部状态</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-holding-status-btn" data-status="active">未用完</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-holding-status-btn" data-status="used">已用完</button>
                        <button type="button" class="btn btn-outline-secondary filter-timecard-holding-status-btn" data-status="expired">已过期</button>
                    </div>
                    <button type="button" class="btn btn-outline-success export-excel-btn ml-3" data-table="timecardHoldingTable">
                        <i class="fas fa-file-excel"></i> 导出Excel
                    </button>
                </form>
            </div>
            <div class="stats-summary mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">持有总数</h6>
                            <div class="stats-value timecard-holding-total-holdings">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">获得总次数</h6>
                            <div class="stats-value timecard-holding-total-times" style="color: #007bff;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">剩余总次数</h6>
                            <div class="stats-value timecard-holding-total-remaining" style="color: #28a745; font-weight: bold;">0</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-box">
                            <h6 class="text-muted">可用次卡券数</h6>
                            <div class="stats-value timecard-holding-active-holdings" style="color: #28a745;">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="records-container">
                <div id="timecard-holding-message"></div>
                <table class="table table-striped table-hover" id="timecardHoldingTable">
                    <thead class="thead-light">
                        <tr>
                            <th>序号</th>
                            <th>销售订单号</th>
                            <th>购买时间</th>
                            <th>券名称</th>
                            <th>类型</th>
                            <th>时长</th>
                            <th>剩余/总次数</th>
                            <th>手机号</th>
                            <th>姓名</th>
                            <th>状态</th>
                            <th>过期时间</th>
                            <th>最后使用时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="12" class="text-center py-3 text-muted">请设置查询条件并点击搜索</td>
                        </tr>
                    </tbody>
                </table>
                <div id="timecardHoldingPaginationContainer" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="productRefundModal" tabindex="-1" role="dialog" aria-labelledby="productRefundModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content border-danger">
            <div class="modal-header bg-danger text-white py-2">
                <h6 class="modal-title" id="productRefundModalLabel">
                    商品订单退单
                </h6>
                <button type="button" class="close text-white modal-close-btn" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center py-3">
                <div class="mb-3">
                    <i class="fas fa-undo-alt text-danger" style="font-size: 2rem;"></i>
                </div>
                <div class="mb-2" style="font-size:15px;">确定要退单吗？</div>
                <div class="text-muted" style="font-size:13px;">退单后，本订单金额记录为0元</div>
                <div class="text-muted" style="font-size:13px;">会员卡支付会退回会员卡余额</div>
                <input type="hidden" id="refundOrderId" value="">
                <div id="processingIndicator" class="mt-3 text-center" style="display: none;">
                    <div class="spinner-border text-danger" role="status">
                        <span class="sr-only">处理中...</span>
                    </div>
                    <p class="text-danger mt-2">正在处理退单请求，请稍候...</p>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary btn-sm modal-close-btn" data-dismiss="modal">
                    关闭
                </button>
                <button type="button" class="btn btn-danger btn-sm" id="confirmRefundBtn">
                    确认退单
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="timecardRefundModal" tabindex="-1" role="dialog" aria-labelledby="timecardRefundModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content border-danger">
            <div class="modal-header bg-danger text-white py-2">
                <h6 class="modal-title" id="timecardRefundModalLabel">
                    次卡券订单退单
                </h6>
                <button type="button" class="close text-white modal-close-btn" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center py-3">
                <div class="mb-3">
                    <i class="fas fa-undo-alt text-danger" style="font-size: 2rem;"></i>
                </div>
                <div class="mb-2" style="font-size:15px;">确定要退单吗？</div>
                <div class="text-muted" style="font-size:13px;">退单后，本订单金额记录为0元</div>
                <div class="text-muted" style="font-size:13px;">会员卡支付会退回会员卡余额</div>
                <div class="text-muted" style="font-size:13px;">注意：次卡券已使用则不允许退款</div>
                <input type="hidden" id="refundTimecardOrderId" value="">
                <div id="timecardProcessingIndicator" class="mt-3 text-center" style="display: none;">
                    <div class="spinner-border text-danger" role="status">
                        <span class="sr-only">处理中...</span>
                    </div>
                    <p class="text-danger mt-2">正在处理退单请求，请稍候...</p>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary btn-sm modal-close-btn" data-dismiss="modal">
                    关闭
                </button>
                <button type="button" class="btn btn-danger btn-sm" id="confirmTimecardRefundBtn">
                    确认退单
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="timecardUsageRefundModal" tabindex="-1" role="dialog" aria-labelledby="timecardUsageRefundModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content border-danger">
            <div class="modal-header bg-danger text-white py-2">
                <h6 class="modal-title" id="timecardUsageRefundModalLabel">
                    次卡券使用退单
                </h6>
                <button type="button" class="close text-white modal-close-btn" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center py-3">
                <div class="mb-3">
                    <i class="fas fa-undo-alt text-danger" style="font-size: 2rem;"></i>
                </div>
                <div class="mb-2" style="font-size:15px;">确定要退单吗？</div>
                <div class="text-muted" style="font-size:13px;">退单后将退回次卡次数</div>
                <div class="text-danger" style="font-size:13px;"><i class="fas fa-exclamation-triangle"></i> 注意：<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>已使用的时间不会退回</div>
                <div class="text-muted" style="font-size:13px;">此操作不可撤销</div>
                <input type="hidden" id="refundTimecardUsageId" value="">
                <input type="hidden" id="refundTimecardUsageOrderNo" value="">
                <div id="timecardUsageProcessingIndicator" class="mt-3 text-center" style="display: none;">
                    <div class="spinner-border text-danger" role="status">
                        <span class="sr-only">处理中...</span>
                    </div>
                    <p class="text-danger mt-2">正在处理退单请求，请稍候...</p>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary btn-sm modal-close-btn" data-dismiss="modal">
                    取消
                </button>
                <button type="button" class="btn btn-danger btn-sm" id="confirmTimecardUsageRefundBtn">
                    确认退单
                </button>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="roomRefundModal" tabindex="-1" role="dialog" aria-labelledby="roomRefundModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content border-danger">
            <div class="modal-header bg-danger text-white py-2">
                <h6 class="modal-title" id="roomRefundModalLabel">
                    <?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>订单退费
                </h6>
                <button type="button" class="close text-white modal-close-btn" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body py-3">
                <input type="hidden" id="roomRefundOrderId" value="">
                <div id="refundPaymentMethodsContainer">
                    <div class="text-center">
                        <i class="fas fa-spinner fa-spin mr-2"></i>正在加载支付明细...
                    </div>
                </div>
                <div id="roomRefundProcessingIndicator" class="mt-3 text-center" style="display: none;">
                    <div class="spinner-border text-danger" role="status">
                        <span class="sr-only">处理中...</span>
                    </div>
                    <p class="text-danger mt-2">正在处理退费请求，请稍候...</p>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary btn-sm modal-close-btn" data-dismiss="modal">
                    关闭
                </button>
                <button type="button" class="btn btn-danger btn-sm" id="confirmRoomRefundBtn">
                    确认退费
                </button>
            </div>
        </div>
    </div>
</div>
<div class="back-to-top">
    <i class="fas fa-arrow-up"></i>
</div>
<script src="/asset/lib/js/jquery.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/jquery.min.js') ?>"></script>
<script src="/asset/lib/js/bootstrap.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/bootstrap.min.js') ?>"></script>
<script src="/asset/sys_query.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/sys_query.js') ?>"></script>
<script src="/asset/lib/js/exceljs.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/exceljs.min.js') ?>"></script>
<script>
$(document).on('click', '.overview-info-icon', function() {
    const info = $(this).data('info');
    if (info) {
        const popupHtml = `
            <div id="infoPopup" style="
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                padding: 25px;
                max-width: 450px;
                min-width: 350px;
                z-index: 9999;
                font-size: 16px;
                line-height: 1.6;
                color: #333;
            ">
                <div>${info}</div>
            </div>
            <div id="infoOverlay" style="
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.3);
                z-index: 9998;
            " onclick="document.getElementById('infoPopup').remove(); document.getElementById('infoOverlay').remove();"></div>
        `;
        $('#infoPopup, #infoOverlay').remove();
        $('body').append(popupHtml);
    }
});
$(function() {
    var $btn = $('.back-to-top');
    function updateBackToTop() {
        var scrollTop = Math.max(
            window.pageYOffset || 0,
            document.documentElement.scrollTop || 0,
            document.body.scrollTop || 0,
            $(window).scrollTop() || 0,
            $('html').scrollTop() || 0,
            $('body').scrollTop() || 0
        );
        if (scrollTop > 300) {
            $btn.addClass('visible');
        } else {
            $btn.removeClass('visible');
        }
    }
    $(window).on('scroll', updateBackToTop);
    $(document).on('scroll', updateBackToTop);
    $('body').on('scroll', updateBackToTop);
    $btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, 500);
        return false;
    });
    updateBackToTop();
    setTimeout(updateBackToTop, 100);
    setTimeout(updateBackToTop, 500);
    $('.nav-link[data-toggle="tab"]').on('mouseenter', function() {
        const $this = $(this);
        const href = $this.attr('href');
        if (href) {
            $this.data('temp-href', href).removeAttr('href');
        }
    }).on('mouseleave', function() {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href && !$this.attr('href')) {
            $this.attr('href', href);
        }
    }).on('mousedown', function(e) {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href) {
            $this.attr('href', href);
            $this.tab('show');
            setTimeout(function() {
                $this.removeAttr('href');
            }, 0);
            e.preventDefault();
        }
    });
    $('a[href*="auth.php?logout"]').on('mouseenter', function() {
        const $this = $(this);
        const href = $this.attr('href');
        if (href) {
            $this.data('temp-href', href).removeAttr('href');
        }
    }).on('mouseleave click', function() {
        const $this = $(this);
        const href = $this.data('temp-href');
        if (href) {
            $this.attr('href', href);
        }
    });
});
</script>
<div class="modal fade" id="purposeAnalysisModal" tabindex="-1" role="dialog" aria-labelledby="purposeAnalysisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="height: 80vh;">
            <div class="modal-header py-2">
                <h6 class="modal-title" id="purposeAnalysisModalLabel">用途分析</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body py-3" style="overflow-y: auto; height: calc(80vh - 80px);">
                <ul class="nav nav-tabs mb-3" id="purposeAnalysisTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="purpose-by-tag-tab" data-toggle="tab" href="#purposeByTag" role="tab">按标签统计</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="purpose-by-room-tab" data-toggle="tab" href="#purposeByRoom" role="tab">按<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>统计</a>
                    </li>
                    <li class="nav-item ml-auto">
                        <button type="button" class="btn btn-sm btn-outline-success" id="exportPurposeDataBtn">
                            导出Excel
                        </button>
                    </li>
                </ul>
                <div class="tab-content" id="purposeAnalysisTabContent">
                    <div class="tab-pane fade show active" id="purposeByTag" role="tabpanel">
                        <div id="purposeByTagContent">
                            <div class="text-center py-3">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="sr-only">加载中...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="purposeByRoom" role="tabpanel">
                        <div id="purposeByRoomContent">
                            <div class="text-center py-3">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="sr-only">加载中...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer py-2">
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">关闭</button>
            </div>
        </div>
    </div>
</div>
</body>
</html>