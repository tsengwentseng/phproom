<?php
header("Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
$config_path = __DIR__ . '/config.php';
if (file_exists($config_path)) {
    include($config_path);
} else {
    http_response_code(500);
    echo json_encode(['error' => '配置文件不存在']);
    exit;
}
$SCENE_ROOM_NAME = '房间'; 
$scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'");
if ($scene_stmt) {
    $scene_stmt->execute();
    $scene_result = $scene_stmt->get_result();
    if ($scene_result && $scene_row = $scene_result->fetch_assoc()) {
        $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间';
    }
    $scene_stmt->close();
}
require_once 'auth.php';
requirePageAccess('any', SESSION_TIMEOUT_FRONT, $SCENE_ROOM_NAME . '管理');
$feature_switch = [
    'room' => 1,      
    'product' => 1,   
    'member' => 1,    
    'stats' => 1,     
    'rental' => 0,    
    'handover' => 1   
];
$feature_mapping = [
    'feature_room' => 'room',
    'feature_product' => 'product',
    'feature_member' => 'member',
    'feature_stats' => 'stats',
    'feature_rental' => 'rental',
    'feature_handover' => 'handover'
];
if (isset($conn) && $conn) {
    $config_sql = "SELECT config_key, config_value FROM system_config WHERE config_key IN ('feature_room','feature_product','feature_member','feature_stats','feature_rental','feature_handover','background_image','container_opacity','reservation_grace_minutes','reservation_overlap_minutes','order_edit_enabled') AND (is_visible = 1 OR config_key IN ('background_image','container_opacity'))";
    $config_result = $conn->query($config_sql);
    $all_configs = [];
    if ($config_result && $config_result->num_rows > 0) {
        while ($row = $config_result->fetch_assoc()) {
            $all_configs[$row['config_key']] = $row['config_value'];
            if (isset($feature_mapping[$row['config_key']])) {
                $feature_switch[$feature_mapping[$row['config_key']]] = intval($row['config_value']);
            }
        }
        $config_result->free();
    }
    $background_url = $all_configs['background_image'] ?? '';
    $opacity = intval($all_configs['container_opacity'] ?? 30) / 100;
    $grace_minutes = $all_configs['reservation_grace_minutes'] ?? 30;
    $grace_minutes = intval($grace_minutes);
    $order_edit_enabled = intval($all_configs['order_edit_enabled'] ?? 0);
    $static_data = [];
    $rooms_sql = "SELECT * FROM rooms WHERE is_deleted = 0 AND is_enabled = 1 ORDER BY sort_order, id";
    $rooms_result = $conn->query($rooms_sql);
    if ($rooms_result && $rooms_result->num_rows > 0) {
        $static_data['rooms'] = [];
        $room_types_set = []; 
        while ($room = $rooms_result->fetch_assoc()) {
            $static_data['rooms'][] = $room;
            $room_types_set[strtoupper($room['type'])] = strtoupper($room['type']);
        }
        $rooms_result->free();
        $static_data['room_types'] = [];
        foreach ($room_types_set as $type) {
            $static_data['room_types'][] = ['type' => $type];
        }
        usort($static_data['room_types'], function($a, $b) {
            return strcmp($a['type'], $b['type']);
        });
    }
    $products_sql = "SELECT * FROM products 
                     WHERE is_deleted = 0 
                     AND is_enabled = 1 
                     AND (allow_zero_stock = 1 OR stock_quantity > 0)
                     ORDER BY sort_order, id";
    $products_result = $conn->query($products_sql);
    if ($products_result && $products_result->num_rows > 0) {
        $static_data['products'] = [];
        $product_types_set = []; 
        while ($product = $products_result->fetch_assoc()) {
            $static_data['products'][] = $product;
            $product_types_set[strtoupper($product['type'])] = strtoupper($product['type']);
        }
        $products_result->free();
        $static_data['product_types'] = [];
        foreach ($product_types_set as $type) {
            $static_data['product_types'][] = ['type' => $type];
        }
        usort($static_data['product_types'], function($a, $b) {
            return strcmp($a['type'], $b['type']);
        });
    }
    $time_cards_sql = "SELECT * FROM time_card_products 
                       WHERE is_deleted = 0 
                       AND is_enabled = 1 
                       ORDER BY sort_order, id";
    $time_cards_result = $conn->query($time_cards_sql);
    if ($time_cards_result && $time_cards_result->num_rows > 0) {
        $static_data['time_cards'] = [];
        while ($tc = $time_cards_result->fetch_assoc()) {
            $static_data['time_cards'][] = $tc;
        }
        $time_cards_result->free();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理系统</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/asset/lib/css/bootstrap.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="/asset/lib/css/all.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/all.min.css') ?>" rel="stylesheet">
    <link href="/asset/main.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/main.css') ?>" rel="stylesheet">
    <style>
        :root {
            --background-image: <?php echo $background_url ? "url('$background_url')" : "none"; ?>;
            --container-opacity: <?php echo $opacity; ?>;
        }
        .main-navbar .nav-link,
        .main-navbar .nav-link:hover,
        .main-navbar .nav-link:focus,
        .main-navbar .nav-link:active,
        a[onclick*="logoutAndRefresh"] {
            cursor: pointer !important;
        }
        #pageLoader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.3s ease-out;
        }
        #pageLoader.fade-out {
            opacity: 0;
            pointer-events: none;
        }
        .loader-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .loader-text {
            margin-top: 20px;
            font-size: 16px;
            color: #666;
            font-weight: 500;
        }
        body.loading .container,
        body.loading .main-navbar {
            opacity: 0;
        }
        body.loaded .container,
        body.loaded .main-navbar {
            opacity: 1;
            transition: opacity 0.3s ease-in;
        }
    </style>    
    <script>
        window.SYSTEM_CONFIG = {
          serverTime: '<?php echo date('c'); ?>',
          clientTime: Date.now(),
          sceneRoomName: '<?php echo addslashes($SCENE_ROOM_NAME); ?>', 
          operatorId: <?php echo (int)($_SESSION['front_user_id'] ?? 0); ?>
        };
        window.SERVER_TIME = new Date(window.SYSTEM_CONFIG.serverTime).getTime();
        window.APP_CONFIG = {
            serverDate: '<?= date('Y-m-d') ?>'
        };
        window.systemConfig = <?php
            $config_sql = "SELECT config_key, config_value FROM system_config WHERE is_visible = 1";
            $config_result = $conn->query($config_sql);
            $configs = [];
            $visibleConfigs = [];
            if ($config_result && $config_result->num_rows > 0) {
                while ($row = $config_result->fetch_assoc()) {
                    $configs[$row['config_key']] = $row['config_value'];
                    $visibleConfigs[$row['config_key']] = $row['config_value'];
                }
            }
            echo json_encode($configs);
        ?>;
        window.validProducts = <?php
            if (isset($static_data['products']) && !empty($static_data['products'])) {
                $validProducts = [];
                foreach ($static_data['products'] as $product) {
                    $validProducts[] = [
                        'id' => $product['id'],
                        'name' => $product['name'],
                        'price' => $product['price'],
                        'memberDiscount' => $product['member_discount']
                    ];
                }
                echo json_encode($validProducts);
            } else {
                echo '[]';
            }
        ?>;
    </script>
    <script>
        window.EXCELJS_VERSION = '<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/exceljs.min.js') ?>';
    </script>
    <script src="/asset/lib/js/jquery.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/jquery.min.js') ?>"></script>
    <script src="/asset/lib/js/bootstrap.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/bootstrap.min.js') ?>"></script>
    <script src="/asset/core.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/core.js') ?>"></script>
</head>
<body class="loading">
<div id="pageLoader">
    <div class="loader-spinner"></div>
    <div class="loader-text">加载中...</div>
</div>
<button class="navbar-expand-btn" id="navbarExpandBtn" title="显示导航栏">
    <i class="fas fa-chevron-left"></i>
</button>
<nav class="main-navbar" role="navigation">
    <div class="nav-container">
        <ul class="nav nav-left" role="tablist">
            <?php if ($feature_switch['room']): ?>
            <li class="nav-item">
                <a href="#roomContainer" class="nav-link" id="nav-room" data-toggle="tab" role="tab" aria-controls="roomContainer" aria-selected="false">
                    <i class="fas fa-home"></i>
                    <span class="font-weight-bold"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#reservationContainer" class="nav-link" id="nav-reserve" data-toggle="tab" role="tab" aria-controls="reservationContainer" aria-selected="false">
                    <i class="fas fa-calendar-alt"></i>
                    <span class="font-weight-bold">预定管理</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if ($feature_switch['product']): ?>
            <li class="nav-item">
                <a href="#productContainer" class="nav-link" id="nav-product" data-toggle="tab" role="tab" aria-controls="productContainer" aria-selected="false">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="font-weight-bold">商品销售</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if ($feature_switch['member']): ?>
            <li class="nav-item">
                <a href="#memberCardContainer" class="nav-link" id="nav-member" data-toggle="tab" role="tab" aria-controls="memberCardContainer" aria-selected="false">
                    <i class="fas fa-id-card"></i>
                    <span class="font-weight-bold">会员服务</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if ($feature_switch['stats']): ?>
            <li class="nav-item">
                <a href="#statsContainer" class="nav-link" id="nav-stats" data-toggle="tab" role="tab" aria-controls="statsContainer" aria-selected="false">
                    <i class="fas fa-chart-line"></i>
                    <span class="font-weight-bold">营业统计</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <div class="nav-right">
            <!--<a href="#" class="nav-link" id="nav-all">
                <i class="fas fa-th-large"></i>
                <span class="font-weight-bold">全显</span>
            </a> -->
            <i class="fas fa-bullhorn announce-icon" id="announceBtn" title="播放商家公告" style="cursor:pointer;"></i>
            <span class="current-datetime" id="currentDateTime">
                <span id="dateText"></span>
                <span id="weekText"></span>
                <span id="timeText"></span>
                <div class="server-status-tooltip" id="serverStatusTooltip">
                    <div class="status-title">
                        <i class="fas fa-server"></i> 服务器状态
                    </div>
                    <div class="loading">加载中...</div>
                </div>
            </span>
            <?php if ($feature_switch['rental']): ?>
            <a href="../ext/rental/rental.php" class="nav-link" target="_blank">
                <i class="fas fa-box"></i>
                <span class="font-weight-bold">租赁</span>
            </a>
            <?php endif; ?>
            <?php if ($feature_switch['handover']): ?>
            <a href="handover.php" class="nav-link" target="_blank">
                <i class="fas fa-user-clock"></i>
                <span class="font-weight-bold">交班</span>
            </a>
            <?php endif; ?>
            <a href="sys_query.php" class="nav-link" target="_blank">
                <i class="fas fa-chart-bar"></i>
                <span class="font-weight-bold">报表</span>
            </a>
            <a href="admin.php" class="nav-link" target="_blank">
                <i class="fas fa-cog"></i>
                <span class="font-weight-bold">后台</span>
            </a>
            <?php
            $frontUsername = $_SESSION['front_username'] ?? '';
            $frontName = $_SESSION['front_name'] ?? '';
            $frontRole = $_SESSION['front_role'] ?? '';
            $roleText = $frontRole === 'admin' ? '管理员' : '前台';
            $logoutTitle = "用户名：{$frontUsername}\n姓名：{$frontName}\n权限：{$roleText}";
            ?>
            <a onclick="logoutAndRefresh()" class="nav-link danger" title="<?php echo htmlspecialchars($logoutTitle); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span class="font-weight-bold">退出</span>
            </a>
        </div>
        <button class="navbar-collapse-btn" id="navbarCollapseBtn" title="隐藏导航栏">
            <i class="fas fa-chevron-right"></i>
        </button>
        <div class="menu-toggle">
            <button>
                <i class="fas fa-bars"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-right">
               <!-- <a href="#" class="dropdown-item" id="nav-all-dropdown">
                    <i class="fas fa-th-large"></i> 全显
                </a> -->
                <?php if ($feature_switch['rental']): ?>
                <a href="../ext/rental/rental.php" class="dropdown-item" target="_blank">
                    <i class="fas fa-box"></i> 租赁
                </a>
                <?php endif; ?>
                <?php if ($feature_switch['handover']): ?>
                <a href="handover.php" class="dropdown-item" target="_blank">
                    <i class="fas fa-user-clock"></i> 交班
                </a>
                <?php endif; ?>
                <a href="sys_query.php" class="dropdown-item" target="_blank">
                    <i class="fas fa-chart-bar"></i> 报表
                </a>
                <a href="admin.php" class="dropdown-item" target="_blank">
                    <i class="fas fa-cog"></i> 后台
                </a>
                <a href="javascript:void(0)" onclick="logoutAndRefresh()" class="dropdown-item text-danger" title="<?php echo htmlspecialchars($logoutTitle); ?>">
                    <i class="fas fa-sign-out-alt"></i> 退出
                </a>
            </div>
        </div>
    </div>
</nav>
<div class="container">
    <div class="tab-content" id="mainTabContent">
    <?php if ($feature_switch['room']): ?>
    <div class="tab-pane fade" id="roomContainer" role="tabpanel">
    <div class="row">
        <div class="col-12 mb-3" style="margin-top: 5px;">
            <h4 class="border-bottom pb-2" style="font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center;">
                <span style="flex-shrink: 0;"><i class="fas fa-home mr-2"></i><span class="title-text-full"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理</span><span class="title-text-short"><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?></span></span>
                <div id="roomTypeQuickBtns" style="display: none; flex: 1; overflow-x: auto; overflow-y: hidden; margin: 0 50px 0 30px;">
                    <div style="display: flex; gap: 20px; flex-wrap: nowrap; align-items: center;">
                    </div>
                </div>
                <div style="display: flex; gap: 10px; align-items: center; flex-shrink: 0;">
                    <button class="btn btn-outline-secondary btn-sm" id="batchCheckoutBtn" style="border-radius: 4px; min-width: 60px;">
                        <i class="fas fa-check-double mr-1"></i><span class="btn-text" style="display: inline; line-height: inherit; font-size: inherit;">结账</span>
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" id="roomCompactModeBtn" style="border-radius: 4px; min-width: 60px;" title="切换到紧凑模式">
                        <i class="fas fa-th mr-1"></i><span class="btn-text" style="display: inline; line-height: inherit; font-size: inherit;">正常</span>
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" id="roomTypeFilterBtn" style="border-radius: 4px; min-width: 60px;">
                        <i class="fas fa-filter mr-1"></i><span id="currentFilterText" class="btn-text" style="display: inline; line-height: inherit; font-size: inherit;">筛选</span>
                    </button>
                </div>
            </h4>
        </div>
        <?php
        if (!isset($static_data['rooms']) || empty($static_data['rooms'])) {
            echo '<div class="col-12 alert alert-warning">尚未添加任何' . htmlspecialchars($SCENE_ROOM_NAME) . '，请先到<a href="admin.php" target="_blank">管理页面</a>添加</div>';
        } else {
            $room_ids = array_column($static_data['rooms'], 'id');
            $room_ids_str = implode(',', array_map('intval', $room_ids));
            $orders_map = [];
            if (!empty($room_ids_str)) {
                $orders_query = "
                    SELECT o.* 
                    FROM orders o
                    INNER JOIN (
                        SELECT room_id, MAX(start_time) as max_start_time, MAX(id) as max_id
                        FROM orders
                        WHERE room_id IN ($room_ids_str) AND status = 0
                        GROUP BY room_id
                    ) latest ON o.room_id = latest.room_id 
                               AND o.start_time = latest.max_start_time 
                               AND o.id = latest.max_id
                    WHERE o.status = 0
                ";
                $orders_result = $conn->query($orders_query);
                if ($orders_result) {
                    while ($order = $orders_result->fetch_assoc()) {
                        $orders_map[$order['room_id']] = $order;
                    }
                    $orders_result->free();
                }
            }
            $product_totals = [];
            if (!empty($orders_map)) {
                $order_ids = array_column($orders_map, 'id');
                $order_ids_str = implode(',', array_map(function($id) { 
                    return "'" . addslashes($id) . "'"; 
                }, $order_ids));
                $product_query = "
                    SELECT batch_id, SUM(total_amount) as product_total
                    FROM product_orders
                    WHERE batch_id IN ($order_ids_str) AND is_refunded = 0
                    GROUP BY batch_id
                ";
                $product_result = $conn->query($product_query);
                if ($product_result) {
                    while ($row = $product_result->fetch_assoc()) {
                        $product_totals[$row['batch_id']] = (float)$row['product_total'];
                    }
                    $product_result->free();
                }
            }
            $credit_product_totals = [];
            if (!empty($orders_map)) {
                $order_ids = array_column($orders_map, 'id');
                $order_ids_str = implode(',', array_map(function($id) { 
                    return "'" . addslashes($id) . "'"; 
                }, $order_ids));
                $credit_product_query = "
                    SELECT batch_no, SUM(total_amount) as credit_product_total
                    FROM product_credit_for_room
                    WHERE batch_no IN ($order_ids_str)
                    GROUP BY batch_no
                ";
                $credit_product_result = $conn->query($credit_product_query);
                if ($credit_product_result) {
                    while ($row = $credit_product_result->fetch_assoc()) {
                        $credit_product_totals[$row['batch_no']] = (float)$row['credit_product_total'];
                    }
                    $credit_product_result->free();
                }
            }
            $order_credits = [];
            if (!empty($orders_map)) {
                $order_ids = array_column($orders_map, 'id');
                $order_ids_str = implode(',', array_map(function($id) { return "'" . addslashes($id) . "'"; }, $order_ids));
                $credits_query = "
                    SELECT DISTINCT order_id
                    FROM orders_payment_details
                    WHERE order_id IN ($order_ids_str) AND payment_method_id = 88
                ";
                $credits_result = $conn->query($credits_query);
                if ($credits_result) {
                    while ($row = $credits_result->fetch_assoc()) {
                        $order_credits[$row['order_id']] = true;
                    }
                    $credits_result->free();
                }
            }
            $order_promotions = [];
            if (!empty($orders_map)) {
                $order_ids = array_column($orders_map, 'id');
                $order_ids_str = implode(',', array_map(function($id) { return "'" . addslashes($id) . "'"; }, $order_ids));
                $promo_query = "
                    SELECT DISTINCT order_id
                    FROM orders_payment_details
                    WHERE order_id IN ($order_ids_str) 
                    AND promotion_data IS NOT NULL 
                    AND promotion_data != '' 
                    AND promotion_data != '[]'
                ";
                $promo_result = $conn->query($promo_query);
                if ($promo_result) {
                    while ($row = $promo_result->fetch_assoc()) {
                        $order_promotions[$row['order_id']] = true;
                    }
                    $promo_result->free();
                }
            }
            $reservation_counts = [];
            if (!empty($room_ids_str)) {
                if ($grace_minutes > 0) {
                    $count_query = "
                        SELECT room_id, COUNT(*) as total_reservations
                        FROM reservations
                        WHERE room_id IN ($room_ids_str)
                        AND (
                            status = 0
                            OR (status = 1 AND TIMESTAMPDIFF(MINUTE, reservation_time, NOW()) <= $grace_minutes)
                        )
                        GROUP BY room_id
                    ";
                } else {
                    $count_query = "
                        SELECT room_id, COUNT(*) as total_reservations
                        FROM reservations
                        WHERE room_id IN ($room_ids_str) AND status = 0
                        GROUP BY room_id
                    ";
                }
                $count_result = $conn->query($count_query);
                if ($count_result) {
                    while ($row = $count_result->fetch_assoc()) {
                        $reservation_counts[$row['room_id']] = (int)$row['total_reservations'];
                    }
                    $count_result->free();
                }
            }
            $reservations_map = [];
            if (!empty($room_ids_str)) {
                if ($grace_minutes > 0) {
                    $reservations_query = "
                        SELECT r.*
                        FROM reservations r
                        INNER JOIN (
                            SELECT room_id, MIN(reservation_time) as min_time, MIN(id) as min_id
                            FROM reservations
                            WHERE room_id IN ($room_ids_str)
                            AND (
                                status = 0
                                OR (status = 1 AND TIMESTAMPDIFF(MINUTE, reservation_time, NOW()) <= $grace_minutes)
                            )
                            GROUP BY room_id
                        ) earliest ON r.room_id = earliest.room_id 
                                     AND r.reservation_time = earliest.min_time 
                                     AND r.id = earliest.min_id
                        WHERE (
                            r.status = 0
                            OR (r.status = 1 AND TIMESTAMPDIFF(MINUTE, r.reservation_time, NOW()) <= $grace_minutes)
                        )
                    ";
                } else {
                    $reservations_query = "
                        SELECT r.*
                        FROM reservations r
                        INNER JOIN (
                            SELECT room_id, MIN(reservation_time) as min_time, MIN(id) as min_id
                            FROM reservations
                            WHERE room_id IN ($room_ids_str) AND status = 0
                            GROUP BY room_id
                        ) earliest ON r.room_id = earliest.room_id 
                                     AND r.reservation_time = earliest.min_time 
                                     AND r.id = earliest.min_id
                        WHERE r.status = 0
                    ";
                }
                $reservations_result = $conn->query($reservations_query);
                if ($reservations_result) {
                    while ($reservation = $reservations_result->fetch_assoc()) {
                        $reservations_map[$reservation['room_id']] = $reservation;
                    }
                    $reservations_result->free();
                }
            }
            foreach ($static_data['rooms'] as $room) {
                $order = isset($orders_map[$room['id']]) ? $orders_map[$room['id']] : null;
                $total_income = 0;
                $has_credit = false;
                $order_amount_is_zero = false;  
                if ($order) {
                    $total_income = floatval($order['total_amount'] ?? 0);
                    $order_amount_is_zero = ($total_income <= 0);
                    $has_credit = isset($order_credits[$order['id']]);
                    if (isset($product_totals[$order['id']])) {
                        $total_income += $product_totals[$order['id']];
                    }
                    if (isset($credit_product_totals[$order['id']])) {
                        $has_credit = true;
                    }
                }
                $reservation_count = isset($reservation_counts[$room['id']]) ? $reservation_counts[$room['id']] : 0;
                $reservation = isset($reservations_map[$room['id']]) ? $reservations_map[$room['id']] : null;
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 mb-3">
            <div class="card room-card <?= $order ? 'border-danger' : 'border-success' ?>" data-room-id="<?= htmlspecialchars($room['id']) ?>">
                <div class="card-body position-relative">
                    <?php
                    $isScanCheckin = $order && ($order['is_scan_checkin'] ?? 0) == 1;
                    ?>
                    <?php if ($order && $reservation): ?>
                        <span class="badge badge-warning status-badge reservation-badge">预定中</span>
                        <span class="badge badge-danger status-badge"><?= $isScanCheckin ? '扫码开台' : '使用中' ?></span>
                    <?php elseif ($order): ?>
                        <span class="badge badge-danger status-badge"><?= $isScanCheckin ? '扫码开台' : '使用中' ?></span>
                    <?php elseif ($reservation): ?>
                        <span class="badge badge-warning status-badge">预定中</span>
                    <?php endif; ?>
                    <h5 class="card-title mb-3">
                        <?= htmlspecialchars(strtoupper($room['name'])) ?>
                        <small class="text-muted"><?= htmlspecialchars(strtoupper($room['type'])) ?></small>
                        <?php if ($room['enable_standard_price'] == 1 && $room['standard_price'] > 0): ?>
                        <i class="fas fa-yen-sign text-primary ml-1" title="标准价<?= htmlspecialchars($room['standard_price']) ?>元/时"></i>
                        <?php endif; ?>
                        <?php if ($order): ?>
                        <button class="btn btn-outline-success btn-sm ml-1 room-cart-btn" 
                            data-order-id="<?= htmlspecialchars($order['id']) ?>"
                            data-room-id="<?= htmlspecialchars($room['id']) ?>"
                            data-room-name="<?= htmlspecialchars($room['name']) ?>"
                            title="购买商品">
                            <i class="fas fa-shopping-cart"></i>
                        </button>
                        <button class="btn btn-outline-secondary btn-sm ml-1 room-actions-toggle" 
                            data-room-id="<?= htmlspecialchars($room['id']) ?>"
                            title="更多操作">
                            <i class="fas fa-arrow-right"></i>
                        </button>
                        <span class="room-actions-group" style="display: none;">
                            <?php if ($room['device_enabled'] == 1): ?>
<?php
$commandsArr = [];
$rawCommands = json_decode($room['device_commands'], true);
if (is_array($rawCommands)) {
    foreach ($rawCommands as $device => $cmds) {
        $commandsArr[] = [
            'device' => $device,
            'on' => $cmds['开'] ?? '',
            'off' => $cmds['关'] ?? ''
        ];
    }
}
$commandsJson = json_encode($commandsArr, JSON_UNESCAPED_UNICODE);
?>
<button class="btn btn-outline-info btn-sm ml-1 device-control-btn room-action-item" 
    data-room-id="<?= htmlspecialchars($room['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    data-device-commands='<?= htmlspecialchars($commandsJson) ?>'
    title="设备控制">
    <i class="fas fa-sliders-h"></i>
</button>
<?php endif; ?>
<button class="btn btn-outline-info btn-sm ml-1 room-transfer-btn room-action-item" 
    data-order-id="<?= htmlspecialchars($order['id']) ?>"
    data-room-id="<?= htmlspecialchars($room['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    title="更换<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>">
    <i class="fas fa-random"></i>
</button>
<button class="btn btn-outline-warning btn-sm ml-1 order-notes-btn room-action-item" 
    data-order-id="<?= htmlspecialchars($order['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    title="订单备注">
    <i class="fas fa-sticky-note"></i>
</button>
<button class="btn btn-outline-secondary btn-sm ml-1 order-pause-btn room-action-item" 
    data-order-id="<?= htmlspecialchars($order['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    title="暂停计时">
    <i class="fas fa-pause"></i>
</button>
<?php if ($order_edit_enabled): ?>
<button class="btn btn-outline-info btn-sm ml-1 order-edit-btn room-action-item" 
    data-order-id="<?= htmlspecialchars($order['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    data-start-time="<?= htmlspecialchars($order['start_time']) ?>"
    data-end-time="<?= htmlspecialchars($order['expected_end_time']) ?>"
    title="编辑订单时间">
    <i class="fas fa-clock"></i>
</button>
<?php endif; ?>
                        </span>
                        <?php else: ?>
                        <?php if ($room['device_enabled'] == 1): ?>
<?php
$commandsArr = [];
$rawCommands = json_decode($room['device_commands'], true);
if (is_array($rawCommands)) {
    foreach ($rawCommands as $device => $cmds) {
        $commandsArr[] = [
            'device' => $device,
            'on' => $cmds['开'] ?? '',
            'off' => $cmds['关'] ?? ''
        ];
    }
}
$commandsJson = json_encode($commandsArr, JSON_UNESCAPED_UNICODE);
?>
<button class="btn btn-outline-info btn-sm ml-1 device-control-btn" 
    data-room-id="<?= htmlspecialchars($room['id']) ?>"
    data-room-name="<?= htmlspecialchars($room['name']) ?>"
    data-device-commands='<?= htmlspecialchars($commandsJson) ?>'
    title="设备控制">
    <i class="fas fa-sliders-h"></i>
</button>
<?php endif; ?>
                        <?php endif; ?>
                    </h5>
                    <div class="room-status-container position-relative">
                        <?php if ($order): ?>
                        <div class="pause-overlay" style="display: <?= (isset($order['is_paused']) && $order['is_paused'] == 1) ? 'flex' : 'none' ?>;">
                            <div class="pause-content">
                                <div class="pause-text">
                                    <span>计时已暂停</span>
                                </div>
                                <button class="btn btn-success btn-sm order-resume-btn">
                                    <i class="fas fa-play-circle mr-1"></i>恢复计时
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="countdown-area" style="position:relative;">
                            <div class="alert-control" data-id="<?= htmlspecialchars($room['id']) ?>"></div>
                            <?php if ($order): 
                                $startTime = new DateTime($order['start_time']);
                                $endTime = new DateTime($order['expected_end_time']);
                                ?>
                                <div class="timer" 
                                    data-start="<?= htmlspecialchars($startTime->format('c')) ?>" 
                                    data-end="<?= htmlspecialchars($endTime->format('c')) ?>" 
                                    data-timer-mode="<?= intval($order['timer_mode'] ?? 0) ?>">
                                    <i class="fas <?= intval($order['timer_mode'] ?? 0) === 1 ? 'fa-stopwatch' : 'fa-hourglass-half' ?> mr-1 timer-mode-icon"></i>计算中...
                                </div>
                                <div class="room-income-wrapper" style="display: flex; align-items: center; gap: 4px;">
                                    <?php if (isset($order_promotions[$order['id']])): ?>
                                    <span class="promotion-icon" data-order-id="<?= htmlspecialchars($order['id']) ?>" data-room-id="<?= htmlspecialchars($room['id']) ?>" title="套餐详情" style="cursor: pointer; line-height: 1;">
                                        <i class="fas fa-tags text-primary" style="font-size: 14px;"></i>
                                    </span>
                                    <?php endif; ?>
                                    <div class="room-income"<?= ($has_credit || $order_amount_is_zero) ? ' style="color: #dc3545"' : ' style="color: #28a745"' ?>>
                                        ¥<?= number_format($total_income, 2) ?>
                                    </div>
                                    <?php if (($visibleConfigs['guest_count_enabled'] ?? '0') === '1' && !empty($order['guest_count']) && $order['guest_count'] > 0): ?>
                                    <span class="guest-count-badge" title="房间人次">
                                        <i class="icon-guest"></i><span class="guest-count-num"><?= (int)$order['guest_count'] ?></span>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="middle-area">
                            <?php if ($order): ?>
                                <div class="time-info-area">
                                    <div class="start-time">
                                        <small class="text-muted">
                                            <span class="time-label">开始时间：</span><span class="time-value" title="<?= htmlspecialchars($startTime->format('m月d日 H:i')) ?>"><?= htmlspecialchars($startTime->format('H:i')) ?></span>
                                        </small>
                                    </div>
                                    <div class="end-time">
                                        <small class="text-muted">
                                            <span class="time-label">结束时间：</span><span class="time-value" title="<?= htmlspecialchars($endTime->format('m月d日 H:i')) ?>"><?= htmlspecialchars($endTime->format('H:i')) ?></span>
                                        </small>
                                    </div>
                                </div>
                                <div class="action-buttons-area">
                                    <button class="btn btn-warning btn-sm extend-time" 
                                        data-id="<?= htmlspecialchars($order['id']) ?>"
                                        data-room="<?= htmlspecialchars($room['name']) ?>">
                                        <i class="fas fa-plus-circle mr-1"></i>加时
                                    </button>
                                    <button class="btn btn-danger btn-sm checkout" 
                                        data-id="<?= htmlspecialchars($order['id']) ?>"
                                        data-room="<?= htmlspecialchars($room['name']) ?>">
                                        <i class="fas fa-stopwatch mr-1"></i>结账
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="idle-info-area">
                                    <span class="badge badge-success">空闲中</span>
                                </div>
                                <div class="action-buttons-area">
                                    <button class="btn btn-success btn-sm open" 
                                            data-id="<?= htmlspecialchars($room['id']) ?>">
                                        <i class="fas fa-play-circle mr-1"></i>使用
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="border-primary rounded p-2 bg-light reservation-box">
                        <div class="d-flex justify-content-between align-items-center" style="white-space: nowrap; overflow: hidden;">
                            <?php if ($reservation): 
                            $reservationTime = new DateTime($reservation['reservation_time']);
                            $now = new DateTime();
                            $isOverdue = $now > $reservationTime;
                            $diff = $isOverdue ? $now->diff($reservationTime) : null;
                            $overdueMinutes = $isOverdue ? ($diff->days * 24 * 60 + $diff->h * 60 + $diff->i) : 0;
                            ?>
                                <div class="reservation-info <?= $isOverdue ? 'text-danger' : '' ?>" style="flex-shrink: 0;">
                                    <i class="fas fa-clock"></i>
                                    <span class="reservation-time <?= $isOverdue ? 'text-danger' : 'text-black' ?> font-weight-bold mr-2"
                                        data-time="<?= htmlspecialchars($reservationTime->format('c')) ?>"
                                        data-before-seconds="10"
                                        title="<?= htmlspecialchars($reservationTime->format('m 月 d 日 H:i')) ?>">
                                        <?= htmlspecialchars($reservationTime->format('H:i')) ?>
                                    </span>
                                    <?php if($isOverdue): ?>
                                        <span class="badge badge-danger">已超时</span>
                                    <?php endif; ?>
                                </div>
                                <div class="reservation-actions" style="flex-shrink: 0;">
                                <?php if($reservation_count > 1): ?>
                                        <button class="btn btn-sm btn-outline-primary room-reservation-count ml-1" 
                                               data-room-id="<?= htmlspecialchars($room['id']) ?>"
                                               title="查看所有预定">
                                            <strong><?= $reservation_count ?></strong>
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-sm btn-outline-primary view-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="查看详情">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <!-- 
                                    <button class="btn btn-sm btn-outline-success edit-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="编辑预定">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                     -->                                   
                                    <button class="btn btn-sm btn-outline-danger cancel-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="取消预定">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-info reserve" 
                                            data-id="<?= htmlspecialchars($room['id']) ?>"
                                            title="添加预定">
                                        <i class="fas fa-calendar-plus"></i>
                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="text-muted" style="flex-shrink: 0;">
                                    <i class="far fa-calendar"></i> 无预定
                                </div>
                                <button class="btn btn-outline-info btn-sm btn-reserve reserve" 
                                        data-id="<?= htmlspecialchars($room['id']) ?>"
                                        style="flex-shrink: 0;">
                                    <i class="fas fa-calendar-plus"></i> 预定
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            }
        }
        ?>
    </div>
    </div>
    <?php endif; ?>
    <?php if ($feature_switch['product']): ?>
    <div class="tab-pane fade" id="productContainer" role="tabpanel">
    <div class="row">
        <div class="col-12 mb-3" style="margin-top: 5px;">
            <h4 class="border-bottom pb-2" style="font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center;">
                <span style="flex-shrink: 0;"><i class="fas fa-shopping-cart mr-2"></i><span class="title-text-full">商品销售</span><span class="title-text-short">商品</span></span>
                <div id="productTypeQuickBtns" style="display: none; flex: 1; overflow-x: auto; overflow-y: hidden; margin: 0 80px 0 80px;">
                    <div style="display: flex; gap: 20px; flex-wrap: nowrap; align-items: center;">
                    </div>
                </div>
                <div style="display: flex; gap: 10px; align-items: center; flex-shrink: 0;">
                    <button class="btn btn-sm btn-outline-primary" id="viewTimeCardsBtn">
                        <i class="fas fa-ticket-alt mr-1"></i><span class="btn-text">次卡券</span>
                    </button>
                    <button class="btn btn-sm btn-outline-primary" id="viewCartBtn" style="position: relative;">
                        <i class="fas fa-shopping-cart mr-1"></i><span class="btn-text">购物车</span>
                        <span class="badge badge-danger" id="cartBadgeHeader" style="position: absolute; top: -8px; right: -8px; display: none;">0</span>
                    </button>
                    <button class="btn btn-outline-secondary btn-sm" id="productTypeFilterBtn" style="border-radius: 4px; min-width: 60px;">
                        <i class="fas fa-filter mr-1"></i><span id="currentProductFilterText" class="btn-text" style="display: inline; line-height: inherit; font-size: inherit;">筛选</span>
                    </button>
                </div>
            </h4>
        </div>
        <div class="col-12" style="margin-top: -20px;">
            <div id="productAlertsContainer" class="mb-1" style="max-width:auto; margin:0 auto 8px;"></div>
        </div>
        <?php
        if (!isset($static_data['products']) || empty($static_data['products'])) {
            echo '<div class="col-12 alert alert-warning" id="productEmptyAlert">尚未添加任何商品，请先到<a href="admin.php#productSection" target="_blank">管理页面</a>添加</div>';
        } else {
            foreach ($static_data['products'] as $product) {
        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3">
            <div class="card product-card h-100" data-product-id="<?= htmlspecialchars($product['id']) ?>" data-product-type="<?= htmlspecialchars(strtoupper($product['type'])) ?>">
                <div class="card-body text-center" style="display: flex; flex-direction: column; padding: 1rem;">
                    <div style="flex: 1; display: flex; flex-direction: column;">
                        <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                        <p class="card-text text-muted"><?= htmlspecialchars(strtoupper($product['type'])) ?></p>
                    </div>
                    <div style="margin-top: auto;">
                        <div class="price-tag my-3">
                            <span class="text-danger font-weight-bold">¥<?= number_format((float)$product['price'], 2) ?></span>
                        </div>
                        <button class="btn btn-sm btn-outline-primary buy-product" 
                                data-id="<?= htmlspecialchars($product['id']) ?>"
                                data-name="<?= htmlspecialchars($product['name']) ?>"
                                data-price="<?= htmlspecialchars($product['price']) ?>"
                                data-member-discount="<?= htmlspecialchars($product['member_discount']) ?>"
                                data-enable-member-levels-discount="<?= htmlspecialchars($product['enable_member_levels_discount'] ?? 1) ?>"
                                data-is-time-card="false"
                                style="width: 100%;">
                            <i class="fas fa-shopping-bag mr-1"></i>购买
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            }
        }
        ?>
        <div class="col-12" id="timeCardEmptyState" style="display:none;">
            <div class="text-center p-5 bg-light rounded shadow-sm">
                <i class="fas fa-ticket-alt fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">当前没有任何次卡券</h5>
                <p class="text-muted small mb-0">可以在后台管理页面添加次卡券商品</p>
            </div>
        </div>
        <?php
        if (isset($static_data['time_cards']) && !empty($static_data['time_cards'])) {
            foreach ($static_data['time_cards'] as $timeCard) {
        ?>
        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 mb-3" style="display:none;">
            <div class="card product-card time-card-card h-100" data-product-id="timecard_<?= htmlspecialchars($timeCard['id']) ?>" data-product-type="次卡券" data-is-time-card="true" style="border: 2px solid #17a2b8; background: linear-gradient(135deg, #f8f9fa 0%, #e3f2fd 100%);">
                <div class="card-body text-center" style="display: flex; flex-direction: column; padding: 1rem;">
                    <div style="flex: 1; display: flex; flex-direction: column;">
                        <div class="mb-2">
                            <span class="badge badge-info" style="border-radius: 4px; padding: 0.25em 0.5em; line-height: 1.4; vertical-align: middle;">次卡券</span>
                            <span class="badge badge-<?= $timeCard['type'] === 'room' ? 'primary' : 'success' ?>"
                                  style="border-radius: 4px; padding: 0.25em 0.5em; line-height: 1.4; vertical-align: middle;">
                                <?= $timeCard['type'] === 'room' ? htmlspecialchars($SCENE_ROOM_NAME) : '商品' ?>
                            </span>
                        </div>
                        <h5 class="card-title"><?= htmlspecialchars($timeCard['name']) ?></h5>
                        <div class="text-muted small mb-2" style="display: inline-block; text-align: left; max-width: 80%; margin-left: 15%;">
                            <?php if ($timeCard['type'] === 'room' && $timeCard['hours'] > 0): ?>
                            <div><i class="fas fa-ticket-alt mr-1" style="width: 14px; display: inline-block;"></i><?= htmlspecialchars($timeCard['total_times']) ?>次 <i class="fas fa-clock ml-2 mr-1" style="width: 14px; display: inline-block;"></i><?= htmlspecialchars($timeCard['hours']) ?>小时/次</div>
                            <?php else: ?>
                            <div><i class="fas fa-ticket-alt mr-1" style="width: 14px; display: inline-block;"></i><?= htmlspecialchars($timeCard['total_times']) ?>次</div>
                            <?php endif; ?>
                            <div><i class="fas fa-calendar-alt mr-1" style="width: 14px; display: inline-block;"></i><?= $timeCard['validity_days'] ? htmlspecialchars($timeCard['validity_days']) . '天' : '永久' ?></div>
                            <?php 
                            $applicableText = '';
                            $applicableIcon = '';
                            $applicableTitle = '';
                            if ($timeCard['type'] === 'room') {
                                if (empty($timeCard['room_ids']) || $timeCard['room_ids'] === null) {
                                    $applicableText = '全部' . $SCENE_ROOM_NAME;
                                    $applicableIcon = 'fa-home';
                                    $applicableTitle = '全部' . $SCENE_ROOM_NAME;
                                } else {
                                    $roomIdsArray = json_decode($timeCard['room_ids'], true);
                                    $roomCount = is_array($roomIdsArray) ? count($roomIdsArray) : 0;
                                    $applicableText = $roomCount . '个' . $SCENE_ROOM_NAME;
                                    $applicableIcon = 'fa-home';
                                    if ($roomCount > 0) {
                                        $roomIdsStr = implode(',', array_map('intval', $roomIdsArray));
                                        $roomNamesQuery = "SELECT name FROM rooms WHERE id IN ($roomIdsStr) ORDER BY sort_order, id";
                                        $roomNamesResult = $conn->query($roomNamesQuery);
                                        $roomNames = [];
                                        if ($roomNamesResult) {
                                            while ($roomRow = $roomNamesResult->fetch_assoc()) {
                                                $roomNames[] = $roomRow['name'];
                                            }
                                        }
                                        $applicableTitle = !empty($roomNames) ? implode('、', $roomNames) : $roomCount . '个' . $SCENE_ROOM_NAME;
                                    } else {
                                        $applicableTitle = '未指定' . $SCENE_ROOM_NAME;
                                    }
                                }
                            } else {
                                if (empty($timeCard['product_ids']) || $timeCard['product_ids'] === null) {
                                    $applicableText = '全部商品';
                                    $applicableIcon = 'fa-shopping-cart';
                                    $applicableTitle = '全部商品';
                                } else {
                                    $productIdsArray = json_decode($timeCard['product_ids'], true);
                                    $productCount = is_array($productIdsArray) ? count($productIdsArray) : 0;
                                    $applicableText = $productCount . '个商品';
                                    $applicableIcon = 'fa-shopping-cart';
                                    if ($productCount > 0) {
                                        $productIdsStr = implode(',', array_map('intval', $productIdsArray));
                                        $productNamesQuery = "SELECT name FROM products WHERE id IN ($productIdsStr) ORDER BY sort_order, id";
                                        $productNamesResult = $conn->query($productNamesQuery);
                                        $productNames = [];
                                        if ($productNamesResult) {
                                            while ($productRow = $productNamesResult->fetch_assoc()) {
                                                $productNames[] = $productRow['name'];
                                            }
                                        }
                                        $applicableTitle = !empty($productNames) ? implode('、', $productNames) : $productCount . '个商品';
                                    } else {
                                        $applicableTitle = '未指定商品';
                                    }
                                }
                            }
                            ?>
                            <div title="<?= htmlspecialchars($applicableTitle) ?>"><i class="fas <?= $applicableIcon ?> mr-1" style="width: 14px; display: inline-block;"></i><?= $applicableText ?></div>
                        </div>
                    </div>
                    <div style="margin-top: auto;">
                        <div class="price-tag my-3">
                            <span class="text-danger font-weight-bold">¥<?= number_format((float)$timeCard['price'], 2) ?></span>
                        </div>
                        <?php 
                        $applicableText = '';
                        if ($timeCard['type'] === 'room') {
                            if (empty($timeCard['room_ids']) || $timeCard['room_ids'] === null) {
                                $applicableText = '全部' . $SCENE_ROOM_NAME;
                            } else {
                                $roomIdsArray = json_decode($timeCard['room_ids'], true);
                                $roomCount = is_array($roomIdsArray) ? count($roomIdsArray) : 0;
                                $applicableText = $roomCount . '个' . $SCENE_ROOM_NAME;
                            }
                        } else {
                            if (empty($timeCard['product_ids']) || $timeCard['product_ids'] === null) {
                                $applicableText = '全部商品';
                            } else {
                                $productIdsArray = json_decode($timeCard['product_ids'], true);
                                $productCount = is_array($productIdsArray) ? count($productIdsArray) : 0;
                                $applicableText = $productCount . '个商品';
                            }
                        }
                        ?>
                        <button class="btn btn-sm btn-outline-info buy-product" 
                                data-id="timecard_<?= htmlspecialchars($timeCard['id']) ?>"
                                data-name="<?= htmlspecialchars($timeCard['name']) ?>"
                                data-price="<?= htmlspecialchars($timeCard['price']) ?>"
                                data-member-discount="<?= htmlspecialchars($timeCard['member_discount']) ?>"
                                data-enable-member-levels-discount="<?= htmlspecialchars($timeCard['enable_member_levels_discount'] ?? 1) ?>"
                                data-is-time-card="true"
                                data-time-card-type="<?= htmlspecialchars($timeCard['type']) ?>"
                                data-time-card-times="<?= htmlspecialchars($timeCard['total_times']) ?>"
                                data-time-card-hours="<?= htmlspecialchars($timeCard['hours'] ?? 0) ?>"
                                data-time-card-validity="<?= htmlspecialchars($timeCard['validity_days'] ?? '') ?>"
                                data-time-card-applicable="<?= htmlspecialchars($applicableText) ?>"
                                style="width: 100%;">
                            <i class="fas fa-shopping-bag mr-1"></i>购买
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php 
            }
        }
        ?>
    </div>
    </div>
    <?php endif; ?>
    <?php if ($feature_switch['room']): ?>
    <div class="tab-pane fade" id="reservationContainer" role="tabpanel">
    <div class="row">
        <div class="col-12 mb-3" style="margin-top: 5px;">
            <h4 class="border-bottom pb-2" style="font-size: 1.1rem; display: flex; justify-content: space-between; align-items: center;">
                <span style="flex-shrink: 0;"><i class="fas fa-calendar-alt mr-2"></i><span class="title-text-full">预定管理</span><span class="title-text-short">预定</span></span>
                <div id="reservationQuickBtns" style="display: none; flex: 1; overflow-x: auto; overflow-y: hidden; margin: 0 10px 0 80px;">
                    <div style="display: flex; gap: 20px; flex-wrap: nowrap; align-items: center;">
                    </div>
                </div>
                <div style="flex-shrink: 0; min-width: 10px;"></div>
            </h4>
        </div>
        <?php
        if ($grace_minutes > 0) {
            $rooms_with_reservations_sql = "
                SELECT r.*, COUNT(res.id) as reservation_count 
                FROM rooms r
                JOIN reservations res ON r.id = res.room_id
                WHERE r.is_deleted = 0 
                AND (
                    res.status = 0
                    OR (res.status = 1 AND TIMESTAMPDIFF(MINUTE, res.reservation_time, NOW()) <= $grace_minutes)
                )
                GROUP BY r.id
                ORDER BY r.sort_order, r.id
            ";
        } else {
            $rooms_with_reservations_sql = "
                SELECT r.*, COUNT(res.id) as reservation_count 
                FROM rooms r
                JOIN reservations res ON r.id = res.room_id
                WHERE r.is_deleted = 0 AND res.status = 0
                GROUP BY r.id
                ORDER BY r.sort_order, r.id
            ";
        }
        $rooms_with_reservations_result = $conn->query($rooms_with_reservations_sql);
        if (!$rooms_with_reservations_result) {
            echo "<div class='col-12 alert alert-danger'>预定数据加载失败：".htmlspecialchars($conn->error)."</div>";
        } else if ($rooms_with_reservations_result->num_rows === 0) {
            echo '<div class="col-12">
                    <div class="text-center p-5 bg-light rounded shadow-sm">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">当前没有任何预定信息</h5>
                        <p class="text-muted small mb-0">可以在<?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>管理页面添加预定</p>
                    </div>
                  </div>';
        } else {
            echo '<div class="col-12">
                    <div id="reservationAlertsContainer" class="mb-1" style="max-width:auto; margin:0 auto 8px;"></div>
                  </div>';
            if ($grace_minutes > 0) {
                $rooms_display_sql = "
                    SELECT r.*, COUNT(res.id) as reservation_count,
                           MIN(res.reservation_time) as earliest_reservation
                    FROM rooms r
                    JOIN reservations res ON r.id = res.room_id
                    WHERE r.is_deleted = 0 
                    AND (
                        res.status = 0
                        OR (res.status = 1 AND TIMESTAMPDIFF(MINUTE, res.reservation_time, NOW()) <= $grace_minutes)
                    )
                    GROUP BY r.id
                    ORDER BY earliest_reservation ASC, r.sort_order ASC, r.id ASC
                ";
            } else {
                $rooms_display_sql = "
                    SELECT r.*, COUNT(res.id) as reservation_count,
                           MIN(res.reservation_time) as earliest_reservation
                    FROM rooms r
                    JOIN reservations res ON r.id = res.room_id
                    WHERE r.is_deleted = 0 AND res.status = 0
                    GROUP BY r.id
                    ORDER BY earliest_reservation ASC, r.sort_order ASC, r.id ASC
                ";
            }
            $rooms_display_result = $conn->query($rooms_display_sql);
            $all_reservations = [];
            if ($rooms_display_result && $rooms_display_result->num_rows > 0) {
                $room_ids_with_res = [];
                $rooms_display_result->data_seek(0); 
                while ($room = $rooms_display_result->fetch_assoc()) {
                    $room_ids_with_res[] = $room['id'];
                }
                if (!empty($room_ids_with_res)) {
                    $room_ids_str = implode(',', array_map('intval', $room_ids_with_res));
                    if ($grace_minutes > 0) {
                        $all_reservations_sql = "
                            SELECT * FROM reservations 
                            WHERE room_id IN ($room_ids_str)
                            AND (
                                status = 0
                                OR (status = 1 AND TIMESTAMPDIFF(MINUTE, reservation_time, NOW()) <= $grace_minutes)
                            )
                            ORDER BY room_id, reservation_time ASC
                        ";
                    } else {
                        $all_reservations_sql = "
                            SELECT * FROM reservations 
                            WHERE room_id IN ($room_ids_str) AND status = 0
                            ORDER BY room_id, reservation_time ASC
                        ";
                    }
                    $all_reservations_result = $conn->query($all_reservations_sql);
                    if ($all_reservations_result) {
                        while ($res = $all_reservations_result->fetch_assoc()) {
                            if (!isset($all_reservations[$res['room_id']])) {
                                $all_reservations[$res['room_id']] = [];
                            }
                            $all_reservations[$res['room_id']][] = $res;
                        }
                        $all_reservations_result->free();
                    }
                }
            }
            $rooms_display_result->data_seek(0); 
            while ($room = $rooms_display_result->fetch_assoc()) {
                $room_reservations = isset($all_reservations[$room['id']]) ? $all_reservations[$room['id']] : [];
                if (!empty($room_reservations)) {
        ?>
        <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 mb-3" data-sort-order="<?= htmlspecialchars($room['sort_order']) ?>">
            <div class="card room-card reservation-room-card" data-room-id="<?= htmlspecialchars($room['id']) ?>">
                <div class="card-body position-relative">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0 font-weight-bold">
                            <i class="fas fa-home mr-2"></i><?= htmlspecialchars($room['name']) ?>
                        </h5>
                        <span class="badge badge-pill badge-success">
                            <i class="fas fa-calendar-check mr-1"></i><?= $room['reservation_count'] ?>个预定
                        </span>
                    </div>
                    <div class="reservation-list border-top pt-2">
                    <?php 
                        foreach ($room_reservations as $reservation) {
                            $reservationTime = new DateTime($reservation['reservation_time']);
                            $now = new DateTime();
                            $isOverdue = $now > $reservationTime;
                            $diff = $now->diff($reservationTime);
                            $diffSeconds = $isOverdue ? -($diff->days * 86400 + $diff->h * 3600 + $diff->i * 60 + $diff->s) : ($diff->days * 86400 + $diff->h * 3600 + $diff->i * 60 + $diff->s);
                            $beforeTenSeconds = $diffSeconds < 10;
                            $diffMinutes = $diff->days * 24 * 60 + $diff->h * 60 + $diff->i;
                            $diffHours = floor($diffMinutes / 60);
                            $diffMinutes = $diffMinutes % 60;
                            $timeDisplay = '';
                            if ($diffHours > 0) {
                                $timeDisplay .= $diffHours . '小时';
                            }
                            if ($diffMinutes > 0 || $diffHours == 0) {
                                $timeDisplay .= $diffMinutes . '分钟';
                            }
                            $timeDisplay .= $isOverdue ? '前' : '后';
                            $itemClass = $isOverdue ? 'bg-light-danger' : 'bg-light-primary';
                            $timeClass = $beforeTenSeconds ? 'text-danger' : 'text-primary';
                            $badgeClass = 'badge-danger';
                            if (!$isOverdue) {
                                $totalMinutes = $diffHours * 60 + $diffMinutes;
                                if ($totalMinutes > 60) {
                                    $badgeClass = 'badge-success';
                                } else {
                                    $badgeClass = 'badge-warning';
                                }
                            }
                    ?>
                        <div class="reservation-item <?= $itemClass ?> p-2 border-bottom">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div>
                                    <div class="d-flex align-items-center">
                                        <span class="reservation-time <?= $timeClass ?> font-weight-bold mr-2"
                                            data-time="<?= htmlspecialchars($reservationTime->format('c')) ?>"
                                            data-before-seconds="10">
                                            <i class="<?= $isOverdue ? 'fas fa-exclamation-circle' : 'far fa-clock' ?> mr-1"></i>
                                            <span class="date-part"><?= htmlspecialchars($reservationTime->format('m-d')) ?></span><br>
                                            <span class="time-part"><?= htmlspecialchars($reservationTime->format('H:i')) ?></span>
                                        </span>
                                        <span class="badge <?= $badgeClass ?> badge-pill">
                                            <?= $isOverdue ? '已超时' . ($diffHours > 0 ? $diffHours . '小时' : '') . ($diffMinutes > 0 || $diffHours == 0 ? $diffMinutes . '分钟' : '') : $timeDisplay ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="reservation-actions">
                                    <button class="btn btn-sm btn-outline-primary view-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="查看详情">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-success edit-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="编辑预定">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger cancel-reservation" 
                                            data-id="<?= htmlspecialchars($reservation['id']) ?>"
                                            title="取消预定">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                            <?php if (!empty($reservation['phone'])): ?>
                            <div class="info-pill phone-info mt-2">
                                <i class="fas fa-phone fa-fw mr-1" style="color: #6c757d;"></i>
                                <span><?= htmlspecialchars($reservation['phone']) ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if (!empty($reservation['notes'])): ?>
                            <div class="info-pill note-info mt-1">
                                <i class="fas fa-comment-alt mr-1"></i>
                                <span><?= htmlspecialchars(mb_strlen($reservation['notes']) > 30 ? mb_substr($reservation['notes'], 0, 30) . '...' : $reservation['notes']) ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php } ?>
                    </div>
                    <div class="text-center mt-3">
                        <button class="btn btn-outline-primary btn-sm reserve" 
                                data-id="<?= htmlspecialchars($room['id']) ?>">
                            <i class="fas fa-calendar-plus mr-1"></i>添加预定
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php
                }
            }
        }
        ?>
    </div>
    </div>
    <?php endif; ?>
    <?php if ($feature_switch['member']): ?>
    <div class="tab-pane fade" id="memberCardContainer" role="tabpanel">
    <div class="row">
        <div class="col-12 mb-3" style="margin-top: -2px;">
            <h4 class="border-bottom pb-2" style="font-size: 1.1rem; display: flex; align-items: center;"><i class="fas fa-id-card mr-2"></i><span class="title-keep-full">会员服务</span></h4>
        </div>
        <div class="col-12" style="margin-top: -20px;">
            <div id="rechargeAlertsContainer" class="mb-1" style="max-width:auto; margin:0 auto 8px;"></div>
        </div>
        <div class="col-12 d-flex justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body p-3" id="rechargeSection">
                        <div id="memberAlertsContainer" class="mb-3"></div>
                        <form id="rechargeForm" class="needs-validation" novalidate>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="font-weight-bold mb-0">开卡充值</h5>
                                <div>
                                    <button type="button" id="btnTimeCardEntry" class="btn btn-outline-primary btn-sm mr-2">
                                        <i class="fas fa-ticket-alt btn-icon-margin"></i><span class="btn-text">次卡券购买</span>
                                    </button>
                                    <button type="button" id="btnMemberQuery" class="btn btn-outline-primary btn-sm mr-2">
                                        <i class="fas fa-search btn-icon-margin"></i><span class="btn-text">记录查询</span>
                                    </button>
                                    <button type="button" id="btnChangeMember" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-edit btn-icon-margin"></i><span class="btn-text">信息修改</span>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label for="cardNoInput" class="font-weight-bold">手机号</label>
                                <input type="tel" class="form-control form-control-sm" id="cardNoInput" 
                                    placeholder="请输入后四位或完整手机号查询" 
                                    maxlength="11"
                                    oninput="value=value.replace(/[^\d]/g,'')" autocomplete="off">
                                <div class="invalid-feedback small">请输入正确的手机号</div>
                            </div>
                            <div class="form-row mb-2">
                                <div class="col">
                                    <label for="nameInput" class="font-weight-bold">姓名</label>
                                    <input type="text" class="form-control form-control-sm" id="nameInput" 
                                        value="张三" required onfocus="if(this.value=='张三'){this.value='';}" onblur="if(this.value==''){this.value='张三';}" autocomplete="off"
                                        maxlength="6">
                                    <div class="invalid-feedback small">请输入姓名</div>
                                </div>
                                <div class="col">
                                    <label for="memberLevelSelect" class="font-weight-bold">卡类型</label>
                                    <select class="form-control form-control-sm" id="memberLevelSelect" required>
                                        <option value="">加载中...</option>
                                    </select>
                                    <small class="form-text text-muted small" id="levelHint"></small>
                                </div>
                            </div>
                            <div class="form-group mb-2">
                                <label class="font-weight-bold">当前余额</label>
                                <div class="d-flex align-items-center">
                                    <div id="balanceDisplay" class="font-weight-bold text-danger display-4" style="font-size: 28px;">0.00</div>
                                </div>
                            </div>
                            <div class="form-group mb-2" id="timeCardsContainer" style="display: none;">
                                <label class="font-weight-bold mb-1">可用次卡券</label>
                                <div id="timeCardsList" class="border rounded p-2 bg-light" style="max-height: 200px; overflow-y: auto;">
                                </div>
                            </div>
                            <div class="form-group mb-2" id="passwordInputGroup" style="display: none;">
                                <div class="row">
                                    <div class="col">
                                        <label for="passwordInput" class="font-weight-bold">
                                            设置密码<small>（数字类型）</small>
                                        </label>
                                        <input type="password" class="form-control form-control-sm" id="passwordInput" 
                                            placeholder="请输入至少6位数字密码" required autocomplete="new-password"
                                            minlength="6" maxlength="20" pattern="[0-9]{6,}" inputmode="numeric">
                                        <div class="invalid-feedback small" style="display:none;">请输入至少6位数字密码</div>
                                    </div>
                                    <div class="col">
                                        <label for="confirmPasswordInput" class="font-weight-bold">确认密码</label>
                                        <input type="password" class="form-control form-control-sm" id="confirmPasswordInput" 
                                            placeholder="请再次输入密码" required autocomplete="new-password"
                                            minlength="6" maxlength="20" pattern="[0-9]{6,}" inputmode="numeric">
                                        <div class="invalid-feedback small" style="display:none;">两次输入的密码不一致</div>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <button type="button" class="btn btn-outline-secondary btn-sm" id="btnSetDefaultPassword">
                                        <i class="fas fa-magic mr-1"></i>设为手机尾号
                                    </button>
                                    <button type="button" class="btn btn-outline-info btn-sm ml-2" id="btnZeroRecharge" style="transition: all 0.2s ease;">
                                        <i class="fas fa-gift mr-1"></i>0元开卡
                                    </button>
                                </div>
                            </div>
                            <div class="form-group mb-2" id="confirmPasswordGroup" style="display: none;"></div>
                            <div class="form-row mb-2">
                                <div class="col">
                                    <label for="rechargeAmountInput" class="font-weight-bold">充值金额</label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" class="form-control" id="rechargeAmountInput" 
                                            placeholder="0.00" required step="0.01" value="0"
                                            min="-5000" max="5000">
                                        <div class="input-group-append">
                                            <span class="input-group-text">元</span>
                                        </div>
                                    </div>
                                    <small class="form-text text-muted small">单次最高5000元</small>
                                </div>
                                <div class="col">
                                    <label for="paymentMethodSelect" class="font-weight-bold">支付方式</label>
                                    <select class="form-control form-control-sm" id="paymentMethodSelect" required>
                                        <option value="">请选择支付方式</option>
                                    </select>
                                    <small class="form-text text-muted small">请选择支付方式</small>
                                </div>
                            </div>
                            <div class="form-row mb-2">
                                <div class="col gift-amount-container">
                                    <label for="giftAmountInput" class="small font-weight-bold">赠送金额</label>
                                    <div class="input-group input-group-sm">
                                        <input type="number" class="form-control" id="giftAmountInput" 
                                            placeholder="0.00" step="0.01" value="0"
                                            min="-3000" max="3000">
                                        <div class="input-group-append">
                                            <span class="input-group-text">元</span>
                                        </div>
                                    </div>
                                    <small class="form-text text-muted small">单次最高3000元</small>
                                </div>
                                <div class="col">
                                    <label class="small font-weight-bold">赠送方式</label>
                                    <input type="text" class="form-control form-control-sm" value="赠送" readonly>
                                    <input type="hidden" id="giftMethodId" value="2">
                                    <small class="form-text text-muted small">系统自动赠送</small>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm btn-block mt-2">
                                <i class="fas fa-exchange-alt mr-1"></i>确认操作
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php endif; ?>
    <?php if ($feature_switch['stats']): ?>
    <div class="tab-pane fade" id="statsContainer" role="tabpanel">
    <div class="row">
        <div class="col-12 mb-3" style="margin-top: -2px;">
            <h4 class="border-bottom pb-2" style="font-size: 1.1rem; display: flex; align-items: center;"><i class="fas fa-chart-line mr-2"></i><span class="title-keep-full">营业统计</span></h4>
        </div>
        <div class="col-12" style="margin-top: -20px;">
            <div id="statsAlertsContainer" class="mb-1" style="max-width:auto; margin:0 auto 8px;"></div>
        </div>
        <div class="col-12 d-flex justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body p-2">
                        <div class="mb-2 text-center">
                            <div class="btn-group btn-group-sm date-selector" role="group" aria-label="日期选择">
                                <button type="button" class="btn btn-outline-secondary" data-days="1" style="width: 60px; font-size: 12px; white-space: nowrap;">今日</button>
                                <button type="button" class="btn btn-outline-secondary" data-days="2" style="width: 60px; font-size: 12px; white-space: nowrap;">昨日</button>
                                <button type="button" class="btn btn-outline-secondary" data-days="3" style="width: 60px; font-size: 12px; white-space: nowrap;">近3天</button>
                                <button type="button" class="btn btn-outline-secondary" data-days="7" style="width: 60px; font-size: 12px; white-space: nowrap;">近7天</button>
                            </div>
                            <input type="hidden" id="startDate">
                            <input type="hidden" id="endDate">
                        </div>
                        <div id="statsArea" class="stats-container">
                            <div class="text-center py-4">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="sr-only">加载中...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php endif; ?>
    </div>
</div>
<div class="modal fade" id="roomTypeFilterModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-filter mr-2"></i><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>筛选
                </h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="mb-3 pb-2 border-bottom">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="roomFilterCombineSwitch">
                            <label class="custom-control-label" for="roomFilterCombineSwitch">
                                组合筛选
                            </label>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-secondary" id="roomFilterClearBtn">
                            <i class="fas fa-eraser mr-1"></i>清除
                        </button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <h6 class="mb-3"><i class="fas fa-tag mr-2"></i><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>类型</h6>
                        <div class="list-group room-type-options">
                            <button type="button" class="list-group-item list-group-item-action active" data-type="all">
                                <i class="fas fa-th-large mr-2"></i>全部类型
                            </button>
                            <?php
                            if (isset($static_data['room_types']) && !empty($static_data['room_types'])) {
                                foreach ($static_data['room_types'] as $type) {
                                    echo '<button type="button" class="list-group-item list-group-item-action" data-type="'.htmlspecialchars(strtoupper($type['type'])).'">
                                        <i class="fas fa-tag mr-2"></i>'.htmlspecialchars($type['type']).'
                                    </button>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <h6 class="mb-3"><i class="fas fa-info-circle mr-2"></i><?php echo htmlspecialchars($SCENE_ROOM_NAME); ?>状态</h6>
                        <div class="list-group room-status-options">
                            <button type="button" class="list-group-item list-group-item-action active" data-status="all">
                                <i class="fas fa-th-large mr-2"></i>全部状态
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="idle">
                                <i class="fas fa-circle text-dark mr-2"></i>空闲中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="in-use">
                                <i class="fas fa-circle text-primary mr-2"></i>使用中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="reserved">
                                <i class="fas fa-circle text-success mr-2"></i>预定中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="paused">
                                <i class="fas fa-circle text-secondary mr-2"></i>暂停中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="credit">
                                <i class="fas fa-circle text-warning mr-2"></i>挂单中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="alert">
                                <i class="fas fa-circle text-info mr-2"></i>提醒中
                            </button>
                            <button type="button" class="list-group-item list-group-item-action" data-status="overtime">
                                <i class="fas fa-circle text-danger mr-2"></i>已超时
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="productTypeFilterModal">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-filter mr-2"></i>商品类型筛选
                </h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="list-group product-type-options">
                    <button type="button" class="list-group-item list-group-item-action active" data-type="all">
                        <i class="fas fa-th-large mr-2"></i>全部类型
                    </button>
                    <?php
                    if (isset($static_data['product_types']) && !empty($static_data['product_types'])) {
                        foreach ($static_data['product_types'] as $type) {
                            echo '<button type="button" class="list-group-item list-group-item-action" data-type="'.htmlspecialchars($type['type']).'">
                                <i class="fas fa-tag mr-2"></i>'.htmlspecialchars($type['type']).'
                            </button>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="back-to-top">
    <i class="fas fa-arrow-up"></i>
</div>
<script src="/asset/roomindex.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/roomindex.js') ?>"></script>
<script src="/asset/print.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/print.js') ?>"></script>
<script src="/asset/room.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/room.js') ?>"></script>
<script src="/asset/reservation.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/reservation.js') ?>"></script>
<script src="/asset/product.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/product.js') ?>"></script>
<script src="/asset/member.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/member.js') ?>"></script>
<script src="/asset/stats.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/stats.js') ?>"></script>
<script src="/asset/updates.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/updates.js') ?>"></script>
<script src="/asset/websocket.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/websocket.js') ?>"></script>
<script>
$(window).on('load', function() {
    setTimeout(function() {
        $('#pageLoader').addClass('fade-out');
        $('body').removeClass('loading').addClass('loaded');
        setTimeout(function() {
            $('#pageLoader').remove();
        }, 300);
    }, 100);
});
setTimeout(function() {
    if ($('#pageLoader').length) {
        $('#pageLoader').addClass('fade-out');
        $('body').removeClass('loading').addClass('loaded');
        setTimeout(function() {
            $('#pageLoader').remove();
        }, 300);
    }
}, 5000);
$(function() {
    var $btn = $('.back-to-top');
    $('#nav-member').one('shown.bs.tab', function() {
        if (window.app && window.app.member && !window.app.member._memberLevelsLoaded) {
            window.app.member._memberLevelsLoaded = true;
            window.app.member.loadMemberLevels(true, null);
        }
    });
    $('#nav-stats').one('shown.bs.tab', function() {
        if (window.app && window.app.stats) {
            window.app.stats.setDateRange(1);
        }
    });
    function updateBackToTop() {
        var scrollTop = Math.max(
            window.pageYOffset || 0,
            document.documentElement.scrollTop || 0,
            document.body.scrollTop || 0,
            $(window).scrollTop() || 0,
            $('html').scrollTop() || 0,
            $('body').scrollTop() || 0
        );
        if (scrollTop > 300) {
            $btn.addClass('visible');
        } else {
            $btn.removeClass('visible');
        }
    }
    $(window).on('scroll', updateBackToTop);
    $(document).on('scroll', updateBackToTop);
    $('body').on('scroll', updateBackToTop);
    $btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, 500);
        return false;
    });
    updateBackToTop();
    setTimeout(updateBackToTop, 100);
    setTimeout(updateBackToTop, 500);
    setTimeout(function() {
        $('.main-navbar .nav-link[data-toggle="tab"]').on('mouseenter', function() {
            const $this = $(this);
            const href = $this.attr('href');
            if (href) {
                $this.data('temp-href', href).removeAttr('href');
            }
        }).on('mouseleave', function() {
            const $this = $(this);
            const href = $this.data('temp-href');
            if (href && !$this.attr('href')) {
                $this.attr('href', href);
            }
        }).on('mousedown', function(e) {
            const $this = $(this);
            const href = $this.data('temp-href');
            if (href) {
                $this.attr('href', href);
                $this.tab('show');
                setTimeout(function() {
                    $this.removeAttr('href');
                }, 0);
                e.preventDefault();
            }
        });
        $('.main-navbar .nav-link[target="_blank"]').on('mouseenter', function() {
            const $this = $(this);
            const href = $this.attr('href');
            if (href && href !== 'javascript:void(0)') {
                $this.data('temp-href', href).removeAttr('href');
            }
        }).on('mouseleave click', function() {
            const $this = $(this);
            const href = $this.data('temp-href');
            if (href && !$this.attr('href')) {
                $this.attr('href', href);
            }
        });
    }, 200); 
});
</script>
</body>
</html>