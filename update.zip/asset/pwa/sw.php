<?php
 header('Content-Type: text/javascript; charset=utf-8'); header('Service-Worker-Allowed: /'); header('Cache-Control: no-cache'); ?>
self.addEventListener('install', function () {
  self.skipWaiting();
});
self.addEventListener('activate', function (event) {
  event.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', function () {
});
