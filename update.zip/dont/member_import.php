<?php
/**
 * 会员数据导入工具
 * 单文件版本 - 支持CSV文件导入到member_accounts表
 */

// 数据库配置
date_default_timezone_set('Asia/Shanghai');
$dbHost = 'localhost';
$dbUser = 'root';
$dbPassword = 'room258456room';
$dbName = 'room_management';

// 数据库连接函数
function get_db_connection() {
    global $dbHost, $dbUser, $dbPassword, $dbName;
    
    try {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);
        $conn->set_charset("utf8mb4");
        return $conn;
    } catch (mysqli_sql_exception $e) {
        throw new Exception('数据库连接失败: ' . $e->getMessage());
    }
}

// 处理导入请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    
    $action = $_POST['action'];
    
    // 获取会员类型列表
    if ($action === 'get_levels') {
        try {
            $conn = get_db_connection();
            $result = $conn->query("SELECT id, name FROM member_levels WHERE is_enabled = 1 ORDER BY sort_order, id");
            $levels = [];
            while ($row = $result->fetch_assoc()) {
                $levels[] = $row;
            }
            $conn->close();
            
            echo json_encode(['success' => true, 'data' => $levels], JSON_UNESCAPED_UNICODE);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => '获取会员类型失败: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
    
    // 导入CSV文件
    if ($action === 'import') {
        // 设置无限执行时间（导入大量数据时需要）
        set_time_limit(0);
        ini_set('max_execution_time', '0');
        
        // 增加内存限制（导入大量数据时需要）
        ini_set('memory_limit', '512M');
        
        // 尝试增加上传限制（可能需要在 php.ini 中配置）
        ini_set('upload_max_filesize', '50M');
        ini_set('post_max_size', '50M');
        
        try {
            // 检查文件上传
            if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('请选择要上传的CSV文件');
            }
            
            $file = $_FILES['csv_file'];
            $tmpPath = $file['tmp_name'];
            
            // 验证文件类型
            $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            if ($fileExt !== 'csv') {
                throw new Exception('只支持CSV格式文件');
            }
            
            // 读取并验证CSV内容
            $handle = fopen($tmpPath, 'r');
            if (!$handle) {
                throw new Exception('无法读取CSV文件');
            }
            
            // 跳过标题行（自动检测编码并转换）
            $header = fgetcsv($handle);
            
            $members = [];
            $lineNumber = 1;
            $errors = [];
            
            while (($data = fgetcsv($handle)) !== false) {
                $lineNumber++;
                
                // 跳过空行
                if (empty(array_filter($data))) {
                    continue;
                }
                
                // 验证列数
                if (count($data) < 4) {
                    $errors[] = "第{$lineNumber}行：数据列数不足（需要4列：手机号,姓名,余额,类型ID）";
                    continue;
                }
                
                // 编码转换：GBK -> UTF-8
                $phone = trim(mb_convert_encoding($data[0], 'UTF-8', 'GBK,UTF-8'));
                $name = trim(mb_convert_encoding($data[1], 'UTF-8', 'GBK,UTF-8'));
                $balance = trim($data[2]);
                $levelId = trim($data[3]);
                
                // 验证手机号
                if (empty($phone)) {
                    $errors[] = "第{$lineNumber}行：手机号不能为空";
                    continue;
                }
                
                if (!preg_match('/^1[3-9]\d{9}$/', $phone)) {
                    $errors[] = "第{$lineNumber}行：手机号格式不正确（{$phone}）";
                    continue;
                }
                
                // 验证余额
                if (!is_numeric($balance) || $balance < 0) {
                    $errors[] = "第{$lineNumber}行：余额必须是非负数字（{$balance}）";
                    continue;
                }
                
                // 验证类型ID
                if (!is_numeric($levelId) || $levelId < 1) {
                    $errors[] = "第{$lineNumber}行：类型ID必须是正整数（{$levelId}）";
                    continue;
                }
                
                $members[] = [
                    'phone' => $phone,
                    'name' => $name ?: null,
                    'balance' => floatval($balance),
                    'level_id' => intval($levelId)
                ];
            }
            
            fclose($handle);
            
            // 如果有验证错误，返回错误信息
            if (!empty($errors)) {
                echo json_encode([
                    'success' => false,
                    'message' => '数据验证失败',
                    'errors' => $errors
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
            
            if (empty($members)) {
                throw new Exception('CSV文件中没有有效的数据');
            }
            
            // 检查是否需要用户确认（如果有手机号已存在）
            $forceImport = isset($_POST['force_import']) && $_POST['force_import'] === 'true';
            
            if (!$forceImport) {
                // 连接数据库检查已存在的手机号
                $conn = get_db_connection();
                
                $phones = array_column($members, 'phone');
                $placeholders = implode(',', array_fill(0, count($phones), '?'));
                $checkStmt = $conn->prepare("SELECT member_card_no FROM member_accounts WHERE member_card_no IN ($placeholders)");
                
                // 动态绑定参数
                $types = str_repeat('s', count($phones));
                $checkStmt->bind_param($types, ...$phones);
                $checkStmt->execute();
                $result = $checkStmt->get_result();
                
                $existingPhones = [];
                while ($row = $result->fetch_assoc()) {
                    $existingPhones[] = $row['member_card_no'];
                }
                $checkStmt->close();
                $conn->close();
                
                // 如果有已存在的手机号，返回需要确认的信息
                if (!empty($existingPhones)) {
                    echo json_encode([
                        'success' => false,
                        'need_confirm' => true,
                        'message' => '检测到部分手机号已存在',
                        'existing_count' => count($existingPhones),
                        'existing_phones' => array_slice($existingPhones, 0, 10), // 只返回前10个作为示例
                        'total_count' => count($members)
                    ], JSON_UNESCAPED_UNICODE);
                    exit;
                }
            }
            
            // 连接数据库并导入
            $conn = get_db_connection();
            
            // 检查今日已有的充值记录数量
            $todayDate = date('Ymd');
            $checkTodayStmt = $conn->prepare("
                SELECT COUNT(*) as today_count 
                FROM member_recharges 
                WHERE SUBSTRING(id, 3, 8) = ?
            ");
            $checkTodayStmt->bind_param('s', $todayDate);
            $checkTodayStmt->execute();
            $todayResult = $checkTodayStmt->get_result();
            $todayCount = $todayResult->fetch_assoc()['today_count'];
            $checkTodayStmt->close();
            
            // 计算导入后的总数（只计算有余额的记录，因为余额为0不会创建充值记录）
            $recordsWithBalance = 0;
            foreach ($members as $member) {
                if ($member['balance'] > 0) {
                    $recordsWithBalance++;
                }
            }
            $totalAfterImport = $todayCount + $recordsWithBalance;
            
            // 导入工具默认使用4位尾数（与前台3位尾数区分）
            // 3位尾数 = 前台充值，4位尾数 = 数据导入/转移
            $requiredDigits = 4; // 默认4位
            
            // 如果导入后超过9999条，按需增加位数
            if ($totalAfterImport > 9999) {
                $requiredDigits = strlen((string)$totalAfterImport);
            }
            
            // 标记是否需要临时修改触发器（导入工具总是需要修改为4位或更多）
            $needTriggerModification = true;
            $triggerModified = false; // 标记触发器是否成功修改
            
            // 修改触发器为导入专用格式
            try {
                // 删除现有触发器
                $conn->query("DROP TRIGGER IF EXISTS member_recharges_before_insert");
                
                // 创建支持指定位数的新触发器（查询所有订单，不限制位数）
                $createTriggerSQL = "
                CREATE TRIGGER member_recharges_before_insert
                BEFORE INSERT ON member_recharges
                FOR EACH ROW
                BEGIN
                    DECLARE next_id INT;
                    
                    -- 导入时查询所有订单号（包括3位、4位、5位等），取最大值
                    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id 
                    FROM member_recharges 
                    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
                    
                    SET NEW.id = CONCAT('MR', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, {$requiredDigits}, '0'));
                END";
                
                $conn->query($createTriggerSQL);
                $triggerModified = true; // 标记修改成功
            } catch (Exception $e) {
                $conn->close();
                throw new Exception('修改触发器失败: ' . $e->getMessage());
            }
            
            // 只有触发器修改成功才生成切换提示
            $importWarning = '';
            if ($triggerModified) {
                $importWarning = "<span style='color: blue;'><i class='fas fa-sync-alt'></i> 已智能切换订单号尾数为 {$requiredDigits} 位尾数</span>";
                if ($requiredDigits > 4) {
                    $importWarning .= "<br><span style='color: orange;'><i class='fas fa-exclamation-triangle'></i> 因数据量较大（{$totalAfterImport}条），已自动扩展位数</span>";
                }
            }
            
            $conn->begin_transaction();
            
            $successCount = 0;
            $updateCount = 0;
            $importErrors = [];
            
            // 检查是否存在的语句
            $checkStmt = $conn->prepare("SELECT member_card_no, balance FROM member_accounts WHERE member_card_no = ?");
            
            // 插入新会员的语句（包含密码和累计金额）
            $insertStmt = $conn->prepare("
                INSERT INTO member_accounts (member_card_no, name, balance, level_id, last_four_digits, total_gift_amount, password)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            // 插入充值记录的语句（使用赠送支付方式ID=2）
            $insertRechargeStmt = $conn->prepare("
                INSERT INTO member_recharges (member_card_no, name, payment_method_id, recharge_amount, gift_amount, final_balance, request_code)
                VALUES (?, ?, 2, 0, ?, ?, ?)
            ");
            
            // 更新已存在会员的语句
            $updateStmt = $conn->prepare("
                UPDATE member_accounts 
                SET name = COALESCE(?, name),
                    balance = balance + ?,
                    level_id = ?,
                    total_gift_amount = total_gift_amount + ?
                WHERE member_card_no = ?
            ");
            
            // 分批提交配置（每500条提交一次，避免事务过大）
            $batchSize = 500;
            $processedCount = 0;
            
            foreach ($members as $member) {
                $lastFour = substr($member['phone'], -4);
                $lastSix = substr($member['phone'], -6); // 后6位作为密码
                $hashedPassword = password_hash($lastSix, PASSWORD_DEFAULT); // 加密密码
                
                // 生成唯一的请求码（用于区分导入记录）
                $requestCode = 'IMPORT_' . date('YmdHis') . '_' . bin2hex(random_bytes(8));
                
                try {
                    // 检查会员是否已存在
                    $checkStmt->bind_param('s', $member['phone']);
                    $checkStmt->execute();
                    $result = $checkStmt->get_result();
                    $existing = $result->fetch_assoc();
                    
                    if ($existing) {
                        // 更新已存在的会员（累加余额和充值总额）
                        $updateStmt->bind_param(
                            'sdids',
                            $member['name'],
                            $member['balance'],
                            $member['level_id'],
                            $member['balance'],
                            $member['phone']
                        );
                        
                        if ($updateStmt->execute()) {
                            // 为已存在会员添加充值记录
                            if ($member['balance'] > 0) {
                                $newBalance = $existing['balance'] + $member['balance'];
                                $insertRechargeStmt->bind_param(
                                    'ssdds',
                                    $member['phone'],
                                    $member['name'],
                                    $member['balance'],
                                    $newBalance,
                                    $requestCode
                                );
                                $insertRechargeStmt->execute();
                            }
                            $updateCount++;
                        } else {
                            $importErrors[] = "手机号 {$member['phone']}：更新失败 - " . $updateStmt->error;
                        }
                    } else {
                        // 插入新会员（设置密码为后6位，充值总额=余额）
                        $insertStmt->bind_param(
                            'ssdisds',
                            $member['phone'],
                            $member['name'],
                            $member['balance'],
                            $member['level_id'],
                            $lastFour,
                            $member['balance'],
                            $hashedPassword
                        );
                        
                        if ($insertStmt->execute()) {
                            // 为新会员添加初始充值记录（使用赠送支付方式）
                            if ($member['balance'] > 0) {
                                $insertRechargeStmt->bind_param(
                                    'ssdds',
                                    $member['phone'],
                                    $member['name'],
                                    $member['balance'],
                                    $member['balance'],
                                    $requestCode
                                );
                                $insertRechargeStmt->execute();
                            }
                            $successCount++;
                        } else {
                            $importErrors[] = "手机号 {$member['phone']}：插入失败 - " . $insertStmt->error;
                        }
                    }
                } catch (Exception $e) {
                    $importErrors[] = "手机号 {$member['phone']}：" . $e->getMessage();
                }
                
                // 分批提交：每处理1000条记录提交一次
                $processedCount++;
                if ($processedCount % $batchSize == 0) {
                    $conn->commit();
                    $conn->begin_transaction();
                }
            }
            
            $checkStmt->close();
            $insertStmt->close();
            $insertRechargeStmt->close();
            $updateStmt->close();
            
            // 提交最后一批（如果有未提交的数据）
            $conn->commit();
            
            // 如果修改了触发器，恢复为原来的3位尾数触发器（带重试机制）
            $triggerRestored = false;
            if ($needTriggerModification && $triggerModified) {
                $restoreTriggerSQL = "
                CREATE TRIGGER member_recharges_before_insert
                BEFORE INSERT ON member_recharges
                FOR EACH ROW
                BEGIN
                    DECLARE next_id INT;
                    
                    -- 恢复为3位尾数：只查询3位尾数的订单（尾数 < 1000）
                    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id 
                    FROM member_recharges 
                    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d')
                      AND CAST(SUBSTRING(id, 11) AS UNSIGNED) < 1000;
                    
                    SET NEW.id = CONCAT('MR', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
                END";
                
                // 尝试恢复触发器，最多重试2次
                for ($retry = 0; $retry < 2; $retry++) {
                    try {
                        $conn->query("DROP TRIGGER IF EXISTS member_recharges_before_insert");
                        $conn->query($restoreTriggerSQL);
                        $triggerRestored = true;
                        break; // 成功则跳出循环
                    } catch (Exception $e) {
                        if ($retry == 1) {
                            // 第二次重试也失败，记录错误
                            $importErrors[] = "<span style='color: red;'><strong>严重警告：</strong>触发器恢复失败（已重试2次）<br>请浏览器访问 127.0.0.1:8000/install/index.php 选择保留数据并升级进行修复</span>";
                        }
                        usleep(100000); // 等待100ms后重试
                    }
                }
            }
            
            $conn->close();
            
            $responseData = [
                'success' => true,
                'message' => '导入完成',
                'data' => [
                    'total' => count($members),
                    'new' => $successCount,
                    'updated' => $updateCount,
                    'errors' => $importErrors
                ]
            ];
            
            // 如果有警告信息，添加到响应中
            if (!empty($importWarning)) {
                // 只有触发器成功恢复才添加恢复提示
                if ($triggerRestored) {
                    $importWarning .= "<br><span style='color: green;'><i class='fas fa-check-circle'></i> 已恢复订单号尾数为 3 位尾数</span>";
                }
                $responseData['warning'] = $importWarning;
            }
            
            echo json_encode($responseData, JSON_UNESCAPED_UNICODE);
            
        } catch (Exception $e) {
            if (isset($conn)) {
                $conn->rollback();
                
                // 如果修改了触发器，尝试恢复（带重试机制）
                if (isset($needTriggerModification) && isset($triggerModified) && $needTriggerModification && $triggerModified) {
                    $restoreTriggerSQL = "
                    CREATE TRIGGER member_recharges_before_insert
                    BEFORE INSERT ON member_recharges
                    FOR EACH ROW
                    BEGIN
                        DECLARE next_id INT;
                        
                        -- 恢复为3位尾数：只查询3位尾数的订单（尾数 < 1000）
                        SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id 
                        FROM member_recharges 
                        WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d')
                          AND CAST(SUBSTRING(id, 11) AS UNSIGNED) < 1000;
                        
                        SET NEW.id = CONCAT('MR', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
                    END";
                    
                    // 尝试恢复触发器，最多重试2次
                    for ($retry = 0; $retry < 2; $retry++) {
                        try {
                            $conn->query("DROP TRIGGER IF EXISTS member_recharges_before_insert");
                            $conn->query($restoreTriggerSQL);
                            break; // 成功则跳出循环
                        } catch (Exception $triggerEx) {
                            if ($retry == 1) {
                                // 恢复失败，但不影响错误信息返回
                            }
                            usleep(100000); // 等待100ms后重试
                        }
                    }
                }
                
                $conn->close();
            }
            echo json_encode(['success' => false, 'message' => '导入失败: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>会员数据导入工具</title>
    <!-- 使用国内CDN：BootCDN -->
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/4.6.1/css/bootstrap.min.css">
    <style>
        body {
            background: #f5f5f5;
            min-height: 100vh;
            padding: 20px;
        }
        .import-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 30px;
        }
        .page-title {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-weight: bold;
        }
        .upload-area {
            border: 3px dashed #007bff;
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            background: #f8f9ff;
            cursor: pointer;
            transition: all 0.3s;
            min-height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .upload-area:hover {
            border-color: #0056b3;
            background: #f0f2ff;
        }
        .upload-area.dragover {
            border-color: #0056b3;
            background: #e8ebff;
        }
        .upload-icon {
            font-size: 48px;
            color: #007bff;
            margin-bottom: 10px;
        }
        .file-info {
            padding: 10px;
            background: #e8f5e9;
            border-radius: 5px;
            display: none;
        }
        .result-box {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
            display: none;
        }
        .result-box.success {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .result-box.error {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
        .result-box.info {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            color: #0c5460;
        }
        .error-list {
            max-height: 200px;
            overflow-y: auto;
            margin-top: 10px;
            font-size: 14px;
        }
        .btn-import {
            background: #007bff;
            border: none;
            padding: 12px 40px;
            font-size: 16px;
            font-weight: bold;
        }
        .btn-import:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 123, 255, 0.3);
        }
        .info-card {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .info-card h6 {
            color: #856404;
            margin-bottom: 10px;
        }
        .info-card ul {
            margin-bottom: 0;
            padding-left: 20px;
        }
        .info-card li {
            color: #856404;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="import-container">
        <h2 class="page-title">
            会员数据导入工具
        </h2>
        
        <div class="row">
            <div class="col-md-6">
                <div class="info-card" style="background: #e8f5e9; border-color: #81c784; height: 100%;">
                    <h6 style="color: #2e7d32;">当前系统会员类型</h6>
                    <div id="memberLevels" style="color: #2e7d32;">
                        加载中...
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="info-card" style="height: 100%;">
                    <h6>CSV文件格式说明</h6>
                    <ul>
                        <li>第一行为标题行：手机号,姓名,余额,类型ID</li>
                        <li>手机号：11位数字且是手机号格式，必填</li>
                        <li>姓名：可选，可为空</li>
                        <li>余额：数字，必填（如果会员已存在，余额会累加）</li>
                        <li>类型ID：数字，必填（1=普通卡，其他类型请查看系统设置）</li>
                        <li>密码：自动设置为手机号后6位</li>
                    </ul>
                    
                    <h6 style="margin-top: 20px;">订单号格式说明（数据来源识别）</h6>
                    <ul style="margin-bottom: 0;">
                        <li><strong>前台充值：</strong>订单号为3位尾数（如 MR202602270001）</li>
                        <li><strong>数据导入：</strong>订单号为4位或更多尾数（如 MR202602270001）</li>
                    </ul>
                    
                    <h6 style="margin-top: 20px; color: #0c5460;">CSV模板示例</h6>
                    <pre style="background: white; padding: 10px; border-radius: 5px; margin: 0; color: #0c5460;">手机号,姓名,余额,类型ID
13800138000,张三,100.00,1
13900139000,李四,200.50,1
13700137000,王五,50.00,2</pre>
                </div>
            </div>
        </div>

        <div class="upload-area" id="uploadArea">
            <div id="uploadPrompt">
                <div class="upload-icon">
                    ↑
                </div>
                <h5>拖拽CSV文件到此处</h5>
                <p class="text-muted">支持 .csv 格式文件（单次仅支持一个文件）</p>
            </div>
            <div class="file-info" id="fileInfo">
                <strong>已选择文件：</strong>
                <span id="fileName"></span>
                <button class="btn btn-sm btn-danger ml-3" onclick="clearFile(); event.stopPropagation();">
                    清除
                </button>
            </div>
            <input type="file" id="csvFile" accept=".csv" style="display: none;">
        </div>

        <div class="alert alert-danger text-center mt-4" style="font-size: 16px; font-weight: bold; border: 2px solid #dc3545;">
            导入前请通过后台 > 系统配置 > 数据备份，进行手动备份1次
        </div>

        <div class="text-center mt-3">
            <button class="btn btn-primary btn-lg btn-import" id="importBtn" onclick="importData()" disabled>
                开始导入
            </button>
        </div>

        <div class="result-box" id="resultBox"></div>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/4.6.1/js/bootstrap.min.js"></script>
    <script>
        let selectedFile = null;

        // 页面加载时获取会员类型列表
        $(document).ready(function() {
            loadMemberLevels();
        });

        // 加载会员类型列表
        function loadMemberLevels() {
            $.ajax({
                url: '',
                method: 'POST',
                data: { action: 'get_levels' },
                dataType: 'json',
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        let html = '<table style="width: 100%; border-collapse: collapse;">';
                        html += '<tr style="background: #c8e6c9;"><th style="padding: 8px; border: 1px solid #81c784; text-align: left;">类型ID</th><th style="padding: 8px; border: 1px solid #81c784; text-align: left;">类型名称</th></tr>';
                        response.data.forEach(function(level) {
                            html += `<tr><td style="padding: 8px; border: 1px solid #81c784; font-weight: bold;">${level.id}</td><td style="padding: 8px; border: 1px solid #81c784;">${level.name}</td></tr>`;
                        });
                        html += '</table>';
                        $('#memberLevels').html(html);
                    } else {
                        $('#memberLevels').html('<span style="color: #d32f2f;">未找到可用的会员类型</span>');
                    }
                },
                error: function() {
                    $('#memberLevels').html('<span style="color: #d32f2f;">加载会员类型失败</span>');
                }
            });
        }

        // 上传区域点击事件
        $('#uploadArea').on('click', function(e) {
            // 如果点击的不是清除按钮，则触发文件选择
            if (!$(e.target).closest('button').length) {
                $('#csvFile').click();
            }
        });

        // 文件选择事件
        $('#csvFile').on('change', function(e) {
            if (e.target.files.length > 0) {
                handleFile(e.target.files[0]);
            }
        });

        // 拖拽事件
        $('#uploadArea').on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('dragover');
        });

        $('#uploadArea').on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
        });

        $('#uploadArea').on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
            
            const files = e.originalEvent.dataTransfer.files;
            // 只处理第一个文件（单文件限制）
            if (files.length > 0) {
                if (files.length > 1) {
                    alert('一次只能上传一个文件，已自动选择第一个文件');
                }
                handleFile(files[0]);
            }
        });

        // 处理文件
        function handleFile(file) {
            if (!file) return;
            
            // 验证文件类型
            if (!file.name.toLowerCase().endsWith('.csv')) {
                alert('请选择CSV格式文件');
                return;
            }
            
            selectedFile = file;
            $('#fileName').text(file.name);
            
            // 隐藏上传提示，显示文件信息
            $('#uploadPrompt').hide();
            $('#fileInfo').show();
            
            $('#importBtn').prop('disabled', false);
            $('#resultBox').slideUp();
        }

        // 清除文件
        function clearFile() {
            selectedFile = null;
            $('#csvFile').val('');
            
            // 显示上传提示，隐藏文件信息
            $('#fileInfo').hide();
            $('#uploadPrompt').show();
            
            $('#importBtn').prop('disabled', true);
        }

        // 导入数据
        function importData() {
            if (!selectedFile) {
                alert('请先选择CSV文件');
                return;
            }

            const formData = new FormData();
            formData.append('action', 'import');
            formData.append('csv_file', selectedFile);

            $('#importBtn').prop('disabled', true).html('导入中...');
            
            // 显示导入提示
            showResult('info', `
                <h5>正在导入数据</h5>
                <p>正在进行数据库操作，请不要关闭页面或进行其他操作...</p>
                <p>数据量较大时可能需要较长时间，请耐心等待</p>
            `);

            $.ajax({
                url: '',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        let successHtml = `
                            <h5>${response.message}</h5>
                            <p>总计：${response.data.total} 条</p>
                            <p>新增：${response.data.new} 条</p>
                            <p>更新：${response.data.updated} 条</p>
                            ${response.warning ? `<div style="margin-top: 15px; padding: 10px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;">${response.warning}</div>` : ''}
                            ${response.data.errors.length > 0 ? `
                                <div class="error-list">
                                    <strong>部分导入失败：</strong>
                                    <ul>
                                        ${response.data.errors.map(err => `<li>${err}</li>`).join('')}
                                    </ul>
                                </div>
                            ` : ''}
                        `;
                        showResult('success', successHtml);
                        clearFile();
                    } else if (response.need_confirm) {
                        // 需要用户确认
                        $('#importBtn').prop('disabled', false).html('开始导入');
                        
                        let confirmMsg = `检测到 ${response.existing_count} 个手机号已存在于数据库中！\n\n`;
                        confirmMsg += `示例手机号：\n${response.existing_phones.join('\n')}\n`;
                        if (response.existing_count > 10) {
                            confirmMsg += `\n...还有 ${response.existing_count - 10} 个\n`;
                        }
                        confirmMsg += `\n总共将导入 ${response.total_count} 条记录`;
                        confirmMsg += `\n已存在的会员将累加余额\n\n`;
                        confirmMsg += `是否继续导入？`;
                        
                        if (confirm(confirmMsg)) {
                            // 用户确认，重新提交并标记强制导入
                            formData.append('force_import', 'true');
                            
                            $('#importBtn').prop('disabled', true).html('导入中...');
                            showResult('info', `
                                <h5>正在导入数据</h5>
                                <p>正在进行数据库操作，请不要关闭页面或进行其他操作...</p>
                                <p>数据量较大时可能需要较长时间，请耐心等待</p>
                            `);
                            
                            // 重新发起请求
                            $.ajax({
                                url: '',
                                method: 'POST',
                                data: formData,
                                processData: false,
                                contentType: false,
                                success: function(response) {
                                    if (response.success) {
                                        let successHtml = `
                                            <h5>${response.message}</h5>
                                            <p>总计：${response.data.total} 条</p>
                                            <p>新增：${response.data.new} 条</p>
                                            <p>更新：${response.data.updated} 条</p>
                                            ${response.warning ? `<div style="margin-top: 15px; padding: 10px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 5px;">${response.warning}</div>` : ''}
                                            ${response.data.errors.length > 0 ? `
                                                <div class="error-list">
                                                    <strong>部分导入失败：</strong>
                                                    <ul>
                                                        ${response.data.errors.map(err => `<li>${err}</li>`).join('')}
                                                    </ul>
                                                </div>
                                            ` : ''}
                                        `;
                                        showResult('success', successHtml);
                                        clearFile();
                                    } else {
                                        let errorHtml = `<h5>${response.message}</h5>`;
                                        if (response.errors && response.errors.length > 0) {
                                            errorHtml += `
                                                <div class="error-list">
                                                    <ul>
                                                        ${response.errors.map(err => `<li>${err}</li>`).join('')}
                                                    </ul>
                                                </div>
                                            `;
                                        }
                                        showResult('error', errorHtml);
                                    }
                                },
                                error: function(xhr) {
                                    let message = '导入失败';
                                    try {
                                        const response = JSON.parse(xhr.responseText);
                                        message = response.message || message;
                                    } catch (e) {}
                                    showResult('error', `<h5>${message}</h5>`);
                                },
                                complete: function() {
                                    $('#importBtn').prop('disabled', false).html('开始导入');
                                }
                            });
                        } else {
                            // 用户取消
                            showResult('info', '<h5>已取消导入操作</h5>');
                        }
                    } else {
                        let errorHtml = `<h5>${response.message}</h5>`;
                        if (response.errors && response.errors.length > 0) {
                            errorHtml += `
                                <div class="error-list">
                                    <ul>
                                        ${response.errors.map(err => `<li>${err}</li>`).join('')}
                                    </ul>
                                </div>
                            `;
                        }
                        showResult('error', errorHtml);
                    }
                },
                error: function(xhr) {
                    let message = '导入失败';
                    try {
                        const response = JSON.parse(xhr.responseText);
                        message = response.message || message;
                    } catch (e) {}
                    showResult('error', `<h5>${message}</h5>`);
                },
                complete: function() {
                    $('#importBtn').prop('disabled', false).html('开始导入');
                }
            });
        }

        // 显示结果
        function showResult(type, html) {
            $('#resultBox')
                .removeClass('success error info')
                .addClass(type)
                .html(html)
                .slideDown();
        }

    </script>
</body>
</html>
