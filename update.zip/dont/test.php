<?php
/**
 * 更新源连通性测试页面
 * 独立版本，不需要登录，使用与 admin.php 完全一致的逻辑
 */

// 只引入配置文件，不引入完整的 admin.php
$config_path = dirname(__DIR__) . '/config/config.php';
if (file_exists($config_path)) {
    include($config_path);
} else {
    die('配置文件不存在');
}

// 定义更新源常量（与 admin.php 保持一致）
define('REMOTE_UPDATE_BASE_URL', 'https://gitee.com/phproom/phproom/raw/master/');
define('REMOTE_UPDATE_BASE_URL_BACKUP', 'https://gh-proxy.org/https://raw.githubusercontent.com/tsengwentseng/phproom/main/');

// 远程文件名配置
define('REMOTE_UPDATE_ZIP', 'update.zip');
define('REMOTE_VERSION_FILE', 'version.txt');
define('REMOTE_VERSIONLOG_FILE', 'versionlog.txt');
define('REMOTE_API_HASH_FILE', 'room_api_hash.txt');
define('REMOTE_API_EXE_FILE', 'room_api.exe');
define('REMOTE_MACHINEID_FILE', 'devrunlog.txt');

/**
 * 获取远程更新URL（支持多源切换）
 * 与 admin.php 完全一致
 */
function getRemoteUpdateUrl($filename, $sourceIndex = 0) {
    if ($sourceIndex === 0) {
        return REMOTE_UPDATE_BASE_URL . $filename;
    } else {
        return REMOTE_UPDATE_BASE_URL_BACKUP . $filename;
    }
}

/**
 * 带重试机制的远程文件获取函数
 * 与 admin.php 完全一致
 */
function getRemoteFileWithRetry($url, $maxRetries = 3, $retryDelay = 1) {
    $lastError = '';
    
    for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
        try {
            // 设置超时和错误处理
            $context = stream_context_create([
                'http' => [
                    'timeout' => 15,
                    'ignore_errors' => true,
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\n"
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ]);
            
            $content = @file_get_contents($url, false, $context);
            
            // 检查是否成功
            if ($content !== false) {
                // 检查 HTTP 状态码
                if (isset($http_response_header)) {
                    $status_line = $http_response_header[0];
                    preg_match('{HTTP\/\S*\s(\d{3})}', $status_line, $match);
                    $status = intval($match[1] ?? 0);
                    
                    // 2xx 成功，3xx 重定向（PHP已自动跟随）
                    if ($status >= 200 && $status < 400) {
                        return $content;
                    } else {
                        $lastError = "HTTP {$status}";
                    }
                } else {
                    // 没有 HTTP 响应头，但内容不为 false，认为成功
                    return $content;
                }
            } else {
                $error = error_get_last();
                $lastError = $error['message'] ?? '未知错误';
            }
            
        } catch (Exception $e) {
            $lastError = $e->getMessage();
        }
        
        // 如果不是最后一次尝试，等待后重试
        if ($attempt < $maxRetries) {
            sleep($retryDelay);
        }
    }
    
    // 所有尝试都失败
    return false;
}

// 定义测试文件列表
$testFiles = [
    'version.txt' => '版本号文件',
    'versionlog.txt' => '更新日志文件',
    'update.zip' => '更新包文件',
    'room_api_hash.txt' => 'API Hash文件',
    'room_api.exe' => 'API程序文件',
    'devrunlog.txt' => '设备日志文件'
];

// 处理 AJAX 请求
if (isset($_POST['action']) && $_POST['action'] === 'test_source') {
    // 设置更长的执行时间
    set_time_limit(300); // 5分钟
    ignore_user_abort(false); // 用户断开时停止执行
    
    header('Content-Type: application/json; charset=utf-8');
    
    $sourceIndex = isset($_POST['source']) && $_POST['source'] === 'github' ? 1 : 0;
    $results = [];
    
    foreach ($testFiles as $filename => $description) {
        $url = getRemoteUpdateUrl($filename, $sourceIndex);
        $result = testFileWithSameLogic($url, $filename, $description);
        $results[] = $result;
        
        // 每测试完一个文件，输出进度（可选，用于调试）
        // flush();
    }
    
    echo json_encode([
        'success' => true,
        'results' => $results,
        'source' => $sourceIndex === 0 ? 'gitee' : 'github'
    ]);
    exit;
}

/**
 * 使用与 admin.php 完全一致的逻辑测试文件
 * 复用 getRemoteFileWithRetry 函数
 */
function testFileWithSameLogic($url, $filename, $description) {
    $startTime = microtime(true);
    
    // 使用与 admin.php 完全相同的函数
    $content = getRemoteFileWithRetry($url, 3, 1);
    
    $duration = round((microtime(true) - $startTime) * 1000); // 毫秒
    
    if ($content !== false) {
        // 成功 - 获取 HTTP 状态码
        $statusCode = 200; // file_get_contents 成功后通常是 200 或重定向后的最终状态码
        $size = strlen($content);
        
        return [
            'fileName' => $filename,
            'fileDesc' => $description,
            'success' => true,
            'statusCode' => $statusCode,
            'duration' => $duration,
            'size' => $size,
            'error' => null
        ];
    } else {
        // 失败
        return [
            'fileName' => $filename,
            'fileDesc' => $description,
            'success' => false,
            'statusCode' => 0,
            'duration' => $duration,
            'size' => 0,
            'error' => '连接失败或超时（已重试3次）'
        ];
    }
}

/**
 * 格式化文件大小
 */
function formatSize($bytes) {
    if ($bytes === 0) return '0 B';
    $k = 1024;
    $sizes = ['B', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>更新源连通性测试</title>
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/4.6.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background: #f5f5f5;
            min-height: 100vh;
            padding: 40px 0;
        }
        .test-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .source-card {
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        .source-card:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .source-card.success {
            border-color: #28a745;
            background: #f8fff9;
        }
        .source-card.failed {
            border-color: #dc3545;
            background: #fff8f8;
        }
        .test-btn {
            padding: 12px 30px;
            font-size: 16px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .test-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .result-badge {
            font-size: 14px;
            padding: 8px 15px;
            border-radius: 20px;
            margin-left: 10px;
        }
        .file-result {
            background: #f8f9fa;
            border-left: 4px solid #6c757d;
            padding: 12px;
            margin: 8px 0;
            border-radius: 5px;
        }
        .file-result.success {
            border-left-color: #28a745;
            background: #f0fff4;
        }
        .file-result.failed {
            border-left-color: #dc3545;
            background: #fff5f5;
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .summary-box {
            background: #e3f2fd;
            color: #1976d2;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 30px;
            border-left: 4px solid #2196f3;
        }
        .code-block {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="test-container">
            <h2 class="text-center mb-4">
                <i class="fas fa-network-wired mr-2"></i>更新源连通性测试
            </h2>
            <p class="text-center text-muted mb-4">
                <i class="fas fa-info-circle mr-1"></i>
                使用与 admin.php 完全一致的逻辑（getRemoteFileWithRetry）进行测试
            </p>
            
            <!-- 总结区域 -->
            <div class="summary-box" id="summaryBox" style="display: none;">
                <h5 class="mb-3"><i class="fas fa-chart-bar mr-2"></i>测试结果总结</h5>
                <div id="summaryContent"></div>
            </div>

            <!-- Gitee 源测试 -->
            <div class="source-card" id="giteeCard">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="mb-0">
                        <i class="fab fa-git-alt text-primary mr-2"></i>Gitee 主源
                    </h4>
                    <span id="giteeStatus"></span>
                </div>
                <div class="code-block mb-3">
                    <?php echo REMOTE_UPDATE_BASE_URL; ?>
                </div>
                <button class="btn btn-primary test-btn" onclick="testSource('gitee')" id="giteeBtn">
                    <i class="fas fa-play mr-2"></i>开始测试
                </button>
                <div id="giteeResults" class="mt-3"></div>
            </div>

            <!-- GitHub 源测试 -->
            <div class="source-card" id="githubCard">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="mb-0">
                        <i class="fab fa-github text-dark mr-2"></i>GitHub 备用源
                    </h4>
                    <span id="githubStatus"></span>
                </div>
                <div class="code-block mb-3">
                    <?php echo REMOTE_UPDATE_BASE_URL_BACKUP; ?>
                </div>
                <button class="btn btn-secondary test-btn" onclick="testSource('github')" id="githubBtn">
                    <i class="fas fa-play mr-2"></i>开始测试
                </button>
                <div id="githubResults" class="mt-3"></div>
            </div>

            <!-- 全部测试按钮 -->
            <div class="text-center mt-4">
                <button class="btn btn-success test-btn btn-lg" onclick="testAllSources()">
                    <i class="fas fa-tasks mr-2"></i>测试所有源
                </button>
                <button class="btn btn-outline-secondary test-btn btn-lg ml-2" onclick="clearResults()">
                    <i class="fas fa-trash mr-2"></i>清空结果
                </button>
            </div>
            
            <!-- 说明 -->
            <div class="alert alert-info mt-4">
                <h6><i class="fas fa-lightbulb mr-2"></i>测试说明</h6>
                <ul class="mb-0">
                    <li>使用与 admin.php 完全相同的 <code>getRemoteFileWithRetry()</code> 函数</li>
                    <li>每个文件最多重试 3 次，每次间隔 1 秒</li>
                    <li>HTTP 状态码 200-399 视为成功（包括 302 重定向）</li>
                    <li>可以准确判断哪个源彻底失效</li>
                </ul>
            </div>
        </div>
    </div>

    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/twitter-bootstrap/4.6.2/js/bootstrap.bundle.min.js"></script>
    <script>
        // 测试单个源
        function testSource(sourceName) {
            const btn = document.getElementById(sourceName + 'Btn');
            const resultsDiv = document.getElementById(sourceName + 'Results');
            const card = document.getElementById(sourceName + 'Card');
            const statusSpan = document.getElementById(sourceName + 'Status');

            // 禁用按钮，显示加载状态
            btn.disabled = true;
            btn.innerHTML = '<span class="loading mr-2"></span>测试中...';
            resultsDiv.innerHTML = '';
            card.className = 'source-card';
            statusSpan.innerHTML = '';

            // 发送 AJAX 请求到 PHP（请求当前页面）
            $.ajax({
                url: window.location.pathname,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'test_source',
                    source: sourceName
                },
                timeout: 300000, // 5分钟超时（6个文件 × 3次重试 × 15秒超时 + 间隔）
                success: function(response) {
                    // 先恢复按钮
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-redo mr-2"></i>重新测试';
                    
                    if (response.success) {
                        displayResults(sourceName, response.results);
                    } else {
                        resultsDiv.innerHTML = '<div class="alert alert-danger">测试失败：' + (response.message || '未知错误') + '</div>';
                    }
                },
                error: function(xhr, status, error) {
                    resultsDiv.innerHTML = '<div class="alert alert-danger">请求失败：' + error + '</div>';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-play mr-2"></i>开始测试';
                }
            });
        }

        // 显示测试结果
        function displayResults(sourceName, results) {
            const resultsDiv = document.getElementById(sourceName + 'Results');
            const card = document.getElementById(sourceName + 'Card');
            const statusSpan = document.getElementById(sourceName + 'Status');

            let successCount = 0;
            let failCount = 0;

            results.forEach(function(result) {
                if (result.success) {
                    successCount++;
                } else {
                    failCount++;
                }
                displayFileResult(resultsDiv, result);
            });

            // 更新卡片状态
            if (failCount === 0) {
                card.className = 'source-card success';
                statusSpan.innerHTML = '<span class="badge badge-success result-badge"><i class="fas fa-check mr-1"></i>全部成功</span>';
            } else if (successCount === 0) {
                card.className = 'source-card failed';
                statusSpan.innerHTML = '<span class="badge badge-danger result-badge"><i class="fas fa-times mr-1"></i>全部失败</span>';
            } else {
                card.className = 'source-card failed';
                statusSpan.innerHTML = '<span class="badge badge-warning result-badge"><i class="fas fa-exclamation-triangle mr-1"></i>部分失败 (' + successCount + '/' + results.length + ')</span>';
            }

            // 保存结果用于总结
            window[sourceName + 'Results'] = results;
            updateSummary();
        }

        // 显示单个文件结果
        function displayFileResult(container, result) {
            const statusClass = result.success ? 'success' : 'failed';
            const icon = result.success ? 'check-circle text-success' : 'times-circle text-danger';
            const statusText = result.success ? 
                '✓ HTTP ' + result.statusCode + ' (' + result.duration + 'ms, ' + formatSize(result.size) + ')' :
                '✗ ' + result.error;

            const html = `
                <div class="file-result ${statusClass}">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong><i class="fas fa-file mr-2"></i>${result.fileName}</strong>
                            <small class="text-muted ml-2">(${result.fileDesc})</small>
                        </div>
                        <small class="${result.success ? 'text-success' : 'text-danger'}">
                            <i class="fas ${icon} mr-1"></i>${statusText}
                        </small>
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', html);
        }

        // 格式化文件大小
        function formatSize(bytes) {
            if (bytes === 0) return '0 B';
            const k = 1024;
            const sizes = ['B', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }

        // 测试所有源
        async function testAllSources() {
            clearResults();
            testSource('gitee');
            setTimeout(() => testSource('github'), 1000);
        }

        // 清空结果
        function clearResults() {
            ['gitee', 'github'].forEach(function(source) {
                document.getElementById(source + 'Results').innerHTML = '';
                document.getElementById(source + 'Card').className = 'source-card';
                document.getElementById(source + 'Status').innerHTML = '';
                const btn = document.getElementById(source + 'Btn');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-play mr-2"></i>开始测试';
            });
            document.getElementById('summaryBox').style.display = 'none';
            window.giteeResults = [];
            window.githubResults = [];
        }

        // 更新总结
        function updateSummary() {
            if (!window.giteeResults || !window.githubResults || 
                window.giteeResults.length === 0 || window.githubResults.length === 0) {
                return;
            }

            const summaryBox = document.getElementById('summaryBox');
            const summaryContent = document.getElementById('summaryContent');

            const giteeSuccess = window.giteeResults.filter(r => r.success).length;
            const githubSuccess = window.githubResults.filter(r => r.success).length;
            const totalFiles = window.giteeResults.length;

            let recommendation = '';
            let alertClass = '';

            if (giteeSuccess === totalFiles && githubSuccess === totalFiles) {
                recommendation = '✅ 两个源都正常工作，可以正常使用双源切换功能';
                alertClass = 'alert-success';
            } else if (giteeSuccess === totalFiles) {
                recommendation = '⚠️ Gitee 源正常，GitHub 源部分或全部失效。建议检查 GitHub 源的可用性';
                alertClass = 'alert-warning';
            } else if (githubSuccess === totalFiles) {
                recommendation = '⚠️ GitHub 源正常，Gitee 源部分或全部失效。系统会自动切换到 GitHub 源';
                alertClass = 'alert-warning';
            } else {
                recommendation = '❌ 两个源都有问题！请检查网络连接或联系管理员';
                alertClass = 'alert-danger';
            }

            summaryContent.innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <div class="alert ${alertClass} mb-0">
                            <h6 class="mb-2"><i class="fas fa-lightbulb mr-2"></i>建议</h6>
                            <p class="mb-0">${recommendation}</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless text-white mb-0">
                            <tr>
                                <td>Gitee 成功率：</td>
                                <td><strong>${giteeSuccess}/${totalFiles}</strong></td>
                            </tr>
                            <tr>
                                <td>GitHub 成功率：</td>
                                <td><strong>${githubSuccess}/${totalFiles}</strong></td>
                            </tr>
                        </table>
                    </div>
                </div>
            `;

            summaryBox.style.display = 'block';
        }
    </script>
</body>
</html>
