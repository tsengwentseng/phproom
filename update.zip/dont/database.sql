-- 创建数据库
CREATE DATABASE IF NOT EXISTS `room_management`
DEFAULT CHARACTER SET utf8mb4
DEFAULT COLLATE utf8mb4_unicode_ci;

USE `room_management`;

-- 设置时区为Asia/Shanghai
SET time_zone = '+8:00';
SET GLOBAL time_zone = '+8:00';

-- 支付方式表
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '支付方式名称',
  `description` VARCHAR(255) DEFAULT NULL COMMENT '支付方式描述',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否系统预设 (1=是，可软删除)',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序顺序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  INDEX `idx_active` (`is_deleted`, `id`, `name`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 会员卡类型表
CREATE TABLE IF NOT EXISTS `member_levels` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '卡类型名称',
  `min_first_recharge` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '首次开卡最低金额',
  `min_recharge` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '续费充值最低金额',
  `auto_upgrade_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '自动升级需累计充值金额',
  `member_discount` INT UNSIGNED NOT NULL DEFAULT 100 COMMENT '会员折扣(1-100)，在商品/房间折扣基础上再打折',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否系统级卡类型 1=系统级不可修改 0=普通',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员卡类型表';

-- 会员明细表（主表）
CREATE TABLE IF NOT EXISTS `member_accounts` (
  `member_card_no` VARCHAR(50) NOT NULL COMMENT '会员卡号(即手机号)',
  `name` VARCHAR(50) DEFAULT NULL COMMENT '会员姓名',
  `balance` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '当前余额',
  `level_id` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '会员卡类型ID',
  `total_recharge_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '累计充值金额',
  `total_gift_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '累计赠送金额',
  `total_consumption_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '累计消费金额',
  `password` VARCHAR(255) DEFAULT NULL COMMENT '会员密码',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用 1=启用 0=停用',
  `last_four_digits` VARCHAR(4) DEFAULT NULL COMMENT '卡号后4位，用于模糊查询',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `last_consumption_time` DATETIME NULL DEFAULT NULL COMMENT '最后消费时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`member_card_no`),
  INDEX `idx_name` (`name`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_last_consumption` (`last_consumption_time`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_last_four_digits` (`last_four_digits`),
  INDEX `idx_level_id` (`level_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 会员充值记录表
CREATE TABLE IF NOT EXISTS `member_recharges` (
  `id` VARCHAR(20) NOT NULL COMMENT '充值单号(MRYYYYMMDDNNN格式)',
  `member_card_no` VARCHAR(50) NOT NULL COMMENT '会员卡号',
  `name` VARCHAR(50) DEFAULT NULL COMMENT '会员姓名',
  `payment_method_id` INT UNSIGNED NOT NULL COMMENT '支付方式ID',
  `recharge_amount` DECIMAL(10,2) NOT NULL COMMENT '充值金额',
  `gift_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '赠送金额',
  `final_balance` DECIMAL(10,2) NOT NULL COMMENT '充值后余额',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '充值时间',
  `request_code` VARCHAR(64) DEFAULT NULL COMMENT '唯一请求码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_code` (`request_code`),
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT,
  INDEX `idx_card_no` (`member_card_no`),
  INDEX `idx_payment_method` (`payment_method_id`),
  INDEX `idx_time` (`create_time`),
  INDEX `idx_card_time` (`member_card_no`, `create_time`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 包间信息表
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '包间名称',
  `type` VARCHAR(20) NOT NULL DEFAULT '普通' COMMENT '包间类型',
  `standard_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '标准价(1小时)',
  `enable_standard_price` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '启用标准价 0=不启用 1=启用',
  `member_discount` INT NOT NULL DEFAULT 100 COMMENT '会员折扣(百分比，例如80表示8折)',
  `enable_member_levels_discount` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否参与会员等级折扣 1=参与 0=不参与',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用 1=启用 0=停用',
  `device_ip` VARCHAR(15) DEFAULT NULL COMMENT '设备IP地址',
  `device_port` INT DEFAULT NULL COMMENT '设备端口',
  `device_protocol` ENUM('modbus_tcp', 'tcp_hex') DEFAULT NULL COMMENT '设备协议类型',
  `device_commands` JSON DEFAULT NULL COMMENT '设备指令配置 (JSON 格式)',
  `device_workflow` JSON DEFAULT NULL COMMENT '设备工作流配置 (JSON 格式)',
  `device_enabled` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '设备控制是否启用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序序号',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_name` (`name`),
  INDEX `idx_sort` (`sort_order`),
  INDEX `idx_active` (`is_deleted`, `id`, `name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 房间访问码表（二维码功能）
CREATE TABLE IF NOT EXISTS `room_access_codes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `room_id` INT UNSIGNED NOT NULL COMMENT '房间 ID',
  `access_code` VARCHAR(32) NOT NULL COMMENT '随机访问码',
  `verification_code` VARCHAR(50) DEFAULT NULL COMMENT '核销码/团购券号（只允许数字和字母）',
  `verification_type` VARCHAR(20) DEFAULT NULL COMMENT '验证类型',
  `verification_time` DATETIME DEFAULT NULL COMMENT '核销码提交时间',
  `verification_status` TINYINT(1) DEFAULT NULL COMMENT '核销状态：0=未核销，1=已核销',
  `verification_note` VARCHAR(90) DEFAULT NULL COMMENT '核销服务备注描述',
  `note` VARCHAR(90) DEFAULT NULL COMMENT '呼叫店员备注描述',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '启用状态：1=启用，0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记：0=正常，1=已删除（保留访问记录）',
  `scan_count` INT NOT NULL DEFAULT 0 COMMENT '扫码次数统计',
  `last_scanned_at` DATETIME DEFAULT NULL COMMENT '最后扫码时间',
  `audio_muted` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '音频静音：0=未静音，1=已静音',
  `audio_updated_at` DATETIME DEFAULT NULL COMMENT '音频更新时间',
  `qr_audio` DATETIME DEFAULT NULL COMMENT '店员服务提交时间',
  `qr_verification` DATETIME DEFAULT NULL COMMENT '核销服务提交时间',
  `qr_checkin_muted` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '扫码开台提醒静音：0=提醒中，1=已静音',
  `qr_checkin_time` DATETIME DEFAULT NULL COMMENT '扫码开台提醒提交时间',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_room_id` (`room_id`),
  UNIQUE KEY `idx_access_code` (`access_code`),
  INDEX `idx_audio_alerts` (`is_enabled`, `audio_muted`, `audio_updated_at`),
  INDEX `idx_verification_alerts` (`is_enabled`, `verification_code`, `verification_status`, `verification_time`),
  INDEX `idx_qr_checkin_alerts` (`is_enabled`, `qr_checkin_muted`, `qr_checkin_time`),
  CONSTRAINT `fk_room_access_codes_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 订单记录表
CREATE TABLE IF NOT EXISTS `orders` (
  `id` VARCHAR(20) NOT NULL COMMENT '订单号(格式RMYYYYMMDDNNN)',
  `room_id` INT UNSIGNED NOT NULL COMMENT '包间ID',
  `start_time` DATETIME NOT NULL COMMENT '开始时间',
  `expected_end_time` DATETIME NOT NULL COMMENT '预计结束时间',
  `end_time` DATETIME DEFAULT NULL COMMENT '实际结束时间',
  `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '总金额',
  `credit_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '挂单金额',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员卡号',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '订单备注',
  `guest_count` SMALLINT UNSIGNED DEFAULT NULL COMMENT '房间人数',
  `purpose` JSON DEFAULT NULL COMMENT '用途标签(JSON数组: [1, 3, 5])',
  `status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=进行中 1=已结账',
  `audio_muted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未静音 1=已静音',
  `audio_updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '音频更新时间',
  `snooze_alert` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '稍后提醒开关 0=关闭 1=开启',
  `is_paused` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '暂停标记 0=正常计时 1=已暂停',
  `pause_start_time` DATETIME NULL DEFAULT NULL COMMENT '暂停开始时间',
  `total_pause_duration` INT NOT NULL DEFAULT 0 COMMENT '累计暂停时间 (秒)',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `origin_client` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '操作来源标识',
  `is_scan_checkin` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否扫码开台：0=否，1=是',
  `timer_mode` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '计时方式：0=倒计时，1=正计时',
  `is_unlimited` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否不限时订单：0=否，1=是（开台/加时使用不限时套餐时写入，前端计时显示不限时）',
  `audio_replay` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '手动重播标记：0=正常 1=等待重播（独立于 audio_muted/snooze_alert，仅由 replay API 设置，Go 轮询广播后立即清零）',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX `idx_room` (`room_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_room_status` (`room_id`, `status`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_member_card` (`member_card_no`),
  INDEX `idx_alert_query` (`status`, `audio_muted`, `audio_updated_at`),
  INDEX `idx_update_check` (`origin_client`, `update_time`),
  INDEX `idx_smart_refresh_orders` (`create_time`, `status`) COMMENT '智能刷新优化索引',
  INDEX `idx_pause_status` (`is_paused`, `status`),
  INDEX `idx_audio_replay` (`audio_replay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 包间支付明细表
CREATE TABLE IF NOT EXISTS `orders_payment_details` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` VARCHAR(20) NOT NULL COMMENT '关联订单ID',
  `payment_method_id` INT UNSIGNED NOT NULL COMMENT '支付方式ID',
  `amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '实收金额',
  `credit_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '挂单金额（独立字段，不参与营业额计算）',
  `extra_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '附加费用',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员卡号（当使用会员卡支付时）',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `payment_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '支付时间',
  `payment_type` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '支付类型：0=开台，1=加时，2=结账附加费',
  `hours` DECIMAL(6,2) DEFAULT NULL COMMENT '本次增加的时长（小时），开台/加时时记录，结账时为NULL',
  `guest_count` SMALLINT DEFAULT NULL COMMENT '本次操作人数变化量（相对上一次录入值，正数=增加，负数=减少；开台为首次录入人数）',
  `promotion_data` JSON DEFAULT NULL COMMENT '套餐数据(JSON格式: [{id, quantity}, ...])',
  `time_card_data` JSON DEFAULT NULL COMMENT '次卡券数据(JSON格式: [{id, quantity}, ...])',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `request_code` VARCHAR(64) DEFAULT NULL COMMENT '唯一请求码',
  PRIMARY KEY (`id`),
  INDEX `idx_order_id` (`order_id`),
  INDEX `idx_payment_method` (`payment_method_id`),
  INDEX `idx_member_card` (`member_card_no`),
  INDEX `idx_order_payment_time` (`order_id`, `payment_type`, `create_time`),
  INDEX `idx_request_code` (`request_code`),
  INDEX `idx_operator` (`operator_id`),
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 预定订单表
CREATE TABLE IF NOT EXISTS `reservations` (
  `id` VARCHAR(20) NOT NULL COMMENT '订单号(格式BKYYYYMMDDNNN)',
  `room_id` INT UNSIGNED NOT NULL COMMENT '包间ID',
  `reservation_time` DATETIME NOT NULL COMMENT '预定时间',
  `phone` VARCHAR(20) DEFAULT NULL COMMENT '联系电话',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '备注信息',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未到期 1=已超时 2=已取消 3=超时并取消 4=已使用',
  `audio_muted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未静音 1=已静音',
  `audio_updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '音频更新时间',
  `snooze_alert` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '稍后提醒开关 0=关闭 1=开启',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `origin_client` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '操作来源标识',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  INDEX `idx_room` (`room_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_room_status` (`room_id`, `status`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_time` (`reservation_time`),
  INDEX `idx_alert_query` (`status`, `audio_muted`, `audio_updated_at`),
  INDEX `idx_update_check` (`origin_client`, `update_time`),
  INDEX `idx_smart_refresh_reservations` (`create_time`, `status`) COMMENT '智能刷新优化索引',
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 系统配置表
CREATE TABLE IF NOT EXISTS `system_config` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `config_key` VARCHAR(50) NULL,
  `config_value` VARCHAR(255),
  `password_version` INT NOT NULL DEFAULT 1 COMMENT '密码版本号',
  `config_type` VARCHAR(20) NOT NULL DEFAULT 'string' COMMENT '配置类型：boolean, number, string',
  `config_group` VARCHAR(50) NOT NULL DEFAULT 'system' COMMENT '配置分组：system, member, room, product',
  `config_description` VARCHAR(255) DEFAULT NULL COMMENT '配置描述',
  `is_visible` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否在界面可见',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序顺序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '',
  INDEX `idx_config_key` (`config_key`),
  INDEX `idx_visible` (`is_visible`),
  INDEX `idx_group` (`config_group`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 订单表触发器
DELIMITER //

CREATE TRIGGER orders_before_insert
BEFORE INSERT ON `orders`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    DECLARE offset_seconds INT;

    -- 获取音频提醒基准偏移配置
    SELECT CAST(config_value AS SIGNED) INTO offset_seconds
    FROM system_config
    WHERE config_key = 'alert_offset_seconds';

    -- 如果没有找到配置，使用默认值0（到期时间）
    IF offset_seconds IS NULL THEN
        SET offset_seconds = 0;
    END IF;

    -- 注释掉自动设置audio_muted，改为保留应用层设置的值
    -- 如果应用层没有设置（NULL），则根据status自动设置
    -- SET NEW.audio_muted = IF(NEW.status = 0, 0, 1);

    -- 时间同步：根据offset_seconds调整提醒时间
    -- 负数=提前（减去秒数），正数=推后（加上秒数），0=到期时间
    IF offset_seconds < 0 THEN
        -- 提前提醒：减去绝对值
        SET NEW.audio_updated_at = DATE_SUB(NEW.expected_end_time, INTERVAL ABS(offset_seconds) SECOND);
    ELSEIF offset_seconds > 0 THEN
        -- 推后提醒：加上秒数
        SET NEW.audio_updated_at = DATE_ADD(NEW.expected_end_time, INTERVAL offset_seconds SECOND);
    ELSE
        -- 到期时间提醒
        SET NEW.audio_updated_at = NEW.expected_end_time;
    END IF;

    -- 生成订单号(RMYYYYMMDDNNN格式)
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `orders`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
    SET NEW.id = CONCAT('RM', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
END//

CREATE TRIGGER orders_before_update
BEFORE UPDATE ON `orders`
FOR EACH ROW
BEGIN
    DECLARE mute_seconds INT;
    DECLARE offset_seconds INT;
    DECLARE pause_duration INT;

    -- 从配置表获取自动静音时间
    SELECT CAST(config_value AS UNSIGNED) INTO mute_seconds
    FROM system_config
    WHERE config_key = 'alert_auto_mute_seconds';

    -- 如果没有找到配置，使用默认值90
    IF mute_seconds IS NULL THEN
        SET mute_seconds = 90;
    END IF;

    -- 获取音频提醒基准偏移配置
    SELECT CAST(config_value AS SIGNED) INTO offset_seconds
    FROM system_config
    WHERE config_key = 'alert_offset_seconds';

    -- 如果没有找到配置，使用默认值0（到期时间）
    IF offset_seconds IS NULL THEN
        SET offset_seconds = 0;
    END IF;

    -- 当status变化时自动更新audio_muted
    IF NEW.status != OLD.status THEN
        SET NEW.audio_muted = IF(NEW.status = 0, 0, 1);
    END IF;

    -- 时间同步：只有当expected_end_time变化时才更新audio_updated_at
    IF NEW.expected_end_time != OLD.expected_end_time THEN
        -- 根据offset_seconds调整提醒时间
        IF offset_seconds < 0 THEN
            -- 提前提醒：减去绝对值
            SET NEW.audio_updated_at = DATE_SUB(NEW.expected_end_time, INTERVAL ABS(offset_seconds) SECOND);
        ELSEIF offset_seconds > 0 THEN
            -- 推后提醒：加上秒数
            SET NEW.audio_updated_at = DATE_ADD(NEW.expected_end_time, INTERVAL offset_seconds SECOND);
        ELSE
            -- 到期时间提醒
            SET NEW.audio_updated_at = NEW.expected_end_time;
        END IF;

        -- 新功能：只要新改的预计结束时间超过了数据库时间，就重置为新的订单
        IF NEW.expected_end_time > CURRENT_TIMESTAMP THEN
            SET NEW.audio_muted = 0;
            SET NEW.snooze_alert = 0;
        END IF;
    END IF;

    -- 暂停/恢复逻辑
    IF NEW.is_paused != OLD.is_paused THEN
        IF NEW.is_paused = 1 AND OLD.is_paused = 0 THEN
            -- 暂停：设置暂停开始时间
            SET NEW.pause_start_time = CURRENT_TIMESTAMP;
        ELSEIF NEW.is_paused = 0 AND OLD.is_paused = 1 THEN
            -- 恢复：计算暂停时长并延长时间
            SET pause_duration = TIMESTAMPDIFF(SECOND, OLD.pause_start_time, CURRENT_TIMESTAMP);

            -- 延长预计结束时间
            SET NEW.expected_end_time = DATE_ADD(OLD.expected_end_time, INTERVAL pause_duration SECOND);

            -- 延长音频提醒时间
            SET NEW.audio_updated_at = DATE_ADD(OLD.audio_updated_at, INTERVAL pause_duration SECOND);

            -- 累加暂停时长
            SET NEW.total_pause_duration = OLD.total_pause_duration + pause_duration;

            -- 清空暂停开始时间
            SET NEW.pause_start_time = NULL;
        END IF;
    END IF;

    -- 检查是否超时（基于真实到期时间 expected_end_time）
    IF NEW.audio_muted = 0 AND TIMESTAMPDIFF(SECOND, NEW.expected_end_time, CURRENT_TIMESTAMP) > mute_seconds THEN
        SET NEW.audio_muted = 1;
    END IF;
END//

-- 支付明细表触发器 - 设备控制
CREATE TRIGGER payment_details_after_insert
AFTER INSERT ON `orders_payment_details`
FOR EACH ROW
BEGIN
    -- 根据payment_type判断工作流类型
    IF NEW.payment_type = 0 THEN -- 开台
        INSERT INTO device_execution_queue (room_id, command_name, command_data, protocol_type, status, priority, origin_client)
        SELECT
            o.room_id,
            '开台设备控制工作流',
            JSON_OBJECT('workflow', '开台流程'),
            r.device_protocol,
            'pending',
            10,
            'OpTypeDevCtrl'
        FROM orders o
        JOIN rooms r ON o.room_id = r.id
        WHERE o.id = NEW.order_id
        AND r.device_enabled = 1;

    ELSEIF NEW.payment_type = 1 THEN -- 加时
        INSERT INTO device_execution_queue (room_id, command_name, command_data, protocol_type, status, priority, origin_client)
        SELECT
            o.room_id,
            '加时设备控制工作流',
            JSON_OBJECT('workflow', '加时流程'),
            r.device_protocol,
            'pending',
            5,
            'OpTypeDevCtrl'
        FROM orders o
        JOIN rooms r ON o.room_id = r.id
        WHERE o.id = NEW.order_id
        AND r.device_enabled = 1;

    ELSEIF NEW.payment_type = 2 THEN -- 结账
        INSERT INTO device_execution_queue (room_id, command_name, command_data, protocol_type, status, priority, origin_client)
        SELECT
            o.room_id,
            '结账设备控制工作流',
            JSON_OBJECT('workflow', '结账流程'),
            r.device_protocol,
            'pending',
            15,
            'OpTypeDevCtrl'
        FROM orders o
        JOIN rooms r ON o.room_id = r.id
        WHERE o.id = NEW.order_id
        AND r.device_enabled = 1;
    END IF;
END//

-- 预定表触发器
CREATE TRIGGER reservations_before_insert
BEFORE INSERT ON `reservations`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    DECLARE offset_seconds INT;

    -- 获取音频提醒基准偏移配置
    SELECT CAST(config_value AS SIGNED) INTO offset_seconds
    FROM system_config
    WHERE config_key = 'alert_offset_seconds';

    -- 如果没有找到配置，使用默认值0（到期时间）
    IF offset_seconds IS NULL THEN
        SET offset_seconds = 0;
    END IF;

    -- 规则: 状态为0(未到期)或1(已超时)时音频不静音，其他状态静音
    SET NEW.audio_muted = IF(NEW.status IN (0, 1), 0, 1);

    -- 时间同步：根据offset_seconds调整提醒时间
    IF offset_seconds < 0 THEN
        -- 提前提醒：减去绝对值
        SET NEW.audio_updated_at = DATE_SUB(NEW.reservation_time, INTERVAL ABS(offset_seconds) SECOND);
    ELSEIF offset_seconds > 0 THEN
        -- 推后提醒：加上秒数
        SET NEW.audio_updated_at = DATE_ADD(NEW.reservation_time, INTERVAL offset_seconds SECOND);
    ELSE
        -- 到期时间提醒
        SET NEW.audio_updated_at = NEW.reservation_time;
    END IF;

    -- 生成订单号(BKYYYYMMDDNNN格式)
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `reservations`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
    SET NEW.id = CONCAT('BK', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
END//

CREATE TRIGGER reservations_before_update
BEFORE UPDATE ON `reservations`
FOR EACH ROW
BEGIN
    DECLARE mute_seconds INT;
    DECLARE offset_seconds INT;

    -- 从配置表获取自动静音时间
    SELECT CAST(config_value AS UNSIGNED) INTO mute_seconds
    FROM system_config
    WHERE config_key = 'alert_auto_mute_seconds';

    -- 如果没有找到配置，使用默认值90
    IF mute_seconds IS NULL THEN
        SET mute_seconds = 90;
    END IF;

    -- 获取音频提醒基准偏移配置
    SELECT CAST(config_value AS SIGNED) INTO offset_seconds
    FROM system_config
    WHERE config_key = 'alert_offset_seconds';

    -- 如果没有找到配置，使用默认值0（到期时间）
    IF offset_seconds IS NULL THEN
        SET offset_seconds = 0;
    END IF;

    -- 当status变化时自动更新audio_muted
    -- 注意：只有从非活跃状态(2,3,4)变为活跃状态(0,1)时才重置audio_muted
    -- 从0变为1（未到期→已超时）不应该重置，因为用户可能已经手动静音了
    IF NEW.status != OLD.status THEN
        -- 只有从非活跃状态变为活跃状态时才重置
        IF OLD.status NOT IN (0, 1) AND NEW.status IN (0, 1) THEN
            SET NEW.audio_muted = 0;
        -- 从活跃状态变为非活跃状态时静音
        ELSEIF OLD.status IN (0, 1) AND NEW.status NOT IN (0, 1) THEN
            SET NEW.audio_muted = 1;
        END IF;
        -- 从0变为1或从1变为0时，不改变audio_muted
    END IF;

    -- 时间同步：只有当reservation_time变化时才更新audio_updated_at
    IF NEW.reservation_time != OLD.reservation_time THEN
        -- 根据offset_seconds调整提醒时间
        IF offset_seconds < 0 THEN
            -- 提前提醒：减去绝对值
            SET NEW.audio_updated_at = DATE_SUB(NEW.reservation_time, INTERVAL ABS(offset_seconds) SECOND);
        ELSEIF offset_seconds > 0 THEN
            -- 推后提醒：加上秒数
            SET NEW.audio_updated_at = DATE_ADD(NEW.reservation_time, INTERVAL offset_seconds SECOND);
        ELSE
            -- 到期时间提醒
            SET NEW.audio_updated_at = NEW.reservation_time;
        END IF;

        -- 新功能：只要新改的预定时间超过了数据库时间，就重置为新的预定
        IF NEW.reservation_time > CURRENT_TIMESTAMP THEN
            SET NEW.audio_muted = 0;
            SET NEW.status = 0;
            SET NEW.snooze_alert = 0;
        END IF;
    END IF;

    -- 检查是否超时（基于真实到期时间 reservation_time）
    IF NEW.audio_muted = 0 AND TIMESTAMPDIFF(SECOND, NEW.reservation_time, CURRENT_TIMESTAMP) > mute_seconds THEN
        SET NEW.audio_muted = 1;
    END IF;
END//

DELIMITER ;

-- 设备执行队列表
CREATE TABLE IF NOT EXISTS `device_execution_queue` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `room_id` INT UNSIGNED NOT NULL COMMENT '房间ID',
  `command_name` VARCHAR(50) NOT NULL COMMENT '指令名称',
  `command_data` JSON NOT NULL COMMENT '指令数据',
  `protocol_type` ENUM('modbus_tcp', 'tcp_hex') NOT NULL COMMENT '协议类型',
  `status` ENUM('pending', 'executing', 'completed', 'failed') NOT NULL DEFAULT 'pending' COMMENT '执行状态',
  `priority` INT NOT NULL DEFAULT 0 COMMENT '优先级(数字越大优先级越高)',
  `retry_count` INT NOT NULL DEFAULT 0 COMMENT '重试次数',
  `max_retries` INT NOT NULL DEFAULT 2 COMMENT '最大重试次数',
  `error_message` TEXT DEFAULT NULL COMMENT '错误信息',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `execute_time` DATETIME NULL DEFAULT NULL COMMENT '执行时间',
  `complete_time` DATETIME NULL DEFAULT NULL COMMENT '完成时间',
  `origin_client` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '操作来源标识',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  INDEX `idx_status` (`status`),
  INDEX `idx_room` (`room_id`),
  INDEX `idx_priority` (`priority`),
  INDEX `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 设备执行队列自动清理事件
-- 每隔20小时清理1天前的所有状态记录
DROP EVENT IF EXISTS device_queue_cleanup_event;

DELIMITER //

CREATE EVENT device_queue_cleanup_event
ON SCHEDULE EVERY 20 HOUR  -- 每20小时执行一次
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DECLARE affected_rows INT DEFAULT 0;

    -- 清理1天前的所有状态记录（包括pending、executing、completed、failed）
    DELETE FROM device_execution_queue
    WHERE create_time < DATE_SUB(NOW(), INTERVAL 1 DAY);

    -- 获取影响的行数
    SET affected_rows = ROW_COUNT();


END//

DELIMITER ;

-- 创建自动静音和超时设备控制事件（每10秒检查一次）
DROP EVENT IF EXISTS auto_mute_and_timeout_device_control_event;

DELIMITER //

CREATE EVENT IF NOT EXISTS auto_mute_and_timeout_device_control_event
ON SCHEDULE EVERY 10 SECOND
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DECLARE mute_seconds INT;
    DECLARE grace_minutes INT;

    -- 从配置表获取自动静音时间
    SELECT CAST(config_value AS UNSIGNED) INTO mute_seconds
    FROM system_config
    WHERE config_key = 'alert_auto_mute_seconds';

    -- 如果没有找到配置，使用默认值90
    IF mute_seconds IS NULL THEN
        SET mute_seconds = 90;
    END IF;

    -- 从配置表获取预定宽限期（分钟）
    SELECT CAST(config_value AS UNSIGNED) INTO grace_minutes
    FROM system_config
    WHERE config_key = 'reservation_grace_minutes';

    -- 如果没有找到配置，使用默认值30分钟
    IF grace_minutes IS NULL THEN
        SET grace_minutes = 30;
    END IF;

    -- 更新orders表 - 订单超时静音并触发设备控制（基于真实到期时间 expected_end_time）
    UPDATE orders
    SET audio_muted = 1,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND audio_muted = 0
    AND TIMESTAMPDIFF(SECOND, expected_end_time, CURRENT_TIMESTAMP) > mute_seconds;

    -- 订单超时设备控制逻辑：基于精确时间点触发，每个时间点只执行一次
    -- 排除0小时订单（start_time = expected_end_time）
    -- 基于真实到期时间 expected_end_time
    INSERT INTO device_execution_queue (room_id, command_name, command_data, protocol_type, status, priority, origin_client)
    SELECT
        o.room_id,
        '订单超时设备控制工作流',
        JSON_OBJECT('workflow', '订单超时流程'),
        r.device_protocol,
        'pending',
        20,
        'TimeoutDevCtrl'
    FROM orders o
    JOIN rooms r ON o.room_id = r.id
    WHERE o.create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND o.audio_muted = 1
    AND o.status = 0
    AND r.device_enabled = 1
    AND o.start_time != o.expected_end_time
    AND DATE_ADD(o.expected_end_time, INTERVAL mute_seconds SECOND) <= CURRENT_TIMESTAMP
    AND DATE_ADD(o.expected_end_time, INTERVAL mute_seconds SECOND) > DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 10 SECOND)
    AND NOT EXISTS (
        SELECT 1 FROM device_execution_queue eq
        WHERE eq.room_id = o.room_id
        AND eq.command_name = '订单超时流程'
        AND eq.status IN ('pending', 'executing')
    );

    -- 更新reservations表（基于真实到期时间 reservation_time）
    UPDATE reservations
    SET audio_muted = 1,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND audio_muted = 0
    AND TIMESTAMPDIFF(SECOND, reservation_time, CURRENT_TIMESTAMP) > mute_seconds;

    -- 更新超时的预定状态为已超时(status=1)
    UPDATE reservations
    SET status = 1,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND status = 0
    AND TIMESTAMPDIFF(SECOND, reservation_time, CURRENT_TIMESTAMP) > 5;

    -- 更新超过宽限期的预定状态为超时并取消(status=3)
    -- 秒级判定：满宽限期秒数即触发，与前端 prune 及 PHP 查询边界对齐（满60秒才算1分钟）
    UPDATE reservations
    SET status = 3,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND status = 1
    AND TIMESTAMPDIFF(SECOND, reservation_time, CURRENT_TIMESTAMP) >= grace_minutes * 60;

    -- 稍后提醒逻辑：检查订单稍后提醒（只对进行中的订单）
    UPDATE orders
    SET audio_muted = 0,
        snooze_alert = 0,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND snooze_alert = 1
    AND audio_updated_at <= CURRENT_TIMESTAMP
    AND audio_muted = 1
    AND status = 0;

    -- 稍后提醒逻辑：检查预定稍后提醒（只对已超时的预定）
    UPDATE reservations
    SET audio_muted = 0,
        snooze_alert = 0,
        origin_client = 'system_auto_update',
        update_time = CURRENT_TIMESTAMP
    WHERE create_time >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND snooze_alert = 1
    AND audio_updated_at <= CURRENT_TIMESTAMP
    AND audio_muted = 1
    AND status = 1;

    -- 设备执行队列超时检测：将超过10秒的pending状态记录标记为failed
    UPDATE device_execution_queue
    SET status = 'failed',
        error_message = '执行超时：超过10秒未处理',
        create_time = CURRENT_TIMESTAMP
    WHERE status = 'pending'
    AND create_time < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 10 SECOND);

    -- 呼叫店员自动静音：超过 auto_mute_seconds 未处理则自动静音
    UPDATE room_access_codes
    SET audio_muted = 1,
        update_time = CURRENT_TIMESTAMP
    WHERE audio_muted = 0
    AND audio_updated_at IS NOT NULL
    AND TIMESTAMPDIFF(SECOND, audio_updated_at, CURRENT_TIMESTAMP) > mute_seconds;

    -- 呼叫店员自动静音：二维码已停用但音频标记仍为未静音，强制静音
    UPDATE room_access_codes
    SET audio_muted = 1,
        update_time = CURRENT_TIMESTAMP
    WHERE audio_muted = 0
    AND is_enabled = 0;

    -- 核销服务自动静音：访问码被取消时强制静音
    UPDATE room_access_codes
    SET verification_status = 1,
        update_time = CURRENT_TIMESTAMP
    WHERE verification_status = 0
    AND is_enabled = 0;

    -- 核销服务自动静音：超过 auto_mute_seconds 未处理则自动静音
    UPDATE room_access_codes
    SET verification_status = 1,
        update_time = CURRENT_TIMESTAMP
    WHERE verification_status = 0
    AND verification_time IS NOT NULL
    AND TIMESTAMPDIFF(SECOND, verification_time, CURRENT_TIMESTAMP) > mute_seconds;

END//

DELIMITER ;

-- 用途标签表
CREATE TABLE IF NOT EXISTS `purpose_tags` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '标签名称',
  `usage_count` INT NOT NULL DEFAULT 0 COMMENT '使用次数',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_name` (`name`),
  INDEX `idx_usage` (`usage_count`),
  INDEX `idx_active` (`is_deleted`, `usage_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用途标签表';

-- 卖品信息表
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '卖品名称',
  `type` VARCHAR(20) NOT NULL DEFAULT '饮品' COMMENT '卖品类型',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '单价',
  `member_discount` INT NOT NULL DEFAULT 100 COMMENT '会员折扣(百分比，例如80表示8折)',
  `enable_member_levels_discount` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否参与会员等级折扣 1=参与 0=不参与',
  `allow_zero_stock` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '允许零库存销售 1=允许 0=不允许',
  `stock_quantity` INT NOT NULL DEFAULT 0 COMMENT '当前库存数量',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用 1=启用 0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序序号',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_name` (`name`),
  INDEX `idx_sort` (`sort_order`),
  INDEX `idx_type` (`type`),
  INDEX `idx_active` (`is_deleted`, `id`, `name`),
  INDEX `idx_stock` (`stock_quantity`),
  INDEX `idx_allow_zero_stock` (`allow_zero_stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 卖品订单表
CREATE TABLE IF NOT EXISTS `product_orders` (
  `id` VARCHAR(20) NOT NULL COMMENT '订单号(格式PDYYYYMMDDNNN)',
  `batch_id` VARCHAR(20) DEFAULT NULL COMMENT '批次ID，同一次购买的商品共享此ID',
  `product_id` INT UNSIGNED NOT NULL COMMENT '卖品ID',
  `quantity` INT NOT NULL DEFAULT 1 COMMENT '数量',
  `unit_price` DECIMAL(10,2) NOT NULL COMMENT '单价',
  `discount` INT UNSIGNED NOT NULL DEFAULT 100 COMMENT '会员折扣快照',
  `total_amount` DECIMAL(10,2) NOT NULL COMMENT '总金额',
   `payment_method_id` INT UNSIGNED NOT NULL COMMENT '支付方式ID',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员卡号',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '订单备注',
  `time_card_data` JSON DEFAULT NULL COMMENT '次卡券数据(JSON格式)',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未结账 1=已结账',
  `is_refunded` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未退款 1=已退款',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `origin_client` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '操作来源标识',
  `request_code` VARCHAR(64) DEFAULT NULL COMMENT '唯一请求码',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  INDEX `idx_batch` (`batch_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_product` (`product_id`),
  INDEX `idx_payment` (`payment_method_id`),
  INDEX `idx_origin_client` (`origin_client`),
  INDEX `idx_member_card` (`member_card_no`),
  INDEX `idx_refund` (`is_refunded`),
  INDEX `idx_product_client_time` (`product_id`, `origin_client`, `create_time`),
  INDEX `idx_request_code` (`request_code`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 卖品订单表触发器
DELIMITER //

CREATE TRIGGER product_orders_before_insert
BEFORE INSERT ON `product_orders`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;

    -- 生成订单号(PDYYYYMMDDNNN格式)
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `product_orders`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
    SET NEW.id = CONCAT('PD', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
END//

DELIMITER ;

-- 商品入库记录表
CREATE TABLE IF NOT EXISTS `product_stock_records` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_no` VARCHAR(20) NOT NULL COMMENT '批次号(格式RKYYYYMMDDNNN)',
  `product_id` INT UNSIGNED NOT NULL COMMENT '商品ID',
  `product_name` VARCHAR(50) NOT NULL COMMENT '商品名称',
  `current_stock` INT NOT NULL COMMENT '当前库存(入库前)',
  `in_quantity` INT NOT NULL DEFAULT 0 COMMENT '入库数量',
  `loss_quantity` INT NOT NULL DEFAULT 0 COMMENT '损耗数量',
  `stock_quantity` INT NOT NULL COMMENT '库存数量 (当前库存 + 入库 - 损耗)',
  `unit_price` DECIMAL(10,2) NOT NULL COMMENT '单价',
  `total_amount` DECIMAL(10,2) NOT NULL COMMENT '总金额',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT,
  INDEX `idx_batch_no` (`batch_no`),
  INDEX `idx_product` (`product_id`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_batch_product` (`batch_no`, `product_id`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品入库记录表';

-- 商品挂单表
CREATE TABLE IF NOT EXISTS `product_credit_for_room` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `batch_no` VARCHAR(20) NOT NULL COMMENT '批次号',
  `product_id` INT UNSIGNED NOT NULL COMMENT '商品ID',
  `quantity` INT NOT NULL DEFAULT 1 COMMENT '数量',
  `unit_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '单价（购买时的单价）',
  `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '总金额（单价×数量）',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT,
  INDEX `idx_batch_no` (`batch_no`),
  INDEX `idx_product` (`product_id`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_batch_product` (`batch_no`, `product_id`),
  INDEX `idx_batch_product_price` (`batch_no`, `product_id`, `unit_price`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品挂单表';

-- 订单挂单表已删除
-- 挂单功能现在通过 orders_payment_details 表实现
-- 挂单记录使用 payment_method_id=88 且 amount 为负值

-- 套餐管理表
CREATE TABLE IF NOT EXISTS `promotion_strategies` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL COMMENT '套餐名称',
  `type` VARCHAR(20) NOT NULL DEFAULT '通用' COMMENT '套餐类型',
  `hours` DECIMAL(5,2) NOT NULL COMMENT '时长（小时）',
  `price` DECIMAL(10,2) NOT NULL COMMENT '价格',
  `room_ids` TEXT COMMENT '适用房间ID（JSON数组，空或null表示全部房间）',
  `apply_mode` VARCHAR(10) NOT NULL DEFAULT 'room' COMMENT '适配维度：room=按房间，type=按房间类型（与room_ids二选一）',
  `room_types` TEXT COMMENT '适用房间类型（JSON数组，apply_mode=type时生效；空或null表示全部类型）',
  `weekdays` VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5,6,7' COMMENT '适用星期（1-7，逗号分隔）',
  `time_start` TIME NOT NULL DEFAULT '00:00:00' COMMENT '开始时间',
  `time_end` TIME NOT NULL DEFAULT '23:59:59' COMMENT '结束时间',
  `member_discount` INT NOT NULL DEFAULT 100 COMMENT '会员折扣(百分比，例如80表示8折)',
  `enable_member_levels_discount` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否参与会员等级折扣 1=参与 0=不参与',
  `is_all_day` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否全天套餐 1=全天 0=普通',
  `is_unlimited` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否不限时套餐 1=不限时 0=普通',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用（1=启用，0=停用）',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `usage_count` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '使用标记：0=未使用，1=已使用',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`),
  INDEX `idx_sort` (`sort_order`),
  INDEX `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='套餐管理表';

-- ============================================
-- 次卡券系统表
-- ============================================

-- 次卡券商品定义表
CREATE TABLE IF NOT EXISTS `time_card_products` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL COMMENT '次卡券名称',
  `type` ENUM('room', 'product') NOT NULL COMMENT '次卡券类型：room=房间次卡券，product=商品次卡券',
  `price` DECIMAL(10,2) NOT NULL COMMENT '售价',
  `total_times` INT UNSIGNED NOT NULL COMMENT '总次数',
  `hours` DECIMAL(6,2) DEFAULT NULL COMMENT '房间次卡券抵扣时长（小时）',
  `product_ids` JSON DEFAULT NULL COMMENT '商品次卡券：适用商品ID数组（NULL=全部商品）',
  `product_apply_mode` VARCHAR(10) NOT NULL DEFAULT 'product' COMMENT '商品适配维度：product=按商品名称，type=按商品类型（与product_ids二选一）',
  `product_types` JSON DEFAULT NULL COMMENT '适用商品类型（JSON数组，product_apply_mode=type时生效；NULL=全部类型）',
  `room_ids` JSON DEFAULT NULL COMMENT '房间次卡券：适用房间ID数组（NULL=全部房间）',
  `apply_mode` VARCHAR(10) NOT NULL DEFAULT 'room' COMMENT '适配维度：room=按房间，type=按房间类型（与room_ids二选一）',
  `room_types` JSON DEFAULT NULL COMMENT '适用房间类型（JSON数组，apply_mode=type时生效；NULL=全部类型）',
  `validity_days` INT UNSIGNED DEFAULT NULL COMMENT '有效期天数（NULL=永久有效）',
  `member_discount` INT NOT NULL DEFAULT 100 COMMENT '会员折扣(百分比，例如80表示8折)',
  `enable_member_levels_discount` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否参与会员等级折扣 1=参与 0=不参与',
  `is_all_day` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否全天次卡券（仅room类型适用）：1=全天，到期按系统设置的全天到期时间计算；0=普通按时长。商品次卡无此概念',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记（0=未删除，1=已删除）',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `idx_name` (`name`),
  INDEX `idx_type` (`type`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`),
  INDEX `idx_active` (`is_deleted`, `is_enabled`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='次卡券商品定义表';

-- 次卡券销售订单表
CREATE TABLE IF NOT EXISTS `time_card_orders` (
  `id` VARCHAR(20) NOT NULL COMMENT '订单号(格式TCYYYYMMDDNNN)',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员手机号',
  `time_card_id` INT UNSIGNED NOT NULL COMMENT '次卡券商品ID',
  `total_times` INT UNSIGNED NOT NULL COMMENT '总次数（快照）',
  `hours` DECIMAL(5,2) DEFAULT NULL COMMENT '时长（快照，房间次卡专用）',
  `validity_days` INT UNSIGNED DEFAULT NULL COMMENT '有效期天数（快照，NULL=永久）',
  `quantity` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '数量',
  `unit_price` DECIMAL(10,2) NOT NULL COMMENT '单价',
  `total_amount` DECIMAL(10,2) NOT NULL COMMENT '总金额',
  `payment_method_id` INT UNSIGNED NOT NULL COMMENT '支付方式ID',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '备注',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `status` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未结账 1=已结账',
  `is_refunded` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未退款 1=已退款',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `origin_client` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '操作来源标识',
  `request_code` VARCHAR(64) DEFAULT NULL COMMENT '唯一请求码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_code` (`request_code`),
  INDEX `idx_member` (`member_card_no`),
  INDEX `idx_time_card` (`time_card_id`),
  INDEX `idx_payment` (`payment_method_id`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_status` (`status`),
  INDEX `idx_refund` (`is_refunded`),
  INDEX `idx_origin_client` (`origin_client`),
  INDEX `idx_member_status` (`member_card_no`, `status`),
  INDEX `idx_member_refund` (`member_card_no`, `is_refunded`),
  INDEX `idx_status_refund` (`status`, `is_refunded`),
  INDEX `idx_total_times` (`total_times`),
  INDEX `idx_validity` (`validity_days`),
  INDEX `idx_operator` (`operator_id`),
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  FOREIGN KEY (`time_card_id`) REFERENCES `time_card_products`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='次卡券销售订单表';

-- 会员持有次卡券表
CREATE TABLE IF NOT EXISTS `time_cards_member` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `sale_order_no` VARCHAR(20) NOT NULL COMMENT '销售订单号（关联次卡券销售订单号）',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员手机号',
  `time_card_id` INT UNSIGNED NOT NULL COMMENT '次卡券 ID',
  `total_times` INT UNSIGNED NOT NULL COMMENT '总次数（购买时的初始次数）',
  `remaining_times` INT UNSIGNED NOT NULL COMMENT '剩余次数',
  `purchase_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '购买时间',
  `expire_time` DATETIME NULL DEFAULT NULL COMMENT '过期时间（NULL=永久有效）',
  `is_expired` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已过期 0=未过期 1=已过期',
  `last_use_time` DATETIME NULL DEFAULT NULL COMMENT '最后使用时间',
  `snapshot_hours` DECIMAL(10,2) NULL DEFAULT NULL COMMENT '抵扣时间快照（购买时保存，仅房间次卡有效）',
  `is_all_day` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否全天次卡券1=全天，0=普通',
  PRIMARY KEY (`id`),
  INDEX `idx_sale_order` (`sale_order_no`),
  INDEX `idx_member` (`member_card_no`),
  INDEX `idx_time_card` (`time_card_id`),
  INDEX `idx_remaining` (`remaining_times`),
  INDEX `idx_expire` (`expire_time`),
  INDEX `idx_expired` (`is_expired`),
  INDEX `idx_member_remaining` (`member_card_no`, `remaining_times`),
  INDEX `idx_member_expire` (`member_card_no`, `expire_time`),
  INDEX `idx_sale_order_member` (`sale_order_no`, `member_card_no`),
  FOREIGN KEY (`sale_order_no`) REFERENCES `time_card_orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  FOREIGN KEY (`time_card_id`) REFERENCES `time_card_products`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员持有次卡券表';

-- 次卡券使用记录表
CREATE TABLE IF NOT EXISTS `time_card_consumptions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `purchase_order_no` VARCHAR(20) NOT NULL COMMENT '次卡券销售单号',
  `batch_no` VARCHAR(20) NOT NULL COMMENT '使用订单号',
  `member_card_no` VARCHAR(50) DEFAULT NULL COMMENT '会员手机号',
  `time_card_id` INT UNSIGNED NOT NULL COMMENT '次卡券商品ID',
  `usage_type` ENUM('room', 'product') NOT NULL COMMENT '使用类型：room=房间，product=商品',
  `room_id` INT UNSIGNED DEFAULT NULL COMMENT '房间ID',
  `deduction_hours` DECIMAL(6,2) DEFAULT NULL COMMENT '抵扣时长（房间次卡券）',
  `product_id` INT UNSIGNED DEFAULT NULL COMMENT '商品ID',
  `used_quantity` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '使用数量',
  `remaining_times` INT UNSIGNED NOT NULL COMMENT '使用后剩余次数',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `is_refunded` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未退费 1=已退费',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '使用时间',
  `request_code` VARCHAR(64) DEFAULT NULL COMMENT '唯一请求码',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_code` (`request_code`),
  INDEX `idx_purchase_order` (`purchase_order_no`),
  INDEX `idx_batch_no` (`batch_no`),
  INDEX `idx_member` (`member_card_no`),
  INDEX `idx_time_card` (`time_card_id`),
  INDEX `idx_usage_type` (`usage_type`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_refund` (`is_refunded`),
  INDEX `idx_purchase_member` (`purchase_order_no`, `member_card_no`),
  INDEX `idx_batch_type` (`batch_no`, `usage_type`),
  INDEX `idx_member_refund` (`member_card_no`, `is_refunded`),
  INDEX `idx_member_time` (`member_card_no`, `create_time`),
  INDEX `idx_room` (`room_id`),
  INDEX `idx_product` (`product_id`),
  INDEX `idx_operator` (`operator_id`),
  FOREIGN KEY (`purchase_order_no`) REFERENCES `time_card_orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE SET NULL ON UPDATE CASCADE,
  FOREIGN KEY (`time_card_id`) REFERENCES `time_card_products`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='次卡券使用记录表';

-- 次卡券销售订单表触发器：生成订单号
DELIMITER //

CREATE TRIGGER time_card_orders_before_insert
BEFORE INSERT ON `time_card_orders`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `time_card_orders`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
    SET NEW.id = CONCAT('TC', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
END//

DELIMITER ;

-- 会员持有次卡券表触发器：初始化状态
DELIMITER //

CREATE TRIGGER time_cards_member_before_insert
BEFORE INSERT ON `time_cards_member`
FOR EACH ROW
BEGIN
    -- 初始状态为未过期
    -- expire_time由PHP代码负责计算和传入：
    -- - 如果validity_days为NULL，则expire_time为NULL（永久有效）
    -- - 如果validity_days有值，则expire_time为购买时刻+天数（精确到秒）
    SET NEW.is_expired = 0;
END//

CREATE TRIGGER time_cards_member_before_update
BEFORE UPDATE ON `time_cards_member`
FOR EACH ROW
BEGIN
    -- 自动更新过期状态
    IF NEW.expire_time IS NOT NULL AND NEW.expire_time < NOW() THEN
        SET NEW.is_expired = 1;
    END IF;
END//

DELIMITER ;

-- ============================================
-- 次卡券系统表结束
-- ============================================

-- 班次交接表
CREATE TABLE IF NOT EXISTS `shift_handovers` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `operator_id` INT UNSIGNED NOT NULL COMMENT '操作员ID',
  `start_time` DATETIME NOT NULL COMMENT '交接开始时间',
  `end_time` DATETIME NOT NULL COMMENT '交接结束时间',
  `payment_stats` JSON NOT NULL COMMENT '支付方式统计数据(JSON格式)',
  `promotion_stats` JSON DEFAULT NULL COMMENT '套餐统计数据(JSON格式)',
  `total_system_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '系统总金额',
  `total_actual_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '实收总金额',
  `total_diff` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '总差异',
  `promotion_system_qty` INT NOT NULL DEFAULT 0 COMMENT '套餐系统总数量',
  `promotion_actual_qty` INT NOT NULL DEFAULT 0 COMMENT '套餐实际总数量',
  `promotion_diff_qty` INT NOT NULL DEFAULT 0 COMMENT '套餐总差异',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '交接备注',
  `handover_by_user_id` INT UNSIGNED DEFAULT NULL COMMENT '交接操作的用户ID',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  INDEX `idx_operator` (`operator_id`),
  INDEX `idx_time_range` (`start_time`, `end_time`),
  INDEX `idx_create_time` (`create_time`),
  FOREIGN KEY (`operator_id`) REFERENCES `system_users`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='班次交接表';

-- 会员消费记录表
CREATE TABLE IF NOT EXISTS `member_consumptions` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` VARCHAR(20) NOT NULL COMMENT '订单ID',
  `batch_id` VARCHAR(20) DEFAULT NULL COMMENT '批次ID，关联同批次消费',
  `room_id` INT UNSIGNED NULL COMMENT '包间ID',
  `product_id` INT UNSIGNED DEFAULT NULL COMMENT '卖品ID',
  `time_card_id` INT UNSIGNED DEFAULT NULL COMMENT '次卡券ID',
  `member_card_no` VARCHAR(50) NOT NULL COMMENT '会员卡号',
  `name` VARCHAR(50) DEFAULT NULL COMMENT '会员姓名',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '消费金额',
  `final_balance` DECIMAL(10,2) NOT NULL COMMENT '消费后余额',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '消费时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`time_card_id`) REFERENCES `time_card_products`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`member_card_no`) REFERENCES `member_accounts`(`member_card_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX `idx_order` (`order_id`),
  INDEX `idx_batch` (`batch_id`),
  INDEX `idx_card_no` (`member_card_no`),
  INDEX `idx_product` (`product_id`),
  INDEX `idx_time_card` (`time_card_id`),
  INDEX `idx_time` (`create_time`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 会员卡操作历史表
CREATE TABLE IF NOT EXISTS `member_card_transfer_history` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `source_card_no` VARCHAR(50) NOT NULL COMMENT '原卡号',
  `archived_card_no` VARCHAR(50) NOT NULL DEFAULT '' COMMENT '归档卡号',
  `target_card_no` VARCHAR(50) NOT NULL COMMENT '新卡号',
  `transfer_amount` DECIMAL(10,2) NOT NULL COMMENT '转账金额',
  `source_card_name` VARCHAR(50) DEFAULT NULL COMMENT '原卡会员姓名',
  `target_card_name` VARCHAR(50) DEFAULT NULL COMMENT '新卡会员姓名',
  `is_new_card_created` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否创建了新卡（0=新卡已存在，1=新创建）',
  `old_name` VARCHAR(50) DEFAULT NULL COMMENT '修改前姓名',
  `new_name` VARCHAR(50) DEFAULT NULL COMMENT '修改后姓名',
  `password_change` VARCHAR(50) DEFAULT NULL COMMENT '密码变更记录',
  `old_level_id` INT DEFAULT NULL COMMENT '旧卡类型 ID',
  `new_level_id` INT DEFAULT NULL COMMENT '新卡类型 ID',
  `transfer_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  PRIMARY KEY (`id`),
  INDEX `idx_source_card` (`source_card_no`),
  INDEX `idx_archived_card` (`archived_card_no`),
  INDEX `idx_target_card` (`target_card_no`),
  INDEX `idx_transfer_time` (`transfer_time`),
  INDEX `idx_search` (`source_card_no`, `target_card_no`, `transfer_time`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 会员表触发器：新增会员时自动填充后4位
DELIMITER //

CREATE TRIGGER member_accounts_before_insert
BEFORE INSERT ON `member_accounts`
FOR EACH ROW
BEGIN
    -- 如果卡号包含@符号（归档卡），则后4位设为NULL
    IF LOCATE('@', NEW.member_card_no) > 0 THEN
        SET NEW.last_four_digits = NULL;
    ELSE
        -- 否则提取卡号后4位
        SET NEW.last_four_digits = RIGHT(NEW.member_card_no, 4);
    END IF;
END//

CREATE TRIGGER member_accounts_before_update
BEFORE UPDATE ON `member_accounts`
FOR EACH ROW
BEGIN
    -- 只有当卡号发生变化时才更新后4位
    IF NEW.member_card_no != OLD.member_card_no THEN
        -- 如果新卡号包含@符号（归档卡），则后4位设为NULL
        IF LOCATE('@', NEW.member_card_no) > 0 THEN
            SET NEW.last_four_digits = NULL;
        ELSE
            -- 否则提取新卡号后4位
            SET NEW.last_four_digits = RIGHT(NEW.member_card_no, 4);
        END IF;
    END IF;
END//

DELIMITER ;

-- 为充值表创建订单号触发器
DELIMITER //

CREATE TRIGGER member_recharges_before_insert
BEFORE INSERT ON `member_recharges`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;

    -- 生成订单号(MRYYYYMMDDNNN格式，3位尾数)
    -- 只查询3位尾数的订单（尾数 < 1000），忽略数据导入的4位、5位等尾数
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `member_recharges`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d')
      AND CAST(SUBSTRING(id, 11) AS UNSIGNED) < 1000;

    SET NEW.id = CONCAT('MR', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
END//

DELIMITER ;

-- 系统用户表
CREATE TABLE IF NOT EXISTS `system_users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL COMMENT '用户名',
  `name` VARCHAR(50) NOT NULL COMMENT '姓名',
  `password` VARCHAR(255) NOT NULL COMMENT '密码',
  `role` ENUM('admin', 'front') NOT NULL DEFAULT 'front' COMMENT '权限角色：admin=管理员，front=前台',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用 1=启用 0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  INDEX `idx_role` (`role`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- 初始化密码数据
INSERT INTO system_config (config_key, config_value, password_version, config_type, config_group, config_description, is_visible, sort_order)
VALUES ('admin_password', '$2y$10$u0nBpTJTNlFWnuQcObF/.ecOwQJ.XyhQ7qwgdV.PcK2CQ1JD/chjq', 0, 'string', 'system', '管理员密码', 0, 0),
('front_password', '$2y$10$Cu357RUWf5KzSZc5CAZhdOB1YJ5cUK1au5rgtvBqWs/dYY4Hh6fFu', 0, 'string', 'system', '前台访问密码', 0, 0);

-- 初始化系统用户数据
INSERT INTO `system_users` (`username`, `name`, `password`, `role`, `is_enabled`, `is_deleted`) VALUES
('admin', '管理员', '$2y$10$u0nBpTJTNlFWnuQcObF/.ecOwQJ.XyhQ7qwgdV.PcK2CQ1JD/chjq', 'admin', 1, 0);

-- 添加系统配置数据
INSERT INTO system_config (config_key, config_value, password_version, config_type, config_group, config_description, is_visible, sort_order) VALUES
('member_recharge_max_amount', '5000', 1, 'number', 'member', '单次充值最大限额', 1, 1),
('member_gift_max_amount', '500', 1, 'number', 'member', '单次赠送最大限额', 1, 2),
('member_recharge_multiple', '0', 1, 'number', 'member', '充值金额倍数限制', 1, 3),
('member_zero_card_enabled', '0', 1, 'boolean', 'member', '是否允许0元开卡', 1, 4),
('member_gift_enabled', '1', 1, 'boolean', 'member', '是否启用充值赠送功能', 1, 5),
('member_refund_enabled', '1', 1, 'boolean', 'member', '是否启用充值退款功能', 1, 6),
('member_gift_refund_enabled', '1', 1, 'boolean', 'member', '是否启用赠送退款功能', 1, 7),
('member_password_enabled', '1', 1, 'boolean', 'member', '是否启用会员密码功能', 1, 8),
('member_auto_upgrade_enabled', '0', 1, 'boolean', 'member', '是否启用卡类型自动升级', 1, 9),
('room_max_amount', '5000', 1, 'number', 'room', '单次消费金额最大限额', 1, 10),
('room_hours_step', '0.5', 1, 'number', 'room', '房间时长递增值(小时)', 1, 11),
('room_min_hours', '0.5', 1, 'number', 'room', '单次消费时间最小限额(小时)', 1, 12),
('room_max_hours', '24', 1, 'number', 'room', '单次消费时间最大限额(小时)', 1, 13),
('room_default_open_hours', '2', 1, 'number', 'room', '默认开台时长(小时)', 1, 14),
('room_default_extend_hours', '1', 1, 'number', 'room', '默认加时时长(小时)', 1, 15),
('room_open_gift_minutes', '0', 1, 'number', 'room', '开台赠送时长(分钟)', 1, 16),
('overtime_fee_rule', '1', 1, 'number', 'room', '超时费用规则(分钟)', 1, 17),
('default_timer_mode', '0', 1, 'boolean', 'room', '默认计时方式', 1, 18),
('room_price_edit_enabled', '1', 1, 'boolean', 'room', '是否启用开台/加时费用编辑功能', 1, 19),
('room_extra_fee_enabled', '1', 1, 'boolean', 'room', '是否启用结账附加费编辑功能', 1, 20),
('room_refund_enabled', '1', 1, 'boolean', 'room', '是否启用结账退费功能', 1, 21),
('order_edit_enabled', '0', 1, 'boolean', 'room', '是否允许编辑订单信息', 1, 22),
('guest_count_enabled', '0', 1, 'boolean', 'room', '是否启用房间人数功能', 1, 23),
('room_transfer_allow_occupied', '0', 1, 'boolean', 'room', '更换房间规则', 1, 24),
('qr_idle_service_enabled', '0', 1, 'boolean', 'room', '桌码空闲状态服务控制', 1, 25),
('qr_checkin_enabled', '0', 1, 'boolean', 'room', '是否允许桌码扫码开台', 1, 26),
('reservation_grace_minutes', '20', 1, 'number', 'room', '预定超时后继续显示(分钟)', 1, 27),
('reservation_overlap_minutes', '20', 1, 'number', 'room', '同一房间预定防重叠间隔(分钟)', 1, 28),
('timer_tts_enabled', '0', 1, 'boolean', 'audio', '超时语音播报(TTS)', 1, 29),
('tts_number_to_chinese', '0', 1, 'boolean', 'audio', '房间名称数字中文读法', 1, 30),
('timer_tts_template', '房间{房间名}已超时，请及时处理', 1, 'string', 'audio', '房间播报文本模板', 1, 31),
('manual_tts_template', '房间{房间名}已超时，请及时处理', 1, 'string', 'audio', '手动播报文本模板', 1, 32),
('timer_tts_reservation', '房间{房间名}预定已超时，请及时处理', 1, 'string', 'audio', '预定播报文本模板', 1, 33),
('timer_scan_checkin_tts_template', '房间{房间名}客户扫码开台成功', 1, 'string', 'audio', '扫码开台文本模板', 1, 34),
('timer_call_staff_tts_template', '房间{房间名}呼叫服务，请及时处理', 1, 'string', 'audio', '呼叫服务文本模板', 1, 35),
('timer_verification_tts_template', '房间{房间名}有核销服务，请及时处理', 1, 'string', 'audio', '核销服务文本模板', 1, 36),
('merchant_announcement_tts_template', '尊敬的用户，本店营业时间到了', 1, 'string', 'audio', '商家公告文本模板', 1, 37),
('alert_offset_seconds', '0', 1, 'number', 'audio', '音频提醒基准(秒)', 1, 38),
('timer_audio_auto_close_timeout', '60', 1, 'number', 'audio', '音频自动关闭时间(秒)', 1, 39),
('snooze_alert_seconds', '300', 1, 'number', 'audio', '稍后提醒音频延迟时间(秒)', 1, 40),
('alert_auto_mute_seconds', '600', 1, 'number', 'audio', '强制订单超期静音或设备执行(秒)', 1, 41),
('site_title', '包间管理系统', 1, 'string', 'system', '店铺名称', 1, 42),
('scene_room_name', '房间', 1, 'string', 'system', '场景适配-房间称呼', 1, 43),
('feature_room', '1', 1, 'boolean', 'system', '首页房间与预定功能开关', 1, 44),
('feature_product', '1', 1, 'boolean', 'system', '首页商品功能开关', 1, 45),
('feature_member', '1', 1, 'boolean', 'system', '首页会员功能开关', 1, 46),
('feature_stats', '1', 1, 'boolean', 'system', '首页统计功能开关', 1, 47),
('feature_rental', '0', 1, 'boolean', 'system', '首页租赁功能开关', 1, 48),
('feature_handover', '1', 1, 'boolean', 'system', '首页交班功能开关', 1, 49),
('printer', '0', 1, 'boolean', 'system', '打印功能开关(POS80)', 1, 50),
('enable_enter_submit', '0', 1, 'boolean', 'system', '回车键提交表单', 1, 51),
('stats_start_time', '09:00:00', 1, 'string', 'system', '报表统计开始时间', 1, 52),
('stats_end_time', '08:59:59', 1, 'string', 'system', '报表统计结束时间（次日）', 1, 53),
('all_day_end_time', '23:59:59', 1, 'string', 'system', '全天套餐/次卡券到期时间', 1, 54),
('background_image', '', 1, 'text', 'system', '系统背景图片路径', 0, 0),
('container_opacity', '70', 1, 'number', 'system', '内容区域透明度百分比', 0, 0),
('refresh_flag', '2026-01-01 00:00:00.000', 1, 'string', 'system', '前端刷新标记', 0, 0),
('merchant_announcement_trigger', '0', 1, 'string', 'audio', '商家公告触发标记(内部)', 0, 0),
('program_version', '20260912', 1, 'string', 'system', '程序版本号', 0, 0);


-- 初始化房间数据
INSERT INTO `rooms` (`name`, `type`, `sort_order`) VALUES
('示例房间 1', '豪华', 1),
('示例房间 2', '普通', 2),
('示例房间 3', 'VIP', 3),
('示例房间 4', '普通', 4);

-- 初始化卖品数据
INSERT INTO `products` (`name`, `type`, `price`, `sort_order`) VALUES
('可乐', '饮品', 15.00, 1),
('雪碧', '饮品', 15.00, 2),
('薯片', '小吃', 18.00, 3),
('烤肠', '小吃', 12.00, 4);

-- 初始化套餐数据
INSERT INTO `promotion_strategies` (`name`, `type`, `hours`, `price`, `room_ids`, `weekdays`, `time_start`, `time_end`, `member_discount`, `is_enabled`, `sort_order`) VALUES
('1小时10元特惠', '通用', 1.0, 10.00, NULL, '1,2,3,4,5,6,7', '00:00:00', '23:59:59', 100, 1, 1),
('2小时18元套餐', '团购', 2.0, 18.00, NULL, '1,2,3,4,5,6,7', '00:00:00', '23:59:59', 100, 1, 2),
('3小时25元优惠', '通用', 3.0, 25.00, NULL, '1,2,3,4,5', '09:00:00', '18:00:00', 100, 1, 3);

-- 初始化会员卡类型数据
INSERT INTO `member_levels` (`id`, `name`, `min_first_recharge`, `min_recharge`, `auto_upgrade_amount`, `member_discount`, `is_system`, `is_enabled`, `sort_order`) VALUES
(1, '普通卡', 0.00, 0.00, 0.00, 100, 1, 1, 1),
(2, 'VIP卡', 0.00, 0.00, 0.00, 100, 0, 1, 2);

-- 初始化支付方式数据
INSERT INTO `payment_methods` (name, description, is_system, sort_order) VALUES
('会员卡', '会员卡支付', 1, 1),
('赠送', '赠送', 1, 2),
('现金', '现金支付', 1, 3),
('微信', '微信支付', 1, 4),
('支付宝', '支付宝支付', 1, 5);

-- 插入挂单支付方式（ID固定为88，后续自增从88开始）
INSERT INTO `payment_methods` (id, name, description, is_system, is_deleted, sort_order) VALUES
(88, '挂单', '后付费模式，开台时挂单，结账时统一结算（隐藏则为停用此功能）', 1, 1, 888);

-- 插入优惠额支付方式（ID=89，默认软删除）
INSERT INTO `payment_methods` (id, name, description, is_system, is_deleted, sort_order) VALUES
(89, '商家优惠', '当实际收入低于挂单金额时自动应用（可放在隐藏，不影响使用）', 1, 1, 889);

-- 初始化用途标签数据
INSERT INTO `purpose_tags` (`name`, `usage_count`) VALUES
('公司团建', 0),
('朋友聚会', 0);

-- 确保事件调度器已开启
SET GLOBAL event_scheduler = ON;


-- ============================================
-- 租赁系统表结构
-- ============================================

-- 1. 租赁物品表
CREATE TABLE IF NOT EXISTS `rental_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL COMMENT '物品名称',
  `item_type` VARCHAR(50) NOT NULL COMMENT '物品类型',
  `description` TEXT DEFAULT NULL COMMENT '物品描述',
  `daily_overdue_fee` DECIMAL(10,2) DEFAULT NULL COMMENT '每日逾期费率（元/天），NULL表示使用系统默认配置',
  `stock` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '库存数量',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用：1=启用，0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记：0=正常，1=已删除',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序序号',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  INDEX `idx_item_type` (`item_type`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`),
  INDEX `idx_sort` (`sort_order`),
  INDEX `idx_stock` (`stock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='租赁物品目录表';

-- 2. 租赁客户表
CREATE TABLE IF NOT EXISTS `rental_customers` (
  `phone` VARCHAR(20) NOT NULL COMMENT '客户手机号',
  `name` VARCHAR(50) NOT NULL COMMENT '客户姓名',
  `deposit_balance` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '押金余额',
  `total_rentals` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '累计租赁次数',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用：1=启用，0=停用',
  `last_rental_time` DATETIME DEFAULT NULL COMMENT '最后租赁时间',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`phone`),
  INDEX `idx_name` (`name`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_last_rental` (`last_rental_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='租赁客户档案表';

-- 3. 租赁订单表
CREATE TABLE IF NOT EXISTS `rental_orders` (
  `id` VARCHAR(20) NOT NULL COMMENT '订单号(RNYYYYMMDDNNN格式)',
  `customer_phone` VARCHAR(20) NOT NULL COMMENT '客户手机号',
  `items_data` JSON NOT NULL COMMENT '物品列表JSON: [{item_id, item_name, item_type, quantity, daily_overdue_fee_rate}]',
  `pricing_rule_id` INT UNSIGNED NOT NULL COMMENT '计费规则ID（ID=1为畅租规则）',
  `pricing_rule_name` VARCHAR(50) DEFAULT NULL COMMENT '计费规则名称（快照）',
  `days` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '租赁天数',
  `rent_amount` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '租金金额',
  `rent_payment_method_id` INT UNSIGNED DEFAULT NULL COMMENT '租金支付方式ID',
  `rent_out_time` DATETIME NOT NULL COMMENT '借出时间',
  `expected_return_time` DATETIME NOT NULL COMMENT '应还日期',
  `actual_return_time` DATETIME DEFAULT NULL COMMENT '实际归还时间',
  `overdue_days` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '逾期天数',
  `overdue_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '逾期费用（考虑数量）',
  `damage_compensation` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '损坏赔偿金额',
  `return_payment_method_id` INT UNSIGNED DEFAULT NULL COMMENT '归还时支付方式ID（逾期费+损坏赔偿，NULL表示押金抵扣）',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '租赁操作员ID',
  `return_operator_id` INT UNSIGNED DEFAULT NULL COMMENT '归还操作员ID',
  `status` ENUM('renting', 'returned') NOT NULL DEFAULT 'renting' COMMENT '订单状态：renting=在租中，returned=已归还',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`customer_phone`) REFERENCES `rental_customers`(`phone`) ON DELETE RESTRICT ON UPDATE CASCADE,
  FOREIGN KEY (`rent_payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`return_payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE SET NULL,
  INDEX `idx_customer` (`customer_phone`),
  INDEX `idx_status` (`status`),
  INDEX `idx_rent_out_time` (`rent_out_time`),
  INDEX `idx_expected_return` (`expected_return_time`),
  INDEX `idx_actual_return` (`actual_return_time`),
  INDEX `idx_rent_payment` (`rent_payment_method_id`),
  INDEX `idx_return_payment` (`return_payment_method_id`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='租赁订单表';

-- 4. 押金变动记录表
CREATE TABLE IF NOT EXISTS `rental_deposit_records` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_phone` VARCHAR(20) NOT NULL COMMENT '客户手机号',
  `record_type` ENUM('initial', 'supplement', 'refund') NOT NULL COMMENT '记录类型：initial=初始缴纳，supplement=补充，refund=退还',
  `payment_method_id` INT UNSIGNED DEFAULT NULL COMMENT '支付方式ID（引用payment_methods表，NULL表示押金内部抵扣）',
  `refund_method_id` INT UNSIGNED DEFAULT NULL COMMENT '退款方式ID（引用payment_methods表，仅refund类型使用）',
  `amount` DECIMAL(10,2) NOT NULL COMMENT '变动金额（正数为增加，负数为减少）',
  `balance_after` DECIMAL(10,2) NOT NULL COMMENT '变动后余额',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `notes` VARCHAR(255) DEFAULT NULL COMMENT '备注',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`customer_phone`) REFERENCES `rental_customers`(`phone`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`refund_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE SET NULL,
  INDEX `idx_customer` (`customer_phone`),
  INDEX `idx_record_type` (`record_type`),
  INDEX `idx_create_time` (`create_time`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='押金变动流水表';

-- 5. 畅租套餐表（无限次数租赁）
CREATE TABLE IF NOT EXISTS `rental_unlimited_rules` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `rule_name` VARCHAR(50) NOT NULL COMMENT '规则名称（如：7天畅租）',
  `days` INT UNSIGNED NOT NULL COMMENT '有效天数',
  `price` DECIMAL(10,2) NOT NULL COMMENT '规则价格',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用：1=启用，0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rule_name` (`rule_name`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='畅租套餐（无限次数租赁）';

-- 6. 计费规则表（单次租赁）
CREATE TABLE IF NOT EXISTS `rental_pricing_rules` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `rule_name` VARCHAR(50) NOT NULL COMMENT '规则名称（如：租3天）',
  `days` INT UNSIGNED NOT NULL COMMENT '租赁天数',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT '价格',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '是否启用：1=启用，0=停用',
  `is_deleted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '软删除标记',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT '排序',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rule_name` (`rule_name`),
  INDEX `idx_enabled` (`is_enabled`),
  INDEX `idx_deleted` (`is_deleted`),
  INDEX `idx_sort` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='计费规则（按次计费）';

-- 7. 客户持有规则表
CREATE TABLE IF NOT EXISTS `rental_customer_rules` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_phone` VARCHAR(20) NOT NULL COMMENT '客户手机号',
  `unlimited_rule_id` INT UNSIGNED NOT NULL COMMENT '畅租套餐ID',
  `rule_name` VARCHAR(50) NOT NULL COMMENT '规则名称（快照）',
  `days` INT UNSIGNED NOT NULL COMMENT '有效天数（快照）',
  `price` DECIMAL(10,2) NOT NULL COMMENT '价格（快照）',
  `purchase_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '购买时间',
  `expire_time` DATETIME NOT NULL COMMENT '到期时间（购买时间 + 有效天数 -> 当天23:59:59）',
  `payment_method_id` INT UNSIGNED NOT NULL COMMENT '支付方式ID',
  `operator_id` INT UNSIGNED DEFAULT NULL COMMENT '操作员ID',
  `is_expired` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否已过期：0=未过期，1=已过期',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`customer_phone`) REFERENCES `rental_customers`(`phone`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`unlimited_rule_id`) REFERENCES `rental_unlimited_rules`(`id`) ON DELETE RESTRICT,
  FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods`(`id`) ON DELETE RESTRICT,
  INDEX `idx_customer` (`customer_phone`),
  INDEX `idx_unlimited_rule` (`unlimited_rule_id`),
  INDEX `idx_expire_time` (`expire_time`),
  INDEX `idx_expired` (`is_expired`),
  INDEX `idx_customer_expire` (`customer_phone`, `expire_time`, `is_expired`),
  INDEX `idx_operator` (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户持有的畅租套餐';

-- 租赁系统触发器

DELIMITER //

-- 租赁订单号生成触发器
CREATE TRIGGER rental_orders_before_insert
BEFORE INSERT ON `rental_orders`
FOR EACH ROW
BEGIN
    DECLARE next_id INT;
    
    -- 生成订单号(RNYYYYMMDDNNN格式)
    SELECT IFNULL(MAX(CAST(SUBSTRING(id, 11) AS UNSIGNED)), 0) + 1 INTO next_id
    FROM `rental_orders`
    WHERE SUBSTRING(id, 3, 8) = DATE_FORMAT(CURRENT_DATE, '%Y%m%d');
    
    SET NEW.id = CONCAT('RN', DATE_FORMAT(CURRENT_DATE, '%Y%m%d'), LPAD(next_id, 3, '0'));
    
    -- 自动计算应还日期（只有当未设置时才计算）
    IF NEW.expected_return_time IS NULL THEN
        SET NEW.expected_return_time = DATE_ADD(NEW.rent_out_time, INTERVAL NEW.days DAY);
    END IF;
END//

-- 畅租套餐过期检查触发器
CREATE TRIGGER rental_customer_rules_before_update
BEFORE UPDATE ON `rental_customer_rules`
FOR EACH ROW
BEGIN
    -- 自动更新过期状态
    IF NEW.expire_time < NOW() THEN
        SET NEW.is_expired = 1;
    ELSE
        SET NEW.is_expired = 0;
    END IF;
END//

DELIMITER ;

-- 插入系统配置（租赁系统）
INSERT INTO system_config (config_key, config_value, password_version, config_type, config_group, config_description, is_visible, sort_order)
VALUES 
('rental_default_deposit', '0', 1, 'number', 'rental', '默认押金金额', 1, 0),
('rental_daily_overdue_fee', '0', 1, 'number', 'rental', '每日逾期费用', 1, 0),
('rental_deposit_deduction', '0', 1, 'boolean', 'rental', '是否允许押金抵扣费用', 1, 0),
('rental_inventory_enabled', '0', 1, 'boolean', 'rental', '是否开启库存', 1, 0);

-- 初始化系统预设的畅租规则
INSERT INTO `rental_pricing_rules` (`rule_name`, `days`, `price`, `is_enabled`, `is_deleted`, `sort_order`)
VALUES ('畅租规则', 0, 0.00, 1, 0, 0);
