<?php
declare(strict_types=1);
header("Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");
require_once __DIR__ . '/rental_config.php';
require_once __DIR__ . '/../../config/auth.php';
requirePageAccess('any', SESSION_TIMEOUT_FRONT, '租赁系统');
$operator_id = $_SESSION['admin_user_id'] ?? $_SESSION['front_user_id'] ?? 0;
$operator_name = $_SESSION['admin_name'] ?? $_SESSION['front_name'] ?? '操作员';
$operator_role = $_SESSION['admin_role'] ?? $_SESSION['front_role'] ?? 'front';
$rental_config = getRentalConfig($conn);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>租赁系统 - 物品租赁管理</title>
    <link rel="stylesheet" href="../../asset/lib/css/bootstrap.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="../../asset/lib/css/all.min.css?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/css/all.min.css') ?>">
    <link rel="stylesheet" href="rental.css?v=<?= filemtime(__FILE__) ?>">
    <script src="../../asset/core.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/core.js') ?>"></script>
    <script>
        window.SYSTEM_CONFIG = {
            serverTime: '<?php echo date('c'); ?>',
            clientTime: Date.now()
        };
        window.SERVER_TIME = new Date(window.SYSTEM_CONFIG.serverTime).getTime();
    </script>
</head>
<body class="rental-page">
    <div class="container mt-3">
        <div class="page-header d-flex justify-content-between align-items-center mb-3">
            <h2><a href="rental.php" style="color: inherit; text-decoration: none;">租赁系统</a></h2>
            <div>
                <?php
                $logoutUsername = $_SESSION['admin_username'] ?? $_SESSION['username'] ?? '';
                $logoutName = $_SESSION['admin_name'] ?? $_SESSION['name'] ?? '';
                $logoutRole = $_SESSION['admin_role'] ?? $_SESSION['role'] ?? '';
                $roleText = $logoutRole === 'admin' ? '管理员' : '前台';
                $logoutTitle = "用户名：{$logoutUsername}\n姓名：{$logoutName}\n权限：{$roleText}";
                ?>
                <a href="../../config/auth.php?logout=admin&close=1&source=rental" class="btn btn-outline-danger mr-2" title="<?php echo htmlspecialchars($logoutTitle); ?>">
                    <i class="fas fa-sign-out-alt mr-1"></i>退出
                </a>
            </div>
        </div>
        <div class="d-flex align-items-center mb-3">
            <button type="button" class="btn btn-primary me-3" id="btnNewRental">
                <i class="fas fa-plus"></i> 新增租赁
            </button>
            <ul class="nav nav-tabs flex-grow-1 mb-0" id="mainTabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="history-tab" data-toggle="tab" href="#historyTab" role="tab">
                    <i class="fas fa-history"></i> <span>历史租赁</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="customer-tab" data-toggle="tab" href="#customerTab" role="tab">
                    <i class="fas fa-users"></i> <span>客户管理</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="settings-tab" data-toggle="tab" href="#settingsTab" role="tab">
                    <i class="fas fa-cog"></i> <span>租赁配置</span>
                </a>
            </li>
        </ul>
        </div>
        <div class="tab-content mt-3" id="mainTabContent">
            <div class="tab-pane fade show active" id="historyTab" role="tabpanel">
                <div class="module-card">
                    <h5 class="mb-3">历史租赁订单</h5>
                    <form id="ordersQueryForm" class="mb-3">
                        <div class="form-row">
                            <div class="col-12 col-md-2 mb-2">
                                <label for="searchKeyword" class="font-weight-bold">订单号 / 手机号</label>
                                <input type="text" class="form-control" id="searchKeyword" placeholder="输入订单号或手机号搜索" maxlength="20">
                            </div>
                            <div class="col-12 col-md-5 mb-2">
                                <label class="font-weight-bold">日期范围</label>
                                <div class="input-group">
                                    <input type="datetime-local" step="1" class="form-control" id="dateStart">
                                    <span class="input-group-text">至</span>
                                    <input type="datetime-local" step="1" class="form-control" id="dateEnd">
                                </div>
                            </div>
                            <div class="col-12 col-md-3 mb-2">
                                <label class="font-weight-bold">状态</label>
                                <select class="form-control" id="statusFilter">
                                    <option value="">全部</option>
                                    <option value="returned">已归还</option>
                                    <option value="renting">在租中</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-2 mb-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100 py-2">
                                    <i class="fas fa-search mr-1"></i> 查询
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="mb-2" id="statsRow">
                        <div class="row mb-2" id="statsRow1">
                            <div class="col-md-3">
                                <div class="card bg-info text-white text-center">
                                    <div class="card-body py-2">
                                        <div class="text-xs">租赁总数</div>
                                        <div class="text-lg font-bold" id="statRentedQty">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-success text-white text-center">
                                    <div class="card-body py-2">
                                        <div class="text-xs">归还数量</div>
                                        <div class="text-lg font-bold" id="statReturnedQty">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-secondary text-white text-center">
                                    <div class="card-body py-2">
                                        <div class="text-xs">在租数量</div>
                                        <div class="text-lg font-bold" id="statInTransitQty">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-dark text-white text-center">
                                    <div class="card-body py-2">
                                        <div class="text-xs">在租订单</div>
                                        <div class="text-lg font-bold" id="statRentingOrders">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="statsRow2">
                            <div class="col-md">
                                <div class="card bg-primary text-white text-center clickable-stat-card" onclick="showPaymentBreakdown('rent_amount', '使用费')">
                                    <div class="card-body py-2">
                                        <div class="text-xs">使用费</div>
                                        <div class="text-lg font-bold" id="statRentAmount">¥0.00</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="card bg-warning text-white text-center clickable-stat-card" onclick="showPaymentBreakdown('overdue_damage', '逾期/赔偿')">
                                    <div class="card-body py-2">
                                        <div class="text-xs">逾期/赔偿</div>
                                        <div class="text-lg font-bold" id="statOverdueDamage">¥0.00</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="card bg-purple text-white text-center clickable-stat-card" onclick="showPaymentBreakdown('unlimited_income', '畅租收入')">
                                    <div class="card-body py-2">
                                        <div class="text-xs">畅租收入</div>
                                        <div class="text-lg font-bold" id="statUnlimitedIncome">¥0.00</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="card bg-success text-white text-center clickable-stat-card" onclick="showPaymentBreakdown('deposit_in', '收取押金')">
                                    <div class="card-body py-2">
                                        <div class="text-xs">收取押金</div>
                                        <div class="text-lg font-bold" id="statDepositIn">¥0.00</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md">
                                <div class="card bg-danger text-white text-center clickable-stat-card" onclick="showPaymentBreakdown('refund_out', '退还押金')">
                                    <div class="card-body py-2">
                                        <div class="text-xs">退还押金</div>
                                        <div class="text-lg font-bold" id="statRefundOut">¥0.00</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>单号</th>
                                    <th>手机号</th>
                                    <th>姓名</th>
                                    <th>物品</th>
                                    <th>物品类型</th>
                                    <th>计费方案</th>
                                    <th>天数</th>
                                    <th>租金</th>
                                    <th>借出时间</th>
                                    <th>应还日期</th>
                                    <th>状态</th>
                                    <th>归还时间</th>
                                    <th>逾期费</th>
                                    <th>损坏赔偿</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="ordersTableBody">
                                <tr>
                                    <td colspan="15" class="text-center">加载中...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="ordersPaginationContainer"></div>
                </div>
            </div>
            <div class="tab-pane fade" id="customerTab" role="tabpanel">
                <div class="module-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>客户档案管理</h5>
                        <button type="button" class="btn btn-success" id="btnNewCustomer">
                            <i class="fas fa-user-plus"></i> 新建客户
                        </button>
                    </div>
                    <form id="customersQueryForm" class="mb-3">
                        <div class="d-flex align-items-center">
                            <label for="customerSearchPhone" class="font-weight-bold mb-0 mr-3 flex-shrink-0">手机号 / 姓名</label>
                            <input type="text" class="form-control mr-3" id="customerSearchPhone" placeholder="输入手机号或姓名搜索" maxlength="20" style="max-width:280px;">
                            <button type="submit" class="btn btn-primary py-2 px-4 flex-shrink-0">
                                <i class="fas fa-search mr-1"></i> 查询
                            </button>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>手机号</th>
                                    <th>姓名</th>
                                    <th>畅租套餐</th>
                                    <th>押金余额</th>
                                    <th>累计租赁</th>
                                    <th>当前在租</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody id="customersTableBody">
                                <tr>
                                    <td colspan="7" class="text-center">加载中...</td>
                                </tr>
                            </tbody>
                            <tfoot id="customersTableFoot" class="font-weight-bold bg-light"></tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="settingsTab" role="tabpanel">
                <ul class="nav nav-tabs" id="settingsTabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="basic-settings-tab" data-toggle="tab" href="#basicSettings" role="tab">
                            <i class="fas fa-sliders-h"></i> <span>基础设置</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="unlimited-rules-tab" data-toggle="tab" href="#unlimitedRules" role="tab">
                            <i class="fas fa-infinity"></i> <span>畅租套餐</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="pricing-rules-tab" data-toggle="tab" href="#pricingRules" role="tab">
                            <i class="fas fa-tags"></i> <span>计费规则</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="items-tab" data-toggle="tab" href="#items" role="tab">
                            <i class="fas fa-box"></i> <span>物品管理</span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content mt-3" id="settingsTabContent">
                    <div class="tab-pane fade show active" id="basicSettings" role="tabpanel">
                        <div class="module-card">
                            <h5 class="mb-3">基础设置</h5>
                            <form id="basicSettingsForm">
                                <table class="table config-table">
                                    <thead>
                                        <tr>
                                            <th width="30%">描述</th>
                                            <th width="70%">配置值</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>默认押金金额（元）</td>
                                            <td>
                                                <input type="number" class="form-control" id="defaultDeposit" name="default_deposit" 
                                                       value="<?php echo $rental_config['default_deposit']; ?>" min="0" max="99999" step="0.01" required>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>每日逾期费用（元/天）</td>
                                            <td>
                                                <input type="number" class="form-control" id="dailyOverdueFee" name="daily_overdue_fee" 
                                                       value="<?php echo $rental_config['daily_overdue_fee']; ?>" min="0" max="99999" step="0.01" required>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>是否允许押金抵扣费用 <i class="fas fa-info-circle text-info config-info-icon" style="cursor: pointer;" data-info="开启后，归还时可用押金余额抵扣逾期费和损坏赔偿"></i></td>
                                            <td>
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="depositDeduction" name="deposit_deduction" 
                                                           <?php echo $rental_config['deposit_deduction'] ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="depositDeduction">启用</label>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>是否开启库存 <i class="fas fa-info-circle text-info config-info-icon" style="cursor: pointer;" data-info="开启后，租借将扣除库存，归还将恢复库存"></i></td>
                                            <td>
                                                <div class="custom-control custom-switch">
                                                    <input type="checkbox" class="custom-control-input" id="inventoryEnabled" name="inventory_enabled" 
                                                           <?php echo $rental_config['inventory_enabled'] ? 'checked' : ''; ?>>
                                                    <label class="custom-control-label" for="inventoryEnabled">启用</label>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="text-right mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        保存设置
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="unlimitedRules" role="tabpanel">
                        <div class="module-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5>畅租套餐管理</h5>
                                <button type="button" class="btn btn-success" id="btnNewUnlimitedRule">
                                    <i class="fas fa-plus"></i> 新增套餐
                                </button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>规则名称</th>
                                            <th>天数</th>
                                            <th>价格</th>
                                            <th>操作</th>
                                            <th>拖动排序</th>
                                        </tr>
                                    </thead>
                                    <tbody id="unlimitedRulesSortable">
                                        <tr>
                                            <td colspan="6" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div id="unlimitedRulesDeletedSection" class="custom-collapse mt-3">
                                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                                    已隐藏的规则
                                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                                </div>
                                <div class="custom-collapse-content" style="display:none;">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm mb-0">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>规则名称</th>
                                                    <th>天数</th>
                                                    <th>价格</th>
                                                    <th>操作</th>
                                                </tr>
                                            </thead>
                                            <tbody id="unlimitedRulesDeletedBody"></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pricingRules" role="tabpanel">
                        <div class="module-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5>计费规则管理</h5>
                                <button type="button" class="btn btn-success" id="btnNewPricingRule">
                                    <i class="fas fa-plus"></i> 新增规则
                                </button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>规则名称</th>
                                            <th>天数</th>
                                            <th>价格</th>
                                            <th>操作</th>
                                            <th>拖动排序</th>
                                        </tr>
                                    </thead>
                                    <tbody id="pricingRulesSortable">
                                        <tr>
                                            <td colspan="6" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div id="pricingRulesDeletedSection" class="custom-collapse mt-3">
                                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                                    已隐藏的规则
                                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                                </div>
                                <div class="custom-collapse-content" style="display:none;">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm mb-0">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>规则名称</th>
                                                    <th>天数</th>
                                                    <th>价格</th>
                                                    <th>操作</th>
                                                </tr>
                                            </thead>
                                            <tbody id="pricingRulesDeletedBody"></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="items" role="tabpanel">
                        <div class="module-card">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5>租赁物品管理</h5>
                                <button type="button" class="btn btn-success" id="btnNewItem">
                                    <i class="fas fa-plus"></i> 新增物品
                                </button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>物品名称</th>
                                            <th>物品类型</th>
                                            <th>库存</th>
                                            <th>描述</th>
                                            <th>操作</th>
                                            <th>拖动排序</th>
                                        </tr>
                                    </thead>
                                    <tbody id="itemsSortable">
                                        <tr>
                                            <td colspan="7" class="text-center">加载中...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div id="itemsDeletedSection" class="custom-collapse mt-3">
                                <div class="custom-collapse-header" onclick="toggleCollapse(this)">
                                    已隐藏的物品
                                    <span class="custom-collapse-arrow"><i class="fas fa-chevron-down"></i></span>
                                </div>
                                <div class="custom-collapse-content" style="display:none;">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-sm mb-0">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>物品名称</th>
                                                    <th>物品类型</th>
                                                    <th>描述</th>
                                                    <th>操作</th>
                                                </tr>
                                            </thead>
                                            <tbody id="itemsDeletedBody"></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="modalContainer"></div>
    <script src="../../asset/lib/js/jquery.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/jquery.min.js') ?>"></script>
    <script src="../../asset/lib/js/bootstrap.min.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/asset/lib/js/bootstrap.min.js') ?>"></script>
    <script>
        window.RENTAL_CONFIG = {
            operatorId: <?php echo (int)$operator_id; ?>,
            operatorName: <?php echo json_encode((string)$operator_name, JSON_UNESCAPED_UNICODE); ?>,
            operatorRole: <?php echo json_encode((string)$operator_role, JSON_UNESCAPED_UNICODE); ?>,
            defaultDeposit: <?php echo (float)$rental_config['default_deposit']; ?>,
            dailyOverdueFee: <?php echo (float)$rental_config['daily_overdue_fee']; ?>,
            depositDeduction: <?php echo (int)$rental_config['deposit_deduction']; ?>,
            inventoryEnabled: <?php echo (int)$rental_config['inventory_enabled']; ?>
        };
        $(document).ready(function() {
            $('.nav-link[data-toggle="tab"]').on('mouseenter', function() {
                const $this = $(this);
                const href = $this.attr('href');
                if (href) {
                    $this.data('temp-href', href).removeAttr('href');
                }
            }).on('mouseleave', function() {
                const $this = $(this);
                const href = $this.data('temp-href');
                if (href && !$this.attr('href')) {
                    $this.attr('href', href);
                }
            }).on('mousedown', function(e) {
                const $this = $(this);
                const href = $this.data('temp-href');
                if (href) {
                    const scrollTop = $(window).scrollTop();
                    $this.attr('href', href);
                    $this.tab('show');
                    setTimeout(function() {
                        $(window).scrollTop(scrollTop);
                    }, 0);
                    $this.removeData('temp-href');
                }
            });
        });
    </script>
    <script src="/ext/rental/rental.js?v=<?= filemtime($_SERVER['DOCUMENT_ROOT'] . '/ext/rental/rental.js') ?>"></script>
</body>
</html>
