<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $SCENE_ROOM_NAME = '房间'; $scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'"); if ($scene_stmt) { $scene_stmt->execute(); $scene_result = $scene_stmt->get_result(); if ($scene_result && $scene_row = $scene_result->fetch_assoc()) { $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间'; } $scene_stmt->close(); } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $end_date = $end_date . ' 23:59:59'; try { $query = "
        SELECT 
            mc.id,
            mc.member_card_no,
            ma.name,
            mc.amount,
            mc.final_balance,
            mc.create_time,
            mc.order_id,
            mc.batch_id,
            CASE
                WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'RM%' THEN 
                    (SELECT r2.name FROM orders o2 JOIN rooms r2 ON o2.room_id = r2.id 
                     WHERE o2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                ELSE r.name
            END as room_name,
            CASE
                WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'PD%' THEN
                    (SELECT p2.name FROM product_orders po2 JOIN products p2 ON po2.product_id = p2.id 
                     WHERE po2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                ELSE p.name
            END as product_name,
            tcp.name as time_card_name,
            CASE 
                WHEN mc.order_id LIKE '%-R' THEN 
                    CASE 
                        WHEN mc.time_card_id IS NOT NULL THEN '次卡券(退款)'
                        WHEN mc.product_id IS NOT NULL THEN '商品(退款)'
                        WHEN mc.room_id IS NOT NULL THEN '{$SCENE_ROOM_NAME}(退款)'
                        ELSE '退款'
                    END
                ELSE 
                    CASE 
                        WHEN mc.time_card_id IS NOT NULL THEN '次卡券'
                        WHEN mc.product_id IS NOT NULL THEN '商品'
                        WHEN mc.room_id IS NOT NULL THEN '{$SCENE_ROOM_NAME}'
                        ELSE '未知'
                    END
            END as location_type_display,
            CASE 
                WHEN mc.amount > 0 THEN CONCAT('-¥', FORMAT(mc.amount, 2))
                WHEN mc.amount < 0 THEN CONCAT('+¥', FORMAT(ABS(mc.amount), 2))
                ELSE '¥0.00'
            END as amount_display,
            CONCAT('¥', FORMAT(mc.final_balance, 2)) as final_balance_display,
            su.name as operator_name
        FROM 
            member_consumptions mc
        LEFT JOIN 
            member_accounts ma ON mc.member_card_no = ma.member_card_no
        LEFT JOIN 
            rooms r ON mc.room_id = r.id
        LEFT JOIN 
            products p ON mc.product_id = p.id
        LEFT JOIN 
            time_card_products tcp ON mc.time_card_id = tcp.id
        LEFT JOIN
            system_users su ON mc.operator_id = su.id
        WHERE 
            mc.create_time BETWEEN ? AND ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $query .= " AND (mc.id LIKE ? OR mc.order_id LIKE ? OR mc.member_card_no = ? OR ma.name LIKE ? OR mc.batch_id LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $search; $params[] = $searchParam; $params[] = $searchParam; $types .= "sssss"; } else { $query .= " AND (mc.id LIKE ? OR mc.order_id LIKE ? OR mc.member_card_no LIKE ? OR ma.name LIKE ? OR mc.batch_id LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sssss"; } } $query .= " ORDER BY mc.create_time DESC, mc.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $orders = []; while ($row = $result->fetch_assoc()) { $orders[] = [ 'id' => $row['id'], 'member_card_no' => $row['member_card_no'], 'name' => $row['name'] ?? '未知', 'amount' => (float)$row['amount'], 'final_balance' => (float)$row['final_balance'], 'create_time' => $row['create_time'], 'order_id' => $row['order_id'], 'batch_id' => $row['batch_id'], 'room_name' => $row['room_name'], 'product_name' => $row['product_name'], 'time_card_name' => $row['time_card_name'], 'location_type_display' => $row['location_type_display'], 'amount_display' => $row['amount_display'], 'final_balance_display' => $row['final_balance_display'], 'operator_name' => $row['operator_name'] ]; } $stats = calculateStats($conn, $params, $types, $start_date, $end_date, $search); echo json_encode([ 'success' => true, 'data' => $orders, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function calculateStats(mysqli $conn, array $params, string $types, string $start_date, string $end_date, string $search): array { $query = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(mc.amount) as total_consumption,
            SUM(CASE 
                WHEN mc.product_id IS NULL AND mc.time_card_id IS NULL THEN mc.amount
                ELSE 0 
            END) as room_consumption,
            SUM(CASE 
                WHEN mc.product_id IS NOT NULL OR mc.time_card_id IS NOT NULL THEN mc.amount
                ELSE 0 
            END) as product_consumption
        FROM 
            member_consumptions mc
        LEFT JOIN 
            member_accounts ma ON mc.member_card_no = ma.member_card_no
        WHERE 
            mc.create_time BETWEEN ? AND ?
    "; $statsParams = [$start_date, $end_date]; $statsTypes = "ss"; if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $query .= " AND (mc.id LIKE ? OR mc.order_id LIKE ? OR mc.member_card_no = ? OR ma.name LIKE ? OR mc.batch_id LIKE ?)"; $searchParam = "%$search%"; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $search; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsTypes .= "sssss"; } else { $query .= " AND (mc.id LIKE ? OR mc.order_id LIKE ? OR mc.member_card_no LIKE ? OR ma.name LIKE ? OR mc.batch_id LIKE ?)"; $searchParam = "%$search%"; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsTypes .= "sssss"; } } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_orders' => 0, 'total_consumption' => 0, 'room_consumption' => 0, 'product_consumption' => 0 ]; } if (!empty($statsParams)) { $stmt->bind_param($statsTypes, ...$statsParams); } if (!$stmt->execute()) { return [ 'total_orders' => 0, 'total_consumption' => 0, 'room_consumption' => 0, 'product_consumption' => 0 ]; } $result = $stmt->get_result(); $stats = $result->fetch_assoc(); return [ 'total_orders' => (int)($stats['total_orders'] ?? 0), 'total_consumption' => (float)($stats['total_consumption'] ?? 0), 'room_consumption' => (float)($stats['room_consumption'] ?? 0), 'product_consumption' => (float)($stats['product_consumption'] ?? 0) ]; }