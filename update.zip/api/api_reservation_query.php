<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $status = $_GET['status'] ?? 'all'; $end_date = $end_date . ' 23:59:59'; try { $query = "
        SELECT 
            r.id,
            r.room_id,
            r.reservation_time,
            r.phone,
            r.notes,
            r.status,
            r.create_time,
            r.update_time,
            rm.name as room_name,
            CASE 
                WHEN r.status = 0 THEN '未到期'
                WHEN r.status = 1 THEN '已超时'
                WHEN r.status = 2 THEN '已取消'
                WHEN r.status = 3 THEN '超时取消'
                WHEN r.status = 4 THEN '已使用'
                ELSE '未知'
            END as status_display,
            DATE_FORMAT(r.create_time, '%Y-%m-%d %H:%i:%s') as create_time_display,
            DATE_FORMAT(r.reservation_time, '%Y-%m-%d %H:%i:%s') as reservation_time_display,
            DATE_FORMAT(r.update_time, '%Y-%m-%d %H:%i:%s') as update_time_display,
            su.name as operator_name
        FROM reservations r
        JOIN rooms rm ON r.room_id = rm.id
        LEFT JOIN system_users su ON r.operator_id = su.id
        WHERE r.reservation_time >= ? AND r.reservation_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { if ($status == '1') { $query .= " AND (r.status = 1 OR r.status = 3)"; } else { $query .= " AND r.status = ?"; $params[] = $status; $types .= "i"; } } if (!empty($search)) { $query .= " AND (r.id LIKE ? OR rm.name LIKE ? OR r.phone LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $query .= " ORDER BY r.reservation_time DESC, r.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $reservations = []; while ($row = $result->fetch_assoc()) { $reservations[] = [ 'id' => $row['id'], 'room_id' => $row['room_id'], 'reservation_time' => $row['reservation_time'], 'phone' => $row['phone'], 'notes' => $row['notes'], 'status' => (int)$row['status'], 'create_time' => $row['create_time'], 'update_time' => $row['update_time'], 'room_name' => $row['room_name'], 'status_display' => $row['status_display'], 'create_time_display' => $row['create_time_display'], 'reservation_time_display' => $row['reservation_time_display'], 'update_time_display' => $row['update_time_display'], 'operator_name' => $row['operator_name'] ]; } $stats = calculateStats($conn, $params, $types, $start_date, $end_date, $search, $status); echo json_encode([ 'success' => true, 'data' => $reservations, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function calculateStats($conn, $params, $types, $start_date, $end_date, $search, $status) { $query = "
        SELECT 
            COUNT(*) as total_reservations,
            SUM(CASE WHEN r.status = 0 THEN 1 ELSE 0 END) as active_reservations,
            SUM(CASE WHEN r.status = 1 OR r.status = 3 THEN 1 ELSE 0 END) as timeout_reservations,
            SUM(CASE WHEN r.status = 2 THEN 1 ELSE 0 END) as canceled_reservations,
            SUM(CASE WHEN r.status = 3 THEN 1 ELSE 0 END) as timeout_canceled_reservations,
            SUM(CASE WHEN r.status = 4 THEN 1 ELSE 0 END) as used_reservations
        FROM reservations r
        JOIN rooms rm ON r.room_id = rm.id
        WHERE r.reservation_time >= ? AND r.reservation_time <= ?
    "; $stats_params = [$start_date, $end_date]; $stats_types = "ss"; if ($status !== 'all') { if ($status == '1') { $query .= " AND (r.status = 1 OR r.status = 3)"; } else { $query .= " AND r.status = ?"; $stats_params[] = $status; $stats_types .= "i"; } } if (!empty($search)) { $query .= " AND (r.id LIKE ? OR rm.name LIKE ? OR r.phone LIKE ?)"; $searchParam = "%$search%"; $stats_params[] = $searchParam; $stats_params[] = $searchParam; $stats_params[] = $searchParam; $stats_types .= "sss"; } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_reservations' => 0, 'active_reservations' => 0, 'timeout_reservations' => 0, 'canceled_reservations' => 0, 'timeout_canceled_reservations' => 0, 'used_reservations' => 0 ]; } if (!empty($stats_params)) { $stmt->bind_param($stats_types, ...$stats_params); } if (!$stmt->execute()) { return [ 'total_reservations' => 0, 'active_reservations' => 0, 'timeout_reservations' => 0, 'canceled_reservations' => 0, 'timeout_canceled_reservations' => 0, 'used_reservations' => 0 ]; } $result = $stmt->get_result(); $row = $result->fetch_assoc(); return [ 'total_reservations' => (int)$row['total_reservations'], 'active_reservations' => (int)$row['active_reservations'], 'timeout_reservations' => (int)$row['timeout_reservations'], 'canceled_reservations' => (int)$row['canceled_reservations'], 'timeout_canceled_reservations' => (int)$row['timeout_canceled_reservations'], 'used_reservations' => (int)$row['used_reservations'] ]; } 