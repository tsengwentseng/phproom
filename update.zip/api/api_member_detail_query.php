<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultDate = new DateTime(); $startDate = $_GET['start_date'] ?? $defaultDate->format('Y-m-d'); $endDate = $_GET['end_date'] ?? $defaultDate->format('Y-m-d'); $search = trim($_GET['search'] ?? ''); $memberLevel = $_GET['member_level'] ?? 'all'; $status = $_GET['status'] ?? 'all'; $dateType = $_GET['date_type'] ?? 'last_consumption'; if(strpos($endDate, 'T') === false) { $endDate .= 'T23:59:59'; } if ($dateType === 'create') { $sql = "SELECT 
            ma.member_card_no, 
            ma.name, 
            ma.balance, 
            ma.total_recharge_amount,
            ma.total_gift_amount,
            ma.total_consumption_amount,
            ma.is_enabled as status,
            ma.create_time, 
            ma.last_consumption_time,
            CONCAT('¥', FORMAT(ma.balance, 2)) as balance_display,
            CONCAT('¥', FORMAT(ma.total_recharge_amount, 2)) as total_recharge_display,
            CASE 
                WHEN ma.total_gift_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(ma.total_gift_amount), 2))
                ELSE CONCAT('¥', FORMAT(ma.total_gift_amount, 2))
            END as total_gift_display,
            CASE 
                WHEN ma.total_consumption_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(ma.total_consumption_amount), 2))
                ELSE CONCAT('¥', FORMAT(ma.total_consumption_amount, 2))
            END as total_consumption_display,
            CASE 
                WHEN ma.is_enabled = 0 THEN '停用'
                ELSE '正常'
            END AS status_display,
            IFNULL(ml.name, '未知') as level_name
        FROM 
            member_accounts ma
        LEFT JOIN 
            member_levels ml ON ma.level_id = ml.id
        WHERE ma.create_time >= ? AND ma.create_time <= ?"; $params = [$startDate, $endDate]; } else { $sql = "SELECT 
            ma.member_card_no, 
            ma.name, 
            ma.balance, 
            ma.total_recharge_amount,
            ma.total_gift_amount,
            ma.total_consumption_amount,
            ma.is_enabled as status,
            ma.create_time, 
            CASE 
                WHEN ma.last_consumption_time >= ? AND ma.last_consumption_time <= ? THEN ma.last_consumption_time
                ELSE NULL
            END as last_consumption_time,
            CONCAT('¥', FORMAT(ma.balance, 2)) as balance_display,
            CONCAT('¥', FORMAT(ma.total_recharge_amount, 2)) as total_recharge_display,
            CASE 
                WHEN ma.total_gift_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(ma.total_gift_amount), 2))
                ELSE CONCAT('¥', FORMAT(ma.total_gift_amount, 2))
            END as total_gift_display,
            CASE 
                WHEN ma.total_consumption_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(ma.total_consumption_amount), 2))
                ELSE CONCAT('¥', FORMAT(ma.total_consumption_amount, 2))
            END as total_consumption_display,
            CASE 
                WHEN ma.is_enabled = 0 THEN '停用'
                ELSE '正常'
            END AS status_display,
            IFNULL(ml.name, '未知') as level_name
        FROM 
            member_accounts ma
        LEFT JOIN 
            member_levels ml ON ma.level_id = ml.id
        WHERE 1=1"; $params = [$startDate, $endDate]; } if ($memberLevel !== 'all') { $sql .= " AND ma.level_id = ?"; $params[] = $memberLevel; } if ($status !== 'all') { $sql .= " AND ma.is_enabled = ?"; $params[] = $status; } if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $sql .= " AND (ma.member_card_no = ? OR ma.name LIKE ?)"; $params[] = $search; $params[] = "%{$search}%"; } else { $sql .= " AND (ma.member_card_no LIKE ? OR ma.name LIKE ?)"; $params[] = "%{$search}%"; $params[] = "%{$search}%"; } } $sql .= " ORDER BY ma.last_consumption_time DESC, ma.member_card_no ASC"; $stmt = $conn->prepare($sql); if (!empty($params)) { $types = str_repeat('s', count($params)); $stmt->bind_param($types, ...$params); } $stmt->execute(); $result = $stmt->get_result(); if (!$result) { echo json_encode(['success' => false, 'message' => '查询失败']); exit; } $members = []; while ($row = $result->fetch_assoc()) { $members[] = [ 'member_card_no' => $row['member_card_no'], 'name' => $row['name'], 'level_name' => $row['level_name'], 'balance' => (float)$row['balance'], 'total_recharge_amount' => (float)$row['total_recharge_amount'], 'total_gift_amount' => (float)$row['total_gift_amount'], 'total_consumption_amount' => (float)$row['total_consumption_amount'], 'status' => (int)$row['status'], 'create_time' => $row['create_time'], 'last_consumption_time' => $row['last_consumption_time'], 'balance_display' => $row['balance_display'], 'total_recharge_display' => $row['total_recharge_display'], 'total_gift_display' => $row['total_gift_display'], 'total_consumption_display' => $row['total_consumption_display'], 'status_display' => $row['status_display'] ]; } $stmt->close(); $stats = calculateStats($conn, $startDate, $endDate, $search, $memberLevel, $status); $levelStmt = $conn->prepare("SELECT id, name, min_first_recharge, min_recharge, is_enabled, auto_upgrade_amount FROM member_levels ORDER BY sort_order ASC, id ASC"); $levelStmt->execute(); $levelResult = $levelStmt->get_result(); $levels = []; while ($lr = $levelResult->fetch_assoc()) { $levels[] = [ 'id' => (int)$lr['id'], 'name' => $lr['name'], 'min_first_recharge' => (float)$lr['min_first_recharge'], 'min_recharge' => (float)$lr['min_recharge'], 'is_enabled' => (int)$lr['is_enabled'], 'auto_upgrade_amount' => (float)$lr['auto_upgrade_amount'] ]; } $levelStmt->close(); echo json_encode([ 'success' => true, 'data' => $members, 'stats' => $stats, 'levels' => $levels ]); function calculateStats(mysqli $conn, string $startDate, string $endDate, string $search, string $memberLevel = 'all', string $status = 'all'): array { $stats = [ 'total_members' => 0, 'total_balance' => 0, 'new_members' => 0, 'active_members' => 0 ]; $whereClause = "WHERE 1=1"; $params = []; if ($memberLevel !== 'all') { $whereClause .= " AND level_id = ?"; $params[] = $memberLevel; } if ($status !== 'all') { $whereClause .= " AND is_enabled = ?"; $params[] = $status; } if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $whereClause .= " AND (member_card_no = ? OR name LIKE ?)"; $params[] = $search; $params[] = "%{$search}%"; } else { $whereClause .= " AND (member_card_no LIKE ? OR name LIKE ?)"; $params[] = "%{$search}%"; $params[] = "%{$search}%"; } } $sql = "SELECT COUNT(*) as total_members, IFNULL(SUM(balance), 0) as total_balance 
            FROM member_accounts " . $whereClause; $stmt = $conn->prepare($sql); if (!empty($params)) { $types = str_repeat('s', count($params)); $stmt->bind_param($types, ...$params); } $stmt->execute(); $result = $stmt->get_result(); if ($row = $result->fetch_assoc()) { $stats['total_members'] = (int)$row['total_members']; $stats['total_balance'] = (float)$row['total_balance']; } $stmt->close(); if (!empty($startDate) && !empty($endDate)) { $whereClauseNew = $whereClause . " AND create_time >= ? AND create_time <= ?"; $paramsNew = $params; $paramsNew[] = $startDate; $paramsNew[] = $endDate; $sql = "SELECT COUNT(*) as new_members FROM member_accounts " . $whereClauseNew; $stmt = $conn->prepare($sql); if (!empty($paramsNew)) { $types = str_repeat('s', count($paramsNew)); $stmt->bind_param($types, ...$paramsNew); } $stmt->execute(); $result = $stmt->get_result(); if ($row = $result->fetch_assoc()) { $stats['new_members'] = (int)$row['new_members']; } $stmt->close(); $whereClauseActive = $whereClause . " AND last_consumption_time >= ? AND last_consumption_time <= ?"; $paramsActive = $params; $paramsActive[] = $startDate; $paramsActive[] = $endDate; $sql = "SELECT COUNT(*) as active_members FROM member_accounts " . $whereClauseActive; $stmt = $conn->prepare($sql); if (!empty($paramsActive)) { $types = str_repeat('s', count($paramsActive)); $stmt->bind_param($types, ...$paramsActive); } $stmt->execute(); $result = $stmt->get_result(); if ($row = $result->fetch_assoc()) { $stats['active_members'] = (int)$row['active_members']; } $stmt->close(); } return $stats; } ?>
