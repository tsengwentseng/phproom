<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $status = $_GET['status'] ?? 'all'; $queryType = $_GET['query_type'] ?? 'order'; $end_date = $end_date . ' 23:59:59'; try { if ($queryType === 'order') { $orderQuery = "
                SELECT 
                    o.id,
                    o.room_id,
                    o.start_time,
                    o.expected_end_time,
                    o.end_time,
                    o.total_amount,
                    o.credit_amount,
                    o.member_card_no,
                    o.status,
                    o.audio_muted,
                    o.audio_updated_at,
                    o.create_time,
                    o.update_time,
                    o.origin_client,
                    o.notes,
                    o.purpose,
                    o.total_pause_duration,
                    r.name as room_name, 
                    m.name as member_name,
                    CASE 
                        WHEN CAST(o.status AS SIGNED) = 0 THEN '进行中'
                        WHEN CAST(o.status AS SIGNED) = 1 THEN '已结账'
                        ELSE '未知'
                    END as status_display,
                    DATE_FORMAT(o.start_time, '%Y-%m-%d %H:%i:%s') as start_time_display,
                    DATE_FORMAT(o.expected_end_time, '%Y-%m-%d %H:%i:%s') as expected_end_time_display,
                    DATE_FORMAT(o.end_time, '%Y-%m-%d %H:%i:%s') as end_time_display,
                    CASE 
                        WHEN o.total_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(o.total_amount), 2))
                        ELSE CONCAT('¥', FORMAT(o.total_amount, 2))
                    END as total_amount_display,
                    CASE 
                        WHEN o.credit_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(o.credit_amount), 2))
                        WHEN o.credit_amount > 0 THEN CONCAT('¥', FORMAT(o.credit_amount, 2))
                        ELSE '-'
                    END as order_credit_amount_display,
                    CASE 
                        WHEN o.status = 1 AND o.end_time IS NOT NULL THEN 
                            TIMESTAMPDIFF(MINUTE, o.start_time, o.end_time)
                        ELSE 
                            TIMESTAMPDIFF(MINUTE, o.start_time, o.expected_end_time)
                    END as actual_duration_minutes,
                    o.total_pause_duration
                FROM orders o
                JOIN rooms r ON o.room_id = r.id
                LEFT JOIN member_accounts m ON o.member_card_no = m.member_card_no
                WHERE o.start_time >= ? AND o.start_time <= ?
            "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $orderQuery .= " AND o.status = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $orderQuery .= " AND (o.id LIKE ? OR r.name LIKE ? OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $orderQuery .= " ORDER BY o.start_time DESC, o.id DESC"; $stmt = $conn->prepare($orderQuery); if (!$stmt) { throw new Exception("订单查询准备失败: " . $conn->error); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { throw new Exception("订单查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $orders = []; $orderIds = []; while ($row = $result->fetch_assoc()) { $orders[$row['id']] = [ 'order' => $row, 'payment_details' => [] ]; $orderIds[] = $row['id']; } if (!empty($orderIds)) { $placeholders = str_repeat('?,', count($orderIds) - 1) . '?'; $paymentQuery = "
                SELECT 
                    pd.*, 
                    pm.name as payment_method_name,
                    CASE 
                        WHEN pd.payment_type = 0 THEN '开台'
                        WHEN pd.payment_type = 1 THEN '加时'
                        WHEN pd.payment_type = 2 AND pd.payment_time > o.end_time THEN '退费'
                        WHEN pd.payment_type = 2 THEN '结账'
                        ELSE '未知'
                    END as payment_type_display,
                    DATE_FORMAT(pd.payment_time, '%Y-%m-%d %H:%i:%s') as payment_time_display,
                    CASE 
                        WHEN pd.amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount), 2))
                        ELSE CONCAT('¥', FORMAT(pd.amount, 2))
                    END as amount_display,
                    CASE 
                        WHEN pd.extra_fee < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.extra_fee), 2))
                        ELSE CONCAT('¥', FORMAT(pd.extra_fee, 2))
                    END as extra_fee_display,
                    CASE 
                        WHEN pd.credit_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.credit_amount), 2))
                        WHEN pd.credit_amount > 0 THEN CONCAT('¥', FORMAT(pd.credit_amount, 2))
                        ELSE '-'
                    END as credit_amount_display,
                    CASE 
                        WHEN pd.payment_type = 2 THEN 
                            CASE 
                                WHEN pd.extra_fee < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.extra_fee), 2))
                                ELSE CONCAT('¥', FORMAT(pd.extra_fee, 2))
                            END
                        ELSE 
                            CASE 
                                WHEN pd.amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount), 2))
                                ELSE CONCAT('¥', FORMAT(pd.amount, 2))
                            END
                    END as total_payment_display,
                    CASE 
                        WHEN pd.payment_type = 2 THEN 
                            CASE 
                                WHEN pd.extra_fee < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.extra_fee), 2))
                                ELSE CONCAT('¥', FORMAT(pd.extra_fee, 2))
                            END
                        ELSE 
                            CASE 
                                WHEN pd.amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount), 2))
                                ELSE CONCAT('¥', FORMAT(pd.amount, 2))
                            END
                    END as display_amount,
                    pd.hours,
                    pd.promotion_data,
                    pd.time_card_data,
                    su.name as operator_name
                FROM orders_payment_details pd
                JOIN payment_methods pm ON pd.payment_method_id = pm.id
                JOIN orders o ON pd.order_id = o.id
                LEFT JOIN system_users su ON pd.operator_id = su.id
                WHERE pd.order_id IN ($placeholders)
                ORDER BY pd.order_id, pd.payment_time, pd.id
            "; $stmt = $conn->prepare($paymentQuery); if (!$stmt) { throw new Exception("支付明细查询准备失败: " . $conn->error); } $types2 = str_repeat('s', count($orderIds)); $stmt->bind_param($types2, ...$orderIds); if (!$stmt->execute()) { throw new Exception("支付明细查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $promotionName = ''; if (!empty($row['promotion_data'])) { $promotionData = json_decode($row['promotion_data'], true); if (is_array($promotionData) && !empty($promotionData)) { $promotionNames = []; foreach ($promotionData as $promo) { if (isset($promo['id']) && isset($promo['quantity'])) { $promoStmt = $conn->prepare("SELECT name FROM promotion_strategies WHERE id = ? AND is_deleted = 0"); if ($promoStmt) { $promoStmt->bind_param("i", $promo['id']); $promoStmt->execute(); $promoResult = $promoStmt->get_result(); if ($promoRow = $promoResult->fetch_assoc()) { $promotionNames[] = $promoRow['name'] . '×' . $promo['quantity'] . '，'; } else { $promotionNames[] = '套餐#' . $promo['id'] . '×' . $promo['quantity'] . '，'; } $promoStmt->close(); } } } $promotionName = implode("<br>", $promotionNames); } } $row['promotion_name'] = $promotionName; $timeCardName = ''; if (!empty($row['time_card_data'])) { $timeCardData = json_decode($row['time_card_data'], true); if (is_array($timeCardData) && !empty($timeCardData)) { $timeCardNames = []; foreach ($timeCardData as $timeCard) { if (isset($timeCard['id']) && isset($timeCard['quantity'])) { $timeCardStmt = $conn->prepare("SELECT name FROM time_card_products WHERE id = ?"); if ($timeCardStmt) { $timeCardStmt->bind_param("i", $timeCard['id']); $timeCardStmt->execute(); $timeCardResult = $timeCardStmt->get_result(); if ($timeCardRow = $timeCardResult->fetch_assoc()) { $timeCardNames[] = $timeCardRow['name'] . '×' . $timeCard['quantity'] . '次，'; } else { $timeCardNames[] = '次卡券#' . $timeCard['id'] . '×' . $timeCard['quantity'] . '次，'; } $timeCardStmt->close(); } } } $timeCardName = implode("<br>", $timeCardNames); } } $row['time_card_name'] = $timeCardName; if (isset($orders[$row['order_id']])) { $orders[$row['order_id']]['payment_details'][] = $row; } } } } else { $orderQuery = "
            WITH order_interval_income AS (
                SELECT 
                    o.id,
                    COALESCE(SUM(pd2.amount + IFNULL(pd2.extra_fee, 0)), 0) as interval_income
                FROM orders o
                LEFT JOIN orders_payment_details pd2 ON o.id = pd2.order_id 
                    AND pd2.payment_time >= ? AND pd2.payment_time <= ?
                GROUP BY o.id
            )
            SELECT 
                o.id,
                o.room_id,
                o.start_time,
                o.expected_end_time,
                o.end_time,
                o.total_amount,
                o.credit_amount,
                o.member_card_no,
                o.status,
                o.audio_muted,
                o.audio_updated_at,
                o.create_time,
                o.update_time,
                o.origin_client,
                o.notes,
                o.purpose,
                o.total_pause_duration,
                r.name as room_name, 
                m.name as member_name,
                pd.payment_time,
                CASE 
                    WHEN CAST(o.status AS SIGNED) = 0 THEN '进行中'
                    WHEN CAST(o.status AS SIGNED) = 1 THEN '已结账'
                    ELSE '未知'
                END as status_display,
                DATE_FORMAT(o.start_time, '%Y-%m-%d %H:%i:%s') as start_time_display,
                DATE_FORMAT(o.expected_end_time, '%Y-%m-%d %H:%i:%s') as expected_end_time_display,
                DATE_FORMAT(o.end_time, '%Y-%m-%d %H:%i:%s') as end_time_display,
                CASE 
                    WHEN o.total_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(o.total_amount), 2))
                    ELSE CONCAT('¥', FORMAT(o.total_amount, 2))
                END as total_amount_display,
                CASE 
                    WHEN o.credit_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(o.credit_amount), 2))
                    WHEN o.credit_amount > 0 THEN CONCAT('¥', FORMAT(o.credit_amount, 2))
                    ELSE '-'
                END as order_credit_amount_display,
                CASE 
                    WHEN o.status = 1 AND o.end_time IS NOT NULL THEN 
                        TIMESTAMPDIFF(MINUTE, o.start_time, o.end_time)
                    ELSE 
                        TIMESTAMPDIFF(MINUTE, o.start_time, o.expected_end_time)
                END as actual_duration_minutes,
                o.total_pause_duration,
                oii.interval_income,
                CASE 
                    WHEN oii.interval_income < 0 
                    THEN CONCAT('-¥', FORMAT(ABS(oii.interval_income), 2))
                    ELSE CONCAT('¥', FORMAT(oii.interval_income, 2))
                END as interval_income_display
            FROM orders_payment_details pd
            JOIN orders o ON pd.order_id = o.id
            JOIN rooms r ON o.room_id = r.id
            LEFT JOIN member_accounts m ON o.member_card_no = m.member_card_no
            LEFT JOIN order_interval_income oii ON o.id = oii.id
            WHERE pd.payment_time >= ? AND pd.payment_time <= ?
        "; $params = [$start_date, $end_date, $start_date, $end_date]; $types = "ssss"; if ($status !== 'all') { $orderQuery .= " AND o.status = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $orderQuery .= " AND (o.id LIKE ? OR r.name LIKE ? OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $orderQuery .= " ORDER BY pd.payment_time DESC, pd.id DESC"; $stmt = $conn->prepare($orderQuery); if (!$stmt) { throw new Exception("订单查询准备失败: " . $conn->error); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { throw new Exception("订单查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $orders = []; $orderIds = []; while ($row = $result->fetch_assoc()) { $orders[$row['id']] = [ 'order' => $row, 'payment_details' => [] ]; $orderIds[] = $row['id']; } if (!empty($orderIds)) { $placeholders = str_repeat('?,', count($orderIds) - 1) . '?'; $paymentQuery = "
                SELECT 
                    pd.*, 
                    pm.name as payment_method_name,
                    CASE 
                        WHEN pd.payment_type = 0 THEN '开台'
                        WHEN pd.payment_type = 1 THEN '加时'
                        WHEN pd.payment_type = 2 AND pd.payment_time > o.end_time THEN '退费'
                        WHEN pd.payment_type = 2 THEN '结账'
                        ELSE '未知'
                    END as payment_type_display,
                    DATE_FORMAT(pd.payment_time, '%Y-%m-%d %H:%i:%s') as payment_time_display,
                    CASE 
                        WHEN pd.amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount), 2))
                        ELSE CONCAT('¥', FORMAT(pd.amount, 2))
                    END as amount_display,
                    CASE 
                        WHEN pd.extra_fee < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.extra_fee), 2))
                        ELSE CONCAT('¥', FORMAT(pd.extra_fee, 2))
                    END as extra_fee_display,
                    CASE 
                        WHEN pd.credit_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.credit_amount), 2))
                        WHEN pd.credit_amount > 0 THEN CONCAT('¥', FORMAT(pd.credit_amount, 2))
                        ELSE '-'
                    END as credit_amount_display,
                    CASE 
                        WHEN (pd.amount + pd.extra_fee) < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount + pd.extra_fee), 2))
                        ELSE CONCAT('¥', FORMAT(pd.amount + pd.extra_fee, 2))
                    END as total_payment_display,
                    CASE 
                        WHEN pd.payment_type = 2 THEN 
                            CASE 
                                WHEN pd.extra_fee < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.extra_fee), 2))
                                ELSE CONCAT('¥', FORMAT(pd.extra_fee, 2))
                            END
                        ELSE 
                            CASE 
                                WHEN pd.amount < 0 THEN CONCAT('-¥', FORMAT(ABS(pd.amount), 2))
                                ELSE CONCAT('¥', FORMAT(pd.amount, 2))
                            END
                    END as display_amount,
                    pd.hours,
                    su.name as operator_name
                FROM orders_payment_details pd
                JOIN payment_methods pm ON pd.payment_method_id = pm.id
                JOIN orders o ON pd.order_id = o.id
                LEFT JOIN system_users su ON pd.operator_id = su.id
                WHERE pd.order_id IN ($placeholders)
                AND pd.payment_time >= ? AND pd.payment_time <= ?
                ORDER BY pd.order_id, pd.payment_time, pd.id
            "; $types2 = str_repeat('s', count($orderIds)) . 'ss'; $params2 = array_merge($orderIds, [$start_date, $end_date]); $stmt = $conn->prepare($paymentQuery); if (!$stmt) { throw new Exception("支付明细查询准备失败: " . $conn->error); } $stmt->bind_param($types2, ...$params2); if (!$stmt->execute()) { throw new Exception("支付明细查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $promotionName = ''; if (!empty($row['promotion_data'])) { $promotionData = json_decode($row['promotion_data'], true); if (is_array($promotionData) && !empty($promotionData)) { $promotionNames = []; foreach ($promotionData as $promo) { if (isset($promo['id']) && isset($promo['quantity'])) { $promoStmt = $conn->prepare("SELECT name FROM promotion_strategies WHERE id = ? AND is_deleted = 0"); if ($promoStmt) { $promoStmt->bind_param("i", $promo['id']); $promoStmt->execute(); $promoResult = $promoStmt->get_result(); if ($promoRow = $promoResult->fetch_assoc()) { $promotionNames[] = $promoRow['name'] . '×' . $promo['quantity'] . '，'; } else { $promotionNames[] = '套餐#' . $promo['id'] . '×' . $promo['quantity'] . '，'; } $promoStmt->close(); } } } $promotionName = implode("<br>", $promotionNames); } } $row['promotion_name'] = $promotionName; $timeCardName = ''; if (!empty($row['time_card_data'])) { $timeCardData = json_decode($row['time_card_data'], true); if (is_array($timeCardData) && !empty($timeCardData)) { $timeCardNames = []; foreach ($timeCardData as $timeCard) { if (isset($timeCard['id']) && isset($timeCard['quantity'])) { $timeCardStmt = $conn->prepare("SELECT name FROM time_card_products WHERE id = ?"); if ($timeCardStmt) { $timeCardStmt->bind_param("i", $timeCard['id']); $timeCardStmt->execute(); $timeCardResult = $timeCardStmt->get_result(); if ($timeCardRow = $timeCardResult->fetch_assoc()) { $timeCardNames[] = $timeCardRow['name'] . '×' . $timeCard['quantity'] . '次，'; } else { $timeCardNames[] = '次卡券#' . $timeCard['id'] . '×' . $timeCard['quantity'] . '次，'; } $timeCardStmt->close(); } } } $timeCardName = implode("<br>", $timeCardNames); } } $row['time_card_name'] = $timeCardName; if (isset($orders[$row['order_id']])) { $orders[$row['order_id']]['payment_details'][] = $row; } } } } if (!empty($orderIds)) { foreach ($orderIds as $orderId) { $purposeTags = []; $purposeJson = $orders[$orderId]['order']['purpose']; if (!empty($purposeJson)) { $purposeIds = json_decode($purposeJson, true); if (is_array($purposeIds) && !empty($purposeIds)) { $placeholders = str_repeat('?,', count($purposeIds) - 1) . '?'; $tagQuery = "SELECT id, name FROM purpose_tags WHERE id IN ($placeholders)"; $tagStmt = $conn->prepare($tagQuery); if ($tagStmt) { $tagTypes = str_repeat('i', count($purposeIds)); $tagStmt->bind_param($tagTypes, ...$purposeIds); $tagStmt->execute(); $tagResult = $tagStmt->get_result(); while ($tagRow = $tagResult->fetch_assoc()) { $purposeTags[] = [ 'id' => (int)$tagRow['id'], 'name' => $tagRow['name'] ]; } $tagStmt->close(); } } } $orders[$orderId]['order']['purpose_tags'] = $purposeTags; } } $stats = calculateStatsByType($conn, $start_date, $end_date, $search, $status, $queryType); $responseData = []; foreach ($orders as $orderData) { $responseData[] = $orderData; } echo json_encode([ 'success' => true, 'data' => $responseData, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function calculateStats(mysqli $conn, array $params, string $types, string $start_date, string $end_date, string $search, string $status): array { $query = "
        SELECT 
            COUNT(DISTINCT o.id) as total_orders,
            (
                SELECT SUM(total_amount)
                FROM orders
                WHERE start_time >= ? AND start_time <= ?
                " . ($status !== 'all' ? " AND status = " . (int)$status : "") . "
                " . (!empty($search) ? " AND (id LIKE '%$search%' OR room_id IN (SELECT id FROM rooms WHERE name LIKE '%$search%') OR member_card_no LIKE '%$search%')" : "") . "
            ) as total_income,
            SUM(
                CASE 
                    WHEN o.status = 1 AND o.end_time IS NOT NULL THEN 
                        TIMESTAMPDIFF(MINUTE, o.start_time, o.end_time)
                    ELSE 
                        TIMESTAMPDIFF(MINUTE, o.start_time, o.expected_end_time)
                END
            ) as total_duration_minutes,
            CONCAT('¥', FORMAT((
                SELECT SUM(total_amount)
                FROM orders
                WHERE start_time >= ? AND start_time <= ?
                " . ($status !== 'all' ? " AND status = " . (int)$status : "") . "
                " . (!empty($search) ? " AND (id LIKE '%$search%' OR room_id IN (SELECT id FROM rooms WHERE name LIKE '%$search%') OR member_card_no LIKE '%$search%')" : "") . "
            ), 2)) as total_income_display
        FROM orders o
        JOIN rooms r ON o.room_id = r.id
        LEFT JOIN orders_payment_details pd ON o.id = pd.order_id
        WHERE o.start_time >= ? AND o.start_time <= ?
    "; $statsParams = [$start_date, $end_date, $start_date, $end_date, $start_date, $end_date]; $statsTypes = "ssssss"; if ($status !== 'all') { $query .= " AND o.status = ?"; $statsParams[] = $status; $statsTypes .= "i"; } if (!empty($search)) { $query .= " AND (o.id LIKE ? OR r.name LIKE ? OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsTypes .= "sss"; } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_orders' => 0, 'total_income' => 0, 'total_income_display' => '¥0.00', 'total_duration_minutes' => 0, 'payment_methods' => [] ]; } if (!empty($statsParams)) { $stmt->bind_param($statsTypes, ...$statsParams); } if (!$stmt->execute()) { return [ 'total_orders' => 0, 'total_income' => 0, 'total_income_display' => '¥0.00', 'total_duration_minutes' => 0, 'payment_methods' => [] ]; } $result = $stmt->get_result(); $stats = $result->fetch_assoc(); $paymentMethodsQuery = "
        SELECT 
            pm.id as payment_method_id,
            pm.name as payment_method_name,
            pm.sort_order,
            COUNT(DISTINCT o.id) as order_count,
            SUM(CASE 
                WHEN pd.payment_type = 2 THEN pd.extra_fee
                ELSE pd.amount
            END) as method_income,
            CONCAT('¥', FORMAT(SUM(CASE 
                WHEN pd.payment_type = 2 THEN pd.extra_fee
                ELSE pd.amount
            END), 2)) as method_income_display
        FROM orders o
        JOIN orders_payment_details pd ON o.id = pd.order_id
        JOIN payment_methods pm ON pd.payment_method_id = pm.id
        WHERE o.start_time >= ? AND o.start_time <= ?
    "; $pmParams = [$start_date, $end_date]; $pmTypes = "ss"; if ($status !== 'all') { $paymentMethodsQuery .= " AND o.status = ?"; $pmParams[] = $status; $pmTypes .= "i"; } if (!empty($search)) { $paymentMethodsQuery .= " AND (o.id LIKE ? OR o.room_id IN (SELECT id FROM rooms WHERE name LIKE ?) OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmTypes .= "sss"; } $paymentMethodsQuery .= " GROUP BY pm.id, pm.name, pm.sort_order ORDER BY pm.sort_order, pm.id"; $pmStmt = $conn->prepare($paymentMethodsQuery); $paymentMethods = []; if ($pmStmt) { if (!empty($pmParams)) { $pmStmt->bind_param($pmTypes, ...$pmParams); } if ($pmStmt->execute()) { $pmResult = $pmStmt->get_result(); while ($method = $pmResult->fetch_assoc()) { $paymentMethods[] = [ 'id' => (int)$method['payment_method_id'], 'name' => $method['payment_method_name'], 'sort_order' => (int)$method['sort_order'], 'order_count' => (int)$method['order_count'], 'income' => (float)$method['method_income'], 'income_display' => $method['method_income_display'] ]; } } $pmStmt->close(); } $cardIncome = 0; $otherIncome = 0; foreach ($paymentMethods as $method) { if ($method['id'] == 1) { $cardIncome = $method['income']; } else { $otherIncome += $method['income']; } } return [ 'total_orders' => (int)$stats['total_orders'], 'total_income' => (float)($stats['total_income'] ?? 0), 'total_income_display' => $stats['total_income_display'] ?? '¥0.00', 'total_duration_minutes' => (int)($stats['total_duration_minutes'] ?? 0), 'card_income' => $cardIncome, 'other_income' => $otherIncome, 'payment_methods' => $paymentMethods ]; } function calculateStatsByType(mysqli $conn, string $start_date, string $end_date, string $search, string $status, string $queryType): array { if ($queryType === 'order') { return calculateStats($conn, [], '', $start_date, $end_date, $search, $status); } else { $query = "
            SELECT 
                COUNT(DISTINCT o.id) as total_orders,
                SUM(CASE 
                    WHEN pd.payment_type = 2 THEN pd.extra_fee
                    ELSE pd.amount
                END) as interval_income,
                CONCAT('¥', FORMAT(SUM(CASE 
                    WHEN pd.payment_type = 2 THEN pd.extra_fee
                    ELSE pd.amount
                END), 2)) as interval_income_display,
                SUM(o.total_amount) as total_income,
                CONCAT('¥', FORMAT(SUM(o.total_amount), 2)) as total_income_display,
                SUM(
                    CASE 
                        WHEN o.status = 1 AND o.end_time IS NOT NULL THEN 
                            TIMESTAMPDIFF(MINUTE, o.start_time, o.end_time)
                        ELSE 
                            TIMESTAMPDIFF(MINUTE, o.start_time, o.expected_end_time)
                    END
                ) as total_duration_minutes
            FROM orders_payment_details pd
            JOIN orders o ON pd.order_id = o.id
            JOIN rooms r ON o.room_id = r.id
            WHERE pd.payment_time >= ? AND pd.payment_time <= ?
        "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND o.status = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (o.id LIKE ? OR r.name LIKE ? OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_orders' => 0, 'total_income' => 0, 'cash_income' => 0, 'card_income' => 0, 'payment_methods' => [] ]; } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { return [ 'total_orders' => 0, 'interval_income' => 0, 'interval_income_display' => '¥0.00', 'total_income' => 0, 'total_income_display' => '¥0.00', 'total_duration_minutes' => 0, 'payment_methods' => [] ]; } $result = $stmt->get_result(); $stats = $result->fetch_assoc(); $paymentMethodsQuery = "
            SELECT 
                pm.id as payment_method_id,
                pm.name as payment_method_name,
                pm.sort_order,
                COUNT(DISTINCT o.id) as order_count,
                SUM(CASE 
                    WHEN pd.payment_type = 2 THEN pd.extra_fee
                    ELSE pd.amount
                END) as method_income,
                CONCAT('¥', FORMAT(SUM(CASE 
                    WHEN pd.payment_type = 2 THEN pd.extra_fee
                    ELSE pd.amount
                END), 2)) as method_income_display
            FROM orders_payment_details pd
            JOIN payment_methods pm ON pd.payment_method_id = pm.id
            JOIN orders o ON pd.order_id = o.id
            JOIN rooms r ON o.room_id = r.id
            WHERE pd.payment_time >= ? AND pd.payment_time <= ?
        "; $pmParams = [$start_date, $end_date]; $pmTypes = "ss"; if ($status !== 'all') { $paymentMethodsQuery .= " AND o.status = ?"; $pmParams[] = $status; $pmTypes .= "i"; } if (!empty($search)) { $paymentMethodsQuery .= " AND (o.id LIKE ? OR r.name LIKE ? OR o.member_card_no LIKE ?)"; $searchParam = "%$search%"; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmTypes .= "sss"; } $paymentMethodsQuery .= " GROUP BY pm.id, pm.name, pm.sort_order ORDER BY pm.sort_order, pm.id"; $pmStmt = $conn->prepare($paymentMethodsQuery); $paymentMethods = []; if ($pmStmt) { if (!empty($pmParams)) { $pmStmt->bind_param($pmTypes, ...$pmParams); } if ($pmStmt->execute()) { $pmResult = $pmStmt->get_result(); while ($method = $pmResult->fetch_assoc()) { $paymentMethods[] = [ 'id' => (int)$method['payment_method_id'], 'name' => $method['payment_method_name'], 'sort_order' => (int)$method['sort_order'], 'order_count' => (int)$method['order_count'], 'income' => (float)$method['method_income'], 'income_display' => $method['method_income_display'] ]; } } $pmStmt->close(); } $cardIncome = 0; $otherIncome = 0; foreach ($paymentMethods as $method) { if ($method['id'] == 1) { $cardIncome = $method['income']; } else { $otherIncome += $method['income']; } } return [ 'total_orders' => (int)$stats['total_orders'], 'interval_income' => (float)($stats['interval_income'] ?? 0), 'interval_income_display' => $stats['interval_income_display'] ?? '¥0.00', 'total_income' => (float)($stats['total_income'] ?? 0), 'total_income_display' => $stats['total_income_display'] ?? '¥0.00', 'total_duration_minutes' => (int)($stats['total_duration_minutes'] ?? 0), 'card_income' => $cardIncome, 'other_income' => $otherIncome, 'payment_methods' => $paymentMethods ]; } }