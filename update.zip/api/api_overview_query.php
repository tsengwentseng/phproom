<?php
header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $end_date = $end_date . ' 23:59:59'; try { if (!$conn) { throw new Exception('数据库连接失败'); } $giftMethodId = null; $giftMethodQuery = "SELECT id FROM payment_methods WHERE id = 2 LIMIT 1"; $result = $conn->query($giftMethodQuery); if ($row = $result->fetch_assoc()) { $giftMethodId = $row['id']; } if ($giftMethodId === null) { $giftMethodId = 2; } $roomStatsQuery = "
        SELECT 
            COUNT(DISTINCT o.id) as total_orders,
            SUM(pd.amount + IFNULL(pd.extra_fee, 0)) as total_income,
            CONCAT('¥', FORMAT(SUM(pd.amount + IFNULL(pd.extra_fee, 0)), 2)) as total_income_display
        FROM orders_payment_details pd
        JOIN orders o ON pd.order_id = o.id
        JOIN rooms r ON o.room_id = r.id
        WHERE pd.payment_time >= ? AND pd.payment_time <= ?
    "; $stmt = $conn->prepare($roomStatsQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $roomStats = $stmt->get_result()->fetch_assoc(); $productStatsQuery = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(po.total_amount) as total_income,
            CONCAT('¥', FORMAT(SUM(po.total_amount), 2)) as total_income_display
        FROM product_orders po
        WHERE po.create_time >= ? AND po.create_time <= ?
    "; $stmt = $conn->prepare($productStatsQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $productStats = $stmt->get_result()->fetch_assoc(); $rechargeIncomeQuery = "
        SELECT SUM(mr.recharge_amount) as recharge_income
        FROM member_recharges mr
        WHERE mr.create_time >= ? AND mr.create_time <= ? AND mr.payment_method_id != ?
    "; $stmt = $conn->prepare($rechargeIncomeQuery); $stmt->bind_param('ssi', $start_date, $end_date, $giftMethodId); $stmt->execute(); $rechargeIncome = $stmt->get_result()->fetch_assoc()['recharge_income'] ?? 0; $rechargeOrdersQuery = "
        SELECT COUNT(*) as recharge_orders
        FROM member_recharges mr
        WHERE mr.create_time >= ? AND mr.create_time <= ?
    "; $stmt = $conn->prepare($rechargeOrdersQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $rechargeOrders = $stmt->get_result()->fetch_assoc()['recharge_orders'] ?? 0; $giftAmountQuery = "
        SELECT SUM(mr.gift_amount) as gift_amount
        FROM member_recharges mr
        WHERE mr.create_time >= ? AND mr.create_time <= ?
    "; $stmt = $conn->prepare($giftAmountQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $giftAmount = $stmt->get_result()->fetch_assoc()['gift_amount'] ?? 0; $consumptionStatsQuery = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(mc.amount) as total_consumption,
            CONCAT('¥', FORMAT(SUM(mc.amount), 2)) as total_consumption_display,
            SUM(CASE WHEN mc.product_id IS NULL AND mc.time_card_id IS NULL THEN mc.amount ELSE 0 END) as room_consumption,
            CONCAT('¥', FORMAT(SUM(CASE WHEN mc.product_id IS NULL AND mc.time_card_id IS NULL THEN mc.amount ELSE 0 END), 2)) as room_consumption_display,
            SUM(CASE WHEN mc.product_id IS NOT NULL OR mc.time_card_id IS NOT NULL THEN mc.amount ELSE 0 END) as product_consumption,
            CONCAT('¥', FORMAT(SUM(CASE WHEN mc.product_id IS NOT NULL OR mc.time_card_id IS NOT NULL THEN mc.amount ELSE 0 END), 2)) as product_consumption_display
        FROM member_consumptions mc
        WHERE mc.create_time >= ? AND mc.create_time <= ?
    "; $stmt = $conn->prepare($consumptionStatsQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $consumptionStats = $stmt->get_result()->fetch_assoc(); $memberStatsQuery = "
        SELECT 
            COUNT(*) as total_members,
            SUM(ma.balance) as total_balance,
            CONCAT('¥', FORMAT(SUM(ma.balance), 2)) as total_balance_display,
            COUNT(CASE WHEN ma.create_time >= ? AND ma.create_time <= ? THEN 1 END) as new_members,
            COUNT(CASE WHEN ma.last_consumption_time >= ? AND ma.last_consumption_time <= ? THEN 1 END) as active_members
        FROM member_accounts ma
    "; $stmt = $conn->prepare($memberStatsQuery); $stmt->bind_param('ssss', $start_date, $end_date, $start_date, $end_date); $stmt->execute(); $memberStats = $stmt->get_result()->fetch_assoc(); $timeCardStatsQuery = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN tco.is_refunded = 0 THEN tco.total_amount ELSE 0 END) as total_income,
            CONCAT('¥', FORMAT(SUM(CASE WHEN tco.is_refunded = 0 THEN tco.total_amount ELSE 0 END), 2)) as total_income_display
        FROM time_card_orders tco
        WHERE tco.create_time >= ? AND tco.create_time <= ?
    "; $stmt = $conn->prepare($timeCardStatsQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $timeCardStats = $stmt->get_result()->fetch_assoc(); $rechargePaymentMethodsQuery = "
        SELECT 
            pm.id,
            pm.name,
            pm.sort_order,
            COUNT(DISTINCT mr.id) as order_count,
            SUM(mr.recharge_amount) as income,
            CONCAT('¥', FORMAT(SUM(mr.recharge_amount), 2)) as income_display
        FROM payment_methods pm
        JOIN member_recharges mr ON pm.id = mr.payment_method_id
        WHERE mr.create_time >= ? AND mr.create_time <= ?
        AND pm.id != 2
        GROUP BY pm.id, pm.name, pm.sort_order
        HAVING income > 0
        ORDER BY pm.sort_order, pm.id
    "; $stmt = $conn->prepare($rechargePaymentMethodsQuery); $stmt->bind_param('ss', $start_date, $end_date); $stmt->execute(); $rechargePaymentMethods = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $giftAmount = $giftAmount ?? 0; $consumptionAmount = $consumptionStats['total_consumption'] ?? 0; $netIncome = ($roomStats['total_income'] ?? 0) + ($productStats['total_income'] ?? 0) + ($timeCardStats['total_income'] ?? 0) + $rechargeIncome - $giftAmount - $consumptionAmount; $totalOrders = ($roomStats['total_orders'] ?? 0) + ($productStats['total_orders'] ?? 0) + ($timeCardStats['total_orders'] ?? 0) + $rechargeOrders + ($consumptionStats['total_orders'] ?? 0); $response = [ 'success' => true, 'data' => [ 'room_stats' => $roomStats, 'product_stats' => $productStats, 'time_card_stats' => $timeCardStats, 'recharge_income' => $rechargeIncome, 'gift_amount' => $giftAmount, 'consumption_stats' => $consumptionStats, 'member_stats' => $memberStats, 'recharge_payment_methods' => $rechargePaymentMethods ], 'stats' => [ 'net_income' => $netIncome, 'net_income_display' => ($netIncome < 0 ? '-' : '') . '¥' . number_format(abs((float)$netIncome), 2, '.', ''), 'total_orders' => $totalOrders, 'room_orders' => $roomStats['total_orders'] ?? 0, 'room_income' => $roomStats['total_income'] ?? 0, 'room_income_display' => ($roomStats['total_income'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($roomStats['total_income'] ?? 0)), 2, '.', ''), 'product_orders' => $productStats['total_orders'] ?? 0, 'product_income' => $productStats['total_income'] ?? 0, 'product_income_display' => ($productStats['total_income'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($productStats['total_income'] ?? 0)), 2, '.', ''), 'time_card_orders' => $timeCardStats['total_orders'] ?? 0, 'time_card_income' => $timeCardStats['total_income'] ?? 0, 'time_card_income_display' => ($timeCardStats['total_income'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($timeCardStats['total_income'] ?? 0)), 2, '.', ''), 'recharge_orders' => $rechargeOrders, 'recharge_income' => $rechargeIncome, 'recharge_income_display' => ($rechargeIncome < 0 ? '-' : '') . '¥' . number_format(abs((float)$rechargeIncome), 2, '.', ''), 'total_recharge_amount' => $rechargeIncome + $giftAmount, 'total_recharge_amount_display' => (($rechargeIncome + $giftAmount) < 0 ? '-' : '') . '¥' . number_format(abs((float)($rechargeIncome + $giftAmount)), 2, '.', ''), 'gift_amount' => $giftAmount, 'gift_amount_display' => ($giftAmount < 0 ? '-' : '') . '¥' . number_format(abs((float)$giftAmount), 2, '.', ''), 'consumption_orders' => $consumptionStats['total_orders'] ?? 0, 'consumption_amount' => $consumptionStats['total_consumption'] ?? 0, 'consumption_amount_display' => ($consumptionStats['total_consumption'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($consumptionStats['total_consumption'] ?? 0)), 2, '.', ''), 'room_consumption' => $consumptionStats['room_consumption'] ?? 0, 'room_consumption_display' => ($consumptionStats['room_consumption'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($consumptionStats['room_consumption'] ?? 0)), 2, '.', ''), 'product_consumption' => $consumptionStats['product_consumption'] ?? 0, 'product_consumption_display' => ($consumptionStats['product_consumption'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($consumptionStats['product_consumption'] ?? 0)), 2, '.', ''), 'total_members' => $memberStats['total_members'] ?? 0, 'total_balance' => $memberStats['total_balance'] ?? 0, 'total_balance_display' => ($memberStats['total_balance'] < 0 ? '-' : '') . '¥' . number_format(abs((float)($memberStats['total_balance'] ?? 0)), 2, '.', ''), 'new_members' => $memberStats['new_members'] ?? 0, 'active_members' => $memberStats['active_members'] ?? 0 ] ]; echo json_encode($response); } catch (Exception $e) { http_response_code(500); echo json_encode(['success' => false, 'message' => $e->getMessage()]); } finally { }