<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); $SCENE_ROOM_NAME = '房间'; $scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'"); if ($scene_stmt) { $scene_stmt->execute(); $scene_result = $scene_stmt->get_result(); if ($scene_result && $scene_row = $scene_result->fetch_assoc()) { $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间'; } $scene_stmt->close(); } session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $method = $_SERVER['REQUEST_METHOD']; if ($method === 'POST') { $input = json_decode(file_get_contents('php://input'), true); if (!$input && !empty($_POST)) { $input = $_POST; } $action = $input['action'] ?? ''; if ($action === 'refund') { handleRefund($conn, $input); } elseif ($action === 'refund_consumption') { handleRefundConsumption($conn, $input); } else { http_response_code(400); echo json_encode(['success' => false, 'message' => '无效的操作']); } exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $query_type = $_GET['query_type'] ?? 'orders'; $status = $_GET['status'] ?? 'all'; $end_date = $end_date . ' 23:59:59'; try { switch ($query_type) { case 'orders': $data = queryTimeCardOrders($conn, $start_date, $end_date, $search, $status); break; case 'holdings': $data = queryTimeCardHoldings($conn, $start_date, $end_date, $search, $status); break; case 'consumptions': $data = queryTimeCardConsumptions($conn, $start_date, $end_date, $search, $status); break; default: throw new Exception('无效的查询类型'); } echo json_encode([ 'success' => true, 'data' => $data['records'], 'stats' => $data['stats'] ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function handleRefund($conn, $input) { $operatorId = null; if (isset($_SESSION['admin_user_id'])) { $operatorId = (int)$_SESSION['admin_user_id']; } elseif (isset($_SESSION['front_user_id'])) { $operatorId = (int)$_SESSION['front_user_id']; } if ($operatorId === null) { http_response_code(401); echo json_encode(['success' => false, 'message' => '未登录或会话已过期']); exit; } if ($operatorId !== 1) { http_response_code(403); echo json_encode(['success' => false, 'message' => '您没有权限执行退单操作，请使用admin账户操作']); exit; } $orderId = trim($input['order_id'] ?? ''); if (empty($orderId)) { http_response_code(400); echo json_encode(['success' => false, 'message' => '订单ID不能为空']); exit; } $conn->query("SET innodb_lock_wait_timeout = 5"); $conn->begin_transaction(); try { $orderStmt = $conn->prepare("
            SELECT tco.*, tcp.name as time_card_name, pm.name as payment_method_name
            FROM time_card_orders tco
            JOIN time_card_products tcp ON tco.time_card_id = tcp.id
            JOIN payment_methods pm ON tco.payment_method_id = pm.id
            WHERE tco.id = ? AND tco.is_refunded = 0
            FOR UPDATE
        "); $orderStmt->bind_param("s", $orderId); $orderStmt->execute(); $orderResult = $orderStmt->get_result(); if ($orderResult->num_rows === 0) { throw new Exception('订单不存在或已经退款'); } $order = $orderResult->fetch_assoc(); if ($order['payment_method_id'] == 1 && empty($order['member_card_no'])) { throw new Exception('该订单关联的会员卡已不存在，无法退费'); } if (!empty($order['member_card_no']) && strpos($order['member_card_no'], '@') !== false) { throw new Exception('归档卡号不允许退费操作'); } $timeCardStmt = $conn->prepare("
            SELECT * FROM time_cards_member 
            WHERE sale_order_no = ? 
            FOR UPDATE
        "); $timeCardStmt->bind_param("s", $orderId); $timeCardStmt->execute(); $timeCardResult = $timeCardStmt->get_result(); if ($timeCardResult->num_rows === 0) { throw new Exception('未找到对应的次卡记录'); } $timeCard = $timeCardResult->fetch_assoc(); if ($timeCard['remaining_times'] < $timeCard['total_times']) { throw new Exception('次卡券已使用，不允许退款'); } $updateOrderStmt = $conn->prepare("
            UPDATE time_card_orders 
            SET is_refunded = 1, total_amount = 0, operator_id = 1
            WHERE id = ?
        "); $updateOrderStmt->bind_param("s", $orderId); $updateOrderStmt->execute(); $deleteTimeCardStmt = $conn->prepare("
            DELETE FROM time_cards_member 
            WHERE sale_order_no = ?
        "); $deleteTimeCardStmt->bind_param("s", $orderId); $deleteTimeCardStmt->execute(); if ($order['payment_method_id'] == 1 && !empty($order['member_card_no'])) { $memberCardNo = normalizeMemberCardNo($order['member_card_no']); $refundAmount = $order['total_amount']; $memberStmt = $conn->prepare("
                SELECT balance, name FROM member_accounts 
                WHERE member_card_no = ?
            "); $memberStmt->bind_param("s", $memberCardNo); $memberStmt->execute(); $memberResult = $memberStmt->get_result(); if ($memberResult->num_rows > 0) { $member = $memberResult->fetch_assoc(); $currentBalance = floatval($member['balance']); $newBalance = $currentBalance + $refundAmount; $memberName = $member['name'] ?? '未知'; $updateMemberStmt = $conn->prepare("
                    UPDATE member_accounts 
                    SET balance = ?, last_consumption_time = NOW() 
                    WHERE member_card_no = ?
                "); $updateMemberStmt->bind_param("ds", $newBalance, $memberCardNo); $updateMemberStmt->execute(); $operatorId = 1; $consumptionStmt = $conn->prepare("
                    INSERT INTO member_consumptions 
                    (order_id, room_id, product_id, time_card_id, member_card_no, name, amount, final_balance, operator_id) 
                    VALUES (?, NULL, NULL, ?, ?, ?, ?, ?, ?)
                "); $refundOrderId = $orderId . '-R'; $negativeAmount = -$refundAmount; $consumptionStmt->bind_param("sissddi", $refundOrderId, $timeCard['time_card_id'], $memberCardNo, $memberName, $negativeAmount, $newBalance, $operatorId); $consumptionStmt->execute(); $updateConsumptionStmt = $conn->prepare("
                    UPDATE member_accounts 
                    SET total_consumption_amount = (
                        SELECT IFNULL(SUM(amount), 0) 
                        FROM member_consumptions 
                        WHERE member_card_no = ?
                    )
                    WHERE member_card_no = ?
                "); $updateConsumptionStmt->bind_param('ss', $memberCardNo, $memberCardNo); $updateConsumptionStmt->execute(); } } $conn->commit(); echo json_encode([ 'success' => true, 'message' => '退单成功', 'data' => [ 'order_id' => $orderId, 'time_card_name' => $order['time_card_name'], 'refund_amount' => $order['total_amount'] ] ]); } catch (Exception $e) { $conn->rollback(); http_response_code(400); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } } function queryTimeCardOrders($conn, $start_date, $end_date, $search, $status = 'all') { global $SCENE_ROOM_NAME; $query = "
        SELECT 
            tco.id,
            tco.member_card_no,
            tco.time_card_id,
            tco.total_times,
            tco.hours,
            tco.validity_days,
            tco.quantity,
            tco.unit_price,
            tco.total_amount,
            tco.payment_method_id,
            tco.notes,
            tco.status,
            tco.is_refunded,
            tco.create_time,
            tcp.is_all_day as is_all_day,
            tcp.name as time_card_name,
            tcp.type as time_card_type,
            pm.name as payment_method_name,
            CASE 
                WHEN tco.is_refunded = 0 THEN '正常'
                WHEN tco.is_refunded = 1 THEN '已退款'
                ELSE '未知'
            END as status_display,
            CASE 
                WHEN tcp.type = 'room' THEN '{$SCENE_ROOM_NAME}'
                WHEN tcp.type = 'product' THEN '商品'
                ELSE '未知'
            END as type_display,
            DATE_FORMAT(tco.create_time, '%Y-%m-%d %H:%i:%s') as create_time_display,
            CONCAT('¥', FORMAT(tco.unit_price, 2)) as unit_price_display,
            CONCAT('¥', FORMAT(tco.total_amount, 2)) as total_amount_display,
            CONCAT(tco.total_times, '次') as times_display,
            CASE 
                WHEN tco.validity_days IS NULL THEN '永久'
                ELSE CONCAT(tco.validity_days, '天')
            END as validity_display,
            su.name as operator_name
        FROM time_card_orders tco
        JOIN time_card_products tcp ON tco.time_card_id = tcp.id
        JOIN payment_methods pm ON tco.payment_method_id = pm.id
        LEFT JOIN system_users su ON tco.operator_id = su.id
        WHERE tco.create_time >= ? AND tco.create_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND tco.is_refunded = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (tco.id LIKE ? OR tcp.name LIKE ? OR tco.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $query .= " ORDER BY tco.create_time DESC, tco.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } $stmt->bind_param($types, ...$params); if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $records = []; while ($row = $result->fetch_assoc()) { $records[] = $row; } $stats = calculateOrderStats($conn, $start_date, $end_date, $search, $status); return [ 'records' => $records, 'stats' => $stats ]; } function queryTimeCardHoldings($conn, $start_date, $end_date, $search, $status = 'all') { global $SCENE_ROOM_NAME; $query = "
        SELECT 
            tcm.id,
            tcm.sale_order_no,
            tcm.member_card_no,
            tcm.time_card_id,
            tcm.total_times,
            tcm.remaining_times,
            tcm.purchase_time,
            tcm.expire_time,
            tcm.is_expired,
            tcm.last_use_time,
            tcp.name as time_card_name,
            tcp.type as time_card_type,
            tcm.is_all_day as is_all_day,
            tcm.snapshot_hours as hours,
            ma.name as member_name,
            CASE 
                WHEN tcm.remaining_times > 0 AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW()) THEN '可用'
                WHEN tcm.remaining_times = 0 THEN '已用完'
                WHEN tcm.remaining_times > 0 AND tcm.expire_time IS NOT NULL AND tcm.expire_time <= NOW() THEN '已过期'
                ELSE '未知'
            END as status_display,
            CASE 
                WHEN tcp.type = 'room' THEN '{$SCENE_ROOM_NAME}'
                WHEN tcp.type = 'product' THEN '商品'
                ELSE '未知'
            END as type_display,
            DATE_FORMAT(tcm.purchase_time, '%Y-%m-%d %H:%i:%s') as purchase_time_display,
            CASE 
                WHEN tcm.expire_time IS NULL THEN '永久'
                ELSE DATE_FORMAT(tcm.expire_time, '%Y-%m-%d %H:%i:%s')
            END as expire_time_display,
            CASE 
                WHEN tcm.last_use_time IS NULL THEN '-'
                ELSE DATE_FORMAT(tcm.last_use_time, '%Y-%m-%d %H:%i:%s')
            END as last_use_time_display,
            CONCAT(tcm.remaining_times, '/', tcm.total_times) as times_display
        FROM time_cards_member tcm
        JOIN time_card_products tcp ON tcm.time_card_id = tcp.id
        LEFT JOIN member_accounts ma ON tcm.member_card_no = ma.member_card_no
        WHERE tcm.purchase_time >= ? AND tcm.purchase_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status === 'active') { $query .= " AND tcm.remaining_times > 0 AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW())"; } elseif ($status === 'used') { $query .= " AND tcm.remaining_times = 0"; } elseif ($status === 'expired') { $query .= " AND tcm.remaining_times > 0 AND tcm.expire_time IS NOT NULL AND tcm.expire_time <= NOW()"; } if (!empty($search)) { $query .= " AND (tcm.sale_order_no LIKE ? OR tcp.name LIKE ? OR tcm.member_card_no LIKE ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "ssss"; } $query .= " ORDER BY tcm.purchase_time DESC, tcm.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } $stmt->bind_param($types, ...$params); if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $records = []; while ($row = $result->fetch_assoc()) { $records[] = $row; } $stats = calculateHoldingStats($conn, $start_date, $end_date, $search, $status); return [ 'records' => $records, 'stats' => $stats ]; } function queryTimeCardConsumptions($conn, $start_date, $end_date, $search, $status = 'all') { global $SCENE_ROOM_NAME; $query = "
        SELECT 
            tcc.id,
            tcc.purchase_order_no,
            tcc.batch_no,
            tcc.member_card_no,
            tcc.time_card_id,
            tcc.usage_type,
            tcc.room_id,
            tcc.deduction_hours,
            tcc.product_id,
            tcc.used_quantity,
            tcc.remaining_times,
            tcc.is_refunded,
            tcc.create_time,
            tcp.is_all_day as is_all_day,
            tcp.name as time_card_name,
            ma.name as member_name,
            r.name as room_name,
            p.name as product_name,
            CASE 
                WHEN tcc.usage_type = 'room' THEN '{$SCENE_ROOM_NAME}消费'
                WHEN tcc.usage_type = 'product' THEN '商品消费'
                ELSE '未知'
            END as usage_type_display,
            DATE_FORMAT(tcc.create_time, '%Y-%m-%d %H:%i:%s') as create_time_display,
            CASE 
                WHEN tcc.is_refunded = 0 THEN '正常'
                WHEN tcc.is_refunded = 1 THEN '已退款'
                ELSE '未知'
            END as status_display,
            CASE 
                WHEN tcc.usage_type = 'room' THEN r.name
                WHEN tcc.usage_type = 'product' AND p.name IS NOT NULL 
                THEN p.name
                ELSE '-'
            END as usage_detail,
            su.name as operator_name
        FROM time_card_consumptions tcc
        JOIN time_card_products tcp ON tcc.time_card_id = tcp.id
        LEFT JOIN member_accounts ma ON tcc.member_card_no = ma.member_card_no
        LEFT JOIN rooms r ON tcc.room_id = r.id
        LEFT JOIN products p ON tcc.product_id = p.id
        LEFT JOIN system_users su ON tcc.operator_id = su.id
        WHERE tcc.create_time >= ? AND tcc.create_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND tcc.is_refunded = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (tcc.purchase_order_no LIKE ? OR tcc.batch_no LIKE ? OR tcp.name LIKE ? OR tcc.member_card_no LIKE ? OR ma.name LIKE ? OR r.name LIKE ? OR p.name LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sssssss"; } $query .= " ORDER BY tcc.create_time DESC, tcc.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } $stmt->bind_param($types, ...$params); if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $records = []; while ($row = $result->fetch_assoc()) { $records[] = $row; } $stats = calculateConsumptionStats($conn, $start_date, $end_date, $search, $status); return [ 'records' => $records, 'stats' => $stats ]; } function calculateOrderStats($conn, $start_date, $end_date, $search, $status = 'all') { $query = "
        SELECT 
            COUNT(*) as total_orders,
            IFNULL(SUM(CASE WHEN tco.is_refunded = 0 THEN tco.total_amount ELSE 0 END), 0) as total_income,
            IFNULL(SUM(CASE WHEN tco.is_refunded = 0 THEN tco.total_times * tco.quantity ELSE 0 END), 0) as total_times_sold,
            CONCAT('¥', FORMAT(IFNULL(SUM(CASE WHEN tco.is_refunded = 0 THEN tco.total_amount ELSE 0 END), 0), 2)) as total_income_display
        FROM time_card_orders tco
        JOIN time_card_products tcp ON tco.time_card_id = tcp.id
        WHERE tco.create_time >= ? AND tco.create_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND tco.is_refunded = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (tco.id LIKE ? OR tcp.name LIKE ? OR tco.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $stmt = $conn->prepare($query); $stmt->bind_param($types, ...$params); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); return [ 'total_orders' => (int)$row['total_orders'], 'total_income' => (float)$row['total_income'], 'total_times_sold' => (int)$row['total_times_sold'], 'total_income_display' => $row['total_income_display'] ]; } function calculateHoldingStats($conn, $start_date, $end_date, $search, $status = 'all') { $query = "
        SELECT 
            COUNT(*) as total_holdings,
            SUM(tcm.total_times) as total_times,
            SUM(tcm.remaining_times) as total_remaining_times,
            SUM(CASE WHEN tcm.remaining_times > 0 AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW()) THEN 1 ELSE 0 END) as active_holdings
        FROM time_cards_member tcm
        JOIN time_card_products tcp ON tcm.time_card_id = tcp.id
        WHERE tcm.purchase_time >= ? AND tcm.purchase_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status === 'active') { $query .= " AND tcm.remaining_times > 0 AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW())"; } elseif ($status === 'used') { $query .= " AND tcm.remaining_times = 0"; } elseif ($status === 'expired') { $query .= " AND tcm.remaining_times > 0 AND tcm.expire_time IS NOT NULL AND tcm.expire_time <= NOW()"; } if (!empty($search)) { $query .= " AND (tcm.sale_order_no LIKE ? OR tcp.name LIKE ? OR tcm.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $stmt = $conn->prepare($query); $stmt->bind_param($types, ...$params); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); return [ 'total_holdings' => (int)$row['total_holdings'], 'total_times' => (int)$row['total_times'], 'total_remaining_times' => (int)$row['total_remaining_times'], 'active_holdings' => (int)$row['active_holdings'] ]; } function calculateConsumptionStats($conn, $start_date, $end_date, $search, $status = 'all') { $query = "
        SELECT 
            COUNT(*) as total_consumptions,
            SUM(tcc.used_quantity) as total_used_times,
            SUM(CASE WHEN tcc.usage_type = 'room' THEN tcc.used_quantity ELSE 0 END) as room_consumptions,
            SUM(CASE WHEN tcc.usage_type = 'product' THEN tcc.used_quantity ELSE 0 END) as product_consumptions
        FROM time_card_consumptions tcc
        JOIN time_card_products tcp ON tcc.time_card_id = tcp.id
        WHERE tcc.create_time >= ? AND tcc.create_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND tcc.is_refunded = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (tcc.purchase_order_no LIKE ? OR tcp.name LIKE ? OR tcc.member_card_no LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $stmt = $conn->prepare($query); $stmt->bind_param($types, ...$params); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); return [ 'total_consumptions' => (int)$row['total_consumptions'], 'total_used_times' => (int)$row['total_used_times'], 'room_consumptions' => (int)$row['room_consumptions'], 'product_consumptions' => (int)$row['product_consumptions'] ]; } function handleRefundConsumption($conn, $input) { $operatorId = null; if (isset($_SESSION['admin_user_id'])) { $operatorId = (int)$_SESSION['admin_user_id']; } elseif (isset($_SESSION['front_user_id'])) { $operatorId = (int)$_SESSION['front_user_id']; } if ($operatorId === null) { http_response_code(401); echo json_encode(['success' => false, 'message' => '未登录或会话已过期']); exit; } if ($operatorId !== 1) { http_response_code(403); echo json_encode(['success' => false, 'message' => '您没有权限执行退单操作，请使用admin账户操作']); exit; } $consumptionId = (int)($input['consumption_id'] ?? 0); if ($consumptionId <= 0) { http_response_code(400); echo json_encode(['success' => false, 'message' => '使用记录ID无效']); exit; } $conn->query("SET innodb_lock_wait_timeout = 5"); $conn->begin_transaction(); try { $consumptionStmt = $conn->prepare("
            SELECT * FROM time_card_consumptions 
            WHERE id = ? 
            FOR UPDATE
        "); $consumptionStmt->bind_param("i", $consumptionId); $consumptionStmt->execute(); $consumptionResult = $consumptionStmt->get_result(); if ($consumptionResult->num_rows === 0) { throw new Exception('使用记录不存在'); } $consumption = $consumptionResult->fetch_assoc(); if (empty($consumption['member_card_no'])) { throw new Exception('该使用记录关联的会员卡已不存在，无法退费'); } if (strpos($consumption['member_card_no'], '@') !== false) { throw new Exception('归档卡号不允许退费操作'); } if ($consumption['usage_type'] !== 'room') { throw new Exception("只能退{$SCENE_ROOM_NAME}使用的次卡券，商品使用请通过商品订单退单"); } if ($consumption['is_refunded'] == 1) { throw new Exception('该使用记录已经退单'); } $saleOrderNo = $consumption['purchase_order_no']; $timeCardId = $consumption['time_card_id']; $memberCardNo = normalizeMemberCardNo($consumption['member_card_no']); $usedQuantity = $consumption['used_quantity']; $refundTimeCardStmt = $conn->prepare("
            UPDATE time_cards_member 
            SET remaining_times = remaining_times + ?
            WHERE sale_order_no = ? 
              AND time_card_id = ?
              AND member_card_no = ?
        "); $refundTimeCardStmt->bind_param("isis", $usedQuantity, $saleOrderNo, $timeCardId, $memberCardNo); if (!$refundTimeCardStmt->execute()) { throw new Exception('次卡次数退回失败'); } if ($refundTimeCardStmt->affected_rows === 0) { throw new Exception('未找到对应的次卡记录'); } $updateConsumptionStmt = $conn->prepare("
            UPDATE time_card_consumptions 
            SET is_refunded = 1, operator_id = 1
            WHERE id = ?
        "); $updateConsumptionStmt->bind_param("i", $consumptionId); if (!$updateConsumptionStmt->execute()) { throw new Exception('标记退单状态失败'); } $conn->commit(); echo json_encode([ 'success' => true, 'message' => '退单成功' ]); } catch (Exception $e) { $conn->rollback(); http_response_code(400); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } } 