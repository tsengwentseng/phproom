<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $end_date = $end_date . ' 23:59:59'; try { $query = "
        SELECT 
            mr.id,
            mr.member_card_no,
            ma.name,
            mr.recharge_amount,
            mr.gift_amount,
            mr.final_balance,
            pm.name as payment_method,
            mr.create_time,
            CASE WHEN mr.recharge_amount != 0 THEN 1 ELSE 0 END as has_recharge,
            CASE WHEN mr.gift_amount != 0 THEN 1 ELSE 0 END as has_gift,
CASE 
    WHEN mr.recharge_amount = 0 AND (mr.request_code IS NULL OR mr.request_code = '') AND mr.gift_amount != 0 THEN '卡内转账'
    WHEN (mr.recharge_amount + mr.gift_amount) > 0 THEN '充值'
    WHEN (mr.recharge_amount + mr.gift_amount) < 0 THEN '充值退款'
    WHEN (mr.recharge_amount + mr.gift_amount) = 0 THEN '充值'
    ELSE '其他'
END as transaction_type,
            CASE 
                WHEN mr.recharge_amount > 0 THEN CONCAT('+¥', FORMAT(mr.recharge_amount, 2))
                WHEN mr.recharge_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(mr.recharge_amount), 2))
                ELSE '-'
            END as recharge_amount_display,
            CASE 
                WHEN mr.gift_amount > 0 THEN CONCAT('+¥', FORMAT(mr.gift_amount, 2))
                WHEN mr.gift_amount < 0 THEN CONCAT('-¥', FORMAT(ABS(mr.gift_amount), 2))
                WHEN mr.gift_amount = 0 AND pm.id = 2 THEN '¥0.00'
                ELSE '-'
            END as gift_amount_display,
            CONCAT('¥', FORMAT(mr.final_balance, 2)) as final_balance_display,
            su.name as operator_name
        FROM 
            member_recharges mr
        LEFT JOIN 
            member_accounts ma ON mr.member_card_no = ma.member_card_no
        LEFT JOIN 
            payment_methods pm ON mr.payment_method_id = pm.id
        LEFT JOIN
            system_users su ON mr.operator_id = su.id
        WHERE 
            mr.create_time BETWEEN ? AND ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $query .= " AND (mr.id LIKE ? OR mr.member_card_no = ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $search; $params[] = $searchParam; $types .= "sss"; } else { $query .= " AND (mr.id LIKE ? OR mr.member_card_no LIKE ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } } $query .= " ORDER BY mr.create_time DESC, mr.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { $error_msg = "查询准备失败: " . $conn->error; throw new Exception($error_msg); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { $error_msg = "查询执行失败: " . $stmt->error; throw new Exception($error_msg); } $result = $stmt->get_result(); $orders = []; while ($row = $result->fetch_assoc()) { $orders[] = [ 'id' => $row['id'], 'member_card_no' => $row['member_card_no'], 'name' => $row['name'] ?? '未知', 'recharge_amount' => (float)$row['recharge_amount'], 'gift_amount' => (float)$row['gift_amount'], 'final_balance' => (float)$row['final_balance'], 'payment_method' => $row['payment_method'] ?? '未知', 'create_time' => $row['create_time'], 'has_recharge' => (int)$row['has_recharge'], 'has_gift' => (int)$row['has_gift'], 'transaction_type' => $row['transaction_type'], 'recharge_amount_display' => $row['recharge_amount_display'], 'gift_amount_display' => $row['gift_amount_display'], 'final_balance_display' => $row['final_balance_display'], 'operator_name' => $row['operator_name'] ]; } $stats = calculateStats($conn, $params, $types, $start_date, $end_date, $search); echo json_encode([ 'success' => true, 'data' => $orders, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function calculateStats($conn, $params, $types, $start_date, $end_date, $search) { $query = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(recharge_amount) as total_recharge,
            SUM(gift_amount) as total_gift,
            SUM(recharge_amount + gift_amount) as total_income
        FROM 
            member_recharges mr
        LEFT JOIN 
            member_accounts ma ON mr.member_card_no = ma.member_card_no
        LEFT JOIN 
            payment_methods pm ON mr.payment_method_id = pm.id
        WHERE 
            mr.create_time BETWEEN ? AND ?
    "; $statsParams = [$start_date, $end_date]; $statsTypes = "ss"; if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $query .= " AND (mr.id LIKE ? OR mr.member_card_no = ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $statsParams[] = $searchParam; $statsParams[] = $search; $statsParams[] = $searchParam; $statsTypes .= "sss"; } else { $query .= " AND (mr.id LIKE ? OR mr.member_card_no LIKE ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsParams[] = $searchParam; $statsTypes .= "sss"; } } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_orders' => 0, 'total_recharge' => 0, 'total_gift' => 0, 'total_income' => 0, 'payment_methods' => [] ]; } if (!empty($statsParams)) { $stmt->bind_param($statsTypes, ...$statsParams); } if (!$stmt->execute()) { return [ 'total_orders' => 0, 'total_recharge' => 0, 'total_gift' => 0, 'total_income' => 0, 'payment_methods' => [] ]; } $result = $stmt->get_result(); $stats = $result->fetch_assoc(); $paymentMethodsQuery = "
        SELECT 
            pm.id as payment_method_id,
            pm.name as payment_method_name,
            pm.sort_order,
            SUM(mr.recharge_amount) as method_income,
            CONCAT('¥', FORMAT(SUM(mr.recharge_amount), 2)) as income_display
        FROM 
            member_recharges mr
        JOIN 
            payment_methods pm ON mr.payment_method_id = pm.id
        LEFT JOIN 
            member_accounts ma ON mr.member_card_no = ma.member_card_no
        WHERE 
            mr.create_time BETWEEN ? AND ?
            AND pm.id != 2
    "; $pmParams = [$start_date, $end_date]; $pmTypes = "ss"; if (!empty($search)) { if (preg_match('/^1[3-9]\d{9}$/', $search)) { $paymentMethodsQuery .= " AND (mr.id LIKE ? OR mr.member_card_no = ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $pmParams[] = $searchParam; $pmParams[] = $search; $pmParams[] = $searchParam; $pmTypes .= "sss"; } else { $paymentMethodsQuery .= " AND (mr.id LIKE ? OR mr.member_card_no LIKE ? OR ma.name LIKE ?)"; $searchParam = "%$search%"; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmParams[] = $searchParam; $pmTypes .= "sss"; } } $paymentMethodsQuery .= " GROUP BY pm.id, pm.name, pm.sort_order ORDER BY pm.sort_order, pm.id"; $pmStmt = $conn->prepare($paymentMethodsQuery); $paymentMethods = []; if ($pmStmt) { if (!empty($pmParams)) { $pmStmt->bind_param($pmTypes, ...$pmParams); } if ($pmStmt->execute()) { $pmResult = $pmStmt->get_result(); while ($method = $pmResult->fetch_assoc()) { $paymentMethods[] = [ 'id' => (int)$method['payment_method_id'], 'name' => $method['payment_method_name'], 'sort_order' => (int)$method['sort_order'], 'income' => (float)$method['method_income'], 'income_display' => $method['income_display'] ]; } } $pmStmt->close(); } $cardIncome = 0; $otherIncome = 0; foreach ($paymentMethods as $method) { if ($method['id'] == 1) { $cardIncome = $method['income']; } else { $otherIncome += $method['income']; } } return [ 'total_orders' => (int)($stats['total_orders'] ?? 0), 'total_recharge' => (float)($stats['total_recharge'] ?? 0), 'total_gift' => (float)($stats['total_gift'] ?? 0), 'total_income' => (float)($stats['total_income'] ?? 0), 'card_income' => $cardIncome, 'other_income' => $otherIncome, 'payment_methods' => $paymentMethods ]; }