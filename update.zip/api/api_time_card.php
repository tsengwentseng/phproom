<?php
 require_once '../config/config.php'; header('Content-Type: application/json; charset=utf-8'); function handleError($message, $code = 400) { http_response_code($code); echo json_encode(['success' => false, 'message' => $message], JSON_UNESCAPED_UNICODE); exit(); } function handleSuccess($data = [], $message = '操作成功') { echo json_encode(['success' => true, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE); exit(); } $method = $_SERVER['REQUEST_METHOD']; $action = $_GET['action'] ?? ''; try { if ($action === 'get_available_product_time_cards' && $method === 'GET') { $memberCardNo = $_GET['member_card_no'] ?? ''; $productId = intval($_GET['product_id'] ?? 0); if (empty($memberCardNo)) { handleError('会员卡号不能为空'); } if ($productId <= 0) { handleError('商品ID无效'); } $sql = "
            SELECT 
                tcm.sale_order_no,
                tcm.time_card_id,
                tcp.name AS time_card_name,
                tcp.product_ids,
                tcm.total_times,
                tcm.remaining_times,
                tcm.purchase_time,
                tcm.expire_time,
                CASE 
                    WHEN tcm.expire_time IS NULL THEN '永久有效'
                    WHEN tcm.expire_time > NOW() THEN CONCAT('还剩', DATEDIFF(tcm.expire_time, NOW()), '天')
                    ELSE '已过期'
                END AS validity_status,
                CASE 
                    WHEN tcm.expire_time IS NULL THEN 1
                    ELSE 0
                END AS is_permanent
            FROM time_cards_member tcm
            JOIN time_card_products tcp ON tcm.time_card_id = tcp.id
            WHERE tcm.member_card_no = ?
              AND tcp.type = 'product'
              AND tcm.remaining_times > 0
              AND tcm.is_expired = 0
              AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW())
              AND (
                tcp.product_ids IS NULL 
                OR JSON_CONTAINS(tcp.product_ids, ?, '$')
              )
            ORDER BY 
              is_permanent ASC,
              tcm.expire_time ASC,
              tcm.purchase_time ASC
        "; $stmt = $conn->prepare($sql); $productIdJson = json_encode($productId); $stmt->bind_param("ss", $memberCardNo, $productIdJson); $stmt->execute(); $result = $stmt->get_result(); $timeCards = []; while ($row = $result->fetch_assoc()) { $timeCards[] = $row; } handleSuccess($timeCards); } else if ($action === 'get_available_room_time_cards' && $method === 'GET') { $memberCardNo = $_GET['member_card_no'] ?? ''; $roomId = intval($_GET['room_id'] ?? 0); if (empty($memberCardNo)) { handleError('会员卡号不能为空'); } if ($roomId <= 0) { handleError('房间ID无效'); } $sql = "
            SELECT 
                tcm.sale_order_no,
                tcm.time_card_id,
                tcp.name AS time_card_name,
                tcp.room_ids,
                tcm.total_times,
                tcm.remaining_times,
                tcm.snapshot_hours,
                tcm.purchase_time,
                tcm.expire_time,
                CASE 
                    WHEN tcm.expire_time IS NULL THEN '永久有效'
                    WHEN tcm.expire_time > NOW() THEN CONCAT('还剩', DATEDIFF(tcm.expire_time, NOW()), '天')
                    ELSE '已过期'
                END AS validity_status,
                CASE 
                    WHEN tcm.expire_time IS NULL THEN 1
                    ELSE 0
                END AS is_permanent
            FROM time_cards_member tcm
            JOIN time_card_products tcp ON tcm.time_card_id = tcp.id
            WHERE tcm.member_card_no = ?
              AND tcp.type = 'room'
              AND tcm.remaining_times > 0
              AND tcm.is_expired = 0
              AND (tcm.expire_time IS NULL OR tcm.expire_time > NOW())
              AND (
                tcp.room_ids IS NULL 
                OR JSON_CONTAINS(tcp.room_ids, ?, '$')
              )
            ORDER BY 
              is_permanent ASC,
              tcm.expire_time ASC,
              tcm.purchase_time ASC
        "; $stmt = $conn->prepare($sql); $roomIdJson = json_encode($roomId); $stmt->bind_param("ss", $memberCardNo, $roomIdJson); $stmt->execute(); $result = $stmt->get_result(); $timeCards = []; while ($row = $result->fetch_assoc()) { $timeCards[] = $row; } handleSuccess($timeCards); } else { handleError('未知操作', 404); } } catch (Exception $e) { handleError('系统错误：' . $e->getMessage(), 500); } 