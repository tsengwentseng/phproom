<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); $STATS_START_TIME = '09:00:00'; $STATS_END_TIME = '08:59:59'; $SCENE_ROOM_NAME = '房间'; $scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'"); if ($scene_stmt) { $scene_stmt->execute(); $scene_result = $scene_stmt->get_result(); if ($scene_result && $scene_row = $scene_result->fetch_assoc()) { $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间'; } $scene_stmt->close(); } try { $startTimeStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = ?"); $startTimeKey = 'stats_start_time'; $startTimeStmt->bind_param("s", $startTimeKey); $startTimeStmt->execute(); $startTimeResult = $startTimeStmt->get_result(); if ($startTimeResult && $startTimeResult->num_rows > 0) { $STATS_START_TIME = $startTimeResult->fetch_assoc()['config_value']; } $startTimeStmt->close(); $endTimeStmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = ?"); $endTimeKey = 'stats_end_time'; $endTimeStmt->bind_param("s", $endTimeKey); $endTimeStmt->execute(); $endTimeResult = $endTimeStmt->get_result(); if ($endTimeResult && $endTimeResult->num_rows > 0) { $STATS_END_TIME = $endTimeResult->fetch_assoc()['config_value']; } $endTimeStmt->close(); } catch (Exception $e) { } $STATS_HOUR_BOUNDARY = (int)substr($STATS_START_TIME, 0, 2); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } try { $currentTimeStmt = $conn->query("SELECT NOW() as current_time"); if (!$currentTimeStmt) { $currentHour = (int)date('H'); } else { $currentTimeRow = $currentTimeStmt->fetch_assoc(); $currentTime = new DateTime($currentTimeRow['current_time']); $currentHour = (int)$currentTime->format('H'); } } catch (Exception $e) { $currentHour = (int)date('H'); } $isBeforeTimeBoundary = $currentHour < $STATS_HOUR_BOUNDARY; $startDate = $_GET['start'] ?? date('Y-m-d'); $endDate = $_GET['end'] ?? date('Y-m-d'); if ($isBeforeTimeBoundary) { $today = date('Y-m-d'); if ($startDate === $today) { $dateTime = new DateTime($startDate); $dateTime->modify('-1 day'); $startDate = $dateTime->format('Y-m-d'); } if ($endDate === $today) { $dateTime = new DateTime($endDate); $dateTime->modify('-1 day'); $endDate = $dateTime->format('Y-m-d'); } } if (!DateTime::createFromFormat('Y-m-d', $startDate) || !DateTime::createFromFormat('Y-m-d', $endDate)) { http_response_code(400); echo json_encode(['success' => false, 'message' => '日期格式错误']); exit; } $startDateTime = new DateTime($startDate); $endDateTime = new DateTime($endDate); if ($startDateTime > $endDateTime) { $temp = $startDate; $startDate = $endDate; $endDate = $temp; } $startDate = $startDate . ' ' . $STATS_START_TIME; $endDateTime = new DateTime($endDate); $endDateTime->modify('+1 day'); $endDate = $endDateTime->format('Y-m-d') . ' ' . $STATS_END_TIME; $memberCardPaymentId = 1; if (isset($_GET['type'])) { try { $requestType = $_GET['type']; $paymentDetails = []; if ($requestType === $SCENE_ROOM_NAME . '订单_other' || $requestType === 'room_other') { $stmt = $conn->prepare("
                SELECT 
                    pm.id,
                    pm.name,
                    SUM(opd.amount + IFNULL(opd.extra_fee, 0)) as income
                FROM orders o
                JOIN orders_payment_details opd ON o.id = opd.order_id
                JOIN payment_methods pm ON opd.payment_method_id = pm.id
                WHERE opd.payment_time BETWEEN ? AND ?
                    AND o.status IN (0, 1)
                    AND opd.payment_method_id != ?
                GROUP BY pm.id, pm.name
                ORDER BY pm.sort_order, pm.id
            "); $stmt->bind_param("ssi", $startDate, $endDate, $memberCardPaymentId); } else if ($requestType === '商品销售_other' || $requestType === '商品/次卡券销售_other' || $requestType === 'product_timecard_other') { $stmt = $conn->prepare("
                SELECT 
                    pm.id,
                    pm.name,
                    SUM(combined.total_amount) as income
                FROM (
                    SELECT payment_method_id, total_amount
                    FROM product_orders
                    WHERE create_time BETWEEN ? AND ?
                        AND payment_method_id != ?
                    UNION ALL
                    SELECT payment_method_id, total_amount
                    FROM time_card_orders
                    WHERE create_time BETWEEN ? AND ?
                        AND payment_method_id != ?
                ) AS combined
                JOIN payment_methods pm ON combined.payment_method_id = pm.id
                GROUP BY pm.id, pm.name
                ORDER BY pm.sort_order, pm.id
            "); $stmt->bind_param("ssissi", $startDate, $endDate, $memberCardPaymentId, $startDate, $endDate, $memberCardPaymentId); } else if ($requestType === 'recharge') { $stmt = $conn->prepare("
                SELECT 
                    pm.id,
                    pm.name,
                    SUM(mr.recharge_amount) as income
                FROM member_recharges mr
                JOIN payment_methods pm ON mr.payment_method_id = pm.id
                WHERE mr.create_time BETWEEN ? AND ?
                    AND pm.id != 2
                GROUP BY pm.id, pm.name
                ORDER BY pm.sort_order, pm.id
            "); $stmt->bind_param("ss", $startDate, $endDate); } else { throw new Exception("未知的请求类型: " . $requestType); } $stmt->execute(); $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $paymentDetails[] = [ 'id' => (int)$row['id'], 'name' => $row['name'], 'income' => (float)$row['income'] ]; } echo json_encode([ 'success' => true, 'payment_details' => $paymentDetails ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => '获取支付方式详情失败: ' . $e->getMessage() ]); } exit; } try { $response = [ 'success' => true, 'stats' => [ 'room_orders' => [], 'product_orders' => [], 'timecard_orders' => [], 'recharge_orders' => [], 'consumption_orders' => [] ], ]; $order_stmt = $conn->prepare("
        SELECT 
            COUNT(DISTINCT o.id) as total_orders,
            SUM(opd.amount + IFNULL(opd.extra_fee, 0)) as total_income
        FROM orders_payment_details opd
        JOIN orders o ON opd.order_id = o.id
        WHERE opd.payment_time BETWEEN ? AND ?
          AND o.status IN (0, 1)
    "); $order_stmt->bind_param("ss", $startDate, $endDate); $order_stmt->execute(); $result = $order_stmt->get_result(); $order_totals = $result->fetch_assoc(); $payment_stmt = $conn->prepare("
        SELECT 
            SUM(CASE WHEN opd.payment_method_id = ? THEN opd.amount + IFNULL(opd.extra_fee, 0) ELSE 0 END) as member_card_income,
            SUM(CASE WHEN opd.payment_method_id != ? THEN opd.amount + IFNULL(opd.extra_fee, 0) ELSE 0 END) as other_payment_income
        FROM orders_payment_details opd
        JOIN orders o ON opd.order_id = o.id
        WHERE opd.payment_time BETWEEN ? AND ?
          AND o.status IN (0, 1)
    "); $payment_stmt->bind_param("iiss", $memberCardPaymentId, $memberCardPaymentId, $startDate, $endDate); $payment_stmt->execute(); $result = $payment_stmt->get_result(); $payment_stats = $result->fetch_assoc(); $response['stats']['room_orders'] = [ 'total_orders' => (int)($order_totals['total_orders'] ?? 0), 'total_income' => (float)($order_totals['total_income'] ?? 0), 'other_payment_income' => (float)($payment_stats['other_payment_income'] ?? 0), 'member_card_income' => (float)($payment_stats['member_card_income'] ?? 0) ]; $product_order_stmt = $conn->prepare("
        SELECT 
            COUNT(id) as total_orders,
            SUM(total_amount) as total_income
        FROM product_orders
        WHERE create_time BETWEEN ? AND ?
    "); $product_order_stmt->bind_param("ss", $startDate, $endDate); $product_order_stmt->execute(); $result = $product_order_stmt->get_result(); $product_totals = $result->fetch_assoc(); $timecard_order_stmt = $conn->prepare("
        SELECT 
            COUNT(id) as total_orders,
            SUM(total_amount) as total_income
        FROM time_card_orders
        WHERE create_time BETWEEN ? AND ?
    "); $timecard_totals = ['total_orders' => 0, 'total_income' => 0]; if ($timecard_order_stmt) { $timecard_order_stmt->bind_param("ss", $startDate, $endDate); $timecard_order_stmt->execute(); $result = $timecard_order_stmt->get_result(); $timecard_totals = $result->fetch_assoc(); } $combined_total_orders = (int)($product_totals['total_orders'] ?? 0) + (int)($timecard_totals['total_orders'] ?? 0); $combined_total_income = (float)($product_totals['total_income'] ?? 0) + (float)($timecard_totals['total_income'] ?? 0); $product_payment_stmt = $conn->prepare("
        SELECT 
            SUM(CASE WHEN payment_method_id = ? THEN total_amount ELSE 0 END) as member_card_income,
            SUM(CASE WHEN payment_method_id != ? THEN total_amount ELSE 0 END) as other_payment_income
        FROM product_orders
        WHERE create_time BETWEEN ? AND ?
    "); $product_payment_stmt->bind_param("iiss", $memberCardPaymentId, $memberCardPaymentId, $startDate, $endDate); $product_payment_stmt->execute(); $result = $product_payment_stmt->get_result(); $product_payment_stats = $result->fetch_assoc(); $timecard_payment_stmt = $conn->prepare("
        SELECT 
            SUM(CASE WHEN payment_method_id = ? THEN total_amount ELSE 0 END) as member_card_income,
            SUM(CASE WHEN payment_method_id != ? THEN total_amount ELSE 0 END) as other_payment_income
        FROM time_card_orders
        WHERE create_time BETWEEN ? AND ?
    "); $timecard_payment_stats = ['member_card_income' => 0, 'other_payment_income' => 0]; if ($timecard_payment_stmt) { $timecard_payment_stmt->bind_param("iiss", $memberCardPaymentId, $memberCardPaymentId, $startDate, $endDate); $timecard_payment_stmt->execute(); $result = $timecard_payment_stmt->get_result(); $timecard_payment_stats = $result->fetch_assoc(); } $combined_member_card_income = (float)($product_payment_stats['member_card_income'] ?? 0) + (float)($timecard_payment_stats['member_card_income'] ?? 0); $combined_other_payment_income = (float)($product_payment_stats['other_payment_income'] ?? 0) + (float)($timecard_payment_stats['other_payment_income'] ?? 0); $response['stats']['product_orders'] = [ 'total_orders' => $combined_total_orders, 'total_income' => $combined_total_income, 'other_payment_income' => $combined_other_payment_income, 'member_card_income' => $combined_member_card_income ]; $recharge_stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(recharge_amount) as recharge_amount,
            SUM(gift_amount) as gift_amount,
            SUM(recharge_amount + gift_amount) as total_amount
        FROM member_recharges
        WHERE create_time BETWEEN ? AND ?
    "); $recharge_stmt->bind_param("ss", $startDate, $endDate); $recharge_stmt->execute(); $result = $recharge_stmt->get_result(); $recharge_stats = $result->fetch_assoc(); $response['stats']['recharge_orders'] = [ 'total_orders' => (int)($recharge_stats['total_orders'] ?? 0), 'recharge_amount' => (float)($recharge_stats['recharge_amount'] ?? 0), 'gift_amount' => (float)($recharge_stats['gift_amount'] ?? 0), 'total_amount' => (float)($recharge_stats['total_amount'] ?? 0) ]; $consumption_stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_orders,
            SUM(amount) as total_amount,
            SUM(CASE 
                WHEN product_id IS NULL AND time_card_id IS NULL THEN amount
                ELSE 0 
            END) as room_amount,
            SUM(CASE 
                WHEN product_id IS NOT NULL OR time_card_id IS NOT NULL THEN amount
                ELSE 0 
            END) as product_amount
        FROM member_consumptions
        WHERE create_time BETWEEN ? AND ?
    "); $consumption_stmt->bind_param("ss", $startDate, $endDate); $consumption_stmt->execute(); $result = $consumption_stmt->get_result(); $consumption_stats = $result->fetch_assoc(); $response['stats']['consumption_orders'] = [ 'total_orders' => (int)($consumption_stats['total_orders'] ?? 0), 'total_amount' => (float)($consumption_stats['total_amount'] ?? 0), 'room_amount' => (float)($consumption_stats['room_amount'] ?? 0), 'product_amount' => (float)($consumption_stats['product_amount'] ?? 0) ]; $response['date_range'] = [ 'start' => $startDate, 'end' => $endDate ]; echo json_encode($response); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => '查询失败: ' . $e->getMessage() ]); } ?>