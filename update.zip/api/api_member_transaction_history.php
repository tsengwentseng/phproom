<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $SCENE_ROOM_NAME = '房间'; $scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'"); if ($scene_stmt) { $scene_stmt->execute(); $scene_result = $scene_stmt->get_result(); if ($scene_result && $scene_row = $scene_result->fetch_assoc()) { $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间'; } $scene_stmt->close(); } $SCENE_ROOM_NAME_ESC = "'" . $conn->real_escape_string($SCENE_ROOM_NAME) . "'"; $member_card_no = trim($_GET['member_card_no'] ?? ''); $start_date = $_GET['start_date'] ?? ''; $end_date = $_GET['end_date'] ?? ''; $record_type = $_GET['record_type'] ?? 'all'; if (empty($member_card_no)) { http_response_code(400); echo json_encode(['success' => false, 'message' => '请输入会员卡号']); exit; } try { $member_query = "SELECT member_card_no, name, balance, is_enabled FROM member_accounts WHERE member_card_no = ?"; $stmt = $conn->prepare($member_query); $stmt->bind_param("s", $member_card_no); $stmt->execute(); $member_result = $stmt->get_result(); if ($member_result->num_rows === 0) { http_response_code(404); echo json_encode(['success' => false, 'message' => '会员卡号不存在']); exit; } $member = $member_result->fetch_assoc(); $date_condition_recharge = ""; $date_condition_consumption = ""; $rechargeDateParams = []; $consumptionDateParams = []; if (!empty($start_date)) { $date_condition_recharge .= " AND mr.create_time >= ?"; $date_condition_consumption .= " AND mc.create_time >= ?"; $rechargeDateParams[] = $start_date . ' 00:00:00'; $consumptionDateParams[] = $start_date . ' 00:00:00'; } if (!empty($end_date)) { $date_condition_recharge .= " AND mr.create_time <= ?"; $date_condition_consumption .= " AND mc.create_time <= ?"; $rechargeDateParams[] = $end_date . ' 23:59:59'; $consumptionDateParams[] = $end_date . ' 23:59:59'; } $query = ""; if ($record_type === 'all' || $record_type === 'recharge') { $query .= "
        SELECT 
            CASE 
                WHEN mr.recharge_amount = 0 AND (mr.request_code IS NULL OR mr.request_code = '') AND mr.gift_amount != 0 THEN '卡内转账'
                WHEN (mr.recharge_amount + mr.gift_amount) > 0 THEN '充值'
                WHEN (mr.recharge_amount + mr.gift_amount) < 0 THEN '充值退款'
                ELSE '其他'
            END as record_type,
            mr.id as record_id,
            mr.id as order_id,
            NULL as batch_id,
            (mr.recharge_amount + mr.gift_amount) as amount,
            mr.recharge_amount,
            mr.gift_amount,
            mr.final_balance as balance_after,
            pm.name as payment_method,
            NULL as location,
            mr.create_time,
            su.name as operator_name,
            CONCAT(
                CASE 
                    WHEN mr.recharge_amount = 0 AND (mr.request_code IS NULL OR mr.request_code = '') AND mr.gift_amount != 0 THEN 
                        CONCAT(
                            '卡内转账 ',
                            CASE 
                                WHEN mr.gift_amount > 0 THEN 
                                    CONCAT('转入 ¥', FORMAT(mr.gift_amount, 2), 
                                           COALESCE((SELECT CONCAT(' [来自 ', mr2.member_card_no, ']') 
                                                     FROM member_recharges mr2 
                                                     WHERE mr2.recharge_amount = 0 
                                                     AND mr2.request_code IS NULL
                                                     AND mr2.gift_amount = -mr.gift_amount
                                                     AND mr2.member_card_no != mr.member_card_no
                                                     AND mr2.payment_method_id = 2
                                                     AND ABS(TIMESTAMPDIFF(SECOND, mr2.create_time, mr.create_time)) <= 2
                                                     ORDER BY ABS(TIMESTAMPDIFF(SECOND, mr2.create_time, mr.create_time)) ASC
                                                     LIMIT 1), ''))
                                WHEN mr.gift_amount < 0 THEN 
                                    CONCAT('转出 ¥', FORMAT(ABS(mr.gift_amount), 2),
                                           COALESCE((SELECT CONCAT(' [转至 ', mr2.member_card_no, ']') 
                                                     FROM member_recharges mr2 
                                                     WHERE mr2.recharge_amount = 0 
                                                     AND mr2.request_code IS NULL
                                                     AND mr2.gift_amount = -mr.gift_amount
                                                     AND mr2.member_card_no != mr.member_card_no
                                                     AND mr2.payment_method_id = 2
                                                     AND ABS(TIMESTAMPDIFF(SECOND, mr2.create_time, mr.create_time)) <= 2
                                                     ORDER BY ABS(TIMESTAMPDIFF(SECOND, mr2.create_time, mr.create_time)) ASC
                                                     LIMIT 1), ''))
                            END
                        )
                    WHEN (mr.recharge_amount + mr.gift_amount) > 0 THEN 
                        CONCAT('充值 ',
                            CASE 
                                -- 只有充值金额
                                WHEN mr.recharge_amount != 0 AND mr.gift_amount = 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.recharge_amount), 2), ' [', pm.name, ']')
                                -- 只有赠送金额
                                WHEN mr.recharge_amount = 0 AND mr.gift_amount != 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.gift_amount), 2), ' [', pm.name, ']')
                                -- 充值+赠送
                                WHEN mr.recharge_amount != 0 AND mr.gift_amount != 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.recharge_amount), 2), ' [', pm.name, ']',
                                           CASE 
                                               WHEN mr.gift_amount > 0 THEN CONCAT(' + 赠送¥', FORMAT(mr.gift_amount, 2))
                                               WHEN mr.gift_amount < 0 THEN CONCAT(' - 赠送¥', FORMAT(ABS(mr.gift_amount), 2))
                                           END)
                                ELSE CONCAT('¥0.00 [', pm.name, ']')
                            END
                        )
                    WHEN (mr.recharge_amount + mr.gift_amount) < 0 THEN 
                        CONCAT('充值退款 -',
                            CASE 
                                -- 只有充值金额
                                WHEN mr.recharge_amount != 0 AND mr.gift_amount = 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.recharge_amount), 2), ' [', pm.name, ']')
                                -- 只有赠送金额
                                WHEN mr.recharge_amount = 0 AND mr.gift_amount != 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.gift_amount), 2), ' [', pm.name, ']')
                                -- 充值+赠送
                                WHEN mr.recharge_amount != 0 AND mr.gift_amount != 0 THEN 
                                    CONCAT('¥', FORMAT(ABS(mr.recharge_amount), 2), ' [', pm.name, ']',
                                           CASE 
                                               WHEN mr.gift_amount > 0 THEN CONCAT(' + 赠送¥', FORMAT(mr.gift_amount, 2))
                                               WHEN mr.gift_amount < 0 THEN CONCAT(' - 赠送¥', FORMAT(ABS(mr.gift_amount), 2))
                                           END)
                                ELSE CONCAT('¥0.00 [', pm.name, ']')
                            END
                        )
                    ELSE '其他 '
                END
            ) as description
        FROM member_recharges mr
        LEFT JOIN payment_methods pm ON mr.payment_method_id = pm.id
        LEFT JOIN system_users su ON mr.operator_id = su.id
        WHERE mr.member_card_no = ?
        $date_condition_recharge
        "; } if ($record_type === 'all' || $record_type === 'consumption') { if (!empty($query)) { $query .= " UNION ALL "; } $query .= "
        SELECT 
                CASE 
                    WHEN mc.order_id LIKE '%-R' THEN 
                        CASE 
                            WHEN mc.time_card_id IS NOT NULL THEN '次卡券退单'
                            WHEN mc.product_id IS NOT NULL THEN '商品退单'
                            WHEN mc.room_id IS NOT NULL THEN CONCAT({$SCENE_ROOM_NAME_ESC}, '退单')
                            ELSE '退单'
                        END
                    ELSE 
                        CASE 
                            WHEN mc.time_card_id IS NOT NULL THEN '次卡券消费'
                            WHEN mc.product_id IS NOT NULL THEN '商品消费'
                            WHEN mc.room_id IS NOT NULL THEN CONCAT({$SCENE_ROOM_NAME_ESC}, '消费')
                            ELSE '消费'
                        END
                END as record_type,
            mc.id as record_id,
            mc.order_id,
            mc.batch_id,
            -mc.amount as amount,
            0 as recharge_amount,
            0 as gift_amount,
            mc.final_balance as balance_after,
            '会员卡' as payment_method,
            CASE
                -- 退款情况：根据订单类型查找对应的房间、商品或次卡券名称
                WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'RM%' THEN 
                    (SELECT r2.name FROM orders o2 JOIN rooms r2 ON o2.room_id = r2.id 
                     WHERE o2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'PD%' THEN
                    (SELECT p2.name FROM product_orders po2 JOIN products p2 ON po2.product_id = p2.id 
                     WHERE po2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                WHEN mc.time_card_id IS NOT NULL THEN tcp.name
                -- 正常消费
                WHEN mc.product_id IS NOT NULL THEN p.name
                WHEN mc.room_id IS NOT NULL THEN r.name
                ELSE NULL
            END as location,
            mc.create_time,
            su.name as operator_name,
            CONCAT(
                CASE 
                    WHEN mc.order_id LIKE '%-R' THEN '退单 +'
                    ELSE '消费 -'
                END,
                '¥', FORMAT(ABS(mc.amount), 2),
                ' [',
                CASE
                    -- 退款情况
                    WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'RM%' THEN 
                        (SELECT r2.name FROM orders o2 JOIN rooms r2 ON o2.room_id = r2.id 
                         WHERE o2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                    WHEN mc.order_id LIKE '%-R' AND mc.order_id LIKE 'PD%' THEN
                        (SELECT p2.name FROM product_orders po2 JOIN products p2 ON po2.product_id = p2.id 
                         WHERE po2.id = REPLACE(mc.order_id, '-R', '') LIMIT 1)
                    -- 次卡券（正常和退款都用字段）
                    WHEN mc.time_card_id IS NOT NULL THEN tcp.name
                    -- 其次显示商品名称
                    WHEN mc.product_id IS NOT NULL THEN p.name
                    WHEN mc.room_id IS NOT NULL THEN 
                        CONCAT(
                            r.name,
                            -- 查询房间消费类型（开台/加时/结账）
                            COALESCE(
                                (SELECT 
                                    CASE 
                                        WHEN opd.payment_type = 0 THEN '-开台'
                                        WHEN opd.payment_type = 1 THEN '-加时'
                                        WHEN opd.payment_type = 2 THEN '-结账'
                                        ELSE ''
                                    END
                                FROM orders_payment_details opd
                                WHERE opd.order_id = mc.order_id 
                                AND opd.member_card_no = mc.member_card_no
                                AND ABS(TIMESTAMPDIFF(SECOND, opd.create_time, mc.create_time)) <= 2
                                ORDER BY opd.create_time DESC
                                LIMIT 1
                                ), ''
                            )
                        )
                    ELSE '未知'
                END,
                ']'
            ) as description
        FROM member_consumptions mc
        LEFT JOIN rooms r ON mc.room_id = r.id
        LEFT JOIN products p ON mc.product_id = p.id
        LEFT JOIN time_card_products tcp ON mc.time_card_id = tcp.id
        LEFT JOIN system_users su ON mc.operator_id = su.id
        WHERE mc.member_card_no = ?
        $date_condition_consumption
        "; } $query .= " ORDER BY create_time DESC, record_id DESC"; $stmt = $conn->prepare($query); $bindParams = []; if ($record_type === 'all') { $bindParams[] = $member_card_no; $bindParams = array_merge($bindParams, $rechargeDateParams); $bindParams[] = $member_card_no; $bindParams = array_merge($bindParams, $consumptionDateParams); } elseif ($record_type === 'recharge') { $bindParams[] = $member_card_no; $bindParams = array_merge($bindParams, $rechargeDateParams); } else { $bindParams[] = $member_card_no; $bindParams = array_merge($bindParams, $consumptionDateParams); } $bindTypes = str_repeat('s', count($bindParams)); $stmt->bind_param($bindTypes, ...$bindParams); $stmt->execute(); $result = $stmt->get_result(); $transactions = []; while ($row = $result->fetch_assoc()) { $transactions[] = [ 'record_type' => $row['record_type'], 'record_id' => $row['record_id'], 'order_id' => $row['order_id'], 'batch_id' => $row['batch_id'], 'amount' => (float)$row['amount'], 'recharge_amount' => (float)$row['recharge_amount'], 'gift_amount' => (float)$row['gift_amount'], 'balance_after' => (float)$row['balance_after'], 'payment_method' => $row['payment_method'], 'location' => $row['location'], 'create_time' => $row['create_time'], 'description' => $row['description'], 'operator_name' => $row['operator_name'] ]; } $stats = calculateStats($conn, $member_card_no, $start_date, $end_date); echo json_encode([ 'success' => true, 'member' => [ 'member_card_no' => $member['member_card_no'], 'name' => $member['name'], 'balance' => (float)$member['balance'] ], 'data' => $transactions, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => '查询失败: ' . $e->getMessage() ]); } function calculateStats(mysqli $conn, string $member_card_no, string $start_date, string $end_date): array { $date_condition_recharge = ""; $date_condition_consumption = ""; $rechargeDateParams = []; $rechargeDateTypes = ""; $consumptionDateParams = []; $consumptionDateTypes = ""; if (!empty($start_date)) { $date_condition_recharge .= " AND mr.create_time >= ?"; $date_condition_consumption .= " AND mc.create_time >= ?"; $rechargeDateParams[] = $start_date . ' 00:00:00'; $rechargeDateTypes .= "s"; $consumptionDateParams[] = $start_date . ' 00:00:00'; $consumptionDateTypes .= "s"; } if (!empty($end_date)) { $date_condition_recharge .= " AND mr.create_time <= ?"; $date_condition_consumption .= " AND mc.create_time <= ?"; $rechargeDateParams[] = $end_date . ' 23:59:59'; $rechargeDateTypes .= "s"; $consumptionDateParams[] = $end_date . ' 23:59:59'; $consumptionDateTypes .= "s"; } $recharge_query = "
        SELECT 
            IFNULL(SUM(mr.recharge_amount + mr.gift_amount), 0) as total_recharge,
            IFNULL(SUM(mr.recharge_amount), 0) as total_recharge_only,
            IFNULL(SUM(mr.gift_amount), 0) as total_gift,
            COUNT(*) as recharge_count
        FROM member_recharges mr
        WHERE mr.member_card_no = ?
        $date_condition_recharge
    "; $stmt = $conn->prepare($recharge_query); $stmt->bind_param("s" . $rechargeDateTypes, $member_card_no, ...$rechargeDateParams); $stmt->execute(); $recharge_result = $stmt->get_result()->fetch_assoc(); $consumption_query = "
        SELECT 
            IFNULL(SUM(mc.amount), 0) as total_consumption,
            COUNT(*) as consumption_count
        FROM member_consumptions mc
        WHERE mc.member_card_no = ?
        $date_condition_consumption
    "; $stmt = $conn->prepare($consumption_query); $stmt->bind_param("s" . $consumptionDateTypes, $member_card_no, ...$consumptionDateParams); $stmt->execute(); $consumption_result = $stmt->get_result()->fetch_assoc(); return [ 'total_recharge' => (float)$recharge_result['total_recharge'], 'total_recharge_only' => (float)$recharge_result['total_recharge_only'], 'total_gift' => (float)$recharge_result['total_gift'], 'total_consumption' => (float)$consumption_result['total_consumption'], 'total_refund' => 0, 'recharge_count' => (int)$recharge_result['recharge_count'], 'consumption_count' => (int)$consumption_result['consumption_count'], 'refund_count' => 0 ]; } 