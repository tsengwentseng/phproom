<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); session_start(); if (!isset($_SESSION['loggedin'])) { http_response_code(401); echo json_encode(['success' => false, 'message' => '请先登录']); exit; } $defaultStartDate = new DateTime(); $defaultStartDate->modify('-7 days'); $start_date = $_GET['start_date'] ?? $defaultStartDate->format('Y-m-d'); $end_date = $_GET['end_date'] ?? date('Y-m-d'); $search = trim($_GET['search'] ?? ''); $status = $_GET['status'] ?? 'all'; $end_date = $end_date . ' 23:59:59'; try { $query = "
        SELECT 
            po.id,
            po.batch_id,
            po.product_id,
            po.quantity,
            po.unit_price,
            po.total_amount,
            po.payment_method_id,
            po.member_card_no,
            po.notes,
            po.status,
            po.is_refunded,
            po.create_time,
            po.update_time,
            po.origin_client,
            po.request_code,
            po.time_card_data,
            p.name as product_name,
            pm.name as payment_method_name,
            CASE 
                WHEN po.is_refunded = 0 THEN '正常'
                WHEN po.is_refunded = 1 THEN '已退款'
                ELSE '未知'
            END as status_display,
            DATE_FORMAT(po.create_time, '%Y-%m-%d %H:%i:%s') as create_time_display,
            DATE_FORMAT(po.update_time, '%Y-%m-%d %H:%i:%s') as update_time_display,
            CONCAT('¥', FORMAT(po.unit_price, 2)) as unit_price_display,
            CONCAT('¥', FORMAT(po.total_amount, 2)) as total_amount_display,
            su.name as operator_name
        FROM product_orders po
        JOIN products p ON po.product_id = p.id
        JOIN payment_methods pm ON po.payment_method_id = pm.id
        LEFT JOIN system_users su ON po.operator_id = su.id
        WHERE po.create_time >= ? AND po.create_time <= ?
    "; $params = [$start_date, $end_date]; $types = "ss"; if ($status !== 'all') { $query .= " AND po.is_refunded = ?"; $params[] = $status; $types .= "i"; } if (!empty($search)) { $query .= " AND (po.id LIKE ? OR p.name LIKE ? OR po.batch_id LIKE ?)"; $searchParam = "%$search%"; $params[] = $searchParam; $params[] = $searchParam; $params[] = $searchParam; $types .= "sss"; } $query .= " ORDER BY po.create_time DESC, po.id DESC"; $stmt = $conn->prepare($query); if (!$stmt) { throw new Exception("查询准备失败: " . $conn->error); } if (!empty($params)) { $stmt->bind_param($types, ...$params); } if (!$stmt->execute()) { throw new Exception("查询执行失败: " . $stmt->error); } $result = $stmt->get_result(); $orders = []; while ($row = $result->fetch_assoc()) { $timeCardDisplay = ''; if (!empty($row['time_card_data'])) { $timeCardData = json_decode($row['time_card_data'], true); if ($timeCardData && is_array($timeCardData) && !empty($timeCardData)) { $timeCardNames = []; foreach ($timeCardData as $card) { if (isset($card['id']) && isset($card['quantity'])) { $tcStmt = $conn->prepare("SELECT name FROM time_card_products WHERE id = ?"); if ($tcStmt) { $tcStmt->bind_param("i", $card['id']); $tcStmt->execute(); $tcResult = $tcStmt->get_result(); if ($tcRow = $tcResult->fetch_assoc()) { $timeCardNames[] = $tcRow['name'] . '×' . $card['quantity'] . '次'; } else { $timeCardNames[] = '次卡券#' . $card['id'] . '×' . $card['quantity'] . '次'; } $tcStmt->close(); } } } $timeCardDisplay = implode("<br>", $timeCardNames); } } $orders[] = [ 'id' => $row['id'], 'batch_id' => $row['batch_id'], 'product_id' => (int)$row['product_id'], 'quantity' => (int)$row['quantity'], 'unit_price' => (float)$row['unit_price'], 'total_amount' => (float)$row['total_amount'], 'payment_method_id' => (int)$row['payment_method_id'], 'member_card_no' => $row['member_card_no'], 'notes' => $row['notes'], 'status' => (int)$row['status'], 'is_refunded' => (int)$row['is_refunded'], 'create_time' => $row['create_time'], 'update_time' => $row['update_time'], 'origin_client' => $row['origin_client'], 'request_code' => $row['request_code'], 'product_name' => $row['product_name'], 'payment_method_name' => $row['payment_method_name'], 'time_card_display' => $timeCardDisplay, 'status_display' => $row['status_display'], 'create_time_display' => $row['create_time_display'], 'update_time_display' => $row['update_time_display'], 'unit_price_display' => $row['unit_price_display'], 'total_amount_display' => $row['total_amount_display'], 'operator_name' => $row['operator_name'] ]; } $stats = calculateStats($conn, $params, $types, $start_date, $end_date, $search, $status); echo json_encode([ 'success' => true, 'data' => $orders, 'stats' => $stats ]); } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function calculateStats($conn, $params, $types, $start_date, $end_date, $search, $status) { $query = "
        SELECT 
            COUNT(*) as total_orders,
            SUM(CASE WHEN po.is_refunded = 0 THEN po.total_amount ELSE 0 END) as total_income,
            CONCAT('¥', FORMAT(SUM(CASE WHEN po.is_refunded = 0 THEN po.total_amount ELSE 0 END), 2)) as total_income_display
        FROM product_orders po
        JOIN products p ON po.product_id = p.id
        JOIN payment_methods pm ON po.payment_method_id = pm.id
        WHERE po.create_time >= ? AND po.create_time <= ?
    "; $stats_params = [$start_date, $end_date]; $stats_types = "ss"; if ($status !== 'all') { $query .= " AND po.is_refunded = ?"; $stats_params[] = $status; $stats_types .= "i"; } if (!empty($search)) { $query .= " AND (po.id LIKE ? OR p.name LIKE ? OR po.batch_id LIKE ?)"; $searchParam = "%$search%"; $stats_params[] = $searchParam; $stats_params[] = $searchParam; $stats_params[] = $searchParam; $stats_types .= "sss"; } $stmt = $conn->prepare($query); if (!$stmt) { return [ 'total_orders' => 0, 'total_income' => 0, 'card_income' => 0, 'cash_income' => 0, 'payment_methods' => [] ]; } if (!empty($stats_params)) { $stmt->bind_param($stats_types, ...$stats_params); } if (!$stmt->execute()) { return [ 'total_orders' => 0, 'total_income' => 0, 'card_income' => 0, 'cash_income' => 0, 'payment_methods' => [] ]; } $result = $stmt->get_result(); $row = $result->fetch_assoc(); $payment_query = "
        SELECT 
            pm.id as payment_method_id,
            pm.name as payment_method_name,
            pm.sort_order,
            COUNT(*) as order_count,
            SUM(CASE WHEN po.is_refunded = 0 THEN po.total_amount ELSE 0 END) as total_amount,
            CONCAT('¥', FORMAT(SUM(CASE WHEN po.is_refunded = 0 THEN po.total_amount ELSE 0 END), 2)) as income_display
        FROM product_orders po
        JOIN products p ON po.product_id = p.id
        JOIN payment_methods pm ON po.payment_method_id = pm.id
        WHERE po.create_time >= ? AND po.create_time <= ?
    "; $payment_params = [$start_date, $end_date]; $payment_types = "ss"; if ($status !== 'all') { $payment_query .= " AND po.is_refunded = ?"; $payment_params[] = $status; $payment_types .= "i"; } if (!empty($search)) { $payment_query .= " AND (po.id LIKE ? OR p.name LIKE ? OR po.batch_id LIKE ?)"; $searchParam = "%$search%"; $payment_params[] = $searchParam; $payment_params[] = $searchParam; $payment_params[] = $searchParam; $payment_types .= "sss"; } $payment_query .= " GROUP BY pm.id, pm.name, pm.sort_order ORDER BY pm.sort_order, pm.id"; $payment_stmt = $conn->prepare($payment_query); $payment_methods = []; if ($payment_stmt) { if (!empty($payment_params)) { $payment_stmt->bind_param($payment_types, ...$payment_params); } if ($payment_stmt->execute()) { $payment_result = $payment_stmt->get_result(); while ($payment_row = $payment_result->fetch_assoc()) { $payment_methods[] = [ 'id' => (int)$payment_row['payment_method_id'], 'name' => $payment_row['payment_method_name'], 'sort_order' => (int)$payment_row['sort_order'], 'order_count' => (int)$payment_row['order_count'], 'income' => (float)$payment_row['total_amount'], 'income_display' => $payment_row['income_display'] ]; } } } $cardIncome = 0; $otherIncome = 0; foreach ($payment_methods as $method) { if ($method['id'] == 1) { $cardIncome = $method['income']; } else { $otherIncome += $method['income']; } } return [ 'total_orders' => (int)$row['total_orders'], 'total_income' => (float)$row['total_income'], 'total_income_display' => $row['total_income_display'], 'card_income' => $cardIncome, 'other_income' => $otherIncome, 'payment_methods' => $payment_methods ]; }