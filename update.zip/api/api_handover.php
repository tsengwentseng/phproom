<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); $config_path = __DIR__ . '/../config/config.php'; if (!file_exists($config_path)) { http_response_code(500); echo json_encode(['success' => false, 'message' => '配置文件不存在']); exit; } include($config_path); $SCENE_ROOM_NAME = '房间'; $scene_stmt = $conn->prepare("SELECT config_value FROM system_config WHERE config_key = 'scene_room_name'"); if ($scene_stmt) { $scene_stmt->execute(); $scene_result = $scene_stmt->get_result(); if ($scene_result && $scene_row = $scene_result->fetch_assoc()) { $SCENE_ROOM_NAME = $scene_row['config_value'] ?: '房间'; } $scene_stmt->close(); } if (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest') { header('Content-Type: application/json; charset=utf-8'); if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['keys'])) { $keys = explode(',', $_GET['keys']); $response = ['success' => true, 'data' => []]; $validKeys = array_filter($keys, function($key) { $key = trim($key); return !empty($key) && preg_match('/^[a-zA-Z0-9_]+$/', $key); }); if (!empty($validKeys)) { $placeholders = implode(',', array_fill(0, count($validKeys), '?')); $stmt = $conn->prepare("SELECT config_key, config_value FROM system_config WHERE config_key IN ($placeholders)"); if ($stmt) { $types = str_repeat('s', count($validKeys)); $stmt->bind_param($types, ...array_values($validKeys)); $stmt->execute(); $result = $stmt->get_result(); if ($result && $result->num_rows > 0) { while ($row = $result->fetch_assoc()) { $response['data'][$row['config_key']] = $row['config_value']; } } $stmt->close(); } } echo json_encode($response); exit; } } $method = $_SERVER['REQUEST_METHOD']; $action = ''; if ($method === 'GET') { $action = $_GET['action'] ?? ''; } else if ($method === 'POST') { $input = json_decode(file_get_contents('php://input'), true); $action = $input['action'] ?? ''; } session_start(); $isAdmin = false; if (isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'admin') { $isAdmin = true; } if (!$isAdmin && isset($_SESSION['front_role']) && $_SESSION['front_role'] === 'admin') { $isAdmin = true; } if (!$isAdmin) { http_response_code(403); echo json_encode(['success' => false, 'message' => '需要管理员权限']); exit; } try { switch ($action) { case 'get_operators': getOperators($conn); break; case 'get_payment_methods': getPaymentMethods($conn); break; case 'get_promotions': getPromotions($conn); break; case 'get_shift_data': getShiftData($conn); break; case 'complete_handover': completeHandover($conn); break; case 'get_history': getHandoverHistory($conn); break; default: throw new Exception('无效的操作'); } } catch (Exception $e) { http_response_code(500); echo json_encode([ 'success' => false, 'message' => $e->getMessage() ]); } function getOperators($conn) { $startTime = $_GET['start_time'] ?? ''; $endTime = $_GET['end_time'] ?? ''; if (empty($startTime) || empty($endTime)) { throw new Exception('时间区间无效'); } $query = "
        SELECT DISTINCT u.id, u.username, u.name, u.is_enabled
        FROM system_users u
        WHERE (
            EXISTS (
                SELECT 1 FROM orders_payment_details opd
                WHERE opd.operator_id = u.id
                AND opd.payment_time >= ?
                AND opd.payment_time <= ?
                AND opd.payment_method_id NOT IN (1, 88, 89, 2)
            )
            OR EXISTS (
                SELECT 1 FROM product_orders po
                WHERE po.operator_id = u.id
                AND po.create_time >= ?
                AND po.create_time <= ?
                AND po.is_refunded = 0
                AND po.payment_method_id NOT IN (1, 88, 89, 2)
            )
            OR EXISTS (
                SELECT 1 FROM member_recharges mr
                WHERE mr.operator_id = u.id
                AND mr.create_time >= ?
                AND mr.create_time <= ?
                AND mr.payment_method_id NOT IN (1, 88, 89, 2)
            )
        )
        ORDER BY u.is_enabled DESC, u.id
    "; $stmt = $conn->prepare($query); $stmt->bind_param('ssssss', $startTime, $endTime, $startTime, $endTime, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); $operators = []; while ($row = $result->fetch_assoc()) { $operators[] = $row; } echo json_encode([ 'success' => true, 'data' => $operators ]); } function getPaymentMethods($conn) { $query = "SELECT id, name FROM payment_methods WHERE is_deleted = 0 AND id NOT IN (1, 88, 89, 2) ORDER BY sort_order, id"; $result = $conn->query($query); $methods = []; while ($row = $result->fetch_assoc()) { $methods[$row['id']] = $row['name']; } echo json_encode([ 'success' => true, 'data' => $methods ]); } function getPromotions($conn) { $query = "SELECT id, name FROM promotion_strategies WHERE is_deleted = 0 ORDER BY sort_order, id"; $result = $conn->query($query); $promotions = []; while ($row = $result->fetch_assoc()) { $promotions[$row['id']] = $row['name']; } echo json_encode([ 'success' => true, 'data' => $promotions ]); } function getShiftData($conn) { $operatorId = intval($_GET['operator_id'] ?? 0); $startTime = $_GET['start_time'] ?? ''; $endTime = $_GET['end_time'] ?? ''; if ($operatorId <= 0) { throw new Exception('操作员ID无效'); } if (empty($startTime) || empty($endTime)) { throw new Exception('时间区间无效'); } $userQuery = "SELECT name FROM system_users WHERE id = ?"; $stmt = $conn->prepare($userQuery); $stmt->bind_param('i', $operatorId); $stmt->execute(); $result = $stmt->get_result(); $user = $result->fetch_assoc(); if (!$user) { throw new Exception('操作员不存在'); } $handoverQuery = "
        SELECT start_time, end_time
        FROM shift_handovers
        WHERE operator_id = ?
        AND NOT (end_time <= ? OR start_time >= ?)
        ORDER BY start_time
    "; $stmt = $conn->prepare($handoverQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); $excludedRanges = []; while ($row = $result->fetch_assoc()) { $excludedRanges[] = [ 'start' => $row['start_time'], 'end' => $row['end_time'] ]; } $paymentMethodsQuery = "SELECT id, name FROM payment_methods WHERE is_deleted = 0 AND id NOT IN (1, 88, 89, 2) ORDER BY sort_order, id"; $result = $conn->query($paymentMethodsQuery); $paymentMethods = []; while ($row = $result->fetch_assoc()) { $paymentMethods[$row['id']] = $row['name']; } $modules = getShiftModulesDataWithExclusion($conn, $operatorId, $startTime, $endTime, $excludedRanges); $actualTimeRange = getActualOrderTimeRange($conn, $operatorId, $startTime, $endTime, $excludedRanges); $hasData = false; foreach ($modules as $module) { if (!empty($module['stats'])) { $hasData = true; break; } } if (!$hasData) { $message = '该时间区间内没有 ' . $user['name'] . ' 的订单记录'; if (count($excludedRanges) > 0) { $message .= '（已排除 ' . count($excludedRanges) . ' 个已交接的时间段）'; } echo json_encode([ 'success' => false, 'message' => $message ]); return; } $filteredModules = []; foreach ($modules as $key => $module) { if (!empty($module['stats'])) { $filteredModules[$key] = $module; } } echo json_encode([ 'success' => true, 'data' => [ 'operator_name' => $user['name'], 'start_time' => $actualTimeRange['min_time'], 'end_time' => $actualTimeRange['max_time'], 'payment_methods' => $paymentMethods, 'modules' => $filteredModules, 'excluded_count' => count($excludedRanges) ] ]); } function getActualOrderTimeRange($conn, $operatorId, $startTime, $endTime, $excludedRanges) { $exclusionCondition = ''; if (count($excludedRanges) > 0) { $exclusions = []; foreach ($excludedRanges as $range) { $exclusions[] = "NOT (payment_time >= '" . $conn->real_escape_string($range['start']) . "' AND payment_time <= '" . $conn->real_escape_string($range['end']) . "')"; } $exclusionCondition = ' AND (' . implode(' AND ', $exclusions) . ')'; } $exclusionConditionForCreate = ''; if (count($excludedRanges) > 0) { $exclusions = []; foreach ($excludedRanges as $range) { $exclusions[] = "NOT (create_time >= '" . $conn->real_escape_string($range['start']) . "' AND create_time <= '" . $conn->real_escape_string($range['end']) . "')"; } $exclusionConditionForCreate = ' AND (' . implode(' AND ', $exclusions) . ')'; } $minTime = null; $maxTime = null; $roomQuery = "
        SELECT MIN(payment_time) as min_time, MAX(payment_time) as max_time
        FROM orders_payment_details
        WHERE operator_id = ?
        AND payment_time >= ?
        AND payment_time <= ?
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionCondition
    "; $stmt = $conn->prepare($roomQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); if ($row['min_time']) { $minTime = $row['min_time']; $maxTime = $row['max_time']; } $productQuery = "
        SELECT MIN(create_time) as min_time, MAX(create_time) as max_time
        FROM product_orders
        WHERE operator_id = ?
        AND create_time >= ?
        AND create_time <= ?
        AND is_refunded = 0
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionConditionForCreate
    "; $stmt = $conn->prepare($productQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); if ($row['min_time']) { if ($minTime === null || $row['min_time'] < $minTime) { $minTime = $row['min_time']; } if ($maxTime === null || $row['max_time'] > $maxTime) { $maxTime = $row['max_time']; } } $memberQuery = "
        SELECT MIN(create_time) as min_time, MAX(create_time) as max_time
        FROM member_recharges
        WHERE operator_id = ?
        AND create_time >= ?
        AND create_time <= ?
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionConditionForCreate
    "; $stmt = $conn->prepare($memberQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); $row = $result->fetch_assoc(); if ($row['min_time']) { if ($minTime === null || $row['min_time'] < $minTime) { $minTime = $row['min_time']; } if ($maxTime === null || $row['max_time'] > $maxTime) { $maxTime = $row['max_time']; } } return [ 'min_time' => $minTime ?? $startTime, 'max_time' => $maxTime ?? $endTime ]; } function getShiftModulesDataWithExclusion($conn, $operatorId, $startTime, $endTime, $excludedRanges) { global $SCENE_ROOM_NAME; $exclusionCondition = ''; if (count($excludedRanges) > 0) { $exclusions = []; foreach ($excludedRanges as $range) { $exclusions[] = "NOT (payment_time >= '" . $conn->real_escape_string($range['start']) . "' AND payment_time <= '" . $conn->real_escape_string($range['end']) . "')"; } $exclusionCondition = ' AND (' . implode(' AND ', $exclusions) . ')'; } $roomStats = []; $roomQuery = "
        SELECT payment_method_id, 
               SUM(CASE WHEN payment_type = 2 THEN extra_fee ELSE amount END) as total
        FROM orders_payment_details
        WHERE operator_id = ?
        AND payment_time >= ?
        AND payment_time <= ?
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionCondition
        GROUP BY payment_method_id
    "; $stmt = $conn->prepare($roomQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $roomStats[$row['payment_method_id']] = floatval($row['total']); } $exclusionConditionForCreate = ''; if (count($excludedRanges) > 0) { $exclusions = []; foreach ($excludedRanges as $range) { $exclusions[] = "NOT (create_time >= '" . $conn->real_escape_string($range['start']) . "' AND create_time <= '" . $conn->real_escape_string($range['end']) . "')"; } $exclusionConditionForCreate = ' AND (' . implode(' AND ', $exclusions) . ')'; } $promotionStats = []; $promotionQuery = "
        SELECT promotion_data
        FROM orders_payment_details
        WHERE operator_id = ?
        AND payment_time >= ?
        AND payment_time <= ?
        AND promotion_data IS NOT NULL
        $exclusionCondition
    "; $stmt = $conn->prepare($promotionQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $promotionData = json_decode($row['promotion_data'], true); if (is_array($promotionData)) { foreach ($promotionData as $promo) { if (isset($promo['id']) && isset($promo['quantity'])) { $promoId = intval($promo['id']); $quantity = intval($promo['quantity']); if (!isset($promotionStats[$promoId])) { $promotionStats[$promoId] = 0; } $promotionStats[$promoId] += $quantity; } } } } $productStats = []; $productQuery = "
        SELECT payment_method_id, SUM(total_amount) as total
        FROM product_orders
        WHERE operator_id = ?
        AND create_time >= ?
        AND create_time <= ?
        AND is_refunded = 0
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionConditionForCreate
        GROUP BY payment_method_id
    "; $stmt = $conn->prepare($productQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $productStats[$row['payment_method_id']] = floatval($row['total']); } $memberStats = []; $memberQuery = "
        SELECT payment_method_id, SUM(recharge_amount) as total
        FROM member_recharges
        WHERE operator_id = ?
        AND create_time >= ?
        AND create_time <= ?
        AND payment_method_id NOT IN (1, 88, 89, 2)
        $exclusionConditionForCreate
        GROUP BY payment_method_id
    "; $stmt = $conn->prepare($memberQuery); $stmt->bind_param('iss', $operatorId, $startTime, $endTime); $stmt->execute(); $result = $stmt->get_result(); while ($row = $result->fetch_assoc()) { $memberStats[$row['payment_method_id']] = floatval($row['total']); } return [ 'room' => ['name' => $SCENE_ROOM_NAME, 'stats' => $roomStats], 'promotion' => ['name' => '套餐', 'stats' => $promotionStats], 'product' => ['name' => '商品', 'stats' => $productStats], 'member' => ['name' => '会员', 'stats' => $memberStats] ]; } function completeHandover($conn) { $input = json_decode(file_get_contents('php://input'), true); $operatorId = intval($input['operator_id'] ?? 0); $startTime = $input['start_time'] ?? ''; $endTime = $input['end_time'] ?? ''; $modulesData = $input['modules_data'] ?? []; $promotionData = $input['promotion_data'] ?? []; $notes = $input['notes'] ?? ''; if (mb_strlen($notes) > 200) { $notes = mb_substr($notes, 0, 200); } if ($operatorId <= 0) { throw new Exception('操作员ID无效'); } if (empty($startTime) || empty($endTime)) { throw new Exception('时间范围无效'); } $conn->begin_transaction(); try { $totalSystemAmount = 0; $totalActualAmount = 0; foreach ($modulesData as $module) { foreach ($module['payments'] as $payment) { $totalSystemAmount += floatval($payment['system_amount']); $totalActualAmount += floatval($payment['actual_amount']); } } $totalDiff = $totalActualAmount - $totalSystemAmount; $promotionSystemQty = 0; $promotionActualQty = 0; foreach ($promotionData as $promo) { $promotionSystemQty += intval($promo['system_qty']); $promotionActualQty += intval($promo['actual_qty']); } $promotionDiffQty = $promotionActualQty - $promotionSystemQty; $currentUserId = getCurrentOperatorId(); $insertQuery = "
            INSERT INTO shift_handovers 
            (operator_id, start_time, end_time, payment_stats, promotion_stats,
             total_system_amount, total_actual_amount, total_diff, 
             promotion_system_qty, promotion_actual_qty, promotion_diff_qty,
             notes, handover_by_user_id, create_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        "; $paymentStatsJson = json_encode($modulesData, JSON_UNESCAPED_UNICODE); $promotionStatsJson = !empty($promotionData) ? json_encode($promotionData, JSON_UNESCAPED_UNICODE) : null; $stmt = $conn->prepare($insertQuery); $stmt->bind_param( 'issssdddiiisi', $operatorId, $startTime, $endTime, $paymentStatsJson, $promotionStatsJson, $totalSystemAmount, $totalActualAmount, $totalDiff, $promotionSystemQty, $promotionActualQty, $promotionDiffQty, $notes, $currentUserId ); $stmt->execute(); $conn->commit(); echo json_encode([ 'success' => true, 'message' => '交接完成' ]); } catch (Exception $e) { $conn->rollback(); throw $e; } } function getHandoverHistory($conn) { $operatorId = intval($_GET['operator_id'] ?? 0); $startDate = $_GET['start_date'] ?? ''; $endDate = $_GET['end_date'] ?? ''; $page = intval($_GET['page'] ?? 1); $pageSize = intval($_GET['page_size'] ?? 20); if ($page < 1) $page = 1; if ($pageSize < 1 || $pageSize > 100) $pageSize = 20; $offset = ($page - 1) * $pageSize; $where = []; $params = []; $types = ''; if ($operatorId > 0) { $where[] = "sh.operator_id = ?"; $params[] = $operatorId; $types .= 'i'; } if ($startDate) { $where[] = "DATE(sh.create_time) >= ?"; $params[] = $startDate; $types .= 's'; } if ($endDate) { $where[] = "DATE(sh.create_time) <= ?"; $params[] = $endDate; $types .= 's'; } $whereClause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : ''; $countQuery = "SELECT COUNT(*) as total FROM shift_handovers sh $whereClause"; if (count($params) > 0) { $stmt = $conn->prepare($countQuery); $stmt->bind_param($types, ...$params); $stmt->execute(); $result = $stmt->get_result(); } else { $result = $conn->query($countQuery); } $total = $result->fetch_assoc()['total']; $dataQuery = "
        SELECT 
            sh.id,
            sh.operator_id,
            COALESCE(u.name, CONCAT('用户', sh.operator_id)) as operator_name,
            sh.start_time,
            sh.end_time,
            sh.total_system_amount,
            sh.total_actual_amount,
            sh.total_diff,
            sh.promotion_system_qty,
            sh.promotion_actual_qty,
            sh.promotion_diff_qty,
            sh.notes,
            sh.create_time,
            sh.payment_stats,
            sh.promotion_stats
        FROM shift_handovers sh
        LEFT JOIN system_users u ON sh.operator_id = u.id
        $whereClause
        ORDER BY sh.create_time DESC
        LIMIT ? OFFSET ?
    "; $dataParams = $params; $dataParams[] = $pageSize; $dataParams[] = $offset; $dataTypes = $types . 'ii'; $stmt = $conn->prepare($dataQuery); $stmt->bind_param($dataTypes, ...$dataParams); $stmt->execute(); $result = $stmt->get_result(); $records = []; while ($row = $result->fetch_assoc()) { $row['payment_stats'] = json_decode($row['payment_stats'], true); $row['promotion_stats'] = $row['promotion_stats'] ? json_decode($row['promotion_stats'], true) : []; $records[] = $row; } echo json_encode([ 'success' => true, 'data' => [ 'records' => $records, 'total' => $total, 'page' => $page, 'page_size' => $pageSize, 'total_pages' => ceil($total / $pageSize) ] ]); } 