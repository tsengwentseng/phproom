<?php header("Cache-Control: public, max-age=86400");
header("Expires: " . gmdate("D, d M Y H:i:s", time() + 86400) . " GMT");
require_once "config/auth.php";
if (isset($_GET["logout"])) {
    $logoutType = $_GET["logout"] ?? "";
    logoutUser($logoutType);
    if (
        !empty($_SERVER["HTTP_X_REQUESTED_WITH"]) &&
        strtolower($_SERVER["HTTP_X_REQUESTED_WITH"]) === "xmlhttprequest"
    ) {
        header("Content-Type: application/json");
        echo json_encode(["success" => true]);
        exit();
    }
    header("Location: index.php");
    exit();
}
$siteTitle = "包间管理系统";
if (isset($conn) && $conn instanceof mysqli) {
    $stmt = $conn->prepare(
        "SELECT config_value FROM system_config WHERE config_key = 'site_title' LIMIT 1",
    );
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $siteTitle = $row["config_value"] ?? $siteTitle;
        }
        $stmt->close();
    }
}
requireFrontAuthentication("系统登录", SESSION_TIMEOUT_FRONT);
?><!doctypehtml><html lang="zh-CN"><head><meta charset="UTF-8"><title><?= htmlspecialchars(
    $siteTitle,
) ?></title><meta content="width=device-width,initial-scale=1"name="viewport"><link href="/asset/lib/css/bootstrap.min.css?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/lib/css/bootstrap.min.css",
) ?>"rel="stylesheet"><link href="/asset/lib/css/all.min.css?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/lib/css/all.min.css",
) ?>"rel="stylesheet"><style>body,html{height:100%;margin:0;padding:0;overflow:hidden}#mainIframe{width:100%;height:100%;border:none;position:absolute;top:0;left:0;z-index:1}.window-container{display:none;position:fixed;top:10%;left:15%;width:70%;height:80%;background-color:#fff;border-radius:5px;box-shadow:0 5px 15px rgba(0,0,0,.3);z-index:1000;overflow:hidden;display:flex;flex-direction:column;transform:translate3d(0,0,0);will-change:transform;backface-visibility:hidden;transition:box-shadow .2s}.window-header{display:flex;justify-content:space-between;align-items:center;background-color:#0056b3;padding:8px 15px;border-bottom:1px solid #212529;cursor:default;user-select:none;-webkit-touch-callout:none;-webkit-user-select:none}.dragging{box-shadow:0 8px 25px rgba(0,0,0,.5)}.window-title{font-weight:700;margin:0;font-size:16px;color:#fff}.window-controls{display:flex}.window-control{width:24px;height:24px;margin-left:15px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;color:#fff;background-color:transparent}.window-control:hover{filter:brightness(1.1);transform:scale(1.05);color:#007bff;background-color:transparent}.window-close:hover{color:#dc3545}.window-iframe{flex:1;border:none;width:100%;height:100%;display:block}.window-minimized{position:fixed;bottom:20px;left:auto;width:100px;height:40px;background-color:#f8f9fa;border-radius:5px;box-shadow:0 2px 10px rgba(0,0,0,.2);z-index:1000;overflow:hidden;cursor:pointer;display:flex;align-items:center;justify-content:space-between;padding:0 10px;margin-right:10px;transform:translate3d(0,0,0)}.window-minimized.active{background-color:#0056b3;color:#fff}.window-minimized-title{font-size:14px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.window-minimized i{margin-right:10px}.window-minimized-close{display:none;position:absolute;top:0;right:0;width:20px;height:20px;line-height:18px;text-align:center;font-size:18px;font-weight:700;color:#f44;cursor:pointer;border-radius:50%;background-color:transparent;transition:all .2s ease}.window-minimized-close:hover{color:#fff;background-color:#f44}.window-minimized:hover .window-minimized-close{display:block}.window-maximized{top:0!important;left:0!important;width:100%!important;height:100%!important;border-radius:0}.modal-backdrop{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(0,0,0,.5);z-index:999;display:none}[data-action]{cursor:pointer!important}#minimizedContainer{position:fixed;bottom:10px;left:10px;z-index:2000}@media (max-width:1366px){.window-minimized{width:50px;height:50px;padding:0;justify-content:center;margin-bottom:10px;position:relative;bottom:auto!important;left:auto!important}.window-minimized .window-minimized-title{display:none}.window-minimized i{margin-right:0!important;font-size:16px!important}.window-minimized-close{top:0;right:0;width:18px;height:18px;line-height:16px;font-size:16px}#minimizedContainer{display:flex;flex-direction:column-reverse}}</style></head><body><iframe src="config/room.php"id="mainIframe"></iframe><div class="modal-backdrop"></div><div class="window-container"id="handoverWindow"style="display:none"><div class="window-header"><h5 class="window-title">交班管理</h5><div class="window-controls"><div class="window-control window-minimize"data-window="handoverWindow"><i class="fa-xxs fas fa-window-minimize"></i></div><div class="window-control window-maximize"data-window="handoverWindow"><i class="fa-xxs fas fa-window-maximize"></i></div><div class="window-control window-close"data-window="handoverWindow"><i class="fa-xxs fas fa-times"></i></div></div></div><iframe src=""class="window-iframe"></iframe></div><div class="window-container"id="reportWindow"style="display:none"><div class="window-header"><h5 class="window-title">报表查询</h5><div class="window-controls"><div class="window-control window-minimize"data-window="reportWindow"><i class="fa-xxs fas fa-window-minimize"></i></div><div class="window-control window-maximize"data-window="reportWindow"><i class="fa-xxs fas fa-window-maximize"></i></div><div class="window-control window-close"data-window="reportWindow"><i class="fa-xxs fas fa-times"></i></div></div></div><iframe src=""class="window-iframe"></iframe></div><div class="window-container"id="adminWindow"style="display:none"><div class="window-header"><h5 class="window-title">后台管理</h5><div class="window-controls"><div class="window-control window-minimize"data-window="adminWindow"><i class="fa-xxs fas fa-window-minimize"></i></div><div class="window-control window-maximize"data-window="adminWindow"><i class="fa-xxs fas fa-window-maximize"></i></div><div class="window-control window-close"data-window="adminWindow"><i class="fa-xxs fas fa-times"></i></div></div></div><iframe src=""class="window-iframe"></iframe></div><div class="window-container"id="printWindow"style="display:none"><div class="window-header"><h5 class="window-title">打印小票</h5><div class="window-controls"><div class="window-control window-minimize"data-window="printWindow"><i class="fa-xxs fas fa-window-minimize"></i></div><div class="window-control window-maximize"data-window="printWindow"><i class="fa-xxs fas fa-window-maximize"></i></div><div class="window-control window-close"data-window="printWindow"><i class="fa-xxs fas fa-times"></i></div></div></div><iframe src=""class="window-iframe"></iframe></div><div id="minimizedContainer"></div><script src="/asset/lib/js/jquery.min.js?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/lib/js/jquery.min.js",
) ?>"></script><script src="/asset/lib/js/bootstrap.min.js?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/lib/js/bootstrap.min.js",
) ?>"></script><script>var isFrontendUser=<?= isset(
    $_SESSION["front_loggedin"],
) && !isset($_SESSION["admin_loggedin"])
    ? "true"
    : "false" ?></script><script src="/asset/iframe.js?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/iframe.js",
) ?>"></script><script src="/asset/core.js?v=<?= filemtime(
    $_SERVER["DOCUMENT_ROOT"] . "/asset/core.js",
) ?>"></script></body></html>
